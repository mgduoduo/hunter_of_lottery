package com.payegis.tscsecurid.rest.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.payegis.tscsecurid.common.data.entity.BindingInstructions;
import com.payegis.tscsecurid.common.mapper.BindingInstructionsMapper;
import com.payegis.tscsecurid.rest.service.BindInstructionsService;

@Service
public class BindInstructionsServiceImpl implements BindInstructionsService{
	
	@Autowired
	private BindingInstructionsMapper mapper;

	@Override
	public List<BindingInstructions> selectByDeviceId(String deviceId) {
		return mapper.selectByDeviceId(deviceId);
	}

	@Override
	public BindingInstructions selectById(Integer id) {
		return mapper.selectByPrimaryKey(id);
	}

	@Override
	public void updateByRecord(BindingInstructions record) {
		mapper.updateByPrimaryKey(record);
	}

	@Override
	public void saveByRecord(BindingInstructions record) {
		mapper.insert(record);
	}

	@Override
	public void updateByRecords(List<BindingInstructions> records) {
		for (BindingInstructions bindingInstructions : records) {
			bindingInstructions.setIsDo("Y");
			updateByRecord(bindingInstructions);
		}
	}

}
