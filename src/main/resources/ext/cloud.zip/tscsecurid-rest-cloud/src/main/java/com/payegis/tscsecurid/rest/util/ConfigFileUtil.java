package com.payegis.tscsecurid.rest.util;

import org.apache.commons.configuration.Configuration;
import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.ConfigurationFactory;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import java.io.File;
import java.io.IOException;
import java.io.StringReader;
import java.util.Properties;

@Component
public class ConfigFileUtil {
	
	protected final static Logger logger = Logger.getLogger(ConfigFileUtil.class);

	private static Configuration config = null;
	
	private static long lastModifyTime = 0l;

    private static String configFilePath =  "/tscsecurid-api-deploy.properties";

	public static void getConfig(){
		try{
            if (config == null) {
				lastModifyTime = new File(configFilePath).lastModified();
				loadConfig(configFilePath);
			}else{
				if(getReload()){
					long nowLastModifyTime=new File(configFilePath).lastModified();
					if(nowLastModifyTime!=lastModifyTime){
						logger.info("检测到配置文件有变动,重新加载配置文件");
						loadConfig(configFilePath);
						lastModifyTime=nowLastModifyTime;
					}
				}
			}
		}catch (ConfigurationException e){
			logger.error(e.getMessage());
		}
	}
	
	private static void loadConfig(String configFilePath) throws ConfigurationException{
		System.setProperty("config.file", configFilePath);
		ConfigurationFactory factory = new ConfigurationFactory("tscsecurid-api.xml");
		config = factory.getConfiguration();
	}
	
	public static Boolean getReload(){
		if(config==null){
			return true;
		}else{
			return config.getBoolean("config.reload",true);
		}
	}

	public static void setConfig(String message){
		getConfig();
		Properties pro = new Properties();
		try {
			pro.load(new StringReader(message));
		} catch (IOException e) {
			logger.error(e.getMessage());
		}
		for(Object t:pro.keySet()){
			config.clearProperty(t.toString());
			config.addProperty(t.toString(), pro.getProperty(t.toString()));
		}  
	}
	public static String getAppConfig(){
		getConfig();
		return config.getString("app.config");
	}
	public static String getPhoneNo(){
		getConfig();
		return config.getString("phone.no");
	}
	public static String getDownLoadHeadUrl(){
		getConfig();
		return config.getString("download.url.head");
	}

}
