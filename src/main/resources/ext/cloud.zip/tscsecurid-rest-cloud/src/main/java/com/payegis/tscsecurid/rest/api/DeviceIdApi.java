package com.payegis.tscsecurid.rest.api;

import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

import net.sf.json.JSONObject;

import org.springframework.stereotype.Component;

import com.payegis.caesar.sdk.device.InternalDeviceId;
import com.payegis.tscsecurid.rest.util.Base64;

@Component
@Path("/rest/device")
public class DeviceIdApi {
	
	/**
	 * 生成did
	 * @return
	 */
	@POST
	@Path("/deviceId")
	@Produces("application/json;charset=utf-8")
	public String getDid(@FormParam("fp")String fp ){
		String did = InternalDeviceId.makeId();
		String param = new String(Base64.decode(fp,Base64.DEFAULT));
		String[] params = param.split("&");
		String osType = "";
		for (String string : params) {
			if(string.startsWith("app-type")){
				osType = string.split("=")[1];
			}
		}
		if("ios".equals(osType)){
			did = "2" + did;
		}
		if("android".equals(osType)){
			did = "3" + did;
		}
		if("winphone".equals(osType)){
			did = "4" + did;
		}
		JSONObject json = new JSONObject();
		json.put("status", 1);
		json.put("errorMessage", "");
		json.put("deviceId", did);
		json.put("uuid", "");
		return json.toString();
	}
    

}
