package com.payegis.tscsecurid.rest.service;

import com.payegis.tscsecurid.common.data.entity.FeedbackInfo;

public interface FeedBackService {
	void saveFeedBack(FeedbackInfo feedBackInfo);
}
