package com.payegis.tscsecurid.rest.api;

import com.payegis.tscsecurid.common.data.entity.BindingTerminal;
import com.payegis.tscsecurid.common.data.entity.BusinessSystem;
import com.payegis.tscsecurid.common.util.DateUtil;
import com.payegis.tscsecurid.rest.common.Constrants;
import com.payegis.tscsecurid.rest.service.AccountService;
import com.payegis.tscsecurid.rest.service.PatternLockService;
import com.payegis.tscsecurid.rest.util.StringUtil;
import com.payegis.tscsecurid.rest.util.Validator;
import net.sf.json.JSONObject;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import java.util.HashMap;
import java.util.Map;

/**
 * 手势密码接口
 * @author user
 *
 */
@Component
@Path("/lock")
public class PatternLockApi {
	
	@Autowired
	private PatternLockService patternLockService;

	@Autowired
	private AccountService accountService;

	/**
	 * 是否设置手势密码
	 * @param deviceId
	 * @return
	 */
	@POST
	@Path("/isSet")
	@Produces("application/json;charset=utf-8")
	public String isSetLock(@FormParam(Constrants.DEVICE_ID)String deviceId){
		Map<String,String> map = new HashMap<String, String>();
		map.put(Constrants.DEVICE_ID, deviceId);
		if(!Validator.validArgs(map)){
			StringUtil.jsonExceptionMsg(Constrants.ARGU_ERROR_STATUS, Constrants.ARGU_ERROR_DESC);
		}
		BindingTerminal bindingTerminal = patternLockService.findById(deviceId);
		if(null != bindingTerminal && StringUtils.isNotBlank(bindingTerminal.getDevicePassword())){
			return StringUtil.jsonSuccessMsg(Constrants.SUCCESS);
		}
		return StringUtil.jsonExceptionMsg(1, "没有设置手势密码");
	}
	
	/**
	 * 设置手势密码
	 * @param deviceId
	 * @param osType
	 * @param phoneNo
	 * @param devicePassword
	 * @return
	 */
	@POST
	@Path("/set")
	@Produces("application/json;charset=utf-8")
	public String setLock(@FormParam(Constrants.DEVICE_ID)String deviceId,@FormParam(Constrants.OS_TYPE) String osType,
			@FormParam(Constrants.PHONE_NO) String phoneNo,@FormParam(Constrants.DEVICE_PASSWORD) String devicePassword,
			@FormParam(Constrants.ALIAS) String alias,@FormParam(Constrants.SYSTEM_NO)String systemNo){
        System.out.println("systemNo:"+systemNo);
        Map<String,String> map = new HashMap<String, String>();
        map.put(Constrants.DEVICE_ID, deviceId);
        //map.put(Constrants.OS_TYPE, osType);
        //map.put(Constrants.DEVICE_PASSWORD, devicePassword);
		if(!Validator.validArgs(map)){
			return StringUtil.jsonExceptionMsg(Constrants.ARGU_ERROR_STATUS, Constrants.ARGU_ERROR_DESC);
		}
		if(StringUtils.isNotBlank(systemNo)){
			BusinessSystem businessSystem = accountService.selectBySystemNo(systemNo);
			if (null == businessSystem) {
				return StringUtil.jsonExceptionMsg(Constrants.BUSINESSNO_ERROR_STATUS, Constrants.BUSINESSNO_ERROR_DESC);
			}
		}
		Map<String, Object> param = new HashMap<String, Object>();
		param.put(Constrants.DEVICE_ID,deviceId);
		if(StringUtils.isNotBlank(systemNo))
            param.put(Constrants.SYSTEM_NO,systemNo);
		BindingTerminal bindingTerminal = patternLockService.findBindingTerminal(param);
        System.out.println("bindingTerminal:"+bindingTerminal==null);
		if(null == bindingTerminal){
			bindingTerminal = new BindingTerminal();
			bindingTerminal.setDeviceId(deviceId);
			bindingTerminal.setDeviceMobile(phoneNo);
            if(StringUtils.isEmpty(devicePassword))
                devicePassword = "0,1,3,4";
			bindingTerminal.setDevicePassword(devicePassword);
			bindingTerminal.setOsType(osType);
            bindingTerminal.setAlias(alias);
			bindingTerminal.setRegisterTime(DateUtil.getCurrentDateString());
            bindingTerminal.setTimes("0");
            bindingTerminal.setSystemNo(systemNo);
			bindingTerminal.setUnlockTime(DateUtil.getCurrentDateString("yyyy-MM-dd"));
			patternLockService.saveLock(bindingTerminal);
		}else{
            if(StringUtils.isNotEmpty(devicePassword))
			    bindingTerminal.setDevicePassword(devicePassword);
			bindingTerminal.setRegisterTime(DateUtil.getCurrentDateString());
			bindingTerminal.setTimes("0");
            bindingTerminal.setUnlockTime(DateUtil.getCurrentDateString("yyyy-MM-dd"));
            if(StringUtils.isNotEmpty(alias))
                bindingTerminal.setAlias(alias);
			bindingTerminal.setSystemNo(systemNo);
			patternLockService.updateLock(bindingTerminal);
		}
		return StringUtil.jsonSuccessMsg(Constrants.SUCCESS);
	}

    @POST
    @Path("/setLock")
    @Produces("application/json;charset=utf-8")
    public String setLock0(@FormParam(Constrants.DEVICE_ID)String deviceId,@FormParam(Constrants.OS_TYPE) String osType,
                          @FormParam(Constrants.PHONE_NO) String phoneNo,@FormParam(Constrants.DEVICE_PASSWORD) String devicePassword){
        Map<String,String> map = new HashMap<String, String>();
        map.put(Constrants.DEVICE_ID, deviceId);
        map.put(Constrants.OS_TYPE, osType);
        map.put(Constrants.DEVICE_PASSWORD, devicePassword);
        BindingTerminal bindingTerminal = patternLockService.findById(deviceId);
        if(null == bindingTerminal){
            bindingTerminal = new BindingTerminal();
            bindingTerminal.setDeviceId(deviceId);
            bindingTerminal.setDeviceMobile(phoneNo);
            bindingTerminal.setDevicePassword(devicePassword);
            bindingTerminal.setOsType(osType);
            bindingTerminal.setRegisterTime(DateUtil.getCurrentDateString());
            bindingTerminal.setTimes("0");
            bindingTerminal.setUnlockTime(DateUtil.getCurrentDateString("yyyy-MM-dd"));
            bindingTerminal.setAlias("我的微信设备");
            patternLockService.saveLock(bindingTerminal);
        }else{
            bindingTerminal.setDevicePassword(devicePassword);
            bindingTerminal.setRegisterTime(DateUtil.getCurrentDateString());
            bindingTerminal.setTimes("0");
            bindingTerminal.setUnlockTime(DateUtil.getCurrentDateString("yyyy-MM-dd"));
            patternLockService.updateLock(bindingTerminal);
        }
        return StringUtil.jsonSuccessMsg(Constrants.SUCCESS);
    }
	/**
	 *检查手势密码 
	 * @param deviceId
	 * @param devicePassword
	 * @return
	 */
	@POST
	@Path("/check")
	@Produces("application/json;charset=utf-8")
	public String checkLock(@FormParam(Constrants.DEVICE_ID)String deviceId,@FormParam(Constrants.DEVICE_PASSWORD) String devicePassword){
		Map<String,String> map = new HashMap<String, String>();
		map.put(Constrants.DEVICE_ID, deviceId);
		map.put(Constrants.DEVICE_PASSWORD, devicePassword);
		if(!Validator.validArgs(map)){
			StringUtil.jsonExceptionMsg(Constrants.ARGU_ERROR_STATUS, Constrants.ARGU_ERROR_DESC);
		}
		BindingTerminal bindingTerminal = patternLockService.findById(deviceId);
		if(null == bindingTerminal){
			return StringUtil.jsonExceptionMsg(Constrants.FAIL_STATUS, "对不起，您还没有设置手势密码");
		}
		if("5".equals(bindingTerminal.getTimes()) && bindingTerminal.getUnlockTime().equals(DateUtil.getCurrentDateString("yyyy-MM-dd"))){
			return StringUtil.jsonExceptionMsg(2, "手势密码已经连续输错5次，该设备已经锁定，请联系客服");
		}
		if(devicePassword.equals(bindingTerminal.getDevicePassword())){
			bindingTerminal.setActivityTime(DateUtil.getCurrentDateString());
			bindingTerminal.setTimes("0");
            bindingTerminal.setUnlockTime(DateUtil.getCurrentDateString("yyyy-MM-dd"));
			patternLockService.updateLock(bindingTerminal);
			return StringUtil.jsonSuccessMsg(Constrants.SUCCESS);
		}
        String times = bindingTerminal.getTimes();
        if(!bindingTerminal.getUnlockTime().equals(DateUtil.getCurrentDateString("yyyy-MM-dd")) || StringUtil.isBlank(times))
            times = "0";
        bindingTerminal.setTimes((Integer.parseInt(times)+1)+"");
        bindingTerminal.setUnlockTime(DateUtil.getCurrentDateString("yyyy-MM-dd"));
        patternLockService.updateLock(bindingTerminal);
		JSONObject json = new JSONObject();
		json.put("times", bindingTerminal.getTimes());
		return StringUtil.jsonSuccessData(Constrants.FAIL_STATUS, Constrants.FAIL,json );
	}
	

}
