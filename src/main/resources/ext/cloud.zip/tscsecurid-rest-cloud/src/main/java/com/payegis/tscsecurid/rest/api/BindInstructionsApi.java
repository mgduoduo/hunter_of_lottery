package com.payegis.tscsecurid.rest.api;

import com.payegis.tscsecurid.common.data.entity.BindingInstructions;
import com.payegis.tscsecurid.common.util.DateUtil;
import com.payegis.tscsecurid.rest.common.Constrants;
import com.payegis.tscsecurid.rest.service.BindInstructionsService;
import com.payegis.tscsecurid.rest.util.StringUtil;
import com.payegis.tscsecurid.rest.util.Validator;
import net.sf.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


@Component
@Path("/instructions")
public class BindInstructionsApi {
	
	@Autowired
	private BindInstructionsService service;

	@POST
	@Path("/list")
	@Produces("application/json;charset=utf-8")
	public String  list(@FormParam(Constrants.DEVICE_ID) String deviceId){
		Map<String,String> map = new HashMap<String, String>();
		map.put(Constrants.DEVICE_ID, deviceId);
		if(!Validator.validArgs(map)){
			return StringUtil.jsonExceptionMsg(Constrants.ARGU_ERROR_STATUS, Constrants.ARGU_ERROR_DESC);
		}
		List<BindingInstructions> bindInstructions = service.selectByDeviceId(deviceId);
		JSONObject json = new JSONObject();
		json.put("bindInstructions", bindInstructions);
		service.updateByRecords(bindInstructions);
		return StringUtil.jsonSuccessData(json);
	}
	
	@POST
	@Path("/read")
	@Produces("application/json;charset=utf-8")
	public String  read(@FormParam(Constrants.INSTRUCTIONS_ID) String instructionsId){
		Map<String,String> map = new HashMap<String, String>();
		map.put(Constrants.INSTRUCTIONS_ID, instructionsId);
		if(!Validator.validArgs(map)){
			return StringUtil.jsonExceptionMsg(Constrants.ARGU_ERROR_STATUS, Constrants.ARGU_ERROR_DESC);
		}
		BindingInstructions bindInstructions = service.selectById(Integer.parseInt(instructionsId));
		if(null == bindInstructions){
			return StringUtil.jsonExceptionMsg(1, "系统没有此指令");
		}
		bindInstructions.setIsDo("Y");
		service.updateByRecord(bindInstructions);
		return StringUtil.jsonSuccessData(Constrants.SUCCESS);
	}
	@POST
	@Path("/save")
	@Produces("application/json;charset=utf-8")
	public String  save(@FormParam(Constrants.DEVICE_ID) String deviceId,@FormParam(Constrants.SYSTEM_NO) String systemNo,@FormParam(Constrants.SYSTEM_NAME) String systemName,@FormParam(Constrants.SYSTEM_ACCOUNT) String systemAccount,@FormParam(Constrants.FROM) String from,@FormParam(Constrants.INSTRUCTIONS_TYPE) String instructionsType,@FormParam(Constrants.MESSAGE) String message,@FormParam(Constrants.DEVICE_NAME) String deviceName,@FormParam(Constrants.CLIENT_IP) String clientIp,@FormParam(Constrants.MSG_ID) String msgId){
		Map<String,String> map = new HashMap<String, String>();
		map.put(Constrants.DEVICE_ID, deviceId);
		map.put(Constrants.SYSTEM_NO, systemNo);
		map.put(Constrants.SYSTEM_ACCOUNT, systemAccount);
		//map.put(Constrants.FROM, from);
		map.put(Constrants.INSTRUCTIONS_TYPE, instructionsType);
		if(!Validator.validArgs(map)){
			return StringUtil.jsonExceptionMsg(Constrants.ARGU_ERROR_STATUS, Constrants.ARGU_ERROR_DESC);
		}
		BindingInstructions bindInstructions = new BindingInstructions();
		bindInstructions.setDeviceId(deviceId);
		bindInstructions.setInstructionsType(instructionsType);
		bindInstructions.setIsDo("N");
		bindInstructions.setSystemAccount(systemAccount);
		bindInstructions.setSystemNo(systemNo);
		bindInstructions.setCreateTime(DateUtil.getCurrentDateString());
		bindInstructions.setOrigin(from);
        bindInstructions.setMessage(message);
        bindInstructions.setDeviceName(deviceName);
        bindInstructions.setSystemName(systemName);
        bindInstructions.setTransactionId(msgId);
        bindInstructions.setClientIp(clientIp);
		service.saveByRecord(bindInstructions);
		return StringUtil.jsonSuccessData(Constrants.SUCCESS);
	}
}
