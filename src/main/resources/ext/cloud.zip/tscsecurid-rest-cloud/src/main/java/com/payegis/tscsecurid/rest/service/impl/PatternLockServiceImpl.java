package com.payegis.tscsecurid.rest.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.payegis.tscsecurid.common.data.entity.BindingTerminal;
import com.payegis.tscsecurid.common.mapper.BindingTerminalMapper;
import com.payegis.tscsecurid.rest.service.PatternLockService;

import java.util.Map;


@Service
public class PatternLockServiceImpl implements PatternLockService{
	
	@Autowired
	private BindingTerminalMapper bindingTerminalMapper;

	@Override
	public void saveLock(BindingTerminal bindingTerminal) {
		bindingTerminalMapper.insert(bindingTerminal);
	}

	@Override
	public BindingTerminal findById(String deviceId) {
		return bindingTerminalMapper.selectByPrimaryKey(deviceId);
	}

	@Override
	public BindingTerminal findBindingTerminal(Map<String, Object> param) {
		return bindingTerminalMapper.selectBindingTerminal(param);
	}

	@Override
	public void updateLock(BindingTerminal bindingTerminal) {
		bindingTerminalMapper.updateByPrimaryKey(bindingTerminal);
	}

	@Override
	public void deleteById(String deviceId) {
		bindingTerminalMapper.deleteByPrimaryKey(deviceId);
	}


}
