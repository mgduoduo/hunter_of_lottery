package com.payegis.tscsecurid.rest.service;

import com.payegis.tscsecurid.common.data.entity.BusinessSystem;

public interface AccountService {
	BusinessSystem selectBySystemNo(String systemNo);
}
