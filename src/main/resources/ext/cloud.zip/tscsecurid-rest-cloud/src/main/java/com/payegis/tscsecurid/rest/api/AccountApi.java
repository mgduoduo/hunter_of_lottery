package com.payegis.tscsecurid.rest.api;

import com.payegis.tscsecurid.rest.util.ConfigFileUtil;
import com.payegis.tscsecurid.rest.util.StringUtil;
import org.springframework.stereotype.Component;

import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;


/**
 * 账户接口
 * @author user
 *
 */

@Component
@Path("/account")
public class AccountApi {
	
	/**
	 * 获取配置文件
	 * @return
	 */
    @POST
	@Path("/config")
	@Produces("application/json;charset=utf-8")
	public String sysConfig(){
		return StringUtil.jsonSuccessData(ConfigFileUtil.getAppConfig().replaceAll(";", ","));
	}
	
    
}
