package com.payegis.tscsecurid.rest.service;

import java.util.List;

import com.payegis.tscsecurid.common.data.entity.BindingTerminalPwdProtection;


public interface PasswordProtectService {
	void saveQuestions(String deviceId,String questionAnswers);
	BindingTerminalPwdProtection selectByDeviceIdAndQuestionOrder(String deviceId,Integer questionOrder);
	List<BindingTerminalPwdProtection> selectByDeviceId(String deviceId);
}
