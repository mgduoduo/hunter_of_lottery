package com.payegis.tscsecurid.rest.api;

import com.payegis.tscsecurid.common.data.bo.BindInfoDto;
import com.payegis.tscsecurid.common.data.entity.BindingInfoEnterprise;
import com.payegis.tscsecurid.common.data.entity.BindingLogEnterprise;
import com.payegis.tscsecurid.common.data.entity.BusinessSystem;
import com.payegis.tscsecurid.common.util.DateUtil;
import com.payegis.tscsecurid.rest.common.BindTypeEnum;
import com.payegis.tscsecurid.rest.common.Constrants;
import com.payegis.tscsecurid.rest.service.AccountService;
import com.payegis.tscsecurid.rest.service.BindInfoService;
import com.payegis.tscsecurid.rest.util.StringUtil;
import com.payegis.tscsecurid.rest.util.Validator;
import net.sf.json.JSONObject;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
@Path("/bindinfo")
public class BindInfoApi {
	
	@Autowired
	private BindInfoService bindInfoService;

	@Autowired
	private AccountService accountService;

	@POST
	@Path("/save")
	@Produces("application/json;charset=utf-8")
	public String saveBindinfo(@FormParam(Constrants.DEVICE_ID) String deviceId,@FormParam(Constrants.SYSTEM_NO) String systemNo,@FormParam(Constrants.SYSTEM_LOGO_URL) String systemLogoUrl,@FormParam(Constrants.SYSTEM_ACCOUNT)String systemAccount,@FormParam(Constrants.SYSTEM_URL)String systemUrl,@FormParam(Constrants.SYSTEM_NAME) String systemName,@FormParam(Constrants.BUSINESS_TYPE) String businessType,@FormParam(Constrants.ENTERPRISE_NAME) String enterpriseName,@FormParam(Constrants.IS_DEFAULT) String isDefault){
		Map<String,String> map = new HashMap<String, String>();
		map.put(Constrants.DEVICE_ID, deviceId);
		map.put(Constrants.SYSTEM_NO, systemNo);
		map.put(Constrants.SYSTEM_LOGO_URL, systemLogoUrl);
		map.put(Constrants.SYSTEM_ACCOUNT, systemAccount);
		map.put(Constrants.SYSTEM_URL, systemUrl);
		map.put(Constrants.SYSTEM_NAME, systemName);
		map.put(Constrants.BUSINESS_TYPE, businessType);
		//map.put(Constrants.ENTERPRISE_NAME, enterpriseName);
		if(!Validator.validArgs(map)){
			return StringUtil.jsonExceptionMsg(Constrants.ARGU_ERROR_STATUS, Constrants.ARGU_ERROR_DESC);
		}
		BindingInfoEnterprise bindInfo = bindInfoService.selectByDeviceIdAndSystemNoAndSystemAccount(deviceId, systemNo, systemAccount);
		if(null != bindInfo){
			//return StringUtil.jsonExceptionMsg(Constrants.FAIL_STATUS, Constrants.FAIL);
			bindInfo.setSystemLogoUrl(systemLogoUrl);
			bindInfo.setSystemUrl(systemUrl);
			bindInfo.setSystemName(systemName);
			bindInfo.setBusinessType(businessType);
			bindInfo.setEnterpriseName(enterpriseName);
			bindInfoService.updateBindInfo(bindInfo);
		}else{
			bindInfo = new BindingInfoEnterprise();
			bindInfo.setDeviceId(deviceId);
			bindInfo.setSystemAccount(systemAccount);
			bindInfo.setSystemLogoUrl(systemLogoUrl);
			bindInfo.setSystemNo(systemNo);
			bindInfo.setSystemUrl(systemUrl);
			bindInfo.setSystemName(systemName);
			bindInfo.setBindingTime(DateUtil.getCurrentDateString());
			bindInfo.setBusinessType(businessType);
			bindInfo.setEnterpriseName(enterpriseName);
			BindingLogEnterprise logInfo = new BindingLogEnterprise();
			logInfo.setBindingLogType(BindTypeEnum.BINDING.getCode());
			logInfo.setDeviceId(deviceId);
			logInfo.setEnterpriseName(enterpriseName);
			logInfo.setOperationTime(DateUtil.getCurrentDateString());
			logInfo.setSystemAccount(systemAccount);
			logInfo.setSystemName(systemName);
			logInfo.setSystemNo(systemNo);
			bindInfoService.saveBindInfo(bindInfo,logInfo);
		}
		return StringUtil.jsonSuccessMsg(Constrants.SUCCESS);
	}
	@POST
	@Path("/delete")
	@Produces("application/json;charset=utf-8")
	public String deleteBindinfo(@FormParam(Constrants.DEVICE_ID) String deviceId,@FormParam(Constrants.SYSTEM_ACCOUNT) String systemAccount,@FormParam(Constrants.SYSTEM_NO) String systemNo){
		Map<String,String> map = new HashMap<String, String>();
		map.put(Constrants.DEVICE_ID, deviceId);
		map.put(Constrants.SYSTEM_ACCOUNT, systemAccount);
		map.put(Constrants.SYSTEM_NO, systemNo);
		if(!Validator.validArgs(map)){
			return StringUtil.jsonExceptionMsg(Constrants.ARGU_ERROR_STATUS, Constrants.ARGU_ERROR_DESC);
		}
		BindingInfoEnterprise bindInfo = bindInfoService.selectByDeviceIdAndSystemNoAndSystemAccount(deviceId, systemNo, systemAccount);
		if(null == bindInfo){
			//return StringUtil.jsonExceptionMsg(Constrants.FAIL_STATUS, Constrants.FAIL);
			return StringUtil.jsonSuccessMsg(Constrants.SUCCESS);
		}
		BindingLogEnterprise logInfo = new BindingLogEnterprise();
		logInfo.setBindingLogType(BindTypeEnum.UNBINDING.getCode());
		logInfo.setDeviceId(deviceId);
		logInfo.setEnterpriseName(bindInfo.getEnterpriseName());
		logInfo.setOperationTime(DateUtil.getCurrentDateString());
		logInfo.setSystemAccount(systemAccount);
		logInfo.setSystemName(bindInfo.getSystemName());
		logInfo.setSystemNo(systemNo);
		bindInfoService.deleteBindInfo(bindInfo.getBingdingId(),logInfo);
		return StringUtil.jsonSuccessMsg(Constrants.SUCCESS);
	}
	@POST
	@Path("/update")
	@Produces("application/json;charset=utf-8")
	public String updateBindinfo(@FormParam(Constrants.DEVICE_ID) String deviceId,@FormParam(Constrants.SYSTEM_NO) String systemNo,@FormParam(Constrants.SYSTEM_LOGO_URL) String systemLogoUrl,@FormParam(Constrants.SYSTEM_ACCOUNT)String systemAccount,@FormParam(Constrants.SYSTEM_URL)String systemUrl,@FormParam(Constrants.SYSTEM_NAME) String systemName,@FormParam(Constrants.BUSINESS_TYPE) String businessType,@FormParam(Constrants.ENTERPRISE_NAME) String enterpriseName){
		Map<String,String> map = new HashMap<String, String>();
		map.put(Constrants.BIND_ID, deviceId);
		map.put(Constrants.SYSTEM_NO, systemNo);
		map.put(Constrants.SYSTEM_LOGO_URL, systemLogoUrl);
		map.put(Constrants.SYSTEM_ACCOUNT, systemAccount);
		map.put(Constrants.SYSTEM_URL, systemUrl);
		map.put(Constrants.SYSTEM_NAME, systemName);
		map.put(Constrants.BUSINESS_TYPE, businessType);
		map.put(Constrants.ENTERPRISE_NAME, enterpriseName);
		if(!Validator.validArgs(map)){
			return StringUtil.jsonExceptionMsg(Constrants.ARGU_ERROR_STATUS, Constrants.ARGU_ERROR_DESC);
		}
		BindingInfoEnterprise bindInfo = bindInfoService.selectByDeviceIdAndSystemNoAndSystemAccount(deviceId, systemNo, systemAccount);
		if(null == bindInfo){
			return StringUtil.jsonExceptionMsg(Constrants.FAIL_STATUS, Constrants.FAIL);
		}
		bindInfo.setSystemAccount(systemAccount);
		bindInfo.setSystemLogoUrl(systemLogoUrl);
		bindInfo.setSystemNo(systemNo);
		bindInfo.setSystemUrl(systemUrl);
		bindInfo.setSystemName(systemName);
		bindInfo.setEditTime(DateUtil.getCurrentDateString());
		bindInfo.setBusinessType(businessType);
		bindInfo.setEnterpriseName(enterpriseName);
		bindInfoService.updateBindInfo(bindInfo);
		return StringUtil.jsonSuccessMsg(Constrants.SUCCESS);
	}
    @POST
    @Path("/updateOnlineStatus")
    @Produces("application/json;charset=utf-8")
    public String updateOnlineStatus(@FormParam(Constrants.SYSTEM_NO) String systemNo,@FormParam(Constrants.SYSTEM_ACCOUNT)String systemAccount,@FormParam(Constrants.ONLINE_STATUS) String onlineStatus){
        Map<String,String> map = new HashMap<String, String>();
        map.put(Constrants.ONLINE_STATUS, onlineStatus);
        map.put(Constrants.SYSTEM_NO, systemNo);
        map.put(Constrants.SYSTEM_ACCOUNT, systemAccount);
        if(!Validator.validArgs(map)){
            return StringUtil.jsonExceptionMsg(Constrants.ARGU_ERROR_STATUS, Constrants.ARGU_ERROR_DESC);
        }
        BindingInfoEnterprise bindInfo = new BindingInfoEnterprise();
        bindInfo.setSystemAccount(systemAccount);
        bindInfo.setSystemNo(systemNo);
        bindInfo.setOnlineStatus(onlineStatus);
        bindInfo.setEditTime(DateUtil.getCurrentDateString());
        bindInfoService.updateBindInfoOlineStatus(bindInfo);
        return StringUtil.jsonSuccessMsg(Constrants.SUCCESS);
    }

	@POST
	@Path("/list")
	@Produces("application/json;charset=utf-8")
	public String listBindinfo(@FormParam(Constrants.DEVICE_ID) String deviceId, @FormParam(Constrants.SYSTEM_NO) String systemNo){
		Map<String,String> map = new HashMap<String, String>();
		map.put(Constrants.DEVICE_ID, deviceId);
		if(!Validator.validArgs(map)){
			return StringUtil.jsonExceptionMsg(Constrants.ARGU_ERROR_STATUS, Constrants.ARGU_ERROR_DESC);
		}
		if(StringUtils.isNotBlank(systemNo)){
			BusinessSystem businessSystem = accountService.selectBySystemNo(systemNo);
			if (null == businessSystem) {
				return StringUtil.jsonExceptionMsg(Constrants.BUSINESSNO_ERROR_STATUS, Constrants.BUSINESSNO_ERROR_DESC);
			}
		}
		Map<String, Object> param = new HashMap<String, Object>();
		param.put(Constrants.DEVICE_ID,deviceId);
		if(StringUtils.isNotBlank(systemNo)) param.put(Constrants.SYSTEM_NO,systemNo);
		List<BindInfoDto> bindInfos = bindInfoService.selectBindInfoList(param);
		JSONObject json = new JSONObject();
		json.put("bindInfos", bindInfos);
		return StringUtil.jsonSuccessData(json);
	}

	/** unused **/
    /*@POST
    @Path("/listByAccount")
    @Produces("application/json;charset=utf-8")
    public String listByAccount(@FormParam(Constrants.SYSTEM_ACCOUNT) String systemAccount,@FormParam(Constrants.SYSTEM_NO) String systemNo){
        Map<String,String> map = new HashMap<String, String>();
        map.put(Constrants.SYSTEM_ACCOUNT, systemAccount);
        map.put(Constrants.SYSTEM_NO, systemNo);
        if(!Validator.validArgs(map)){
            return StringUtil.jsonExceptionMsg(Constrants.ARGU_ERROR_STATUS, Constrants.ARGU_ERROR_DESC);
        }
        List<BindingInfoEnterprise> bindInfos = bindInfoService.selectBySystemAccountAndSystemNo(systemAccount,systemNo);
        JSONObject json = new JSONObject();
        json.put("bindInfos", bindInfos);
        return StringUtil.jsonSuccessData(json);
    }*/
	/** unused **/
}
