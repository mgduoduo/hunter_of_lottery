package com.payegis.tscsecurid.rest.api;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;


import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.payegis.tscsecurid.common.data.entity.BindingTerminal;
import com.payegis.tscsecurid.common.data.entity.BindingTerminalPwdProtection;
import com.payegis.tscsecurid.rest.common.Constrants;
import com.payegis.tscsecurid.rest.service.PasswordProtectService;
import com.payegis.tscsecurid.rest.service.PatternLockService;
import com.payegis.tscsecurid.rest.util.ConfigFileUtil;
import com.payegis.tscsecurid.rest.util.StringUtil;
import com.payegis.tscsecurid.rest.util.Validator;

/**
 * 密宝接口
 * @author user
 *
 */

@Component
@Path("/protect")
public class PasswordProtectApi {
	
	@Autowired
	private PasswordProtectService passwordProtectService;
	
	@Autowired
	private PatternLockService patternLockService;
	
	
	/**
	 * 是否设置密宝
	 * @param deviceId
	 * @param questionDispOrder
	 * @return
	 */
	@POST
	@Path("/isSet")
	@Produces("application/json;charset=utf-8")
	public String isSetProtect(@FormParam(Constrants.DEVICE_ID)String deviceId){
		Map<String,String> map = new HashMap<String, String>();
		map.put(Constrants.DEVICE_ID, deviceId);
		if(!Validator.validArgs(map)){
			return StringUtil.jsonExceptionMsg(Constrants.ARGU_ERROR_STATUS, Constrants.ARGU_ERROR_DESC);
		}
		List<BindingTerminalPwdProtection> protection = passwordProtectService.selectByDeviceId(deviceId);
		if(protection.size() == 0){
			return StringUtil.jsonSuccessData(Constrants.SUCCESS);
		}
		return StringUtil.jsonExceptionMsg(Constrants.FAIL_STATUS, Constrants.FAIL);
	}
	
	
	/**
	 * 设置密宝
	 * @param deviceId
	 * @param questionDispOrder
	 * @param questionAnswer
	 * @return
	 */
	@POST
	@Path("/set")
	@Produces("application/json;charset=utf-8")
	public String setProtect(@FormParam(Constrants.DEVICE_ID) String deviceId,@FormParam(Constrants.QUESTION_ANSWERS) String questionAnswers){
		Map<String,String> map = new HashMap<String, String>();
		map.put(Constrants.DEVICE_ID, deviceId);
		map.put(Constrants.QUESTION_ANSWERS, questionAnswers);
		if(!Validator.validArgs(map)){
			return StringUtil.jsonExceptionMsg(Constrants.ARGU_ERROR_STATUS, Constrants.ARGU_ERROR_DESC);
		}
		passwordProtectService.saveQuestions(deviceId, questionAnswers);
		return StringUtil.jsonSuccessMsg("密保问题设置成功");
	}
	/**
	 * 找回手势密码
	 * @param deviceId
	 * @param questionDispOrder
	 * @param questionAnswer
	 * @return
	 */
	@POST
	@Path("/findBack")
	@Produces("application/json;charset=utf-8")
	public String checkProtect(@FormParam(Constrants.DEVICE_ID)String deviceId,@FormParam(Constrants.QUESTION_ANSWERS) String questionAnswers){
		Map<String,String> map = new HashMap<String, String>();
		map.put(Constrants.DEVICE_ID, deviceId);
		map.put(Constrants.QUESTION_ANSWERS, questionAnswers);
		if(!Validator.validArgs(map)){
			return StringUtil.jsonExceptionMsg(Constrants.ARGU_ERROR_STATUS, Constrants.ARGU_ERROR_DESC);
		}
		JSONArray jsonArray = JSONArray.fromObject(questionAnswers);
		JSONObject json = null;
		BindingTerminalPwdProtection protection = null;
		for (int i = 0; i < jsonArray.size(); i++) {
			json = (JSONObject)jsonArray.get(i);
			if(null != json){
				protection = passwordProtectService.selectByDeviceIdAndQuestionOrder(deviceId, Integer.parseInt(json.getString("questionDispOrder")));
				if(!json.getString("questionAnswer").equals(protection.getQuestionAnswer())){
					return StringUtil.jsonExceptionMsg(Constrants.FAIL_STATUS, Constrants.FAIL);
				}
			}else{
				return StringUtil.jsonExceptionMsg(Constrants.FAIL_STATUS, Constrants.FAIL);
			}
		}
		BindingTerminal bindingTerminal  = patternLockService.findById(deviceId);
		bindingTerminal.setDevicePassword("");
		patternLockService.updateLock(bindingTerminal);
		return StringUtil.jsonSuccessMsg(Constrants.SUCCESS);
	}
	/**
	 * 查找客服电话
	 * @param deviceId
	 * @return
	 */
	@POST
	@Path("/queryPhone")
	@Produces("application/json;charset=utf-8")
	public String queryPhone(@FormParam(Constrants.DEVICE_ID)String deviceId){
		JSONObject json = new JSONObject();
		json.put("phoneNo", ConfigFileUtil.getPhoneNo());
		return StringUtil.jsonSuccessData(json);
	}
}
