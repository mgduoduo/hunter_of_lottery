package com.payegis.tscsecurid.rest.service.impl;

import com.payegis.tscsecurid.common.data.entity.BusinessSystem;
import com.payegis.tscsecurid.common.mapper.BusinessSystemMapper;
import com.payegis.tscsecurid.rest.service.AccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AccountServiceImpl implements AccountService {
	
    @Autowired
    private BusinessSystemMapper businessSystemMapper;

	@Override
	public BusinessSystem selectBySystemNo(String systemNo) {
		return businessSystemMapper.selectBySystemNo(systemNo);
	}
}
