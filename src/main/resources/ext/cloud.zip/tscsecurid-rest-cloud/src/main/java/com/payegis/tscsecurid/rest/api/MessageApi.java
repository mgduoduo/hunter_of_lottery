package com.payegis.tscsecurid.rest.api;

import java.util.HashMap;
import java.util.Map;

import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

import net.sf.json.JSONObject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.payegis.tscsecurid.common.data.entity.FeedbackInfo;
import com.payegis.tscsecurid.common.data.entity.VersionManage;
import com.payegis.tscsecurid.common.util.DateUtil;
import com.payegis.tscsecurid.rest.common.Constrants;
import com.payegis.tscsecurid.rest.common.FeedbackTypeEnum;
import com.payegis.tscsecurid.rest.service.FeedBackService;
import com.payegis.tscsecurid.rest.service.MessageService;
import com.payegis.tscsecurid.rest.util.ConfigFileUtil;
import com.payegis.tscsecurid.rest.util.StringUtil;
import com.payegis.tscsecurid.rest.util.Validator;

/**
 * 消息接口
 * @author user
 *
 */
@Component
@Path("/message")
public class MessageApi {
	
	@Autowired
	private MessageService messageService;
	
	@Autowired
	private FeedBackService feedBackService;
	
	@POST
	@Path("/check")
	@Produces("application/json;charset=utf-8")
	public String update(@FormParam(Constrants.VERSION_NO) String versionNo,@FormParam(Constrants.VERSION_TYPE) String versionType){
		Map<String,String> map = new HashMap<String, String>();
		map.put(Constrants.VERSION_NO, versionNo);
		map.put(Constrants.VERSION_TYPE, versionType);
		if(!Validator.validArgs(map)){
			return StringUtil.jsonExceptionMsg(Constrants.ARGU_ERROR_STATUS, Constrants.ARGU_ERROR_DESC);
		}
		VersionManage version = messageService.selectVersionByVersionType(versionType);
		if(null == version || versionNo.equals(version.getVersionNo())){
			return StringUtil.jsonSuccessMsg("当前已是最高版本，无需更新");
		}
		JSONObject json = new JSONObject();
		if("Android".endsWith(versionType)){
			json.put("downloadurl",  ConfigFileUtil.getDownLoadHeadUrl()+version.getFilePath());
		}else{
			json.put("downloadurl", "itms-services://?action=download-manifest&url=" + ConfigFileUtil.getDownLoadHeadUrl()+version.getIosPlistPath());
		}
		json.put("force", "force".equals(version.getUpdateType())? "1":"0");
		json.put("description", version.getVersionDesc());
		return StringUtil.jsonSuccessData(1, "存在新版本", json);
	}
	
	@POST
	@Path("/feedback")
	@Produces("application/json;charset=utf-8")
	public String feedbackMessage(@FormParam(Constrants.DEVICE_ID) String deviceId,@FormParam(Constrants.FEEDBACK_CONTENT) String feedbackContent){
		Map<String,String> map = new HashMap<String, String>();
		map.put(Constrants.DEVICE_ID, deviceId);
		map.put(Constrants.FEEDBACK_CONTENT, feedbackContent);
		if(!Validator.validArgs(map)){
			return StringUtil.jsonExceptionMsg(Constrants.ARGU_ERROR_STATUS, Constrants.ARGU_ERROR_DESC);
		}
		FeedbackInfo feedBackInfo = new FeedbackInfo();
		feedBackInfo.setEnterpriseId(0);
		feedBackInfo.setDeviceId(deviceId);
		feedBackInfo.setFeedbackContent(feedbackContent);
		feedBackInfo.setFeedbackType(FeedbackTypeEnum.APP.getCode());
		feedBackInfo.setFeedbackTime(DateUtil.getCurrentDateString());
		feedBackInfo.setOperationState("N");
		feedBackService.saveFeedBack(feedBackInfo);
		return StringUtil.jsonSuccessMsg("提交成功，感谢您的反馈");
	}


}
