package com.payegis.tscsecurid.rest.api;

import com.alibaba.fastjson.JSONObject;
import com.payegis.tscsecurid.common.data.entity.BindingTerminal;
import com.payegis.tscsecurid.common.data.entity.BusinessSystem;
import com.payegis.tscsecurid.rest.common.Constrants;
import com.payegis.tscsecurid.rest.service.AccountService;
import com.payegis.tscsecurid.rest.service.PatternLockService;
import com.payegis.tscsecurid.rest.util.StringUtil;
import com.payegis.tscsecurid.rest.util.Validator;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import java.util.HashMap;
import java.util.Map;

@Component
@Path("/alias")
public class AliasApi {
	
	@Autowired
	private PatternLockService patternLockService;

	@Autowired
	private AccountService accountService;

	@POST
	@Path("/query")
	@Produces("application/json;charset=utf-8")
	public String query(@FormParam(Constrants.DEVICE_ID)String deviceId,@FormParam(Constrants.SYSTEM_NO)String systemNo){
		Map<String,String> map = new HashMap<String, String>();
		map.put(Constrants.DEVICE_ID, deviceId);
		if(!Validator.validArgs(map)){
            return StringUtil.jsonExceptionMsg(Constrants.ARGU_ERROR_STATUS, Constrants.ARGU_ERROR_DESC);
		}
		if(StringUtils.isNotBlank(systemNo)){
			BusinessSystem businessSystem = accountService.selectBySystemNo(systemNo);
			if (null == businessSystem) {
				return StringUtil.jsonExceptionMsg(Constrants.BUSINESSNO_ERROR_STATUS, Constrants.BUSINESSNO_ERROR_DESC);
			}
		}
		Map<String, Object> param = new HashMap<String, Object>();
		param.put(Constrants.DEVICE_ID,deviceId);
		if(StringUtils.isNotBlank(systemNo)) param.put(Constrants.SYSTEM_NO,systemNo);
		BindingTerminal bindingTerminal = patternLockService.findBindingTerminal(param);
		if(bindingTerminal==null){
			return StringUtil.jsonExceptionMsg(1, "查询失败");
		}
		JSONObject json = new JSONObject();
		json.put("alias", null == bindingTerminal.getAlias() ? "":bindingTerminal.getAlias() );
		return StringUtil.jsonSuccessData(json);
	}
	

	@POST
	@Path("/update")
	@Produces("application/json;charset=utf-8")
	public String update(@FormParam(Constrants.DEVICE_ID)String deviceId,@FormParam(Constrants.ALIAS)String alias,@FormParam(Constrants.SYSTEM_NO)String systemNo){
		Map<String,String> map = new HashMap<String, String>();
		map.put(Constrants.DEVICE_ID, deviceId);
        map.put(Constrants.ALIAS, alias);
		if(!Validator.validArgs(map)){
            return StringUtil.jsonExceptionMsg(Constrants.ARGU_ERROR_STATUS, Constrants.ARGU_ERROR_DESC);
		}
		if(StringUtils.isNotBlank(systemNo)){
			BusinessSystem businessSystem = accountService.selectBySystemNo(systemNo);
			if (null == businessSystem) {
				return StringUtil.jsonExceptionMsg(Constrants.BUSINESSNO_ERROR_STATUS, Constrants.BUSINESSNO_ERROR_DESC);
			}
		}
		Map<String, Object> param = new HashMap<String, Object>();
		param.put(Constrants.DEVICE_ID,deviceId);
		if(StringUtils.isNotBlank(systemNo)) param.put(Constrants.SYSTEM_NO,systemNo);
		BindingTerminal bindingTerminal = patternLockService.findBindingTerminal(param);
		if(bindingTerminal==null){
			return StringUtil.jsonExceptionMsg(1, "修改失败");
		}
		bindingTerminal.setAlias(alias);
		bindingTerminal.setSystemNo(systemNo);
		patternLockService.updateLock(bindingTerminal);
		return StringUtil.jsonSuccessMsg("修改成功");
	}
	
}
