package com.payegis.tscsecurid.rest.service.impl;

import java.util.List;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.payegis.tscsecurid.common.data.entity.BindingTerminalPwdProtection;
import com.payegis.tscsecurid.common.mapper.BindingTerminalPwdProtectionMapper;
import com.payegis.tscsecurid.rest.service.PasswordProtectService;

@Service
public class PasswordProtectServiceImpl implements PasswordProtectService{

	@Autowired 
	private BindingTerminalPwdProtectionMapper bindingTerminalPwdProtectionMapper;
	
	@Override
	public void saveQuestions(String deviceId,String questionAnswers) {
		JSONArray jsonArray = JSONArray.fromObject(questionAnswers);
		BindingTerminalPwdProtection protection = null; 
		JSONObject json = null;
		for (int i = 0; i < jsonArray.size(); i++) {
			json = (JSONObject)jsonArray.get(i);
			protection = new BindingTerminalPwdProtection();
			protection.setDeviceId(deviceId);
			protection.setQuestionDispOrder(Integer.parseInt(json.getString("questionDispOrder")));
			protection.setQuestionAnswer(json.getString("questionAnswer"));
			bindingTerminalPwdProtectionMapper.insert(protection);
		}
	}

	@Override
	public List<BindingTerminalPwdProtection> selectByDeviceId(String deviceId) {
		return bindingTerminalPwdProtectionMapper.selectProByDeviceId(deviceId);
	}

	@Override
	public BindingTerminalPwdProtection selectByDeviceIdAndQuestionOrder(
			String deviceId, Integer questionOrder) {
		return bindingTerminalPwdProtectionMapper.selectByDeviceIdAndQuestionOrder(deviceId, questionOrder);
	}

	
}
