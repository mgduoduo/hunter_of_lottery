package com.payegis.tscsecurid.rest.util;

import java.util.Map;

import org.apache.commons.lang.StringUtils;



public class Validator{

   public static boolean validArgs(Map<String, String> map){
      for (Map.Entry<String, String> entry : map.entrySet()){
         String value = entry.getValue();
         if(!StringUtils.isNotBlank(value)){
        	 return false;
          }
      }
      return true;
   }
   
}
