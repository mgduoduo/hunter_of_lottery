/**
 * 
 */
package com.payegis.sdc.mobilepass.dao.impl;

import org.springframework.stereotype.Repository;

import com.payegis.sdc.mobilepass.dao.BaseJPADao;
import com.payegis.sdc.mobilepass.dao.IUserInfoDao;
import com.payegis.sdc.mobilepass.entity.UserInfo;

/**
 * @author xxmfypp
 *
 */
@Repository
public class UserInfoDaoImpl extends BaseJPADao<UserInfo,String> implements IUserInfoDao {

}
