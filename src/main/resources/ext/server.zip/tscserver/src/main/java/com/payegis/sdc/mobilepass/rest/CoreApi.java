package com.payegis.sdc.mobilepass.rest;

import net.sf.json.JSONObject;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.payegis.sdc.mobilepass.common.Constant;
import com.payegis.sdc.mobilepass.common.MessageConstant;
import com.payegis.sdc.mobilepass.dto.BindUserTO;
import com.payegis.sdc.mobilepass.entity.UserInfo;
import com.payegis.sdc.mobilepass.service.IUserInfoService;
import com.payegis.sdc.mobilepass.util.CommonUtil;

public class CoreApi implements Constant  {




	private Logger logger=Logger.getLogger(CoreApi.class);

	/**
	 * @author zw
	 *
	 */

	/*
	 * Parameter constance key
	 * */
	public interface Parameter{
		public String PARTNER_CODE               ="partnerCode";

		public String APP_ID                     ="appId";
		public String CLIENT_NAME                ="clientName";
		public String DC_CODE                    ="dcCode";
		public String DEVICE_ID                  ="deviceId";
		public String DEVICE_TOKEN               ="deviceToken";
		public String EMAIL                      ="email";
		public String ICON                       ="icon";
		public String ICON_ID                    ="iconId";
		public String LOGIN_NAME                 ="loginName";
		public String NEW_PWD                    ="newPwd";
		public String OLD_PWD                    ="oldPwd";
		public String PHONE                      ="phone";
		public String QUICK_BINDING_CODE         ="quickBindingCode";
		public String QUICK_LOGIN_CODE           ="quickLoginCode";
		public String PWD                        ="pwd";
		public String THIRD_PARTY_ACCOUNT_ID     ="3rdAccountId";
		public String THIRD_PARTY_APP_ID         ="3rdAppId";
		public String THIRD_PARTY_PARTNER_CODE   ="3rdPartnerCode";
		public String USER_TOKEN                 ="userToken";
		public String PUSH_SWITCH                ="pushSwitch";
		public String MSG_SWITCH                 ="msgSwitch";
		public String SMSX_SWITCH                ="smsxSwitch";
		public String SESSION_TOKEN              ="sessionToken";
		public String CERTIFICATE_CODE           ="certificateCode";
		public String NICK_NAME                  ="nickName";
		public String AUTHORITY_TYPE             ="authorityType";
		
		public String FRIEND_USERID              ="friendUserId";
		public String TO_USERID                  ="toUserId";
		public String TEXT_CONTENT               ="textContent";
		public String FILE_CONTENT               ="fileContent";
		public String MESSAGE_TYPE               ="messageType";
		
		public String GROUP_NAME                 ="groupName";
		public String DESCRIPTION                ="description";
		public String GROUP_ID                   ="groupId";
		public String GROUP_USERID               ="groupUserId";
		
		public String GROUPCHAT_MESSAGEID        ="groupchatmessageid";
		
		public String APPEAL_TYPE                ="appealType";
		
		public String NAME                       ="name";
		
		public String MARKNAME                   ="markName";
		
		public String DISMISSTIME                ="dismissTime";
		
		public String AUTHORIZECODE              ="authorizeCode";
		
		public String FEEDBACKTYPE               ="feedBackType";
		
		public String USERID                     ="userId";
		


	}
	
	protected String[] parse2DimensionCode(String code){
		if(StringUtils.isEmpty(code)){
			return null;
		}

		return code.split("\\|");
	}


	protected int  checkDeviceId(String userToken,String appPartner,String deviceId,IUserInfoService userInfoService,String appId){
	
		int result = -1;
		try{
			JSONObject paramValue = new JSONObject();
			paramValue.put("appPartner", appPartner);
			paramValue.put("userToken", userToken);
			BindUserTO bindUserTo = new BindUserTO();
			bindUserTo.setAppPartner(appPartner);
			//bindUserTo.setAppId(appId);
			bindUserTo.setUserToken(userToken);
			String did = null;
			UserInfo userinfo = userInfoService.getDeviceId(bindUserTo);
			if(userinfo!=null){
				did = userinfo.getDeviceId();
			}
			if(deviceId.equals(did)){
				result = 0;
			}else{
				result = -2;
			}
		}catch(Exception e){
			//ignore
			logger.error("error.",e);
		}
		return result;
	}

	protected boolean validatParams(String[] keys,String  ...args ){
		boolean valid=true;
		if(args!=null){
			for(int i=0;i<args.length;i++){
				String value=args[i];
				//logger.info("param:"+ (keys!=null && i< keys.length ? keys[i] : "") + " , value:"+value);
				if(StringUtils.isEmpty(value)){
					valid=false;
				}
			}
		}


		return valid;
	}

	protected String buildValidateParamJSON(){
		JSONObject json=new JSONObject();
		json.put(JSON_KEY_STATUS, API_STATUS_FAIL);
		json.put(JSON_KEY_MESSAGE, CommonUtil.getMessage(MessageConstant.Error.ERROR_FIELD_MANDATORY));
		return outputJson(json);
	}

	protected String buildJSON(String status, String message ){
		JSONObject json=new JSONObject();
		json.put(JSON_KEY_STATUS, status);
		json.put(JSON_KEY_MESSAGE, message);
		return outputJson(json);
	}

	protected String buildJSON(String status, String message ,Object object){
		JSONObject json=new JSONObject();
		json.put(JSON_KEY_STATUS, status);
		json.put(JSON_KEY_MESSAGE, message);
		json.put(JSON_KEY_DATA, object);
		return outputJson(json);
	}
	
	private String outputJson(JSONObject json){
		String str=json.toString();
		//logger.info("output json >>> "+str +" <<<");
		return str;
	}
}
