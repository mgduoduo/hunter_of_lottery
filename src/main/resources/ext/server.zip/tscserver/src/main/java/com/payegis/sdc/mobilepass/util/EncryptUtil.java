package com.payegis.sdc.mobilepass.util;

import java.io.UnsupportedEncodingException;
import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.security.Security;

import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.jasypt.encryption.pbe.StandardPBEStringEncryptor;

public class EncryptUtil{
   public static String encryptMD5Password(String plainPassword)throws UnsupportedEncodingException,GeneralSecurityException{
      byte[] finalData = null;
      byte[] data = plainPassword.getBytes("UTF-8");
      MessageDigest md5 = MessageDigest.getInstance("MD5");
      finalData = md5.digest(data);
      return HexUtil.bytesToHex(finalData);
   }

   public static String encryptSHAPassword(String plainPassword)
                     throws UnsupportedEncodingException,
                     GeneralSecurityException
   {
      byte[] finalData = null;
      byte[] data = plainPassword.getBytes("UTF-8");
      MessageDigest sha = MessageDigest.getInstance("SHA");
      finalData = sha.digest(data);
      return HexUtil.bytesToHex(finalData);
   }
   
   private static StandardPBEStringEncryptor encryptor = null;

   public static StandardPBEStringEncryptor getEncryptor()
   {
      if (encryptor == null)
      {
         Security.addProvider(new BouncyCastleProvider());
         encryptor = new StandardPBEStringEncryptor();
         encryptor.setPassword("g0Tu1");
      }
      return encryptor;
   }

   public static String encryptString(String str)
   {
      return getEncryptor().encrypt(str);
   }

   public static String decryptString(String str)
   {
      return getEncryptor().decrypt(str);
   }

   public static StandardPBEStringEncryptor getEncryptor(String seed)
   {
      if (encryptor == null)
      {
         Security.addProvider(new BouncyCastleProvider());
         encryptor = new StandardPBEStringEncryptor();
         encryptor.setPassword("g0Tu1" + seed);
      }
      return encryptor;
   }

   public static String encryptString(String str, String seed)
   {
      return getEncryptor(seed).encrypt(str);
   }

   public static String decryptString(String str, String seed)
   {
      return getEncryptor(seed).decrypt(str);
   }

}
