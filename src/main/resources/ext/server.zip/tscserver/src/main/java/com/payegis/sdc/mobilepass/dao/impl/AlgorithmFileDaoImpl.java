package com.payegis.sdc.mobilepass.dao.impl;

import org.springframework.stereotype.Repository;

import com.payegis.sdc.mobilepass.dao.BaseJPADao;
import com.payegis.sdc.mobilepass.dao.IAlgorithmFileDao;
import com.payegis.sdc.mobilepass.entity.AlgorithmFileInfo;



@Repository
public class AlgorithmFileDaoImpl extends BaseJPADao<AlgorithmFileInfo, String> implements IAlgorithmFileDao {

}
