package com.payegis.sdc.mobilepass.filter.authentication;


import com.payegis.sdc.mobilepass.filter.authentication.util.HmacAttributes;
import org.apache.log4j.Logger;

import javax.servlet.http.HttpServletRequest;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.List;
//import org.joda.time.Instant;



public class CustomSigningUtil {

    private static final Logger LOG = Logger.getLogger(CustomSigningUtil.class);

    public static String getDateFromHeader(final HttpServletRequest request) {
        final String header = request.getHeader(HmacAttributes.X_HMAC_AUTH_DATE);
        if (header == null) {
            return "";
        }
        return header;
    }

    public static String getKvString(final HttpServletRequest request) throws UnsupportedEncodingException{
        String requestTimeString = getDateFromHeader(request);
        LOG.debug("requestTimeString ==> " + requestTimeString);
        String kvString = "";
        Enumeration keys = request.getParameterNames();

//		Enumeration keys = request.getAttributeNames();

        List<String> listKeys = new ArrayList<String>();
        while(keys.hasMoreElements()){
            String name=(String)keys.nextElement();
            listKeys.add(name);
        }
        listKeys.add(HmacAttributes.X_HMAC_AUTH_DATE);
        Collections.sort(listKeys);
        int length = listKeys.size();
        for(int i=0; i<length-1; i++){
            String key = listKeys.get(i);
            if(!key.equals(HmacAttributes.X_HMAC_AUTH_DATE)){
                kvString += key + "=" + request.getParameter(key) + "&";
            }else{
                kvString += key + "=" + requestTimeString + "&";
            }
        }
        if(!listKeys.get(length-1).equals(HmacAttributes.X_HMAC_AUTH_DATE)){
            kvString += listKeys.get(length-1) + "=" + request.getParameter(listKeys.get(length-1));
        }else{
            kvString += listKeys.get(length-1) + "=" + requestTimeString;
        }
       // LOG.info("keys升序排列处理 11==>" + kvString);
        String kvStringE = URLEncoder.encode(kvString,"UTF-8");
        kvString = kvStringE.replace("*", "%2A").replace(" ", "%20");
        //LOG.info("keys升序排列处理 ==>" + kvString);
        return kvStringE;
    }

    public static String getKvStringWithFilter(final HttpServletRequest request, List<String> keyFilter, String requestTimeStamp) throws UnsupportedEncodingException{
        //String requestTimeString = getDateFromHeader(request);
        LOG.debug("requestTimeString ==> " + requestTimeStamp);
        String kvString = "";
        Enumeration keys = request.getParameterNames();

//		Enumeration keys = request.getAttributeNames();
        if(keyFilter==null) keyFilter=new ArrayList<String>();
        List<String> listKeys = new ArrayList<String>();
        while(keys.hasMoreElements()){
            String name=(String)keys.nextElement();

            if(keyFilter.contains(name)) continue;

            listKeys.add(name);
        }
        listKeys.add(HmacAttributes.X_HMAC_AUTH_DATE);
        Collections.sort(listKeys);
        int length = listKeys.size();
        for(int i=0; i<length-1; i++){
            String key = listKeys.get(i);
            if(!key.equals(HmacAttributes.X_HMAC_AUTH_DATE)){
                kvString += key + "=" + request.getParameter(key) + "&";
            }else{
                kvString += key + "=" + requestTimeStamp + "&";
            }
        }

        if(!listKeys.get(length-1).equals(HmacAttributes.X_HMAC_AUTH_DATE)){
            kvString += listKeys.get(length-1) + "=" + request.getParameter(listKeys.get(length-1));
        }else{
            kvString += listKeys.get(length-1) + "=" + requestTimeStamp;
        }
       // LOG.info("keys升序排列处理 11==>" + kvString);
        String kvStringE = URLEncoder.encode(kvString,"UTF-8");
        kvString = kvStringE.replace("*", "%2A").replace("+", "%20");
       // LOG.info("keys升序排列处理 ==>" + kvString);
        return kvStringE;
    }

}
