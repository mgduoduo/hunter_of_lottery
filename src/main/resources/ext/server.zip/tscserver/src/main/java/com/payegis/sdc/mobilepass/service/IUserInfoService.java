package com.payegis.sdc.mobilepass.service;

import net.sf.json.JSONObject;

import com.payegis.sdc.mobilepass.dto.BindUserTO;
import com.payegis.sdc.mobilepass.dto.DcCodeTO;
import com.payegis.sdc.mobilepass.dto.SDKCommonDataTO;
import com.payegis.sdc.mobilepass.dto.ShortTokenTO;
import com.payegis.sdc.mobilepass.entity.UserInfo;

public interface IUserInfoService {
	
	public UserInfo bindUser(BindUserTO bindUserTo);
	
	public String checkNewAlgorithm(SDKCommonDataTO sdkCommonDataTo)throws Exception;
	
	public String getAlgorithmList(SDKCommonDataTO sdkCommonDataTo)throws Exception;
	
	public byte[] getAlgorithmFile(String algorithmFileId)throws Exception;
	
	public UserInfo getDeviceId(BindUserTO bindUserTo)throws Exception;
	
	public String checkShortToken(ShortTokenTO shortTokenTO)throws Exception;
	
	public String validateDcCode(DcCodeTO dcCodeTO)throws Exception;
	
	public JSONObject validateQRCodeforTSC(String  dcCode);

    public void  saveAhgorithmleToDb();
	
}
