package com.payegis.sdc.mobilepass.dao.impl;

import org.springframework.stereotype.Repository;

import com.payegis.sdc.mobilepass.dao.BaseJPADao;
import com.payegis.sdc.mobilepass.dao.IScanHistoryDao;
import com.payegis.sdc.mobilepass.entity.ScanHistory;


@Repository
public class ScanHistoryDaoImpl extends BaseJPADao<ScanHistory, String> implements IScanHistoryDao{

}
