package com.payegis.sdc.mobilepass.service;

public interface IDeviceRecordService {

	
	public boolean saveRecord(String deviceId);
	
}
