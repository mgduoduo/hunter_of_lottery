package com.payegis.sdc.mobilepass.dao.impl;

import org.springframework.stereotype.Repository;

import com.payegis.sdc.mobilepass.dao.BaseJPADao;
import com.payegis.sdc.mobilepass.dao.IBlackListDao;
import com.payegis.sdc.mobilepass.entity.BlackList;


@Repository
public class BlackListDaoImpl extends BaseJPADao<BlackList, String> implements IBlackListDao{

}
