package com.payegis.sdc.mobilepass.dao;

import com.payegis.sdc.mobilepass.entity.ScanHistory;


public interface IScanHistoryDao extends IDao<ScanHistory , String>{

	
	
}
