package com.payegis.sdc.mobilepass.dto;

public class BindUserTO extends SDKCommonDataTO implements java.io.Serializable{
	
	private String userToken;
	
	private String externalId;
	
	private String shortToken;
	

	public String getExternalId() {
		return externalId;
	}

	public void setExternalId(String externalId) {
		this.externalId = externalId;
	}

	public String getUserToken() {
		return userToken;
	}

	public void setUserToken(String userToken) {
		this.userToken = userToken;
	}

	public String getShortToken() {
		return shortToken;
	}

	public void setShortToken(String shortToken) {
		this.shortToken = shortToken;
	}
	
}
