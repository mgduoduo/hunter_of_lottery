package com.payegis.sdc.mobilepass.service;

import java.util.List;

import com.payegis.sdc.mobilepass.entity.ScanHistory;


public interface IScanHistoryService {
	
	public void addScanContent(ScanHistory scanHistory);
	
	public List<ScanHistory> getScanHistory(String deviceId,String appId,String partnerCode,String scanHistoryId,Integer isBefore,Integer pageSize,String userId);

}
