package com.payegis.sdc.mobilepass.exception;

public interface ErrorCodes {

	public static final String ERR_SYS = "E101";


}
