package com.payegis.sdc.mobilepass.exception;

public class HandleException extends BaseException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public HandleException(ErrorMsg msg, Object...arg){
		super(msg, arg);
	}
	
}
