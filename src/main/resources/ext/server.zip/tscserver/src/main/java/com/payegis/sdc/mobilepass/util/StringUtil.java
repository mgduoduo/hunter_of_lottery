package com.payegis.sdc.mobilepass.util;

import net.sf.json.JSONException;
import net.sf.json.JSONObject;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

public class StringUtil {
	
	private static final String STATUS = "status";
	   private static final String MESSAGE = "message";
	   private static final String DATA = "data";
	   
	   private static Logger logger = Logger.getLogger(StringUtil.class);

	   public static final String jsonExceptionMsg(int status, String message){
	       JSONObject json = new JSONObject();
	       try {
	           json.put(STATUS, String.valueOf(status));
	           if(StringUtils.isBlank(message)){           
	               json.put(MESSAGE, "");
	           }else{
	               json.put(MESSAGE, message);
	           }
	       } catch (JSONException e) {
			   logger.error(e.getMessage(), e);
	       }
	       return json.toString();
	   }
	   
	   public static final String jsonSuccessData(Object data){
	       return jsonString(0, "", data);
	   }
	   
	   private static final String jsonString(int status, String message, Object data){
	       JSONObject json = new JSONObject();
	       try {
	           json.put(STATUS, String.valueOf(status));
	           if(StringUtils.isBlank(message)){           
	               json.put(MESSAGE, "");
	           }else{
	               json.put(MESSAGE, message);
	           }
	           if(data == null){
	               json.put(DATA, "");
	           }else{
	               json.put(DATA, data);
	           }
	       } catch (JSONException e) {
			   logger.error(e.getMessage(),e);
	       }
	       //logger.info("return json string: " + json.toString());
	       
	       return json.toString();
	   }

}
