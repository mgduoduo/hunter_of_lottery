package com.payegis.sdc.mobilepass.dto;

import org.apache.commons.lang3.StringUtils;

public class ShortTokenTO {
	
	private String deviceId;
	
	private String shortToken;
	
	private String partnerCode;
	
	private String appId;
	
	public String getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}

	public String getShortToken() {
		return shortToken;
	}

	public void setShortToken(String shortToken) {
		this.shortToken = shortToken;
	}

	public String getPartnerCode() {
		if(StringUtils.isBlank(partnerCode)){
			return "000";
		}else{
			return partnerCode;
		}
	}

	public void setPartnerCode(String partnerCode) {
		this.partnerCode = partnerCode;
	}

	public String getAppId() {
		return appId;
	}

	public void setAppId(String appId) {
		this.appId = appId;
	}

}
