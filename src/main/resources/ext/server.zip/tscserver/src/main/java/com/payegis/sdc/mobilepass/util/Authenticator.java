package com.payegis.sdc.mobilepass.util;


import org.apache.commons.lang.StringUtils;



public class Authenticator
{


    public static String getAppName(String appPartner, String secretKey)
    {
        if (StringUtils.isBlank(secretKey))
        {
            return null;
        }

        secretKey = EncryptUtil.decryptString(secretKey);
        if (!StringUtils.equalsIgnoreCase(appPartner,
                StringUtils.substringBefore(secretKey, ":")))
        {
            return null;
        }
        else
        {
            return StringUtils.substringAfter(secretKey, ":");
        }
    }

}
