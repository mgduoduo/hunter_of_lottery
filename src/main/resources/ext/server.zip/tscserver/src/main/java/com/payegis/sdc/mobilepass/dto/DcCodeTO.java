package com.payegis.sdc.mobilepass.dto;

public class DcCodeTO {
	
	private String dcCode;
	
	private String appId;
	
	private String deviceId;
	
	public DcCodeTO(){}
	
	public DcCodeTO(String code){
		this.dcCode=code;
	}

	public String getDcCode() {
		return dcCode;
	}

	public void setDcCode(String dcCode) {
		this.dcCode = dcCode;
	}

	public String getAppId() {
		return appId;
	}

	public void setAppId(String appId) {
		this.appId = appId;
	}

	public String getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}
	
}
