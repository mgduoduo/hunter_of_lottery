package com.payegis.sdc.mobilepass.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.io.IOException;
import java.io.StringWriter;
import java.security.MessageDigest;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;

import com.payegis.sdc.mobilepass.common.spring.ApplicationContextProvider;

public class CommonUtil {

	private static final Logger LOG = Logger.getLogger(CommonUtil.class);

	public static String generateUUID(){
		UUID uuid = UUID.randomUUID();
		return uuid.toString().replace("-", "");
	}

	/**
	 * 获取语言类型
	 * 
	 * @param language
	 *            语言
	 * @return
	 */
	private static Locale getLocal(String language) {
		Locale locale = Locale.SIMPLIFIED_CHINESE;
		if (language != null && language.startsWith("en")) {
			locale = Locale.ENGLISH;
		}
		if (language != null && language.equals("zh_TW")) {
			locale = Locale.TRADITIONAL_CHINESE;
		}
		return locale;
	}

	/**
	 * 获取国际化信息
	 * 
	 * @param code
	 *            信息key
	 * @param args
	 *            占位符参数
	 * @param language
	 *            语言
	 * @return 国家化信息
	 */
	public static String getMessage(String code, Object[] args, String language) {
		try {
			return ApplicationContextProvider.getApplicationContext().getMessage(
					code, args, getLocal(language));
		} catch (Exception e) {
			// TODO: handle exception
			return code;
		}
	}
	
	/**
	 * 展位符号国际化
	 * @param code
	 * @param args
	 * @param language
	 * @return
	 */
	public static String getMessageForPlaceholder(String code, Object[] args, String language){
		List<Object> list = new ArrayList<Object>();
		if(args!=null&&args.length>0){
			for(int i=0;i<args.length;i++){
				list.add(getMessage(String.valueOf(args[i]), null, language));
			}
		}
		if(!list.isEmpty()){
			return getMessage(code, list.toArray(new Object[list.size()]), language);
		}else{
			return getMessage(code, null, language);
		}
	}
	
	public static String getMessage(String code) {
		return getMessage(code, null, null);
	}
	
	public static int formartInteger(String str) {
		try {
			return Integer.parseInt(str);
		} catch (Exception e) {
			return -1;
		}
	}

	public static int formartInteger(String str, int defaultValue) {
		try {
			return Integer.parseInt(str);
		} catch (Exception e) {
			return defaultValue;
		}
	}
	
	public static long formatLong(String str){
		return formatLong(str , -1);
	}
	
	public static long formatLong(String str, long defaultValue){
		try{
			return Long.parseLong(str);
		}catch(Exception e){
			return defaultValue;
		}
	}
	
	public final static String MD5(String s) {
        char hexDigits[]={'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'};       
        try {
            byte[] btInput = s.getBytes();
            MessageDigest mdInst = MessageDigest.getInstance("MD5");
            mdInst.update(btInput);
            byte[] md = mdInst.digest();
            int j = md.length;
            char str[] = new char[j * 2];
            int k = 0;
            for (int i = 0; i < j; i++) {
                byte byte0 = md[i];
                str[k++] = hexDigits[byte0 >>> 4 & 0xf];
                str[k++] = hexDigits[byte0 & 0xf];
            }
            return new String(str);
        } catch (Exception e) {
        	return "";
        }
    }
	
	public static String getFormatStringByVeloCity(String template,Map<String,String> templateParam){
		VelocityEngine ve = new VelocityEngine();
		StringWriter writer = new StringWriter();
		VelocityContext context = new VelocityContext(templateParam);
		ve.evaluate(context, writer, "", template);
		String content = writer.toString();
		try {
			writer.close();
		} catch (IOException e) {
			LOG.error(e.getMessage(), e);
		}
		return content;
	}
	
	/**
	 * 获取短deviceId
	 * @param deviceId
	 * @return
	 */
	public static String getShortDeviceId(String deviceId){
		if(deviceId!=null){
			String[] deviceIds = StringUtils.split(deviceId, "-");
			if(deviceIds.length==3){
				return deviceIds[0]+"******"+deviceIds[2];
			}
		}
		return "";
	}
	
	public static String getShortDeviceIdOrNickName(String deviceId,String nickName){
		if(StringUtils.isBlank(nickName)){
			String[] deviceIds = StringUtils.split(deviceId, "-");
			return deviceIds[0]+"******"+deviceIds[2];
		}else{
			return nickName;
		}
	}

	public static String getShortSessionKey(String sessionKey){
		if(sessionKey!=null){
			String[] sessionKeys = new String[2];
			sessionKeys[0]= sessionKey.substring(0, 4);
			sessionKeys[1]= sessionKey.substring(sessionKey.length()-4, sessionKey.length());
			return sessionKeys[0]+"******"+sessionKeys[1];
		}
		return "";
	}
	
      
}
