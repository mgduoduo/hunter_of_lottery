package com.payegis.sdc.mobilepass.util;

import com.sun.jna.Library;
import com.sun.jna.Native;

public class DecodeNumber {
	
	private String path;
	
	public DecodeNumber(String path){
		this.path=path;
	}
	
	
	public interface DecodeSO extends Library{
		String getVersion(String dynamicCode);//获取算法版本号
		String getPartnerCode(String dynamicCode);//获取partner code
		String getToken(String dynamicCode);//获取6位token
		String getUserAccount(String dynamicCode);//获取11位user account
	}
	
	
	public DecodeSO getDecodeSO(){
		return (DecodeSO) Native.loadLibrary(path, DecodeSO.class);
	}
	
	public static void main(String[] args){
		for(int i= 1 ;i<100;i++){
			if(i%2!=0){
				String path = "/home/xxmfypp/7788/libDcDecryptSzb10.so";
				String token="84693056261347228310";
				DecodeNumber dn = new DecodeNumber(path);
				System.out.println(dn.getDecodeSO().getToken(token));
			}else{
				String path = "/home/xxmfypp/7788/libDcDecryptSzb11.so";
				String token="38469305626134722810";
				DecodeNumber dn = new DecodeNumber(path);
				System.out.println(dn.getDecodeSO().getToken(token));
			}
		}
	}
}
