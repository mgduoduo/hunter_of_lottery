package com.payegis.sdc.mobilepass.filter;

import com.payegis.sdc.mobilepass.common.Constant;
import com.payegis.sdc.mobilepass.exception.ErrorMsg;
import com.payegis.sdc.mobilepass.filter.authentication.CustomSigningUtil;
import com.payegis.sdc.mobilepass.filter.authentication.WrappedRequest;
import com.payegis.sdc.mobilepass.filter.authentication.util.HmacAttributes;
import com.payegis.sdc.mobilepass.util.ConfigFileUtil;
import com.payegis.sdc.mobilepass.util.MessageUtil;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.core.util.MultivaluedMapImpl;
import net.sf.json.JSONObject;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.*;



/**
 *
 * @author xuman.xu
 *
 */
public class ParmsVerifySecurityFilter implements Filter{
    private static Logger logger = Logger.getLogger(ParmsVerifySecurityFilter.class);

    private String apiList=null;

    public void destroy(){

    }

    private boolean apiNeedBilling(String api){

        if(StringUtils.isBlank(apiList)){
            String apis=ConfigFileUtil.getValue(Constant.KEY_AUTH_API);
            if(StringUtils.isBlank(apis)) return false;
            String[] apiArray= apis.split(";");
            if(apiArray!=null && apiArray.length>0){
                for(String a: apiArray){
                    if(api.equals(a)){
                        return true;
                    }
                }
            }
        }
        return false;

    }

    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException{
        //logger.debug("RestParmsVerifySecurityFilter.doFilter()");

        HttpServletRequest httpRequest =(HttpServletRequest) request;
        showParams(httpRequest);
        String url = httpRequest.getRequestURI();

        String fullUrl= httpRequest.getScheme()+"://"+httpRequest.getServerName()+":"+httpRequest.getServerPort()+url;

        /*if(true){
            chain.doFilter(request, response);
            return;
        }*/
        String serverCode="";
        if(url.contains("forpass")){
            serverCode=ConfigFileUtil.getValue(Constant.KEY_AUTH_SERVER_PASS_CODE);
        }else{
            serverCode=ConfigFileUtil.getValue(Constant.KEY_AUTH_SERVER_TSC_CODE);
        }

        if(url.contains("rest/p2p")||url.contains("rest/version")||url.contains("synctimeForWeb")||url.contains("saveFile")){
            chain.doFilter(request, response);
            return;
        }

        String apiName=null;
        if(!StringUtils.isBlank(url)){
            String[] parten=url.split("\\/");
            if(parten!=null && parten.length>0){
                apiName=parten[parten.length-1];
            }
        }
        String requestTimeStamp=null;
        String clientSignature=null;

        boolean isWeb= apiName.endsWith("Web");
        List<String> keyFilter=new ArrayList<String>();

        if(isWeb){
            //logger.info("request for body param.");
            requestTimeStamp = httpRequest.getParameter(HmacAttributes.X_HMAC_AUTH_DATE);
            //logger.info("requestTimeStamp ==> " + requestTimeStamp);
            clientSignature = httpRequest.getParameter(HmacAttributes.X_HMAC_AUTH_SIGNATURE);
            //logger.info("clientSignature ==> " + clientSignature);

            keyFilter.add("_");
            keyFilter.add("jsoncallback");
            keyFilter.add("x-hmac-auth-date");
            keyFilter.add("x-hmac-auth-signature");


        }else{
            requestTimeStamp = httpRequest.getHeader(HmacAttributes.X_HMAC_AUTH_DATE);
            //logger.info("requestTimeStamp ==> " + requestTimeStamp);
            clientSignature = httpRequest.getHeader(HmacAttributes.X_HMAC_AUTH_SIGNATURE);
            //logger.info("clientSignature ==> " + clientSignature);
        }

        WrappedRequest wrappedRequest = WrappedRequest.wrap(httpRequest);


        //String kvStr = CustomSigningUtil.getKvString(wrappedRequest);


        String kvStr = CustomSigningUtil.getKvStringWithFilter(wrappedRequest, keyFilter, requestTimeStamp);

        //logger.info("clientSignature ==> " + clientSignature);
        long startTime =  System.currentTimeMillis();
        Client client  = new Client();
        WebResource rs = client.resource(ConfigFileUtil.getValue(Constant.KEY_AUTH_URL));

        Map<String,Object> paramMap = new HashMap<String,Object>();
        paramMap.put("clientSignature", clientSignature);
        paramMap.put("requestTimeStamp", requestTimeStamp);
        //paramMap.put("url", url);
        paramMap.put("serverCode", serverCode);
        paramMap.put("kvStr", kvStr);
        paramMap.put("url",fullUrl);
        if( ! apiNeedBilling(apiName)){
            paramMap.put("billing", "N");

        }

        MultivaluedMapImpl params=constructWebserviceParams(paramMap);

        ClientResponse cr = rs.post(ClientResponse.class, params);

        String resultString = cr.getEntity(String.class);
       // logger.info("校验结果===》" + resultString);
        JSONObject json = JSONObject.fromObject(resultString);
        //logger.info("return json: "+ json.toString());
        //logger.info("校验消耗的时间为："+(System.currentTimeMillis()-startTime));
        if("0".equals(json.getString(Constant.Result.STATUS))){
            chain.doFilter(request, response);
        }else{
            logger.info("clientSignature ==> " + clientSignature);
            // logger.info("requestTimeStamp ==> " + requestTimeStamp);
            // logger.info("serverCode ==> " + serverCode);
            logger.info("kvStr ==> " + kvStr);
            //logger.info("url ==> " + fullUrl);
            //throw new AuthenticationException(json.getString(Constant.Result.MESSAGE));
            response.setContentType("application/json;charset=UTF-8");
            String message = MessageUtil.jsonExceptionMsg(ErrorMsg.AUTH_ERROR.getCode(), ErrorMsg.AUTH_ERROR.getMsg());
            response.getWriter().write(message);
        }

    }
/*
	private void filterForHeader(String apiName , HttpServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException{


		String requestTimeStamp = request.getHeader(HmacAttributes.X_HMAC_AUTH_DATE);

		logger.info("requestTimeStamp ==> " + requestTimeStamp);



		String clientSignature = request.getHeader(HmacAttributes.X_HMAC_AUTH_SIGNATURE);

		logger.info("clientSignature ==> " + clientSignature);

		WrappedRequest wrappedRequest = WrappedRequest.wrap(request);


		String kvStr = CustomSigningUtil.getKvString(wrappedRequest);

		logger.info("clientSignature ==> " + clientSignature);


		Client client  = new Client();
		WebResource rs = client.resource(ConfigFileUtil.getValue(Constant.KEY_AUTH_URL));

		Map<String,Object> paramMap = new HashMap<String,Object>();
		paramMap.put("clientSignature", clientSignature);
		paramMap.put("requestTimeStamp", requestTimeStamp);
		//paramMap.put("url", url);
		paramMap.put("serverCode", ConfigFileUtil.getValue(Constant.KEY_AUTH_SERVER_CODE));
		paramMap.put("kvStr", kvStr);
		if( ! apiNeedBilling(apiName)){
			paramMap.put("billing", "0");

		}
		MultivaluedMapImpl params=constructWebserviceParams(paramMap);

		ClientResponse cr = rs.post(ClientResponse.class, params);

		String resultString = cr.getEntity(String.class);

		JSONObject json = JSONObject.fromObject(resultString);
		if(json.getString(Constant.Result.STATUS).equals("0")){
			chain.doFilter(request, response);
		}else{
			//throw new AuthenticationException(json.getString(Constant.Result.MESSAGE));
			response.setContentType("application/json;charset=UTF-8");
			String message = MessageUtil.jsonExceptionMsg(ErrorMsg.AUTH_ERROR.getCode(), ErrorMsg.AUTH_ERROR.getMsg());
			response.getWriter().write(message);
		}


	}*/

    public void init(FilterConfig arg0) throws ServletException{

    }

    private static MultivaluedMapImpl constructWebserviceParams(Map<String,Object> paramMap){
        if(paramMap==null || paramMap.isEmpty()){
            return null;
        }

        MultivaluedMapImpl params = new MultivaluedMapImpl();

        for(Iterator<String> it=paramMap.keySet().iterator() ; it.hasNext();){
            String key= it.next();
            params.add(key, paramMap.get(key));
        }

        return params;

    }

    private void showParams(HttpServletRequest request) {
        Enumeration paramNames = request.getParameterNames();
        while (paramNames.hasMoreElements()) {
            String paramName = (String) paramNames.nextElement();
           //logger.info("---------------"+paramName+"---------------");
        }

    }




}


