package com.payegis.sdc.mobilepass.dao;

import com.payegis.sdc.mobilepass.entity.BlackList;


public interface IBlackListDao extends IDao<BlackList , String>{

	
	
}
