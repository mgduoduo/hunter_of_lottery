package com.payegis.sdc.mobilepass.dao;

import com.payegis.sdc.mobilepass.entity.AlgorithmFileInfo;



public interface IAlgorithmFileDao extends IDao<AlgorithmFileInfo,String>{
	
}
