package com.payegis.sdc.mobilepass.service.impl;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.payegis.sdc.mobilepass.dao.IUserInfoDao;
import com.payegis.sdc.mobilepass.service.ITaskProcessor;
import com.payegis.sdc.mobilepass.util.ConfigFileUtil;
import com.payegis.sdc.mobilepass.util.DateUtil;


@Service("TaskProcessor")
public class TaskProcessorImpl implements ITaskProcessor{

	private static Logger logger=Logger.getLogger(TaskProcessorImpl.class);
	
	@Autowired
	private IUserInfoDao userinfoDao;
	
	
	
	@Override
	public void deleteExpireUserInfo() {
		long start_time=System.currentTimeMillis();
		
		//获取配置中删除数据的时间差，如果取不到时间差，则默认为1200秒
		int seconds=ConfigFileUtil.getClearSdcUserinfoTime(); 
		
		//删除当前时间前10分钟的数据
		Date time=DateUtil.getDateBeforeSecond(seconds);
		
		String sql="delete from UserInfo u  where u.updateTime <= :t";
		
		Map<String,Object> params=new HashMap<String,Object>();
		params.put("t",time);
		
		userinfoDao.executeUpdate(sql, params);
		long end_time=System.currentTimeMillis();
		logger.debug(">>>>>>>>> End clean user_info <<<<<<<<<<<<<<< Cost time: "+(end_time - start_time));
	}



}
