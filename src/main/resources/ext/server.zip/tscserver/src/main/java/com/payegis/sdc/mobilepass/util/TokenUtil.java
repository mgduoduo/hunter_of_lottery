package com.payegis.sdc.mobilepass.util;

import org.apache.log4j.Logger;

import java.util.Calendar;
import java.util.Date;

public final class TokenUtil {

    public static Logger logger = Logger.getLogger(TokenUtil.class);


    public static long getGMTTime(){
        return getGMTTime(new Date());
    }

    private static long getGMTTime(Date date){
        Calendar cal=Calendar.getInstance();
        //int timez= cal.get(Calendar.ZONE_OFFSET);
        long curr=date.getTime();
        //logger.info("=============token time:"+ date);
        //String epoch=""+(curr-timez);
        String epoch=""+curr;
       // logger.info("=============token time epoch:"+ epoch);
        epoch=epoch.substring(0,epoch.length()-3);
        return Long.valueOf(epoch);
    }


    public static String matchToken(String token, String unecrpted,long scantime,String appId){
        int diff = ConfigFileUtil.getValidateTime(appId);
        long crTime=getGMTTime();
        for(int i=0;i<=diff;i++){
            String str=String.valueOf(crTime+i) + unecrpted;
            String encrypted=Encryption.encrypt6Digit(str);
            if(encrypted.equals(token)){
                long time = ((crTime+i)-scantime);
                //logger.info("=============时间差值:"+ time);
                if(Math.abs(time)<=ConfigFileUtil.getScanTime(appId)){
                    return "0";
                }else{
                    return "1";
                }
            }

            str=String.valueOf(crTime-i) + unecrpted;
            encrypted=Encryption.encrypt6Digit(str);
            if(encrypted.equals(token)){
                long time = ((crTime-i)-scantime);
                //logger.info("=============时间差值:"+ time);
                if(Math.abs(time)<=ConfigFileUtil.getScanTime(appId)){
                    return "0";
                }else{
                    return "1";
                }
            }
        }
        return "2";
    }

    public static boolean matchToken(String token, String unecrpted,String appId){
        int diff = ConfigFileUtil.getValidateTime(appId);
        long crTime=getGMTTime();
        //logger.info("matchToken crTime="+crTime);
        for(int i=0;i<=diff;i++){
            String str=String.valueOf(crTime+i) + unecrpted;
            String encrypted=Encryption.encrypt6Digit(str);
            if(encrypted.equals(token)){
                return true;
            }

            str=String.valueOf(crTime-i) + unecrpted;
            encrypted=Encryption.encrypt6Digit(str);
            if(encrypted.equals(token)){
                return true;
            }
        }
        return false;
    }

}
