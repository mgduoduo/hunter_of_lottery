package com.payegis.sdc.mobilepass.service.impl;


import java.util.HashMap;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.payegis.sdc.mobilepass.dao.IScanHistoryDao;
import com.payegis.sdc.mobilepass.entity.ScanHistory;
import com.payegis.sdc.mobilepass.service.IScanHistoryService;

@Service
public class ScanHistoryServiceImpl implements IScanHistoryService {

	@Autowired
	private IScanHistoryDao scanHistoryDao;
	
	@Override
	public void addScanContent(ScanHistory scanHistory) {
		scanHistoryDao.save(scanHistory);
		
	}

	@Override
	public List<ScanHistory> getScanHistory(String deviceId,String appId,String partnerCode,String scanHistoryId,Integer isBefore,Integer pageSize,String userId) {
		/*String query="from ScanHistory s where s.userId=:userId";
		
		Map params=new HashMap();
		params.put("userId", userId);
		
		List<ScanHistory> result= scanHistoryDao.getQueryResultList(query, params);*/
		
		StringBuffer queryBuf = new StringBuffer();
		queryBuf.append("select o from ScanHistory o where o.deviceId=:deviceId and o.appId=:appId and o.partnerCode=:partnerCode ");
		HashMap<String, Object> params = new HashMap<String, Object>();
		params.put("deviceId", deviceId);
		params.put("appId", appId);
		params.put("partnerCode", partnerCode);
		
		if(StringUtils.isNotBlank(userId)){
			queryBuf.append(" and o.userId = :userId ");
			params.put("userId", userId);
		}
		if(scanHistoryId!=null&&scanHistoryId.length()>0){
			if(0 == isBefore){
				queryBuf.append(" and o.createTime < (select t.createTime from ScanHistory t where t.id= :scanHistoryId) ");
			}else{
				queryBuf.append(" and o.createTime > (select t.createTime from ScanHistory t where t.id= :scanHistoryId) ");
			}
			params.put("scanHistoryId", scanHistoryId);
		}
		queryBuf.append(" order by o.createTime desc");
		return scanHistoryDao.getQueryResultList(queryBuf.toString(), 0, pageSize, params);
	}

}
