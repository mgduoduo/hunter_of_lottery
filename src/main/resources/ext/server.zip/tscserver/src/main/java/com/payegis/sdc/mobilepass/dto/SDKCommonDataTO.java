package com.payegis.sdc.mobilepass.dto;

import org.apache.commons.lang.StringUtils;

public class SDKCommonDataTO implements java.io.Serializable{

	protected String deviceId;

	protected String appPartner;
	
	protected String partnerCode;

	protected String appId;

	protected String securityKey;
	
	protected String language;

	public String getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}

	public String getAppPartner() {
		if(StringUtils.isNotBlank(appPartner)){
			return appPartner;
		}else{
			return partnerCode;
		}
	}

	public void setAppPartner(String appPartner) {
		this.appPartner = appPartner;
	}

	public String getAppId() {
		return appId;
	}

	public void setAppId(String appId) {
		this.appId = appId;
	}

	public String getSecurityKey() {
		return securityKey;
	}

	public void setSecurityKey(String securityKey) {
		this.securityKey = securityKey;
	}

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	public String getPartnerCode() {
		if(StringUtils.isNotBlank(partnerCode)){
			return partnerCode;
		}else{
			return appPartner;
		}
	}

	public void setPartnerCode(String partnerCode) {
		this.partnerCode = partnerCode;
	}

}
