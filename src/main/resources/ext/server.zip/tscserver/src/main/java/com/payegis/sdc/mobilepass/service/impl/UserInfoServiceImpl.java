package com.payegis.sdc.mobilepass.service.impl;

import com.payegis.sdc.mobilepass.common.Constant;
import com.payegis.sdc.mobilepass.dao.IAlgorithmFileDao;
import com.payegis.sdc.mobilepass.dao.IDynamicAlgorithmDao;
import com.payegis.sdc.mobilepass.dao.IUserInfoDao;
import com.payegis.sdc.mobilepass.dto.BindUserTO;
import com.payegis.sdc.mobilepass.dto.DcCodeTO;
import com.payegis.sdc.mobilepass.dto.SDKCommonDataTO;
import com.payegis.sdc.mobilepass.dto.ShortTokenTO;
import com.payegis.sdc.mobilepass.entity.AlgorithmFileInfo;
import com.payegis.sdc.mobilepass.entity.DynamicAlgorithmInfo;
import com.payegis.sdc.mobilepass.entity.UserInfo;
import com.payegis.sdc.mobilepass.exception.ErrorMsg;
import com.payegis.sdc.mobilepass.exception.HandleException;
import com.payegis.sdc.mobilepass.exception.UserException;
import com.payegis.sdc.mobilepass.service.IDeviceRecordService;
import com.payegis.sdc.mobilepass.service.IUserInfoService;
import com.payegis.sdc.mobilepass.util.*;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.*;
import java.math.BigDecimal;
import java.util.*;


@Service
public class UserInfoServiceImpl implements IUserInfoService {


    private static Logger logger=Logger.getLogger(UserInfoServiceImpl.class);

    //	private static TimeSpaceCodeLogging cloudLog=new TimeSpaceCodeLogging();

    @Autowired
    private IUserInfoDao userinfoDao;

    @Autowired
    private IAlgorithmFileDao algorithmFileDao;

    @Autowired
    private IDynamicAlgorithmDao dynamicAlgorithmDao;

    @Autowired
    private IDeviceRecordService didRecordService;

    /**
     * 绑定用户
     */
    public UserInfo bindUser(BindUserTO bindUserTo) {
        String hql = "from UserInfo o where o.deviceId=:deviceId and o.appPartner=:appPartner and o.appId=:appId and o.externalId=:externalId";
        Map<Object,Object> params = new HashMap<Object,Object>();
        params.put("deviceId", bindUserTo.getDeviceId());
        params.put("appPartner", bindUserTo.getAppPartner());
        params.put("appId", bindUserTo.getAppId());
        params.put("externalId", bindUserTo.getExternalId());
        //根据 deviceId, partnerCode, appId, externalId 查询，
        UserInfo userinfo = userinfoDao.getQueryResult(hql, params);
        //如果用户存在则返回此用户
        if(userinfo!=null){
            userinfo.setUpdateTime(new Date());
            userinfo = userinfoDao.save(userinfo);
            logger.info("bind userId:"+userinfo.getUserId());
            return userinfo;
        }else{
            //如果用户不存在，则新增一条记录，用以支持多类型时空码登录
			/*Modified by Zhangwei , 2014/03/12*/
			/*hql = "from UserInfo o where o.deviceId=:deviceId ";
			params.remove("appPartner");
			params.remove("appId");
			params.remove("externalId");
			userinfo = userinfoDao.getQueryResult(hql, params);
			if(userinfo!=null){
				userinfoDao.remove(userinfo);
			}
			userinfo = new UserInfo();
			String id = UUID.randomUUID().toString();
			userinfo.setId(id);
			userinfo.setAppId(bindUserTo.getAppId());
			userinfo.setAppPartner(bindUserTo.getAppPartner());
			userinfo.setExternalId(bindUserTo.getExternalId());
			userinfo.setDeviceId(bindUserTo.getDeviceId());
			userinfo.setUserId(getUserId());
			userinfo.setCreator(Constant.SYSTEM_USER);
			userinfo.setUpdater(Constant.SYSTEM_USER);
			userinfo = userinfoDao.save(userinfo);*/

			/*修改人:Zhangwei
			 *修改时间:2013/03/12
			 *修改目的：增加新数据以支持多类型时空码
			 */
            userinfo = new UserInfo();
            String id = UUID.randomUUID().toString();
            userinfo.setId(id);
            userinfo.setAppId(bindUserTo.getAppId());
            userinfo.setAppPartner(bindUserTo.getAppPartner());
            userinfo.setExternalId(bindUserTo.getExternalId());
            userinfo.setDeviceId(bindUserTo.getDeviceId());
            userinfo.setUserId(getUserId());
            userinfo.setCreator(Constant.SYSTEM_USER);
            userinfo.setUpdater(Constant.SYSTEM_USER);
            userinfo = userinfoDao.save(userinfo);
        }
        logger.info("bind userId:"+userinfo.getUserId());
        return userinfo;
    }

    /**
     * 获取用户编号
     * @return
     */
    private String getUserId(){
        String userId = null;
        String hql = "from UserInfo o where o.userId=:userId";
        Map<Object,Object> params = new HashMap<Object,Object>();
        do {
            Random generator = new Random();
            StringBuffer sb = new StringBuffer();
            sb.append(String.valueOf((int)((Math.random()*8)+1)));
            for (int i = 1; i < 8; i++) {
                sb.append(Math.abs(generator.nextInt(10)));

            }
            userId = sb.toString();
            params.put("userId", userId);
        } while (userinfoDao.getQueryResult(hql, params)!=null);
        return userId;
    }


    public String checkNewAlgorithm(SDKCommonDataTO sdkCommonDataTo)
            throws Exception {

        String hql = "from DynamicAlgorithmInfo where partnerCode=:partnerCode and status=:status and appId=:appId order by algorithmVersion desc";
        Map<Object,Object> params = new HashMap<Object,Object>();
        params.put("partnerCode", sdkCommonDataTo.getAppPartner());
        params.put("appId","dcsdk");
        params.put("status", "1");
        DynamicAlgorithmInfo algorithmInfo = dynamicAlgorithmDao.getQueryResult(hql, params);
        if(algorithmInfo==null){
            return MessageUtil.jsonMsg("1", CommonUtil.getMessage("error.dcalgorithm.notexists", null, null), null).toString();
        }
        JSONObject json = new JSONObject();
        json.put("version", algorithmInfo.getAlgorithmVersion());
        hql = " from AlgorithmFileInfo where algorithmId=:algorithmId and sysType=:sysType and type=:type";
        params = new HashMap<Object,Object>();
        params.put("algorithmId", algorithmInfo.getId());
        params.put("type", "1");
        if(sdkCommonDataTo.getDeviceId().startsWith("2")){
            params.put("sysType", "IOS");
            AlgorithmFileInfo fileInfo = algorithmFileDao.getQueryResult(hql, params);
            if(fileInfo!=null){
                json.put("fileSize", fileInfo.getFileSize());
                json.put("md5", fileInfo.getAMd5());
                json.put("id", fileInfo.getId());
            }
        }
        if(sdkCommonDataTo.getDeviceId().startsWith("3")){
            params.put("sysType", "ANDROID");
            AlgorithmFileInfo fileInfo = algorithmFileDao.getQueryResult(hql, params);
            if(fileInfo!=null){
                json.put("fileSize", fileInfo.getFileSize());
                json.put("md5", fileInfo.getAMd5());
                json.put("id", fileInfo.getId());
            }
        }
        if(sdkCommonDataTo.getDeviceId().startsWith("4")){
            params.put("sysType", "WINPHONE");
            AlgorithmFileInfo fileInfo = algorithmFileDao.getQueryResult(hql, params);
            if(fileInfo!=null){
                json.put("fileSize", fileInfo.getFileSize());
                json.put("md5", fileInfo.getAMd5());
                json.put("id", fileInfo.getId());
            }
        }
        return MessageUtil.jsonMsg("0", "", json).toString();
    }

    public String getAlgorithmList(SDKCommonDataTO sdkCommonDataTo)
            throws Exception {

        String hql = "from DynamicAlgorithmInfo where partnerCode=:partnerCode and status=:status";
        Map<Object,Object> params = new HashMap<Object,Object>();
        params.put("partnerCode", sdkCommonDataTo.getAppPartner());
        if(!StringUtils.isEmpty(sdkCommonDataTo.getAppId())){
            hql+=" and appId=:appId ";
            params.put("appId", sdkCommonDataTo.getAppId());
        }
        params.put("status", "1");
        List<DynamicAlgorithmInfo> algorithmList = dynamicAlgorithmDao.getQueryResultList(hql, params);
        JSONArray jsonArray = new JSONArray();
        if(!algorithmList.isEmpty()){
            hql = " from AlgorithmFileInfo where algorithmId=:algorithmId and sysType=:sysType and type=:type";
            params = new HashMap<Object,Object>();
            params.put("type", "2");
            if(sdkCommonDataTo.getDeviceId().startsWith("2")){
                params.put("sysType", "IOS");
            }else if(sdkCommonDataTo.getDeviceId().startsWith("3")){
                params.put("sysType", "ANDROID");
            }else if(sdkCommonDataTo.getDeviceId().startsWith("4")){
                params.put("sysType", "WINPHONE");
            }else{
                params.put("sysType", "NOTKONOW");
            }
            for(DynamicAlgorithmInfo algorithmInfo:algorithmList){
                params.put("algorithmId", algorithmInfo.getId());
                AlgorithmFileInfo fileInfo = algorithmFileDao.getQueryResult(hql, params);
                if(fileInfo!=null){
                    JSONObject json = new JSONObject();
                    json.put("version",algorithmInfo.getAlgorithmVersion());
                    json.put("fileSize", fileInfo.getFileSize());
                    json.put("md5", fileInfo.getAMd5());
                    json.put("id", fileInfo.getId());
                    json.put("appId", algorithmInfo.getAppId());
                    jsonArray.add(json);
                }
            }
        }
        return MessageUtil.jsonMsg("0", "", jsonArray).toString();
    }

    public byte[] getAlgorithmFile(String algorithmFileId) throws Exception {

        AlgorithmFileInfo fileInfo =  algorithmFileDao.find(algorithmFileId);
        return fileInfo.getAFile();
    }


    @Deprecated
    private void saveDecryptAlgorithmFileToDisk(DynamicAlgorithmInfo algorithmInfo,AlgorithmFileInfo fileInfo) throws Exception{
        String hql = " from AlgorithmFileInfo where algorithmId=:algorithmId and type=:type ";
        Map<Object,Object> params = new HashMap<Object,Object>();
        params.put("algorithmId", algorithmInfo.getId());
        params.put("type", "3");
        if(fileInfo==null){
            fileInfo = algorithmFileDao.getQueryResult(hql, params);
        }
        if(fileInfo==null){
            throw new HandleException(ErrorMsg.DYNAMICALGORITHM_DECRYPT_NOTFOUND, "");
        }
        BufferedOutputStream bos = null;
        FileOutputStream fos = null;
        File file = null;
        try {
            File dir = new File(ConfigFileUtil.getAlgorithmPath()+File.separator+algorithmInfo.getPartnerCode()+File.separator+algorithmInfo.getAppId()+File.separator+algorithmInfo.getAlgorithmVersion().multiply(new BigDecimal(10)).intValue());
            if(!dir.exists()){//判断文件目录是否存在
                dir.mkdirs();
            }
            file = new File(dir+File.separator+fileInfo.getAFilename());
            fos = new FileOutputStream(file);
            bos = new BufferedOutputStream(fos);
            bos.write(fileInfo.getAFile());
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            throw e;
        } finally {
            if (bos != null) {
                try {
                    bos.close();
                } catch (IOException e1) {
                    e1.printStackTrace();
                }
            }
            if (fos != null) {
                try {
                    fos.close();
                } catch (IOException e1) {
                    e1.printStackTrace();
                }
            }
        }
        //MD5判断文件
        if(!MD5FileUtil.getFileMD5String(file).equals(fileInfo.getAMd5())){
            throw new HandleException(ErrorMsg.SAVEALGORITHM_DISK_ERROR, "");
        }
    }

    @Override
    public UserInfo getDeviceId(BindUserTO bindUserTo)throws Exception {

        String hql = "from UserInfo o where o.appPartner=:appPartner and o.userId=:userId ";
        Map<Object,Object> params = new HashMap<Object,Object>();
        params.put("appPartner", bindUserTo.getAppPartner());
        params.put("userId", bindUserTo.getUserToken());
        if(StringUtils.isNotBlank(bindUserTo.getAppId())){
            hql+="  and o.appId=:appId ";
            params.put("appId", bindUserTo.getAppId());
        }
        UserInfo userinfo = userinfoDao.getQueryResult(hql, params);
        if(userinfo==null){
            throw new HandleException(ErrorMsg.USERTOKEN_CANNOTFOUND, "");
        }
        return userinfo;
    }

    @Override
    public String checkShortToken(ShortTokenTO shortTokenTO) throws Exception {
        String hql = "from UserInfo o where o.deviceId=:deviceId and o.appPartner=:appPartner and o.appId=:appId";
        Map<Object,Object> params = new HashMap<Object,Object>();
        params.put("deviceId", shortTokenTO.getDeviceId());
        params.put("appPartner", shortTokenTO.getPartnerCode());
        params.put("appId", shortTokenTO.getAppId());
        List<UserInfo> userinfoList = userinfoDao.getQueryResultList(hql, params);
        if(userinfoList==null||userinfoList.isEmpty()){
            throw new HandleException(ErrorMsg.USERTOKEN_CANNOTFOUND, "");
        }else{
            //  String info ="";
            for(UserInfo userinfo:userinfoList){
                //info = "当前时间："+System.currentTimeMillis()+",shortToken:"+shortTokenTO.getShortToken()+",deviceId:"+userinfo.getDeviceId()+",userId:"+userinfo.getUserId()+",appId:"+shortTokenTO.getAppId();

                if (TokenUtil.matchToken(shortTokenTO.getShortToken(),  userinfo.getDeviceId()+userinfo.getUserId(),shortTokenTO.getAppId())) {

					/*if(MemCacheMgr.getMemcache( userinfo.getDeviceId()+shortTokenTO.getShortToken())!=null){
						return MessageUtil.jsonMsg("10001",  CommonUtil.getMessage("error.validate.dccode", null, null), null).toString();
					}else{
						MemCacheMgr.setMemcache(userinfo.getDeviceId()+shortTokenTO.getShortToken(), "1111", 60*1000);
						return MessageUtil.jsonMsg("0", CommonUtil.getMessage("succe.validate.dccode", null, null), null).toString();
					}*/
                    return MessageUtil.jsonMsg("0", CommonUtil.getMessage("succe.validate.dccode", null, null), null).toString();
                }
            }
            //logger.info(info);
            logger.info("==================》"+"短码校验失败！");
            return MessageUtil.jsonMsg("10001",  CommonUtil.getMessage("error.validate.dccode", null, null), null).toString();
        }
    }

    @Override
    public String validateDcCode(DcCodeTO dcCodeTO) throws Exception {

        //logger.info(">>>>>>>>>>>>>>>> validateDcCode , dccode:" + dcCodeTO.getDcCode());
        if(dcCodeTO.getDcCode() == null ||
                dcCodeTO.getDcCode().length()!=30	 //如果dc code不是30位
                ){

            throw new HandleException(ErrorMsg.INVALID_TSC_CODE_FORMAT, "");
        }
        String loginCode = dcCodeTO.getDcCode().substring(0, 20);
        String scantime = dcCodeTO.getDcCode().substring(20, 30);
        //String version = loginCode.substring(loginCode.length()-2);
        String version = loginCode.substring(18,20);
        String partnerCode = loginCode.substring(14, 17);
        // logger.info(">>>>>>>>>>>>>>>> validateDcCode , loginCode:" + loginCode );
        //  logger.info(">>>>>>>>>>>>>>>> validateDcCode , version:" + version );
        // logger.info(">>>>>>>>>>>>>>>> validateDcCode , partnerCode:" + partnerCode);
        String appId = "dcsdk";
        String hql = " from DynamicAlgorithmInfo where algorithmVersion=:algorithmVersion and partnerCode=:partnerCode and appId=:appId and status=:status";
        Map<Object,Object> params = new HashMap<Object,Object>();
        params.put("algorithmVersion", (new BigDecimal(version)).divide(new BigDecimal(10)));
        params.put("partnerCode", partnerCode);
        params.put("appId", appId);
        params.put("status", "1");
        DynamicAlgorithmInfo algorithmInfo = dynamicAlgorithmDao.getQueryResult(hql, params);
        if(algorithmInfo==null){
            logger.error(ErrorMsg.DYNAMICALGORITHM_NOTFOUND.getMsg() + ", appId="+appId);
            throw new HandleException(ErrorMsg.DYNAMICALGORITHM_NOTFOUND, "");
        }

        hql = " from AlgorithmFileInfo where algorithmId=:algorithmId and type=:type ";
        params = new HashMap<Object,Object>();
        params.put("algorithmId", algorithmInfo.getId());
        params.put("type", "3");
        AlgorithmFileInfo fileInfo = algorithmFileDao.getQueryResult(hql, params);
        if(fileInfo==null){
            logger.error(ErrorMsg.DYNAMICALGORITHM_DECRYPT_NOTFOUND.getMsg() +", appId="+ appId);
            throw new HandleException(ErrorMsg.DYNAMICALGORITHM_DECRYPT_NOTFOUND, "");
        }

        String path = ConfigFileUtil.getAlgorithmPath()+File.separator+partnerCode+File.separator+appId+File.separator+version+File.separator+fileInfo.getAFilename();
        File file = new File(path);
        if(!file.exists()){
            saveDecryptAlgorithmFileToDisk(algorithmInfo,fileInfo);
        }
        String[] userId_Tokens = getUserId_Token(path,loginCode);
        String userId = userId_Tokens[0];
        String token = userId_Tokens[1];
        if(userId==null||token==null){
            throw new HandleException(ErrorMsg.ALGORITHM_DECRYPT_ERROR, "");
        }
        hql = "from UserInfo o where o.userId=:userId";
        //and o.appId=:appId
        params = new HashMap<Object, Object>();
        params.put("userId", userId);
        //params.put("appId", dcCodeTO.getAppId());
        //logger.info(">>>>****>>>>>>>>>>>> userId , userId:" + userId );
        //logger.info(">>>>****>>>>>>>>>>>> appId , appId:" + dcCodeTO.getAppId());
        UserInfo userinfo = userinfoDao.getQueryResult(hql, params);
        if (userinfo == null) {
            logger.info("userId:"+userId+",dcCode:"+dcCodeTO.getDcCode());
            throw new UserException(ErrorMsg.USER_NOFOUND_ERROR, "");
        }
        recordDid(userinfo.getDeviceId(), dcCodeTO.getAppId(), "verify");
        String result = TokenUtil.matchToken(token,  userinfo.getDeviceId()+userId,Long.valueOf(scantime),dcCodeTO.getAppId());
        logger.info("校验结果："+result);
        if ("0".equals(result)) {
            JSONObject json = new JSONObject();
            json.put("deviceId", userinfo.getDeviceId());
            json.put("externalId", userinfo.getExternalId());
            json.put("userToken", userinfo.getUserId());
            return MessageUtil.jsonMsg("0", "验证成功", json).toString();
        } else if("1".equals(result)){
            return MessageUtil.jsonMsg("10000", "时空码已过期", null).toString();
        }else {
            return MessageUtil.jsonMsg("10002", "无效时空码", null).toString();
        }
    }

    public JSONObject validateQRCodeforTSC(String  dcCode){
        String loginCode = dcCode.substring(0,20);
        String scantime = dcCode.substring(20,30);
        String version = loginCode.substring(18,20);
        String partnerCode = loginCode.substring(14, 17);
        // logger.info(">>>>>>>>>>>>>>>> validateDcCode , loginCode:" + loginCode );
        // logger.info(">>>>>>>>>>>>>>>> validateDcCode , version:" + version );
        // logger.info(">>>>>>>>>>>>>>>> validateDcCode , partnerCode:" + partnerCode);
        String appId = "dcsdk";
        String hql = " from DynamicAlgorithmInfo where algorithmVersion=:algorithmVersion and partnerCode=:partnerCode and appId=:appId and status=:status";
        Map<Object,Object> params = new HashMap<Object,Object>();
        params.put("algorithmVersion", (new BigDecimal(version)).divide(new BigDecimal(10)));
        params.put("partnerCode", partnerCode);
        params.put("appId", appId);
        params.put("status", "1");
        DynamicAlgorithmInfo algorithmInfo = dynamicAlgorithmDao.getQueryResult(hql, params);
        if(algorithmInfo==null){
            //			throw new HandleException(ErrorMsg.DYNAMICALGORITHM_NOTFOUND, "");
            return MessageUtil.jsonMsg("2",  null, null);

        }

        hql = " from AlgorithmFileInfo where algorithmId=:algorithmId and type=:type ";
        params = new HashMap<Object,Object>();
        params.put("algorithmId", algorithmInfo.getId());
        params.put("type", "3");
        AlgorithmFileInfo fileInfo = algorithmFileDao.getQueryResult(hql, params);
        if(fileInfo==null){
            //			throw new HandleException(ErrorMsg.DYNAMICALGORITHM_DECRYPT_NOTFOUND, "");
            return MessageUtil.jsonMsg("2",  null, null);
        }

        String path = ConfigFileUtil.getAlgorithmPath()+File.separator+partnerCode+File.separator+appId+File.separator+version+File.separator+fileInfo.getAFilename();
        File file = new File(path);
        if(!file.exists()){
            try {
                saveDecryptAlgorithmFileToDisk(algorithmInfo,fileInfo);
            } catch (Exception e) {
                logger.error(e.getMessage(), e);
            }
        }
        String[] userId_Tokens = getUserId_Token(path,loginCode);
        String userId = userId_Tokens[0];
        String token = userId_Tokens[1];
        if(userId==null||token==null){
            //throw new HandleException(ErrorMsg.ALGORITHM_DECRYPT_ERROR, "");
            return MessageUtil.jsonMsg("2",  null, null);
        }
        hql = "from UserInfo o where o.userId=:userId";
        params = new HashMap<Object, Object>();
        params.put("userId", userId);
        UserInfo userinfo = userinfoDao.getQueryResult(hql, params);
        if (userinfo == null) {
            //			throw new UserException(ErrorMsg.USER_NOFOUND_ERROR, "");
            return MessageUtil.jsonMsg("2",  null, null);
        }
        String result = TokenUtil.matchToken(token,  userinfo.getDeviceId()+userId,Long.valueOf(scantime),userinfo.getAppId());
        if ("0".equals(result)) {
            JSONObject json = new JSONObject();
            json.put("deviceId", userinfo.getDeviceId());
            json.put("externalId", userinfo.getExternalId());
            json.put("userId", userinfo.getUserId());
            return MessageUtil.jsonMsg("0", "验证成功", json);
        } else if("1".equals(result)){
            return MessageUtil.jsonMsg("1", "", null);
        }else {
            return MessageUtil.jsonMsg("1", "", null);
        }
    }

    private void recordDid(String did, String appId, String stageType){
        //TimeSpaceCodeLogging cloudLog=new TimeSpaceCodeLogging();
        boolean isNew=didRecordService.saveRecord(did);
        //log
        Map params=new HashMap();

        params.put("deviceId",did);
        params.put("deviceType", isNew? "new" : "old" );
        params.put("stageType", stageType);

        //		cloudLog.businessLog(appId,new Date(), params);
        //		cloudLog.reportingLog(appId, new Date(), params);//ass5533

    }

    public synchronized String[] getUserId_Token(String path,String loginCode){
        DecodeNumber dn = new DecodeNumber(path);
        String userId = dn.getDecodeSO().getUserAccount(loginCode);
        String token = dn.getDecodeSO().getToken(loginCode);
        return new String[]{userId,token};
    }


    public void  saveAhgorithmleToDb(){
        AlgorithmFileInfo af = algorithmFileDao.find("f1d01f20-7d95-4e77-be35-40a98fed97e6");

        byte[] buffer = null;
        try
        {
            File file = new File("C:\\Users\\zzg\\Desktop\\时空码算法so文件_20151029\\解密\\libDcDecryptSzb11.so");
            FileInputStream fis = new FileInputStream(file);
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] b = new byte[1024];
            int n;
            while ((n = fis.read(b)) != -1)
            {
                bos.write(b, 0, n);
            }
            fis.close();
            bos.close();
            buffer = bos.toByteArray();
        }
        catch (FileNotFoundException e)
        {
            e.printStackTrace();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
        af.setAFile(buffer);
        algorithmFileDao.save(af);
    }
}
