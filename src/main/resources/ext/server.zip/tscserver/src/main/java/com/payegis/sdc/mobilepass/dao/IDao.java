package com.payegis.sdc.mobilepass.dao;

import java.util.List;
import java.util.Map;


public interface IDao<T,PK> {

	public T save(T entity) ;

	public void removeById(PK id);

	public void remove(T entity);

	public int executeUpdate(String queryName, Map<String, Object> params);

	
	public List getCustomQueryResultList(String query, int firstResult, int maxResults,Map<String,Object> params);
	public List getCustomQueryResultList(String query, Map<String,Object> params);


	public List<T> getQueryResultList(String query, int firstResult, int maxResults);
	public List<T> getQueryResultList(String query, int firstResult, int maxResults, Map<String,Object> params);
	public List<T> getQueryResultList(String query, Map<Object, Object> params);
	public List<T> getObjectList(Class<T> clz);

	public Object getObject(String queryName, Map<String, Object> params);
	public T getQueryResult(String query, Map<Object, Object> params);

	public boolean exists(PK id);

	public T find(PK id);

	public List getNativeQueryResult(String query, Map<Object, Object> params);
	
	public int executeNativeUpdate(String query, Map<Object, Object> params);
	
	public Object getObject(String query);

}
