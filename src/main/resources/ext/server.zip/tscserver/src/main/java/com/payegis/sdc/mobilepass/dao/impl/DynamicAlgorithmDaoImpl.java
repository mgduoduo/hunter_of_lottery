package com.payegis.sdc.mobilepass.dao.impl;

import org.springframework.stereotype.Repository;

import com.payegis.sdc.mobilepass.dao.BaseJPADao;
import com.payegis.sdc.mobilepass.dao.IDynamicAlgorithmDao;
import com.payegis.sdc.mobilepass.entity.DynamicAlgorithmInfo;



@Repository
public class DynamicAlgorithmDaoImpl extends BaseJPADao<DynamicAlgorithmInfo,String> implements IDynamicAlgorithmDao {


}
