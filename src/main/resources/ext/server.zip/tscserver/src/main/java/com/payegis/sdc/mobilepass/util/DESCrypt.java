package com.payegis.sdc.mobilepass.util;

import org.apache.log4j.Logger;

import javax.crypto.Cipher;
import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.security.Key;
import java.security.Security;

public class DESCrypt {
	private String compressKey = "";
	private static String strDefaultKey = "payegis2010";
	private static String ENCODE_STYLE = "GB2312";
	private static String CRYPT_STYLE = "DESede";
	private static String FILL_SYMBOL = " ";
	private static int contextSize = 8 * 3 - 1;
	private final static int PARAMETER = 64;
	private final static int EIGHT = 8;
	private final static int KEY_SIZE = 8 * 3;
	private final static int CHEAKSUM = 2;
	private final static int MAX_CHEAK_FILL_SIZE = 7;

	private final static int DEVICEID_SIZE = 26;
	private final static int DEVICEID_SEPERATOR_SIZE = 2;

	private final static char[] DIGITS = { '0', 'w', '2', 'y', '4', 'O', '6',
			'%', '8', '*', 'A', '$', 'g', 'D', 'j', 'F', 'l', 'H', 'n', 'K',
			'p', 'M', 'r', 'P', 't', 'a', 'T', 'c', 'W', 'e', 'Y', 'Z', 'S',
			'b', 'U', 'd', 'X', 'f', 'C', 'h', 'E', 'k', 'G', 'm', 'J', 'o',
			'L', 'q', 'N', 's', 'R', 'u', 'v', '1', 'x', '3', 'z', '5', 'V',
			'7', '&', '9', '~', 'B', };

	private Cipher encryptCipher = null;
	private Cipher decryptCipher = null;

	private static Logger logger = Logger.getLogger(DESCrypt.class);

	public DESCrypt() throws Exception {
		this(strDefaultKey);
	}

	@SuppressWarnings("restriction")
	public DESCrypt(String strKey) throws Exception {
		int tmpLength;
		compressKey = this.compressKey(strKey);
		tmpLength = KEY_SIZE - compressKey.length();
		for (int i = 0; i < tmpLength; i++) {
			compressKey = compressKey + "0";
		}
		/*logger.info("compressKey: " + compressKey + " length: "
				+ compressKey.length());*/
		Security.addProvider(new com.sun.crypto.provider.SunJCE());
		Key key = getKey(compressKey.getBytes());
		encryptCipher = Cipher.getInstance(CRYPT_STYLE);
		encryptCipher.init(Cipher.ENCRYPT_MODE, key);
		decryptCipher = Cipher.getInstance(CRYPT_STYLE);
		decryptCipher.init(Cipher.DECRYPT_MODE, key);
	}

	public String getEncString(String strMing) {
		String beforeCheakSum = "";
		String formatStrMing = "";
		try {
			formatStrMing = formatStrMing(strMing);
			beforeCheakSum = byteArr2HexStr(encrypt(formatStrMing
					.getBytes(ENCODE_STYLE)));
			formatStrMing = beforeCheakSum + addCheakSum(beforeCheakSum);
			return formatStrMing;
		} catch (UnsupportedEncodingException e) {
			logger.error("encode fail, return null.");
		} catch (Exception e) {
			logger.error("decode fail, return null.");
		}
		return null;
	}

	public String getDesString(String strMi) {
		String decode;
		String cheakSum = strMi.substring(strMi.length() - CHEAKSUM,
				strMi.length());
		String deduceCheakSum = strMi.substring(0, strMi.length() - CHEAKSUM);
		/*logger.info("cheakSum: " + cheakSum + " deduceCheakSum: "
				+ deduceCheakSum);*/
		try {
			if (vertifyModify(deduceCheakSum, cheakSum)) {
				return null;
			} else {
				decode = new String(decrypt(hexStr2ByteArr(deduceCheakSum)),
						ENCODE_STYLE);
			}
			decode = cleanDecode(decode);
			return decode;
		} catch (UnsupportedEncodingException e) {
			logger.error("'UnsupportedEncodingException' decode fail, return null.");
		} catch (Exception e) {
			logger.error("'Exception decode fail', return null.");
		}
		return null;
	}

	private String cleanDecode(String decode) {
		int cheakFillSize = 0;
		int decodeSize = 0;
		int tmpDecodeSize = 0;
		String tmpDecode = "";
		String cleanDecode = "";
		decodeSize = decode.length();
		tmpDecode = decode.substring(decodeSize - MAX_CHEAK_FILL_SIZE,
				decodeSize);
		tmpDecodeSize = tmpDecode.length();
		for (int i = 0; i < tmpDecodeSize; i++) {
			if (("" + tmpDecode.charAt(tmpDecodeSize-i-1)).equals(FILL_SYMBOL)) {
				cheakFillSize = cheakFillSize + 1;
			}else{
				break;
			}
		}
		cleanDecode = decode.substring(0, decodeSize - cheakFillSize);
		return cleanDecode;
	}

	private String formatStrMing(String strMing)
			throws UnsupportedEncodingException {
		int tmpLength = 0;
		try {
			tmpLength = strMing.getBytes(ENCODE_STYLE).length;
		} catch (UnsupportedEncodingException e) {
			logger.error(e.getMessage(), e);
		}
		contextSize = getContextSize(tmpLength);
		for (int i = 0; i < contextSize - tmpLength; i++) {
			strMing = strMing + FILL_SYMBOL;
		}
		/*logger.info("strMing: " + strMing + " length: "
				+ strMing.getBytes(ENCODE_STYLE).length);*/
		return strMing;
	}

	private int getContextSize(int tmpLength) {
		int tmpSize;
		tmpSize = (tmpLength / EIGHT + 1) * EIGHT;
		return (tmpSize - 1);
	}

	private String addCheakSum(String beforeCheakSum) {
		byte sum = 0;
		int tmpLength = 0;
		byte[] contextAddKey = (beforeCheakSum + compressKey).getBytes();
		tmpLength = contextAddKey.length;
		for (int i = 0; i < tmpLength; i++) {
			sum = (byte) (sum + contextAddKey[i]);
		}
		try {
			return byteArr2HexStr(sum);// 2
		} catch (Exception e) {
		}
		return null;
	}

	private boolean vertifyModify(String deduceCheakSum, String factCheakSum) {
		String computeCheakSum = addCheakSum(deduceCheakSum);
		if (computeCheakSum.equals(factCheakSum)) {
			return false;
		} else {
			logger.warn("cheaksum error.");
			return true;
		}
	}

	public String getDesStr(String strMi) {
		String ming = null;
		try {
			ming = new String(decrypt(hexStr2ByteArr(strMi)), ENCODE_STYLE);
		} catch (Exception e) {
			ming = strMi;
		}
		return ming;
	}

	private static String byteArr2HexStr(byte... arrB) throws Exception {
		int iLen = arrB.length;
		StringBuffer sb = new StringBuffer(iLen * 2);
		for (int i = 0; i < iLen; i++) {
			int intTmp = arrB[i];
			while (intTmp < 0) {
				intTmp = intTmp + 256;
			}
			if (intTmp < 16) {
				sb.append("0");
			}
			sb.append(Integer.toString(intTmp, 16));
		}
		return sb.toString();
	}

	private static byte[] hexStr2ByteArr(String strIn) throws Exception {
		byte[] arrB = strIn.getBytes();
		int iLen = arrB.length;
		byte[] arrOut = new byte[iLen / 2];
		for (int i = 0; i < iLen; i = i + 2) {
			String strTmp = new String(arrB, i, 2);
			arrOut[i / 2] = (byte) Integer.parseInt(strTmp, 16);
		}
		return arrOut;
	}

	private String compressKey(String strKey) {
		String compressKey;
		BigInteger tmpBigInteger = null;
		String formatDeviceId = formatDeviceId(strKey);
		try {
			tmpBigInteger = new BigInteger(formatDeviceId);
		} catch (Exception e) {
			logger.warn("the key is not a number string completely.");
			return formatDeviceId;
		}
		compressKey = numericToString(tmpBigInteger, PARAMETER);
		return compressKey;
	}

	private String formatDeviceId(String str) {
		String stringBuffer;
		String[] tmpStringBuffer;
		tmpStringBuffer = str.split("-");
		if (tmpStringBuffer.length != (DEVICEID_SEPERATOR_SIZE + 1)
				|| str.length() != DEVICEID_SIZE) {
			logger.warn("key is not the deviceid style.");
			return str;
		}
		stringBuffer = tmpStringBuffer[0] + tmpStringBuffer[1]
				+ tmpStringBuffer[2];
		return stringBuffer;
	}

	private String numericToString(BigInteger a, int system) {
		BigInteger num = new BigInteger("0");
		BigInteger tmpBigIntegerSystem;
		long numTmp = (long) 2 * 0x7fffffff + 2;
		if (a.compareTo(new BigInteger("0")) == -1) {
			num = a.add(BigInteger.valueOf(numTmp));
		} else {
			num = a;
		}
		char[] buf = new char[PARAMETER];
		int charPos = PARAMETER;
		tmpBigIntegerSystem = new BigInteger(String.valueOf(system));
		while (num.divide(tmpBigIntegerSystem).compareTo(new BigInteger("0")) == 1) {
			buf[--charPos] = DIGITS[(num.mod(tmpBigIntegerSystem)).intValue()];
			num = num.divide(tmpBigIntegerSystem);
		}
		buf[--charPos] = DIGITS[(num.mod(tmpBigIntegerSystem)).intValue()];
		return new String(buf, charPos, (PARAMETER - charPos));
	}

	private byte[] encrypt(byte[] arrB) throws Exception {
		return encryptCipher.doFinal(arrB);
	}

	private byte[] decrypt(byte[] arrB) throws Exception {
		return decryptCipher.doFinal(arrB);
	}

	private Key getKey(byte[] arrBTmp) throws Exception {
		byte[] arrB = new byte[KEY_SIZE];
		for (int i = 0; i < arrBTmp.length && i < arrB.length; i++) {
			arrB[i] = arrBTmp[i];
		}
		Key key = new javax.crypto.spec.SecretKeySpec(arrB, CRYPT_STYLE);
		return key;
	}
}