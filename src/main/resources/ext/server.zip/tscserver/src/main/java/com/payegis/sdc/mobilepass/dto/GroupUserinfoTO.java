package com.payegis.sdc.mobilepass.dto;

public class GroupUserinfoTO extends FriendUserinfoTO{
	
	public String groupUserType;
	
	public String getGroupUserType() {
		return groupUserType;
	}

	public void setGroupUserType(String groupUserType) {
		this.groupUserType = groupUserType;
	}

}
