package com.payegis.sdc.mobilepass.exception;

import javax.security.sasl.AuthenticationException;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

import org.apache.log4j.Logger;

import com.payegis.sdc.mobilepass.util.CommonUtil;
import com.payegis.sdc.mobilepass.util.MessageUtil;

@Provider
public class JerseyExceptionMapper implements ExceptionMapper<Exception> {

	protected Logger log = Logger.getLogger(JerseyExceptionMapper.class);

	//private static final String INTERNAL_ERROR = "服务器异常";
//	private static final String URL_ERROR = "地址错误";

	public Response toResponse(Exception e) {
		log.info(">>>>>>>>>> System error.", e);
		
		String message ;
		if(e instanceof AuthenticationException){
			message = MessageUtil.jsonExceptionMsg(ErrorMsg.AUTH_ERROR.getCode(), ErrorMsg.AUTH_ERROR.getMsg());

			return Response.status(Response.Status.OK)
					.header("Content-Type", "application/json;charset=UTF-8")
					.entity(message)
					.build();
		}else if(e instanceof BaseException){

			if(((BaseException) e).getErrorMsg().getCode() == 11){
				log.error(e.getMessage(), e);
			}else{				
				log.warn(e.getMessage(), e);
			}
			message = MessageUtil.jsonExceptionMsg(((BaseException) e).getErrorMsg().getCode(),((BaseException) e).getRetMsg());
			return Response.status(Response.Status.OK)
					.header("Content-Type", "application/json;charset=UTF-8")
					.entity(message)
					.build();
		}else if(e instanceof com.sun.jersey.api.NotFoundException){

			message = MessageUtil.jsonExceptionMsg(1000, CommonUtil.getMessage("error.url", null, null));

			return Response.status(Response.Status.OK)
					.header("Content-Type", "application/json;charset=UTF-8")
					.entity(message)
					.build();
		}else if(e instanceof java.lang.IllegalArgumentException){
			message = MessageUtil.jsonExceptionMsg(ErrorMsg.SYSTEM_ARGMENTS_ERROR.getCode(), ErrorMsg.SYSTEM_ARGMENTS_ERROR.getMsg());

			return Response.status(Response.Status.OK)
					.header("Content-Type", "application/json;charset=UTF-8")
					.entity(message)
					.build();
		}
		log.error(CommonUtil.getMessage("error.server", null, null), e);
		message = MessageUtil.jsonExceptionMsg(-1, CommonUtil.getMessage("error.server", null, null));
		return Response.status(Response.Status.BAD_REQUEST)
				.header("Content-Type", "application/json;charset=UTF-8")
				.entity(message)
				.build();
	}
}
