package com.payegis.sdc.mobilepass.common;

public interface Constant {


	public String SYSTEM_USER="system";

	public String USER_TYPE_NORMAL="N";
	public String USER_TYPE_QUICK="Q";

	public String API_STATUS_SUCCESS="0"; //成功代码
	public String API_STATUS_FAIL="10";   //错误代码

	/* Added by Zhangwei, 2014/0311 */
	public String API_STATUS_HAS_TSC="5"; //是否含有时空码密码
	
	public String API_STATUS_CERTIFICATE_ERROR="11"; //扫码登录失败

	public String JSON_KEY_STATUS="status";
	public String JSON_KEY_MESSAGE="message";
	public String JSON_KEY_DATA="data";

	public String PESDK_HOME="pesdk_home";
	
	public String KEY_CODE_EXPIRE_TIME="code.expire.time";
	public String KEY_SERVICE_PHONE="service.phone";
	public String KEY_AUTH_URL="auth.url";
	public String KEY_AUTH_API="auth.api";
	public String KEY_AUTH_SERVER_TSC_CODE="auth.server.tsc.code";
	public String KEY_AUTH_SERVER_PASS_CODE="auth.server.pass.code";
	
	public String KEY_CHECK_XMPP_ONLINE_URL="userstatus.url";
	
	//public String TSC_SERVICE_CODE="TimeSpaceCode";
	
	//返回结果
		interface Result{
			
			public String STATUS = "status";
			
			public String MESSAGE = "message";
			
			public String DATA = "data";
			
		}
		
		interface Parameter{
			
			public String REQUEST_DATA = "requestData";
			
			public String COMMON_DATA = "commonData";
			
			public String ALGORITHMFILEID = "algorithmFileId";
			
			/**
			 * 合作号
			 */
			public String APP_PARTNER = "appPartner";
			
			/**
			 * 应用名称
			 */
			public String APP_ID = "appId";
			
			/**
			 * 安全码
			 */
			public String SECURITYKEY = "securityKey";
			
			/**
			 * 用户编号
			 */
			public String UID = "uid";
			
			public String QRCODE = "qrCode";
			
		}
		
		public String PARTNER_CODE="004";
		public String DEFAULT_ROLE="admin";
		
		public String MEMCACHE_HEAD="tscsecurid_timeoffset_";

}
