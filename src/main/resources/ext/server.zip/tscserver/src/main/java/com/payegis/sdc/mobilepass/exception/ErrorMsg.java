package com.payegis.sdc.mobilepass.exception;

import java.text.MessageFormat;

import com.payegis.sdc.mobilepass.util.CommonUtil;

public enum ErrorMsg {
	
	//argu format exception
	AUTH_ERROR(10000, "error.auth.error"),
	ARGU_NULL_ERROR(10001,"error.validate.cannot.empty"),
	LISENCE_ERROR(10002,"error.validate.lisence"),
//	QRCODE_FORMART_ERROR(10003,"支付码格式不正确"),
	USER_NOFOUND_ERROR(10004,"error.user.not.exists"),
//	QRCODE_VALIDATE_NOPASS(10005,"支付码验证不通过"),
//	MERCHANT_POS_NOTFOUND(10005,"当前POS未绑定商户"),
//	MERCHANT_POS_NOTLOGOUT(10006,"当前POS没有签出，请联系{0}将其签出"),
//	MERCHANT_LOGIN_ERROR(10007,"用户名密码错误"),
//	MERCHANT_POS_APPPARTNERDIFF(10008,"POS机对应商户的合作者代码与当前合作者代码不一致"),
//	USER_NOTFIND_ROLE(10009,"用户角色不存在"),
//	//MERCHANT_POS_HASLOGOUT(10010,"当前POS已经签出，无需再次签出"),
//	MERCHANT_NOTFOUND(10011,"商户不存在"),
//	MERCHANT_POS_HASBIND(10012,"当前POS已经绑定商户"),
//	NWEPWD_CONFIRMPWD_DIFF(10013,"新密码和确认密码不一致"),
//
//    MERCHANT_CREATE_MERCHANT_EXIST(10014,"商户已存在"),
//
//    MERCHANT_CREATE_MERCHANT_USER_EXIST(10015,"商户用户已存在"),
//
//    MERCHANT_UPDATE_MERCHANT_NOT_EXIST(10016,"商户不存在"),
    SYSTEM_ARGMENTS_ERROR(10017,"error.param"),
//    ALGORITHMINFO_HASENABLE(10018,"动态算法已经启用，无法修改"),
//    ALGORITHMINFO_HASWASTE(10019,"动态算法已经废弃，无法修改"),
//    ENCRYPT_IOS_MD5_ERROR(10020,"IOS加密算法文件MD5验证不通过"),
//    ENCRYPT_ANDROID_MD5_ERROR(10021,"ANDROID加密 算法文件MD5验证不通过"),
//    VALIDATE_IOS_MD5_ERROR(10022,"IOS验证 算法文件MD5验证不通过"),
//    VALIDATE_ANDROID_MD5_ERROR(10023,"ANDROID验证算法文件MD5验证不通过"),
//    DECRYPT_MD5_ERROR(10024,"解密算法文件MD5验证不通过"),
    DYNAMICALGORITHM_NOTFOUND(10025,"error.alorithm.nofound"),
//    DYNAMICALGORITHM_CANNOTENABLED(10026,"动态算法文件不全,无法设置为启用状态"),
//    USER_NOTFIND(10027,"用户不存在"),
    DYNAMICALGORITHM_DECRYPT_NOTFOUND(10028,"error.decryptalorithm.cannot.found"),
    SAVEALGORITHM_DISK_ERROR(10029,"error.savealorithm.todisk"),
    ALGORITHM_DECRYPT_ERROR(10030,"error.alorithm.decrypt"),
//    MERCHANT_UPDATEPWD_ERROR(10031,"原密码错误"),
//    DYNAMICALGORITHM_CANNOTDELETE(10032,"动态算法未禁用，无法删除"),
    INVALID_TSC_CODE_FORMAT(10034, "error.tsccode.format"),
    USERTOKEN_CANNOTFOUND(10033,"error.dcserver.nologin"),
	AUTHORIZE_NOTALLOW(10034,"error.authorize.notallow");
	
	

	private String msg;
	private int code;

	private ErrorMsg(int code, String msg){
		this.msg = msg;
		this.code = code;
	}

	public String getMsg() {
		return CommonUtil.getMessage(msg, null, null);
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	public int getCode() {
		return code;
	}
	public void setCode(int code) {
		this.code = code;
	}
	
	public String tipMsg(Object...objects){
		return MessageFormat.format(msg, objects);
	}

	/*public String retMsg(Object...objects){
		return MessageUtil.jsonExceptionMsg(code, MessageFormat.format(msg, objects));
	}*/
	
	public String retMsg(Object...objects){
		return CommonUtil.getMessageForPlaceholder(msg, objects, null);
		//return  MessageFormat.format(msg, objects);
	}

}
