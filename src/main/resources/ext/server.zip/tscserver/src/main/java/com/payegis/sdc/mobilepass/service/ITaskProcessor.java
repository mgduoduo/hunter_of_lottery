package com.payegis.sdc.mobilepass.service;

public interface ITaskProcessor {
	
	public void deleteExpireUserInfo();


}
