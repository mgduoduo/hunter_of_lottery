package com.payegis.sdc.mobilepass.util;

import net.spy.memcached.MemcachedClient;
import org.apache.log4j.Logger;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;



public class MemCacheMgr {
	private static Logger logger = Logger.getLogger(MemCacheMgr.class);
	
	
	private static MemcachedClient memcachedClient = null;

	private static void initMemcached() {
		
	}

	private static void destroyMemcached() {
		if (null != memcachedClient) {
			memcachedClient.shutdown();
		}
		logger.info("destroy memcached success");
	}

	
	public static void setMemcache(String key, Object value, int expTime) {
		try {
			MemcachedClient client = getMemcachedClient();
			Future<Boolean> b = client.set(key, expTime, value);
			/*if (b.get().booleanValue()) {
				logger.info("set value:" + value + " key:" + key);
			}*/
		} catch (Exception ex) {
			logger.error("set memcached error", ex);
			//throw new Exception("set memcached error", ex);
		}
	}

	/**
	 * description: 获取到缓冲的数据或对象.
	 * 
	 * @param key
	 *            查询条件 key
	 * @return Object key对应value
	 * **/
	public static Object getMemcache(String key) {
		Object result = null;
		Future<Object> f = null;
		try {
			MemcachedClient client = getMemcachedClient();
			f = client.asyncGet(key);
			result = f.get(5, TimeUnit.SECONDS);
			//logger.info("get value:" + result + " key:" + key);
		} catch (TimeoutException e) {
			if (null != f) {
				f.cancel(false);
			}
		} catch (Exception ex) {
			logger.error("get memcached error.", ex);
			//throw new Exception("get memcached error.", ex);
		}
		return result;
	}

	/**
	 * description: 清除所有缓存的数据
	 * **/
	public static void flushMemcache(String host) {
		try {
			MemcachedClient client = getMemcachedClient();
			client.flush();
		} catch (Exception e) {
			logger.error("flush memcached error", e);
			//throw new Exception("flush memcached error", e);
		}
	}

	public static MemcachedClient getMemcachedClient() throws IOException {
		if (null == memcachedClient) {
			memcachedClient = new MemcachedClient(new InetSocketAddress(
					ConfigFileUtil.getMemCacheAddress(), ConfigFileUtil.getMemCachePort()));
		}
		return memcachedClient;
	}
	
	public static void delete(String key){
		try {
			MemcachedClient client = getMemcachedClient();
			client.delete(key);
		} catch (IOException e) {
			logger.error("delete error."+e.getMessage(), e);
		}
	}

}
