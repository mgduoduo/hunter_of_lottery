package com.payegis.sdc.mobilepass.dao;

import com.payegis.sdc.mobilepass.entity.DynamicAlgorithmInfo;



public interface IDynamicAlgorithmDao  extends IDao<DynamicAlgorithmInfo,String>{
	
}
