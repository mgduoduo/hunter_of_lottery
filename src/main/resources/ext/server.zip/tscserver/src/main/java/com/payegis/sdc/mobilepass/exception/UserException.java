package com.payegis.sdc.mobilepass.exception;

public class UserException extends BaseException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public UserException(ErrorMsg msg, Object...arg){
		super(msg, arg);
	}
	
}
