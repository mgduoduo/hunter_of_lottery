package com.payegis.sdc.mobilepass.common;

public interface MessageConstant {

	
	public interface Error{
		public String ERROR_ACCOUNT_NOT_MATCH                           ="error.account.not.match";
		public String ERROR_APP_NOT_REGISTER                            ="error.app.not.register";
		public String ERROR_CANNOT_DUPLIDATE_BIND                       ="error.cannot.duplicate.bind";
		public String ERROR_CHECK_DEVICEID_FAIL                         ="error.check.deviceid.fail";
		public String ERROR_DEVICE_ALREADY_BOUND                        ="error.device.already.bound";
		public String ERROR_DEVICE_NOT_BOUND                            ="error.device.not.bound";
		public String ERROR_FIELD_MANDATORY                             ="error.field.mandatory";
		public String ERROR_PASSWORD_INCORRECT                          ="error.password.incorrect";
		public String ERROR_OLDPASSWORD_INCORRECT                       ="error.oldpassword.incorrect";
		public String ERROR_USE_ACCOUNT_LOGIN                           ="error.use.account.login";
		public String ERROR_USER_EXISTS                                 ="error.user.exists";
		public String ERROR_USER_NOT_BOUND                              ="error.user.not.bound";
		public String ERROR_USER_NOT_EXISTS                             ="error.user.not.exists";
		public String ERROR_USER_HAS_JOIN                               ="error.user.has.join";
		public String ERROR_USER_NAME_PASSWORD_INCORRECT                ="error.username.pwd.incorrect";
		public String ERROR_USER_BOUND_ALREADY                          ="error.user.bound.already";
		public String ERROR_3RD_USER_NOT_EXISTS                         ="error.3rd.user.not.exists";
		public String ERROR_BIND_OTHERUSER                              ="error.bind.otheruser";
		public String ERROR_UERR_NOT_ALREADY_OTHER                      ="error.user.bound.already.other";
		
		
		public String ERROR_CERTIFICATE_NOTBIND                         ="error.certificate.notbind";
		public String ERROR_CERTIFICATE_DIFFERENT                       ="error.certificate.different";
		public String ERROR_CERTIFICATE_HAS_BIND                        ="error.certificate.has.bind";
		public String ERROR_CERTIFICATE_HAS_BIND_OTHER                  ="error.certificate.has.bind.other";
		public String ERROR_CERTIFICATE_CANNOT_BIND_EACH_OTHER          ="error.certificate.cannot.bind.each.other";
		
		public String ERROR_GROUP_NAME_EXISTS                           ="error.group.name.exists";
		public String ERROR_FRIENDS_NOT_EXISTS                          ="error.friends.not.exists";
		public String ERROR_INSUFFICIENT_PERMISSIONS                    ="error.Insufficient.permissions";
		
		public String ERROR_GROUP_USER_NOT_EXISTS                       ="error.group.user.not.exists";
		
		public String ERROR_GROUP_OWNER_CANNOT_DELETE                   ="error.group.owner.cannot.delete";
		public String ERROR_GROUP_NOT_EXISTS                            ="error.group.not.exists";
		public String ERROR_GROUP_CANNOT_JOIN                           ="error.group.cannot.join";
		public String ERROR_GROUP_HAS_JOIN                              ="error.group.has.join";
		public String ERROR_GROUP_NOT_JOIN                              ="error.group.not.join";
		
		public String ERROR_CHATGROUP_OVERSTEPQUOTA                     ="error.chatgroup.overstepquota";
	}
	
	public interface Alert{
		public String ALERT_SUCCESS                                     ="alert.success";
		public String ALERT_FAIL                                        ="alert.fail";
		public String ALERT_LOGIN_SUCCESS                               ="alert.login.success";
		public String ALERT_REGISTER_SUCCESS                            ="alert.register.success";
		public String ALERT_BIND_3RD_SUCCESS                            ="alert.bind.3rd.success";
		public String ALERT_UNBIND_3RD_SUCCESS                          ="alert.unbind_3rd_success";
		public String ALERT_UNBIND_SUCCESS                              ="alert.unbind.success";
		public String ALERT_BIND_SUCCESS                                ="alert.bind.success";
		public String ALERT_CHANGE_PWD_SUCCESS                          ="alert.change.pwd.success";
		public String ALERT_SAVE_ICON_SUCCESS                           ="alert.save.icon.success";
		public String ALERT_CHANGE_SUCCESS                              ="alert.change.success";
		public String ALERT_USE_TSC_LOGIN                               ="alert.change.success";
		public String ALERT_CHAT_NOTIC                                   ="alert.chat.notic";
		
		public String ALERT_DELETE_GROUP_SUCCESS                        ="alert.delete.group.success";  //删除空间成功消息
		public String ALERT_LOGOUT_GROUP_SUCCESS                        ="alert.logout.group.success";  //成员主动退出群消息
		public String ALERT_DELETE_GROUP_USER_SUCCESS                   ="alert.delete.group.user.success"; //删除空间成员消息
		
		/*消息或会话列表中显示*/
		public String ALERT_QUICKLOGINSUCCESS_NOTIC                      ="alert.quickloginsuccess.notic";
		
		public String ALERT_QUICKBINDINGSUCCESS_NOTIC                    ="alert.quickbindingsuccess.notic";
		
		public String ALERT_TOBEFRIENDSUCCESS_NOTIC                      ="alert.tobefriendsuccess.notic";
		
		public String ALERT_DELETECHATGROUPUSERBYOWERSUCCESS_NOTIC       ="alert.deletechatgroupuserbyowersuccess.notic";
		
		public String ALERT_DELETECHATGROUPUSERBYSELFSUCCESS_NOTIC       ="alert.deletechatgroupuserbyselfsuccess.notic";
		
		public String ALERT_DELETEBYCHATGROUPOWNER_NOTIC                 ="alert.deletebychatgroupowner.notic";
		
		public String ALERT_CHATGROUOPDISMISS_NOTIC                      ="alert.chatgroupdismiss.notic";
		
		public String ALERT_CHATGROUOPAUTODISMISS_NOTIC                  ="alert.chatgroupautodismiss.notic";
		
		
		public String ALERT_UPDATEMARKNAMESUCCESS                        ="alert.updatemarknamesuccess";
	}
	
	public interface displaytype{
		public String CHAT="chat";
		public String GROUP="group";
		public String OPERATE="operate";
	}
	
	public interface JSONKEY{
		public String REFRESH_CONTACT="refresh_contact";
		public String REMOVE_FRIEND="remove_friend";
		
	}

}
