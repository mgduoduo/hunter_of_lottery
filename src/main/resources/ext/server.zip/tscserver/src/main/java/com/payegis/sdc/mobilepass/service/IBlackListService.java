package com.payegis.sdc.mobilepass.service;

import com.payegis.sdc.mobilepass.entity.BlackList;


public interface IBlackListService {
	
	public BlackList findBlankList(String url);

}
