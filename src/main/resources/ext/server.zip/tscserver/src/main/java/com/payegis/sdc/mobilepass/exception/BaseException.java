package com.payegis.sdc.mobilepass.exception;


public class BaseException extends Exception {
    private ErrorMsg errorMsg;

	/**
	 * 
	 */
	private static final long serialVersionUID = 4162784590101673717L;
	
	private String retMsg;
	
	public BaseException(String msg){
		super(msg);
	}
	
	public BaseException(){
		super();
	}
	
	public String getRetMsg() {
		return retMsg;
	}

	public void setRetMsg(String retMsg) {
		this.retMsg = retMsg;
	}

    public ErrorMsg getErrorMsg() {
        return errorMsg;
    }

    public void setErrorMsg(ErrorMsg errorMsg) {
        this.errorMsg = errorMsg;
    }

    public BaseException(ErrorMsg msg, Object...arg){
        this(msg.tipMsg(arg));
        this.setErrorMsg(msg);
        this.setRetMsg(msg.retMsg(arg));
    }
}
