package com.payegis.sdc.mobilepass.entity;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.persistence.Version;

import org.apache.commons.lang.StringUtils;

@MappedSuperclass
public class GenericEntity {

	protected String creator;
	protected Date createTime;
	protected String updater;
	protected Date updateTime;
	protected int version;
	
	protected Map relatedMap;
	
	public void addRelateObj(String key, Object obj){
		if(relatedMap==null){
			relatedMap=new HashMap();
		}
		relatedMap.put(key,obj);
	}
	
	@Transient
	public Object getRelateObj(String key){
		if(relatedMap==null){
			relatedMap=new HashMap();
		}
		return relatedMap.get(key);
	}

	@Column(name = "creator")
	public String getCreator() {
		return creator;
	}

	public void setCreator(String creator) {
		if(StringUtils.isBlank(creator)){
			this.creator="system";
		}
		
		this.creator = creator;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "create_time")
	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	@Column(name = "updater")
	public String getUpdater() {
		return updater;
	}

	public void setUpdater(String updater) {
		if(StringUtils.isBlank(updater)){
			this.updater="system";
		}
		this.updater = updater;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "update_time")
	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	@Version
	@Column(name = "version")
	public int getVersion() {
		return version;
	}

	public void setVersion(int version) {
		this.version = version;
	}

	@PrePersist
	public void creationDate() {
		if (createTime == null) {
			createTime = new Date();
			updateTime = new Date();
			setVersion(1);
		}
	}

	@PreUpdate
	public void lastModified() {
		updateTime = new Date();
	}

}
