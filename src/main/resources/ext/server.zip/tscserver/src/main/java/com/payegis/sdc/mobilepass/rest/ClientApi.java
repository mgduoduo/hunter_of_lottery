package com.payegis.sdc.mobilepass.rest;

import com.payegis.sdc.mobilepass.util.TokenUtil;
import com.sun.jersey.api.json.JSONWithPadding;
import net.sf.json.JSONObject;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;

@Component
@Path("/client")
public class ClientApi  extends CoreApi{

	private static final Logger logger = Logger.getLogger(ClientApi.class);
	
	
	/**
	 * 浏览器同步时间
	 * @return
	 */
	@Path("/synctimeForWeb")
	@GET
	@Produces("application/javascript")
	public JSONWithPadding syncTime(@QueryParam("jsoncallback") String callback){
		//return buildJSON(API_STATUS_SUCCESS, ""+(new Date()).getTime());
        //logger.info("enter syncTime");

        JSONObject json = new JSONObject();
		json.put("timestamp",TokenUtil.getGMTTime());
		return new JSONWithPadding(buildJSON(API_STATUS_SUCCESS, null, json).toString(),callback);
	}

	
}
