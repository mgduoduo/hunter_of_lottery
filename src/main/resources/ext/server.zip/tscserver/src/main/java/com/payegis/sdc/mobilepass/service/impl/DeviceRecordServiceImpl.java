package com.payegis.sdc.mobilepass.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.payegis.sdc.mobilepass.dao.IDeviceRecordDao;
import com.payegis.sdc.mobilepass.service.IDeviceRecordService;


@Service
public class DeviceRecordServiceImpl implements IDeviceRecordService {

	
	@Autowired
	private IDeviceRecordDao didRecordDao;
	
	@Override
	public boolean saveRecord(String deviceId) {

		if(didRecordDao.didExists(deviceId)){
			return false;
		}else{
			didRecordDao.saveRecord(deviceId);
			return true;
		}
		
		
	}

}
