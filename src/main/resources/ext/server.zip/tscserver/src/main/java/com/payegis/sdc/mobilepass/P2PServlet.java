package com.payegis.sdc.mobilepass;

import java.io.File;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.payegis.sdc.mobilepass.util.ConfigFileUtil;
import com.payegis.shark.p2pverify.CollectHelp;
import com.payegis.shark.p2pverify.Settings;

/**
 * Servlet implementation class P2PServlet
 */
public class P2PServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public P2PServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		Settings.setBaseDir(new File(ConfigFileUtil.getAlgorithmPath()));
		response.getOutputStream().write( CollectHelp.doJob(request.getParameterMap()));
	}

}
