package com.payegis.sdc.mobilepass.dto;

public class CommonDataTO implements java.io.Serializable{
	
	/**
	 * 接口版本
	 */
	protected String version;

	/**
	 * 合作者编号
	 */
	protected String appPartner;

	/**
	 * 网络指纹
	 */
	protected String deviceId;

	/**
	 * 商户号
	 */
	protected String loginMerchantNo;

	/**
	 * 终端编号
	 */
	protected String terminalId;

	/**
	 * 操作员号
	 */
	protected String loginOperatorId;
	
	/**
	 * 语言
	 */
	protected String language;
	
	
	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getAppPartner() {
		return appPartner;
	}

	public void setAppPartner(String appPartner) {
		this.appPartner = appPartner;
	}

	public String getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}

	public String getLoginMerchantNo() {
		return loginMerchantNo;
	}

	public void setLoginMerchantNo(String loginMerchantNo) {
		this.loginMerchantNo = loginMerchantNo;
	}

	public String getTerminalId() {
		return terminalId;
	}

	public void setTerminalId(String terminalId) {
		this.terminalId = terminalId;
	}

	public String getLoginOperatorId() {
		return loginOperatorId;
	}

	public void setLoginOperatorId(String loginOperatorId) {
		this.loginOperatorId = loginOperatorId;
	}

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

}
