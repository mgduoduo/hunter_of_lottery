package com.payegis.sdc.mobilepass.util;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;

import org.apache.commons.codec.binary.Base64;
import org.apache.log4j.Logger;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.core.util.MultivaluedMapImpl;

public class WSUtil {

	private static Logger logger=Logger.getLogger(WSUtil.class);
	
	/**
	 * @param url
	 * @param params
	 * @return
	 */
	public static String sendRequest(String url, Map<String,Object> paramMap){
		logger.info("Webservice url:"+ url);
		MultivaluedMapImpl params=constructWebserviceParams(paramMap);
		
		
		Client client = Client.create();
		WebResource rs = client.resource(url);
		
		ClientResponse cr= rs.post(ClientResponse.class, params);
		  
		return cr.getEntity(String.class);
	}
	
	private static MultivaluedMapImpl constructWebserviceParams(Map<String,Object> paramMap){
		if(paramMap==null || paramMap.isEmpty()){
			return null;
		}
		
		MultivaluedMapImpl params = new MultivaluedMapImpl();
		
		for(Iterator<String> it=paramMap.keySet().iterator() ; it.hasNext();){
			String key= it.next();
			params.add(key, paramMap.get(key));
		}
		
		return params;
		
	}
	
	public static String postPosServer(String url,String param){
		//logger.info(">>>>>>>>>>>>>>>posserver url: "+ url);
		 Client client = Client.create();
		 WebResource rs = client.resource(url);
	     MultivaluedMap formData = new MultivaluedMapImpl();
	     formData.add("requestData", param);
	     ClientResponse response = rs.type(MediaType.APPLICATION_FORM_URLENCODED_TYPE).post(ClientResponse.class, formData);
	     String result = response.getEntity(String.class);
	     //logger.info(">>>>>>>>>>>>>>>posserver url: "+ url+" , result: "+ result);
	     return  result;
	}
	
	public static String validateQRCode(HashMap<String,String> paramMap){
		String url = ConfigFileUtil.getCheckeFraudUrl();
		MultivaluedMapImpl params=constructWebservice(paramMap);
		Client client;
		if(url.startsWith("https")){
			client = Client.create(ClientHelper.configureClient());
		}else{
			client = Client.create();
		}
		String dateTime = String.valueOf(System.currentTimeMillis());
		WebResource rs = client.resource(url);
		String appId = ConfigFileUtil.getFraudAppId();
		String appKey =ConfigFileUtil.getFraudAppKey();
		String sig =  getSig(appKey, dateTime, paramMap);
		ClientResponse cr= rs.header("x-hmac-auth-date", dateTime).header("x-hmac-auth-signature", appId+":"+sig).post(ClientResponse.class, params);
		String result = cr.getEntity(String.class);
		return result;
	}
	
	private static MultivaluedMapImpl constructWebservice(Map<String,String> paramMap){
		if(paramMap==null || paramMap.isEmpty()){
			return null;
		}
		
		MultivaluedMapImpl params = new MultivaluedMapImpl();
		
		for(Iterator<String> it=paramMap.keySet().iterator() ; it.hasNext();){
			String key= it.next();
			params.add(key, paramMap.get(key));
		}
		
		return params;
		
	}
	
	public static String getSig(String appkey, String requestTimeString, HashMap<String,String> parameter){
		try{
			String kvString = "";
			parameter.put("x-hmac-auth-date", requestTimeString);
			//logger.info("x-hmac-auth-date ==>" + requestTimeString);
			Set<String> listKeys = parameter.keySet();
			int length = listKeys.size();
			Iterator<String> it = listKeys.iterator();
			List<String> list = new ArrayList<String>();
			while(it.hasNext()){
				list.add(it.next());
			}
			Collections.sort(list);
			for(int i=0; i<length; i++){
				String key = list.get(i);
				if(i == length -1){
					kvString += key + "=" + parameter.get(key);
				}else{
					kvString += key + "=" + parameter.get(key) + "&";
				}
			}
			String kvStringE = URLEncoder.encode(kvString,"UTF-8");
			kvString = kvStringE.replace("*", "%2A").replace(" ", "%20");
			//logger.info("keys升序排列处理 ==>" + kvString);
			
			//3.method,url,kvString 用&连接
			String firstStep =kvString;
			
			/** Step 2. 构造密钥 */
			String secretoauthkey = appkey;
			secretoauthkey += "&";
			//logger.info("构造密钥 ==>" + secretoauthkey);
			
			/** step 3. 生成签名值*/
			//1.HMACSHA1加密
			String sig = "";
			byte[] encryption = null;
			encryption = HMACSHA1.getSignature(firstStep, secretoauthkey);
			//2.Base64编码
			sig = encodeBase64WithoutLinefeed(encryption);
			//logger.info("生成签名值 sig ==>" + sig);
			return sig;
		}catch(Exception e){
			logger.error(e.getMessage(), e);
			return "";
		}
		
	}
	
	protected static String encodeBase64WithoutLinefeed(byte[] result) {
        return Base64.encodeBase64String(result).trim();
    }
	
}
