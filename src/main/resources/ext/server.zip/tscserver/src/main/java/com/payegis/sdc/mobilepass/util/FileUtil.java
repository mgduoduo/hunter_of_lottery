/**
 * 
 */
package com.payegis.sdc.mobilepass.util;

import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.log4j.Logger;

/*import com.sun.image.codec.jpeg.JPEGCodec;
import com.sun.image.codec.jpeg.JPEGImageEncoder;*/

/**
 * @ClassName: FileUtil.java
 * @Description:
 * @Company: 苏州通付盾信息技术有限公司
 * @Author: qilei.shen
 * @Date: 2013年9月16日 下午12:22:23
 * @Copyright: Copyright(c) 2013
 * 
 * @Changes:
 * 
 */
public class FileUtil {
	private static final Logger logger = Logger.getLogger(FileUtil.class);

	public static void byte2File(byte[] buf, String filePath, String fileName){  
		BufferedOutputStream bos = null;  
		FileOutputStream fos = null;  
		File file = null;  
		try{  
			File dir = new File(filePath);  
			if (!dir.exists()){  
				dir.mkdirs();  
			}  
			file = new File(filePath + File.separator + fileName);  
			fos = new FileOutputStream(file);  
			bos = new BufferedOutputStream(fos);  
			bos.write(buf);  
		}catch (Exception e){
			logger.error(e.getMessage(), e);
		}  
		finally  {  
			if (bos != null)  {  
				try  {  
					bos.close();  
				}catch (IOException e){  
//					e.printStackTrace();  
					logger.error(e.getMessage(), e);
				}  
			}  
			if (fos != null)  {  
				try  {  
					fos.close();  
				}catch (IOException e){  
//					e.printStackTrace();  
					logger.error(e.getMessage(), e);
				}  
			}  
		}  
	} 

	public static void delete( String filePath, String fileName){
		File file = new File(filePath + File.separator + fileName);  
		if(file.exists()){
			file.delete();
		}
	}

	public static byte[] File2byte(String filePath){  
		byte[] buffer = null;  
		try  {  
			File file = new File(filePath);  
			FileInputStream fis = new FileInputStream(file);  
			ByteArrayOutputStream bos = new ByteArrayOutputStream();  
			byte[] b = new byte[1024];  
			int n;  
			while ((n = fis.read(b)) != -1)  {  
				bos.write(b, 0, n);  
			}  
			fis.close();  
			bos.close();  
			buffer = bos.toByteArray();  
		} catch (FileNotFoundException e)  {
			logger.error(e.getMessage(),e);
		}  catch (IOException e)  {
			logger.error(e.getMessage(),e);
		}  
		return buffer;  
	}  
	
	public static void main(String[] args){
		//1407739736562
		//1407739746397
	}
	
	
	/*public static boolean compressPic(String srcFilePath, String descFilePath)  
    {  
        File file = null;  
        BufferedImage src = null;  
        FileOutputStream out = null;  
        ImageWriter imgWrier;  
        ImageWriteParam imgWriteParams;  
  
        // 指定写图片的方式为 jpg  
        imgWrier = ImageIO.getImageWritersByFormatName("jpg").next();  
        imgWriteParams = new javax.imageio.plugins.jpeg.JPEGImageWriteParam(null);  
        // 要使用压缩，必须指定压缩方式为MODE_EXPLICIT  
        imgWriteParams.setCompressionMode(imgWriteParams.MODE_EXPLICIT);  
        // 这里指定压缩的程度，参数qality是取值0~1范围内，  
        imgWriteParams.setCompressionQuality((float)0.1);  
        imgWriteParams.setProgressiveMode(imgWriteParams.MODE_DISABLED);  
        ColorModel colorModel = ColorModel.getRGBdefault();  
        // 指定压缩时使用的色彩模式  
        imgWriteParams.setDestinationType(new javax.imageio.ImageTypeSpecifier(colorModel, colorModel  
                .createCompatibleSampleModel(16, 16)));  
  
        try  
        {  
            if(StringUtils.isBlank(srcFilePath))  
            {  
                return false;  
            }  
            else  
            {  
                file = new File(srcFilePath);  
                src = ImageIO.read(file);  
                out = new FileOutputStream(descFilePath);  
  
                imgWrier.reset();  
                // 必须先指定 out值，才能调用write方法, ImageOutputStream可以通过任何 OutputStream构造  
                imgWrier.setOutput(ImageIO.createImageOutputStream(out));  
                // 调用write方法，就可以向输入流写图片  
                imgWrier.write(null, new IIOImage(src, null, null), imgWriteParams);  
                out.flush();  
                out.close();  
            }  
        }  
        catch(Exception e)  
        {  
            e.printStackTrace();  
            return false;  
        }  
        return true;  
    }  */
	
	public static void createThumbnail(String filePath,String fileName){
	  /*try{
	   File srcfile = new File(filePath+File.separator+fileName);
	   if(!srcfile.exists()){
	    System.out.println("文件不存在");
	    return;
	   }
	   
	  BufferedImage image = ImageIO.read(srcfile);
	  
	   //获得缩放的比例
	   double ratio = 1.0;
	   if(image.getHeight()>250 || image.getWidth()>250)
	   {
	    if(image.getHeight() > image.getWidth())
	    {
	     ratio = 250.0 / image.getHeight();
	    }
	    else
	    {
	     ratio = 250.0 / image.getWidth();
	    }
	   }
	   //计算新的图面宽度和高度
	   int newWidth =(int)(image.getWidth()*ratio);
	   int newHeight =(int)(image.getHeight()*ratio);
	   
	   BufferedImage bfImage= new BufferedImage(newWidth,newHeight,BufferedImage.TYPE_INT_RGB);
	   bfImage.getGraphics().drawImage(image.getScaledInstance(newWidth, newHeight,Image.SCALE_SMOOTH),0,0,null);
	   
	   FileOutputStream os = new FileOutputStream(filePath+File.separator+fileName+"_tmp");
	   JPEGImageEncoder encoder = JPEGCodec.createJPEGEncoder(os);
	   encoder.encode(bfImage);
	   os.close();
	   System.out.println("创建缩略图成功");
	  }
	  catch(Exception e)
	  {
	   System.out.println("创建缩略图发生异常"+e.getMessage());
	  }*/
	 }
	

}
