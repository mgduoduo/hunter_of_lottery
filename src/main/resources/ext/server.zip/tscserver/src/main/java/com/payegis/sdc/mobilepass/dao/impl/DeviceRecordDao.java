package com.payegis.sdc.mobilepass.dao.impl;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.payegis.sdc.mobilepass.dao.BaseJPADao;
import com.payegis.sdc.mobilepass.dao.IDeviceRecordDao;
import com.payegis.sdc.mobilepass.entity.DeviceRecord;
import com.payegis.sdc.mobilepass.util.CommonUtil;

@Repository
public class DeviceRecordDao extends BaseJPADao<DeviceRecord, String> implements IDeviceRecordDao {

	@Override
	public void saveRecord(String deviceId) {
		DeviceRecord dr=new DeviceRecord();
		dr.setDeviceId(deviceId);
		dr.setId(CommonUtil.generateUUID());
		dr.setCreateTime(new Date());
		dr.setCreator("system");
		dr.setUpdater("system");
		dr.setUpdateTime(new Date());
		dr.setVersion(1);
		save(dr);
		
	}

	@Override
	public boolean didExists(String deviceId) {
		String query="from DeviceRecord o where o.deviceId=:did";
		Map params=new HashMap();
		
		params.put("did", deviceId);
		DeviceRecord dr=super.getQueryResult(query, params);
		return dr!=null;
	}

}
