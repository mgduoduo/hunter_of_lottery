package com.payegis.sdc.mobilepass.util;

import com.payegis.sdc.mobilepass.common.Constant;
import net.sf.json.JSONObject;
import org.apache.commons.configuration.Configuration;
import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.ConfigurationFactory;
import org.apache.log4j.Logger;

import java.io.File;
import java.io.IOException;
import java.io.StringReader;
import java.util.Properties;

public class ConfigFileUtil {
	
	protected final static Logger logger = Logger.getLogger(ConfigFileUtil.class);
	
	private static Configuration config = null;
	
	private static long lastModifyTime = 0l;
	
	//private static String configHome = System.getenv(Constant.PESDK_HOME);
	
	private static String configFilePath = "/tscserver.properties";

	public static void getConfig(){
		try{
			if (config == null) {
				lastModifyTime = new File(configFilePath).lastModified();
				loadConfig(configFilePath);
			}else{
				if(getReload()){
					long nowLastModifyTime=new File(configFilePath).lastModified();
					if(nowLastModifyTime!=lastModifyTime){
						logger.info("检测到配置文件有变动,重新加载配置文件");
						loadConfig(configFilePath);
						lastModifyTime=nowLastModifyTime;
					}
				}
			}
		}catch (ConfigurationException e){
			//if (isDebugMode()){
				throw new RuntimeException(e.getMessage());
			//}
		}
	}
	
	private static void loadConfig(String configFilePath) throws ConfigurationException{
		System.setProperty("config.file", configFilePath);
		ConfigurationFactory factory = new ConfigurationFactory("tscserver.xml");
		config = factory.getConfiguration();
	}
	
	public static Boolean getReload(){
		if(config==null){
			return true;
		}else{
			return config.getBoolean("config.reload",true);
		}
	}

	public static void setConfig(String message){
		getConfig();
		Properties pro = new Properties();
		try {
			pro.load(new StringReader(message));
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
		}
		for(Object t:pro.keySet()){
			config.clearProperty(t.toString());
			config.addProperty(t.toString(), pro.getProperty(t.toString()));
		}  
	}

	public static boolean isDebugMode(){
		getConfig();
		return config.getBoolean("debug.mode", false);
	}
	
	public static String getPushUrl(){
		getConfig();
		return config.getString("push.url", "");
	}
	
	/*public static String getPosserverURL(){
		getConfig();
		return config.getString("posserver.url", "");
	}*/
	
	public static String getValue(String key){
		getConfig();
		return config.getString(key);
	}
	
	/**
	 * 获取动态算法文件路径
	 * @return
	 */
	public static String getAlgorithmPath(){
		getConfig();
		return config.getString("algorithm.file.path");
	}
	
	public static String getUserIconPath(){
		getConfig();
		return config.getString("user.icon.path");
	}
	
	public static String getChatGroupIconPath(){
		getConfig();
		return config.getString("chat.group.icon.path");
	}
	
	public static String getChatFilePath(){
		getConfig();
		return config.getString("chat.file.path");
	}
	
	public static String getChatGroupFilePath(){
		getConfig();
		return config.getString("chat.group.file.path");
	}
	
	public static int getValidateTime(String appId) {
		try{
			Object obj = MemCacheMgr.getMemcache(Constant.MEMCACHE_HEAD+appId);
			if(obj!=null){
				JSONObject json = JSONObject.fromObject(obj);
				if(json.getString("timeOffset")!=null){
					//logger.info("Memcache获取的时间差值为："+json.getString("timeOffset"));
					return Integer.valueOf(json.getString("timeOffset"));
				}
			}
		}catch(Exception e){
			logger.error(e.getMessage(), e);
		}
		getConfig();
		return config.getInt("validate.time", 15);
	}
	
	public static int getScanTime(String appId) {
		try{
			Object obj = MemCacheMgr.getMemcache(Constant.MEMCACHE_HEAD+appId);
			if(obj!=null){
				JSONObject json = JSONObject.fromObject(obj);
				if(json.getString("scanTimeOffset")!=null){
					//logger.info("Memcache获取的时间差值为："+json.getString("scanTimeOffset"));
					return Integer.valueOf(json.getString("scanTimeOffset"));
				}
			}
		}catch(Exception e){
			logger.error(e.getMessage(), e);
		}
		getConfig();
		return config.getInt("scan.time", 1);
	}
	
	public static int getClearSdcUserinfoTime(){
		getConfig();
		return config.getInt("clear.sdc.userinfo.time", 1200);
	}
	
	public static int getClearAppealCodeTime(){
		getConfig();
		return config.getInt("clear.sdc.appealcode.time", 6);
	}
	
	public static String getAuthorizeCode(){
		getConfig();
		return config.getString("authorize.code","88/877878789/");
	}
	
	public static String getAppConfig(){
		getConfig();
		return config.getString("app.config");
	}
	
	public static String getCheckeFraudUrl(){
		getConfig();
		return config.getString("check.fraud.url");
	}
	
	public static String getFraudAppId(){
		getConfig();
		return config.getString("fraud.appid");
	}
	
	public static String getFraudAppKey(){
		getConfig();
		return config.getString("fraud.appkey");
	}
	
	public static String getMemCacheAddress(){
		getConfig();
		return config.getString("memcache.address");
	}
	
	public static Integer getMemCachePort(){
		getConfig();
		return config.getInteger("memcache.port",80);
	}
	

}
