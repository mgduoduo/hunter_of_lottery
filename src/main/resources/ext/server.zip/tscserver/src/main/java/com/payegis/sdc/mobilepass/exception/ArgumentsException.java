package com.payegis.sdc.mobilepass.exception;

public class ArgumentsException extends BaseException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ArgumentsException(ErrorMsg msg, Object...arg){
		super(msg, arg);
	}
	
}
