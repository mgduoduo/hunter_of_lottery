package com.payegis.sdc.mobilepass.dao;

import com.payegis.sdc.mobilepass.entity.DeviceRecord;

public interface IDeviceRecordDao extends IDao<DeviceRecord, String> {
	
	public void saveRecord(String deviceId);
	
	public boolean didExists(String deviceId);
	
}
