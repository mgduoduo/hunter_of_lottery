package com.payegis.sdc.mobilepass.rest;

import com.payegis.sdc.mobilepass.common.Constant;
import com.payegis.sdc.mobilepass.common.MessageConstant;
import com.payegis.sdc.mobilepass.dto.BindUserTO;
import com.payegis.sdc.mobilepass.dto.DcCodeTO;
import com.payegis.sdc.mobilepass.dto.SDKCommonDataTO;
import com.payegis.sdc.mobilepass.dto.ShortTokenTO;
import com.payegis.sdc.mobilepass.entity.ScanHistory;
import com.payegis.sdc.mobilepass.entity.UserInfo;
import com.payegis.sdc.mobilepass.exception.ArgumentsException;
import com.payegis.sdc.mobilepass.exception.ErrorMsg;
import com.payegis.sdc.mobilepass.service.IBlackListService;
import com.payegis.sdc.mobilepass.service.IDeviceRecordService;
import com.payegis.sdc.mobilepass.service.IScanHistoryService;
import com.payegis.sdc.mobilepass.service.IUserInfoService;
import com.payegis.sdc.mobilepass.util.CommonUtil;
import com.payegis.sdc.mobilepass.util.MessageUtil;
import com.payegis.sdc.mobilepass.util.WSUtil;
import com.payegis.sdc.mobilepass.util.json.DateJsonValueProcessor;
import com.sun.jersey.api.json.JSONWithPadding;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import net.sf.json.JsonConfig;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.*;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;
import java.util.*;


@Component
@Path("/authority")
public class AuthorityApi extends CoreApi {

	/*private static TimeSpaceCodeLogging cloudLog=new TimeSpaceCodeLogging();*/
	private static Logger logger=Logger.getLogger(AuthorityApi.class);

	@Autowired
	private IUserInfoService userInfoService;


	@Autowired
	private IDeviceRecordService didRecordService;

	@Autowired
	private IBlackListService blankListService;

	@Autowired
	private IScanHistoryService  scanHistoryService;

	@Context
	HttpServletRequest req;


	/**
	 * 网站SDC登录
	 * @return
	 * @throws Exception
	 */
	@Path("userbindForWeb")
	@GET
	@Produces("application/javascript")
	public JSONWithPadding bindUserForWeb(
			@QueryParam(Constant.Parameter.APP_ID) String appId,
			@QueryParam(Constant.Parameter.APP_PARTNER) String partnerCode,
			@QueryParam("deviceId") String deviceId,
			@QueryParam("externalId") String externalId,
			@QueryParam("jsoncallback") String callback
			) throws Exception{
        //logger.info("enter userbindForWeb,appId:"+appId+",partnerCode："+partnerCode+",-------------deviceId:"+deviceId+",externalId:"+externalId);
       // logger.info("deviceId:"+deviceId);
		BindUserTO bindUserTo= new BindUserTO();
		bindUserTo.setAppId(appId);
		bindUserTo.setDeviceId(deviceId);
		bindUserTo.setAppPartner(partnerCode);
		bindUserTo.setExternalId(externalId);

		UserInfo userinfo = userInfoService.bindUser(bindUserTo);
		JSONObject json = new JSONObject();
		json.put(Constant.Parameter.UID, userinfo.getUserId());
        logger.info("绑定成功");

		return new JSONWithPadding(buildJSON(API_STATUS_SUCCESS, null, json).toString(),callback);
	}
	/**
	 * SDC 登录， 返回User token.
	 * @param requestData
	 * @return UserToken
	 * @throws Exception
	 */
	@Path("userbind")
	@POST
	@Produces("application/json;charset=utf-8")
	public String bindUser(@FormParam(Constant.Parameter.REQUEST_DATA) String requestData) throws Exception{

		//logger.info(">>>>>>> /rest/authority/userbind , request data: "+ requestData);

		BindUserTO bindUserTo = (BindUserTO) JSONObject.toBean(JSONObject.fromObject(requestData), BindUserTO.class);

		//add deviceid to db , send log to cloud
		recordDid(bindUserTo.getDeviceId() , bindUserTo.getAppId() , "create");

		validateBindUser(bindUserTo);
		/*String appName = Authenticator.getAppName(bindUserTo.getAppPartner(), bindUserTo.getSecurityKey());
		if (appName == null||!bindUserTo.getAppId().equals(appName)){
			throw new HandleException(ErrorMsg.LISENCE_ERROR,new Object[]{});
		}*/
		UserInfo userinfo = userInfoService.bindUser(bindUserTo);
		JSONObject msg = new JSONObject();
		msg.put(Constant.Parameter.APP_PARTNER, bindUserTo.getAppPartner());
		msg.put(Constant.Parameter.APP_ID, bindUserTo.getAppId());
		msg.put(Constant.Parameter.UID, userinfo.getUserId());
        logger.info("绑定成功");
		return MessageUtil.successMsg("", msg).toString();
	}

	/**
	 * SDC 登录， 返回User token.
	 * @param requestData
	 * @return UserToken
	 * @throws Exception
	 */
	@Path("/forpass/userbind")
	@POST
	@Produces("application/json;charset=utf-8")
	public String bindUserForPass(@FormParam(Constant.Parameter.REQUEST_DATA) String requestData) throws Exception{
		return bindUser(requestData);
	}


	@Path("getdeviceid")
	@POST
	@Produces("application/json;charset=utf-8")
	public String getDeviceId(@FormParam(Constant.Parameter.REQUEST_DATA) String requestData) throws Exception{
		BindUserTO bindUserTo = (BindUserTO) JSONObject.toBean(JSONObject.fromObject(requestData), BindUserTO.class);
		validateGetDeviceId(bindUserTo);
		UserInfo userinfo = userInfoService.getDeviceId(bindUserTo);
		JSONObject msg = new JSONObject();
		msg.put("deviceId", userinfo.getDeviceId());
		return MessageUtil.successMsg("", msg).toString();
	}

	@Path("/forpass/getdeviceid")
	@POST
	@Produces("application/json;charset=utf-8")
	public String getDeviceIdForPass(@FormParam(Constant.Parameter.REQUEST_DATA) String requestData) throws Exception{
		return getDeviceId(requestData);
	}

	@Path("checkshorttoken")
	@POST
	@Produces("application/json;charset=utf-8")
	public String checkShortToken(@FormParam(Constant.Parameter.REQUEST_DATA) String requestData) throws Exception{
		ShortTokenTO shortTokenTO = (ShortTokenTO) JSONObject.toBean(JSONObject.fromObject(requestData), ShortTokenTO.class);
		validateCheckShortToken(shortTokenTO);
		logger.info("checkshorttoken ------------ appId:" + shortTokenTO.getAppId()+"did:"+shortTokenTO.getDeviceId()+"shortToken:"+shortTokenTO.getShortToken()+"partonCode:"+shortTokenTO.getPartnerCode());
		return userInfoService.checkShortToken(shortTokenTO);
	}

	@Path("/forpass/checkshorttoken")
	@POST
	@Produces("application/json;charset=utf-8")
	public String checkShortTokenForpass(@FormParam(Constant.Parameter.REQUEST_DATA) String requestData) throws Exception{
		return checkShortToken(requestData);
	}

	@Path("validatedccode")
	@POST
	@Produces("application/json;charset=utf-8")
	public String validateDcCode(@FormParam(Constant.Parameter.REQUEST_DATA) String requestData
			) throws Exception{
        //logger.info(requestData);
		DcCodeTO dcCodeTO = (DcCodeTO) JSONObject.toBean(JSONObject.fromObject(requestData), DcCodeTO.class);

		validateDCCodeParam(dcCodeTO);

		//		recordDid(dcCodeTO.getDeviceId(), dcCodeTO.getAppId(), "verify");

		return userInfoService.validateDcCode(dcCodeTO);
	}


	@Path("checknewalgorithm")
	@POST
	@Produces("application/json;charset=utf-8")
	public String checkNewAlgorithm(@FormParam(Constant.Parameter.REQUEST_DATA) String requestData)throws Exception{
		SDKCommonDataTO sdkCommonDataTo = (SDKCommonDataTO) JSONObject.toBean(JSONObject.fromObject(requestData), SDKCommonDataTO.class);
		validateCheckNewAlgorithm(sdkCommonDataTo);
		/*String appName = Authenticator.getAppName(sdkCommonDataTo.getAppPartner(), sdkCommonDataTo.getSecurityKey());
		if (appName == null||!sdkCommonDataTo.getAppId().equals(appName)){
			throw new HandleException(ErrorMsg.LISENCE_ERROR,new Object[]{});
		}*/
		return userInfoService.checkNewAlgorithm(sdkCommonDataTo);
	}

	@Path("/forpass/checknewalgorithm")
	@POST
	@Produces("application/json;charset=utf-8")
	public String checkNewAlgorithmForPass(@FormParam(Constant.Parameter.REQUEST_DATA) String requestData)throws Exception{
		String result = checkNewAlgorithm(requestData);
		//logger.info("checkNewAlgorithmForPass result="+result);
		return result;
	}

	@Path("algorithmlist")
	@POST
	@Produces("application/json;charset=utf-8")
	public String getAlgorithmList(@FormParam(Constant.Parameter.REQUEST_DATA) String requestData)throws Exception{
		SDKCommonDataTO sdkCommonDataTo = (SDKCommonDataTO) JSONObject.toBean(JSONObject.fromObject(requestData), SDKCommonDataTO.class);
		validateGetAlgorithmList(sdkCommonDataTo);
		return userInfoService.getAlgorithmList(sdkCommonDataTo);
	}

	@Path("/forpass/algorithmlist")
	@POST
	@Produces("application/json;charset=utf-8")
	public String getAlgorithmListForPass(@FormParam(Constant.Parameter.REQUEST_DATA) String requestData)throws Exception{
		return getAlgorithmList(requestData);
	}

	@Path("/downLoad/algorithm/{algorithmFileId}")
	@GET
	@Produces(MediaType.APPLICATION_OCTET_STREAM)
	public Response downLoad(@PathParam(Constant.Parameter.ALGORITHMFILEID) String algorithmFileId) throws Exception{
		ResponseBuilder response = Response.ok(userInfoService.getAlgorithmFile(algorithmFileId));
		response.header("Content-Disposition", "attachment; filename=1" + "");
		return response.build();
	}

	@Path("/downLoad/algorithm/forpass/{algorithmFileId}")
	@GET
	@Produces(MediaType.APPLICATION_OCTET_STREAM)
	public Response downLoadForPass(@PathParam(Constant.Parameter.ALGORITHMFILEID) String algorithmFileId) throws Exception{
		return downLoad(algorithmFileId);
	}

	private void recordDid(String did, String appId, String stageType){
		//TimeSpaceCodeLogging cloudLog=new TimeSpaceCodeLogging();
		boolean isNew=didRecordService.saveRecord(did);
		//log
		Map params=new HashMap();

		params.put("deviceId",did);
		params.put("deviceType", isNew? "new" : "old" );
		params.put("stageType", stageType);

		//		cloudLog.businessLog(appId,new Date(), params);
//		cloudLog.reportingLog(appId, new Date(), params);

	}

	@Path("qrcodeSecurityvalidate")
	@POST
	@Produces("application/json;charset=utf-8")
	public String qrCodeSecurityValidate(@FormParam(Constant.Parameter.QRCODE) String qrCode,
			@FormParam(Parameter.APP_ID) String appId,
			@FormParam(Parameter.DEVICE_ID) String deviceId,
			@FormParam(Parameter.USERID)String userId,
			@FormParam(Parameter.PARTNER_CODE) String partnerCode){
		if(! validatParams(new String[]{"qrCode" ,"partnerCode" ,"appId","deviceId"}, qrCode,deviceId, partnerCode,appId,deviceId)){
			return buildValidateParamJSON();
		}
		JSONObject jsonResult = new JSONObject();
		//匹配时空码
		if(qrCode.matches("^[0-9]{30}$")){
			JSONObject json = userInfoService.validateQRCodeforTSC(qrCode);
			jsonResult.put("securitylevel", "NONE");
			String status = json.getString(Constant.Result.STATUS);
			if("0".equals(status)){
				jsonResult.put("type", "1");
				jsonResult.put("subtype", "0");
			}else if("1".equals(status)){
				jsonResult.put("type", "1");
				jsonResult.put("subtype", "1");
			}else{
				jsonResult.put("type", "3");
			}
			//匹配网址
		}else if(qrCode.matches("((http|ftp|https)://)?(([a-zA-Z0-9\\._-]+\\.[a-zA-Z]{2,6})|([0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}))(:[0-9]{1,4})*(/[a-zA-Z0-9\\&%_\\.,#!@$+^/-~-]*)?")){

			String ip =  getRemoteIp(req);

			HashMap<String,String> paramMap = new HashMap<String,String>();
			paramMap.put("ip", ip);
			paramMap.put("url", qrCode);
			String jsonResult_Str=WSUtil.validateQRCode(paramMap);
			JSONObject _tmpResult =  JSONObject.fromObject(jsonResult_Str);
			String status = _tmpResult.getString("status");
			jsonResult.put("type", "2");
			if(status!=null&&"1".equals(status)){//校验成功
				String result = _tmpResult.getString("result");
				jsonResult.put("securitylevel", result);
			}else{
				jsonResult.put("securitylevel", "NONE");
			}
			//文本内容
		}else{
			jsonResult.put("type", "3");
			jsonResult.put("securitylevel", "NONE");
		}
		ScanHistory  scanHistory = this.createScanHistory(appId, qrCode, deviceId, partnerCode, jsonResult.optString("subtype", null), jsonResult.getString("type"), jsonResult.getString("securitylevel"),userId);
		scanHistoryService.addScanContent(scanHistory);
		return MessageUtil.successMsg("", jsonResult).toString();
	}

	private String getRemoteIp(HttpServletRequest request){
		String ip  =  request.getHeader( " x-forwarded-for " );  
		if (ip  ==   null   ||  ip.length()  ==   0   ||   " unknown " .equalsIgnoreCase(ip))  {  
			ip  =  request.getHeader( " Proxy-Client-IP " );  
		}   
		if (ip  ==   null   ||  ip.length()  ==   0   ||   " unknown " .equalsIgnoreCase(ip))  {  
			ip  =  request.getHeader( " WL-Proxy-Client-IP " );  
		}   
		if (ip  ==   null   ||  ip.length()  ==   0   ||   " unknown " .equalsIgnoreCase(ip))  {  
			ip  =  request.getRemoteAddr();  
		}   
		if (ip  ==   null   ||  ip.length()  ==   0   ||   " unknown " .equalsIgnoreCase(ip))  {  
			ip  =  request.getHeader("X-Real-IP");  
		}   
		return  ip;  
	}

	private ScanHistory createScanHistory(String appId,String content,String deviceId,String partnerCode,String subType,String type,String level,String userId){
		ScanHistory  scanHistory = new ScanHistory();
		scanHistory.setId(UUID.randomUUID().toString());
		scanHistory.setAppId(appId);
		scanHistory.setContent(content);
		scanHistory.setCreateTime(new Date());
		scanHistory.setCreator("admin");
		scanHistory.setDeviceId(deviceId);
		scanHistory.setLevel(level);
		scanHistory.setPartnerCode(partnerCode);
		scanHistory.setSubType(subType);
		scanHistory.setType(type);
		scanHistory.setUserId(userId);
		scanHistory.setUpdater("admin");
		scanHistory.setUpdateTime(new Date());
		return scanHistory;
	}

	@Path("/getScanHistory")
	@POST
	@Produces("application/json;charset=utf-8")
	public String getScanHistory(
			@FormParam(Parameter.DEVICE_ID) String deviceId,
			@FormParam(Parameter.APP_ID) String appId,
			@FormParam(Parameter.PARTNER_CODE) String partnerCode,
			@FormParam(Parameter.USERID)String userId,
			@FormParam("scanHistoryId")String scanHistoryId,
			@FormParam("isBefore")Integer isBefore,
			@FormParam("pageSize")Integer pageSize
			){
		if(! validatParams(new String[]{"deviceId","appId","partnerCode"}, deviceId, appId, partnerCode)){
			return buildValidateParamJSON();
		}
		if(pageSize==null||pageSize<1){
			pageSize=20;
		}
		List<ScanHistory> results= scanHistoryService.getScanHistory(deviceId,appId,partnerCode,scanHistoryId,isBefore,pageSize,userId);
		JsonConfig jf = new JsonConfig(); 
		jf.registerJsonValueProcessor(java.util.Date.class, new DateJsonValueProcessor("yyyy-MM-dd HH:mm:ss")); 
		JSONArray array = JSONArray.fromObject(results, jf);
		return buildJSON(API_STATUS_SUCCESS, CommonUtil.getMessage(MessageConstant.Alert.ALERT_SUCCESS), array);
	}


	/**
	 * 验证绑定用户的传入参数
	 * @throws Exception
	 */
	private void validateBindUser(BindUserTO bindUserTo) throws Exception{
		if(StringUtils.isEmpty(bindUserTo.getExternalId())){
			throw new ArgumentsException(ErrorMsg.ARGU_NULL_ERROR,new Object[]{"param.external.userid"});
		}
		if(StringUtils.isEmpty(bindUserTo.getDeviceId())){
			throw new ArgumentsException(ErrorMsg.ARGU_NULL_ERROR,new Object[]{"param.devicefingerprinting"});
		}
		if(StringUtils.isEmpty(bindUserTo.getAppPartner())){
			throw new ArgumentsException(ErrorMsg.ARGU_NULL_ERROR,new Object[]{"param.partnercode"});
		}
		if(StringUtils.isEmpty(bindUserTo.getAppId())){
			throw new ArgumentsException(ErrorMsg.ARGU_NULL_ERROR,new Object[]{"param.appid"});
		}
		if(StringUtils.isEmpty(bindUserTo.getSecurityKey())){
			throw new ArgumentsException(ErrorMsg.ARGU_NULL_ERROR,new Object[]{"param.securitykey"});
		}
	}

	private void validateCheckNewAlgorithm(SDKCommonDataTO sdkCommonDataTo) throws Exception{
		if(StringUtils.isEmpty(sdkCommonDataTo.getDeviceId())){
			throw new ArgumentsException(ErrorMsg.ARGU_NULL_ERROR,new Object[]{"param.devicefingerprinting"});
		}
		if(StringUtils.isEmpty(sdkCommonDataTo.getAppPartner())){
			throw new ArgumentsException(ErrorMsg.ARGU_NULL_ERROR,new Object[]{"param.partnercode"});
		}
		if(StringUtils.isEmpty(sdkCommonDataTo.getAppId())){
			throw new ArgumentsException(ErrorMsg.ARGU_NULL_ERROR,new Object[]{"param.appid"});
		}
		if(StringUtils.isEmpty(sdkCommonDataTo.getSecurityKey())){
			throw new ArgumentsException(ErrorMsg.ARGU_NULL_ERROR,new Object[]{"param.securitykey"});
		}
	}

	private void validateGetAlgorithmList(SDKCommonDataTO sdkCommonDataTo) throws Exception{
		if(StringUtils.isEmpty(sdkCommonDataTo.getDeviceId())){
			throw new ArgumentsException(ErrorMsg.ARGU_NULL_ERROR,new Object[]{"param.devicefingerprinting"});
		}
		if(StringUtils.isEmpty(sdkCommonDataTo.getAppPartner())){
			throw new ArgumentsException(ErrorMsg.ARGU_NULL_ERROR,new Object[]{"param.partnercode"});
		}
	}

	private void validateGetDeviceId(BindUserTO bindUserTo) throws Exception{
		if(StringUtils.isEmpty(bindUserTo.getAppPartner())){
			throw new ArgumentsException(ErrorMsg.ARGU_NULL_ERROR,new Object[]{"param.partnercode"});
		}
		if(StringUtils.isEmpty(bindUserTo.getUserToken())){
			throw new ArgumentsException(ErrorMsg.ARGU_NULL_ERROR,new Object[]{"param.usertoken"});
		}
	}

	private void validateCheckShortToken(ShortTokenTO shortTokenTO)throws Exception{
		if(StringUtils.isEmpty(shortTokenTO.getDeviceId())){
			throw new ArgumentsException(ErrorMsg.ARGU_NULL_ERROR,new Object[]{"param.devicefingerprinting"});
		}
		if(StringUtils.isEmpty(shortTokenTO.getShortToken())){
			throw new ArgumentsException(ErrorMsg.ARGU_NULL_ERROR,new Object[]{"param.shorttoken"});
		}
		if(StringUtils.isEmpty(shortTokenTO.getAppId())){
			throw new ArgumentsException(ErrorMsg.ARGU_NULL_ERROR,new Object[]{"param.appid"});
		}
	}

	private void validateDCCodeParam(DcCodeTO dcCodeTO)throws Exception{
		if(StringUtils.isEmpty(dcCodeTO.getDcCode())){
			throw new ArgumentsException(ErrorMsg.ARGU_NULL_ERROR,new Object[]{"param.dccode"});
		}
		if(StringUtils.isEmpty(dcCodeTO.getAppId())){
			throw new ArgumentsException(ErrorMsg.ARGU_NULL_ERROR,new Object[]{"param.appid"});
		}
	}

	private void validateGetAppConfig(SDKCommonDataTO sdkCommonDataTo) throws Exception{
		if(StringUtils.isEmpty(sdkCommonDataTo.getAppPartner())){
			throw new ArgumentsException(ErrorMsg.ARGU_NULL_ERROR,new Object[]{"param.partnercode"});
		}
		if(StringUtils.isEmpty(sdkCommonDataTo.getAppId())){
			throw new ArgumentsException(ErrorMsg.ARGU_NULL_ERROR,new Object[]{"param.appid"});
		}
		if(StringUtils.isEmpty(sdkCommonDataTo.getSecurityKey())){
			throw new ArgumentsException(ErrorMsg.ARGU_NULL_ERROR,new Object[]{"param.securitykey"});
		}
	}

}
