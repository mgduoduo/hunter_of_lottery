package com.payegis.sdc.mobilepass.dao;

import org.apache.log4j.Logger;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class BaseJPADao<T,PK> {
	
	private static Logger logger = Logger.getLogger(BaseJPADao.class);
	
	@PersistenceContext(unitName = "datasource")
    private EntityManager em;
	
	public EntityManager createEntityManager() {
		return em;
	}
	
	  // 泛型反射类  
    private Class<T> entityClass;  
    
    // 通过反射获取子类确定的泛型类  
    @SuppressWarnings({ "rawtypes", "unchecked" })  
    public BaseJPADao() {  
        Type genType = getClass().getGenericSuperclass();  
        Type[] params = ((ParameterizedType) genType).getActualTypeArguments();  
        entityClass = (Class) params[0];  
    }  
	
	public T save(T entity) {
		return createEntityManager().merge(entity);
	}
	
	public void removeById(PK id) {
		EntityManager em = createEntityManager();
		Object o = em.find(this.entityClass, id);
		if (o != null) {
			em.remove(o);
		}
	}
	
	public void remove(T entity) {
		createEntityManager().remove(entity);
	}
	
	public int executeUpdate(String queryName, Map<String, Object> params) {
		EntityManager em = createEntityManager();
		int rowCount = 0;
		Query query = em.createQuery(queryName);
		for(Entry<String,Object> entry:params.entrySet()){
			query.setParameter(entry.getKey(), entry.getValue());
		}
		rowCount = query.executeUpdate();
		return rowCount;
	}
	
	public List<T> getQueryResultList(String query) {
		EntityManager em = createEntityManager();
		Query q = em.createQuery(query);
		return q.getResultList();
	}
	
	public List<T> getQueryResultList(String query, Map<Object, Object> params) {
		EntityManager em = createEntityManager();
		List<T> items = new ArrayList<T>();
		Query q = em.createQuery(query);
		for(Entry<Object,Object> entry:params.entrySet()){
			Object key = entry.getKey();
			Object value = entry.getValue();
			if (key instanceof String) {
				q.setParameter((String) key, value);
			} else if (key instanceof Integer) {
				q.setParameter(((Integer) key).intValue(), value);
			}
		}
		items = q.getResultList();
		return items;
	}
	
	public List<T> getQueryResultList(String query, int firstResult, int maxResults) {
		EntityManager em = createEntityManager();
		Query q = em.createQuery(query);
		q.setFirstResult(firstResult);
		q.setMaxResults(maxResults);
		return q.getResultList();
	}
	
	public List<T> getQueryResultList(String query, int firstResult, int maxResults, Map<String,Object> params) {
		EntityManager em = createEntityManager();
		Query q = em.createQuery(query);
		
		for(Entry<String,Object> entry:params.entrySet()){
			q.setParameter(entry.getKey(), entry.getValue());
		}
		
		q.setFirstResult(firstResult);
		q.setMaxResults(maxResults);
		return q.getResultList();
	}
	
	@SuppressWarnings("unchecked")
	public List<T> getObjectList(Class<T> clz) {
		long startTime = System.currentTimeMillis();
		EntityManager em = createEntityManager();
		List<T> items = new ArrayList<T>();
		try {
			Query query = em.createQuery("SELECT o FROM " + clz.getName()+ " o ");
			items = query.getResultList();
		} catch (Exception e) {
			logger.error(e.getMessage());
			throw new RuntimeException(e);
		}
		long endTime = System.currentTimeMillis();
		/*logger.info("Time (" + (endTime - startTime) + " ms) for query by ["
				+ clz.getName() + "] ");*/
		return items;
	}

	
	public List getCustomQueryResultList(String query, int firstResult, int maxResults,Map<String,Object> params) {
		EntityManager em = createEntityManager();
		Query q = em.createQuery(query);
		
		for(Entry<String,Object> entry:params.entrySet()){
			q.setParameter(entry.getKey(), entry.getValue());
		}
		
		q.setFirstResult(firstResult);
		q.setMaxResults(maxResults);
		return q.getResultList();
	}
	
	public List getCustomQueryResultList(String query, Map<String,Object> params) {
		EntityManager em = createEntityManager();
		Query q = em.createQuery(query);
		
		for(Entry<String,Object> entry:params.entrySet()){
			q.setParameter(entry.getKey(), entry.getValue());
		}
		return q.getResultList();
	}
	
	public Object getObject(String queryName) {
		EntityManager em = createEntityManager();
		Query query = em.createQuery(queryName);
		Object rtn = query.getSingleResult();
		return rtn;
	}
	
	
	public Object getObject(String queryName, Map<String, Object> params) {
		EntityManager em = createEntityManager();
		Query query = em.createQuery(queryName);
		for(Entry<String,Object> entry:params.entrySet()){
			query.setParameter(entry.getKey(), entry.getValue());
		}
		Object rtn = query.getSingleResult();
		return rtn;
	}
	
	public T getQueryResult(String query, Map<Object, Object> params) {
		EntityManager em = createEntityManager();
		Query q = em.createQuery(query);
		for(Entry<Object,Object> entry:params.entrySet()){
			Object key = entry.getKey();
			Object value = entry.getValue();
			if (key instanceof String) {
				q.setParameter((String) key, value);
			} else if (key instanceof Integer) {
				q.setParameter(((Integer) key).intValue(), value);
			}
		}
		List<T> items = q.getResultList();
		if(items==null||items.isEmpty()){
			return null;
		}else{
			return items.get(0);
		}
	}
	
	
	/* 
     * 根据id判断PO是否存在 
     */  
    public boolean exists(PK id) {  
        return createEntityManager().find(this.entityClass,id) != null;  
    }  
    
    public T find(PK id){
    	return createEntityManager().find(this.entityClass,id);  
    }
    
    public List getNativeQueryResult(String query, Map<Object, Object> params){
    	EntityManager em = createEntityManager();
    	Query q =  em.createNativeQuery(query);
    	for(Entry<Object,Object> entry:params.entrySet()){
			Object key = entry.getKey();
			Object value = entry.getValue();
			if (key instanceof String) {
				q.setParameter((String) key, value);
			} else if (key instanceof Integer) {
				q.setParameter(((Integer) key).intValue(), value);
			}
		}
    	return q.getResultList();
    }
    
    public int executeNativeUpdate(String query, Map<Object, Object> params){
    	EntityManager em = createEntityManager();
    	Query q =  em.createNativeQuery(query);
    	for(Entry<Object,Object> entry:params.entrySet()){
			Object key = entry.getKey();
			Object value = entry.getValue();
			if (key instanceof String) {
				q.setParameter((String) key, value);
			} else if (key instanceof Integer) {
				q.setParameter(((Integer) key).intValue(), value);
			}
		}
    	return q.executeUpdate();
    }
    
    

}
