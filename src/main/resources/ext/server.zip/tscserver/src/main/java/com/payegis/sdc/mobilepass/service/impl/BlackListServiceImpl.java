package com.payegis.sdc.mobilepass.service.impl;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.payegis.sdc.mobilepass.dao.IBlackListDao;
import com.payegis.sdc.mobilepass.entity.BlackList;
import com.payegis.sdc.mobilepass.service.IBlackListService;

@Service
public class BlackListServiceImpl implements IBlackListService {
	
	@Autowired
	private IBlackListDao blackListDao;

	@Override
	public BlackList findBlankList(String url) {
		// TODO Auto-generated method stub
		String hql = "from BlackList o where o.url=:url";
		Map<Object,Object> params = new HashMap<Object,Object>();
		params.put("url", url);
		return blackListDao.getQueryResult(hql, params);
	}
	
}
