package com.payegis.sdc.mobilepass.util;

import net.sf.json.JSONException;
import net.sf.json.JSONObject;

import com.payegis.sdc.mobilepass.common.Constant;
import org.apache.log4j.Logger;

/**
 * 消息工具类
 * @author xuman.xu
 *
 */
public class MessageUtil {

	private static final Logger LOG = Logger.getLogger(MessageUtil.class);

	/**
	 * 运行时异常信息
	 * @param message 异常信息
	 * @return 异常信息
	 */
	public static JSONObject runtimeErroMsg(String message){
		JSONObject json = new JSONObject();
		json.put(Constant.Result.STATUS, "1");
		json.put(Constant.Result.MESSAGE, message);
		return json;
	}
	
	public static String jsonExceptionMsg(int status, String message){
		JSONObject json = new JSONObject();
		try {
			json.put(Constant.Result.STATUS, String.valueOf(status));
			if(isBlank(message)){			
				json.put(Constant.Result.MESSAGE, "");
			}else{
				json.put(Constant.Result.MESSAGE, message);
			}
		} catch (JSONException e) {
			LOG.error(e.getMessage(),e);
		}
		return json.toString();
	}
	
	public static JSONObject jsonMsg(String status, String message,Object data){
		JSONObject json = new JSONObject();
		try {
			json.put(Constant.Result.STATUS, String.valueOf(status));
			if(isBlank(message)){			
				json.put(Constant.Result.MESSAGE, "");
			}else{
				json.put(Constant.Result.MESSAGE, message);
			}
			if(data == null){
				json.put(Constant.Result.DATA, "");
			}else{
				json.put(Constant.Result.DATA, data);
			}
		} catch (JSONException e) {
			LOG.error(e.getMessage(),e);
		}
		return json;
	}
	
	/**
	 * 运行成功信息
	 * @param message 成功信息
	 * @param data 返回Object对象
	 * @return 成功信息
	 */
	public static JSONObject successMsg(String message,Object data){
		JSONObject json = new JSONObject();
		json.put(Constant.Result.STATUS, "0");
		if(isBlank(message)){			
			json.put(Constant.Result.MESSAGE, "");
		}else{
			json.put(Constant.Result.MESSAGE, message);
		}
		if(data == null){
			json.put(Constant.Result.DATA, "");
		}else{
			json.put(Constant.Result.DATA, data);
		}
		return json;
	}
	
	private static final boolean isBlank(String value){
		if(value == null) 
			return true;
		if(value.trim().length() == 0) 
			return true;
		return false;
	} 
}
