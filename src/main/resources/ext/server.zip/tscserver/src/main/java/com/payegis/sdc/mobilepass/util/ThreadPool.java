package com.payegis.sdc.mobilepass.util;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * @author zw
 *
 */
public class ThreadPool {

	private static ThreadPool instance;
	private static ExecutorService pool;
	
	private ThreadPool(){}
	
	public static ThreadPool getInstance(){
		if(instance==null){
			synchronized (ThreadPool.class){
				if(instance==null){
					instance= new ThreadPool();
					pool= Executors.newCachedThreadPool();
				}
			}
		}
		return instance;
	}
	
	public void execute(Runnable runnable){
		pool.execute(runnable);
	}
	
	public void closePool(){
		pool.shutdown();
		
	}
}
