package com.payegis.sdc.mobilepass.dao;

import com.payegis.sdc.mobilepass.entity.UserInfo;



public interface IUserInfoDao extends IDao<UserInfo,String>{
	
}
