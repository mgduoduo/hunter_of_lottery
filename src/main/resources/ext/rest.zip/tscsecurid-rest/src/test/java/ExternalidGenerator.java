import com.payegis.tscsecurid.common.util.Base64Util;
import org.apache.commons.lang.StringUtils;

import java.util.List;

public class ExternalidGenerator {
    public static void main(String[] args) {
        net.sf.json.JSONObject jo = new net.sf.json.JSONObject();
        jo.put("message","伟哥于2015年10月12日有一笔  交易，交易金额为：300元");
        jo.put("content","customer:weige,amount:300元,tradId:20151012");
       //String externalId = "30fe6c857cd040b2bb1ad629dbcc1c27|wei@payegis.com|http://192.168.109.77:8080/tscsecurid_rest|"+jo.toString();//QA
       // String externalId = "b3c58e837070401aa794f36a8ccc667e|tfd@payegis.com|https://pws.payegis.com.cn/securid-api|"+jo.toString();//PRO
        //String externalId = "825b730040f64af1bd5594192aa31158|dong@payegis.com|https://pws.payegis.com.cn/securid-api|"+jo.toString();//ios tsl
       // String externalId  = "825b730040f64af1bd5594192aa31158|110004|https://pws.payegis.com.cn/securid-api|{\"message\":\"test\", \"content\":\"e1344daf46964145b5d38fdd276a8ca4\"}";
        String externalId  = "825b730040f64af1bd5594192aa31158|110004|https://pws.payegis.com.cn/securid-api";
        String tmp_payCode = "487046266648300015101445245915";
        String payCode=tmp_payCode.substring(0,20);
        String version = payCode.substring(payCode.length() - 2);
        String partnerCode = payCode.substring(14, 17);
        System.out.println(partnerCode);
        String appId = "dcsdk";


        List<String> authUrlList = null;
        String apis= "a,b,c";
        if(StringUtils.isNotEmpty(apis)){
            authUrlList = java.util.Arrays.asList(apis.split(","));
        }

        String info = Base64Util.encodeToString(externalId.getBytes(), Base64Util.NO_WRAP);
        System.out.println(info);
        System.out.println(String.valueOf(info.hashCode()));



    }
}
