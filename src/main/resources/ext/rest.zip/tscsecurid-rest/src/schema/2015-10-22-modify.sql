ALTER TABLE `binding_terminal` ADD COLUMN system_no VARCHAR(40) CHARACTER SET utf8 COLLATE utf8_general_ci COMMENT '业务系统编号';

alter table binding_terminal drop primary key;
alter table binding_terminal add primary key(device_id,system_no);

alter table `strategy_config` add column `PUSH_NOTIFY`  varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci  NULL DEFAULT 'ALL' COMMENT '通知推送策略：ALL-全部设备，DEFAULT-默认设备';
alter table `strategy_config` add column `PUSH_CONFIRM`  varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci  NULL DEFAULT 'DEFAULT' COMMENT '通知推送策略：ALL-全部设备，DEFAULT-默认设备';