
alter table binding_terminal drop primary key;