alter table binding_instructions add column message varchar(512);
alter table binding_instructions add column device_name varchar(128);
alter table binding_instructions add column client_ip varchar(32);
alter table business_system add column validate_mode varchar(32);
alter table binding_instructions add column transaction_id varchar(64);
alter table binding_instructions add column system_name varchar(128);
ALTER TABLE `strategy_config` ADD COLUMN SYSTEM_NO VARCHAR(40) CHARACTER SET utf8 COLLATE utf8_general_ci COMMENT '业务系统编号';
DELETE FROM `strategy_config` WHERE SYSTEM_NO IS NULL;
INSERT INTO `strategy_config`(SYSTEM_NO,IS_OPEN_SECIDEN,WAIT_TIME,DEFAULT_OPTION,MAX_BIND) SELECT SYSTEM_NO , '1', '30', '1', '3' FROM BUSINESS_SYSTEM;

ALTER TABLE `strategy_config` ADD COLUMN PUSH_NOTIFY VARCHAR(10) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT 'ALL' COMMENT '通知推送策略：ALL-全部设备，DEFAULT-默认设备';
ALTER TABLE `strategy_config` ADD COLUMN PUSH_CONFIRM VARCHAR(10) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT 'DEFAULT' COMMENT '通知推送策略：ALL-全部设备，DEFAULT-默认设备';