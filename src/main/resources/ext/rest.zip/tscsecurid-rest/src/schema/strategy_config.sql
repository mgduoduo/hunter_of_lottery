/*
Navicat MySQL Data Transfer

Source Server         : 192.168.109.89
Source Server Version : 50169
Source Host           : 192.168.109.89:3306
Source Database       : tscsecurid_deploy

Target Server Type    : MYSQL
Target Server Version : 50169
File Encoding         : 65001

Date: 2015-09-09 16:49:23
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `strategy_config`
-- ----------------------------
DROP TABLE IF EXISTS `strategy_config`;
CREATE TABLE `strategy_config` (
  `strategy_id` int(11) NOT NULL AUTO_INCREMENT,
  `is_open_seciden` varchar(5) COLLATE utf8_bin DEFAULT NULL COMMENT '是否强制开启二次认证 1:是，0:否',
  `wait_time` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '推送消息等待时间 ',
  `default_option` varchar(5) COLLATE utf8_bin DEFAULT NULL COMMENT '默认选项 1:确定，0:拒绝',
  `max_bind` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '单个账号最多绑定设备数量',
  PRIMARY KEY (`strategy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- ----------------------------
-- Records of strategy_config
-- ----------------------------


alter table binding_instructions modify system_no varchar(128);

ALTER TABLE `binding_info` ADD COLUMN `is_default`  varchar(5) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '0' COMMENT '是否是默认设备，0否，1是';

ALTER TABLE `enterprise_info` ADD COLUMN `is_delete`  char(1) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT 'N' COMMENT '是否删除企业：Y:是 N:否';
