package com.payegis.tscsecurid.rest.api;

import com.payegis.caesar.sdk.device.InternalDeviceId;
import com.payegis.tscsecurid.common.cache.CacheMgr;
import com.payegis.tscsecurid.common.data.bo.AccountInfoDto;
import com.payegis.tscsecurid.common.data.bo.BindInfoDto;
import com.payegis.tscsecurid.common.data.bo.TxnLogBo;
import com.payegis.tscsecurid.common.data.entity.*;
import com.payegis.tscsecurid.common.util.DateUtil;
import com.payegis.tscsecurid.common.util.PropertyUtil;
import com.payegis.tscsecurid.rest.common.*;
import com.payegis.tscsecurid.rest.message.AppUser;
import com.payegis.tscsecurid.rest.message.MessageAssembleUtil;
import com.payegis.tscsecurid.rest.message.MsgBean;
import com.payegis.tscsecurid.rest.service.*;
import com.payegis.tscsecurid.rest.util.*;
import com.sun.jersey.api.json.JSONWithPadding;
import me.chanjar.weixin.mp.api.WxMpInMemoryConfigStorage;
import me.chanjar.weixin.mp.api.WxMpMessageRouter;
import me.chanjar.weixin.mp.api.WxMpService;
import me.chanjar.weixin.mp.api.WxMpServiceImpl;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletRequest;
import javax.websocket.Session;
import javax.ws.rs.*;
import javax.ws.rs.core.Context;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLDecoder;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


/**
 * 账户接口
 *
 * @author user
 */

@Component
@Path("/")
public class AccountApi {

    @Autowired
    private AccountService accountService;

    @Autowired
    private CacheMgr cacheMgr;

    @Autowired
    private StrategyService strategyService;

    @Autowired
    private SystemTxnService systemTxnService;

    @Autowired
    private PasswordProtectService passwordProtectService;

    @Autowired
    private PatternLockService patternLockService;

    @Autowired
    private MessageService messageService;

    @Autowired
    private FeedBackService feedBackService;

    @Autowired
    private BindInstructionsService service;

    @Autowired
    private BindInfoService bindInfoService;

    public static Config config = null;
   /* @Autowired
    private AppRelationService appRelationService;*/

    private static Logger logger = Logger.getLogger(AccountApi.class);

    private int expTime = Integer.parseInt(ConfigFileUtil.getMemcacheExpireTime());
    private String pushDeviceId;

    private String pushContent;

    protected WxMpInMemoryConfigStorage wxMpConfigStorage;
    protected WxMpService wxMpService;
    protected WxMpMessageRouter wxMpMessageRouter;

    public String getPushDeviceId() {
        return pushDeviceId;
    }

    public void setPushDeviceId(String pushDeviceId) {
        this.pushDeviceId = pushDeviceId;
    }

    public String getPushContent() {
        return pushContent;
    }

    public void setPushContent(String pushContent) {
        this.pushContent = pushContent;
    }

    private ExecutorService cachedThreadPool = Executors.newCachedThreadPool();


    /*************************************************************************Bind/Account Api Begin*****************************************************************************************************************/
    /**
     * 绑定token
     *
     * @return
     */
    @POST
    @Path("/{version}/bindToken")
    @Produces("application/json;charset=utf-8")
    public String bindTokenVersion(@PathParam(Constrants.VERSION) String version,@FormParam(Constrants.DEVICE_ID) String deviceId, @FormParam(Constrants.TOKEN) String token, @FormParam(Constrants.APPCLIENT) String appClient) {
        return bindToken(deviceId,token,appClient);
    }

    @POST
    @Path("/rest/account/bindToken")
    @Produces("application/json;charset=utf-8")
    public String bindToken(@FormParam(Constrants.DEVICE_ID) String deviceId, @FormParam(Constrants.TOKEN) String token, @FormParam(Constrants.APPCLIENT) String appClient) {
        Map<String, String> map = new HashMap<String, String>();
        map.put(Constrants.DEVICE_ID, deviceId);
        map.put(Constrants.TOKEN, token);
        map.put(Constrants.APPCLIENT, appClient);
        if (!Validator.validArgs(map)) {
            return JsonWrapUtil.reMsg(ReturnTypeEnum.PARAMS_ERROR);
        }
        DeviceToken deviceToken = accountService.selectTokenByDeviceId(deviceId);
        if (null == deviceToken) {
            deviceToken = new DeviceToken();
            deviceToken.setDeviceId(deviceId);
            deviceToken.setAppClient(appClient);
            deviceToken.setToken(token);
            accountService.saveDeviceToken(deviceToken);
        } else {
            deviceToken.setToken(token);
            accountService.updateDeviceToken(deviceToken);
        }
        return StringUtil.jsonSuccessMsg(Constrants.SUCCESS);
    }



    /**
     * 用户帐号绑定列表
     * @param deviceId
     * @return
     */

    @POST
    @Path("/{version}/list")
    @Produces("application/json;charset=utf-8")
    public String accountListVersion(@PathParam(Constrants.VERSION) String version,@FormParam(Constrants.DEVICE_ID) String deviceId) {
        return accountList(deviceId);
    }
    @POST
    @Path("/rest/account/list")
    @Produces("application/json;charset=utf-8")
    public String accountList(@FormParam(Constrants.DEVICE_ID) String deviceId) {
        Map<String, String> map = new HashMap<String, String>();
        map.put(Constrants.DEVICE_ID, deviceId);
        if (!Validator.validArgs(map)) {
            return JsonWrapUtil.reMsg(ReturnTypeEnum.PARAMS_ERROR);
        }
        List<AccountInfoDto> accountInfos = accountService.selectAccountInfo(deviceId);
        return StringUtil.jsonSuccessData(accountInfos);
    }



    /**
     * 用户账号绑定
     */
    @POST
    @Path("/{version}/bind")
    @Produces("application/json;charset=utf-8")
    public String bindAccountVersion(@PathParam(Constrants.VERSION) String version,@FormParam(Constrants.SYSTEM_NO) String systemNo, @FormParam(Constrants.DEVICE_ID) String deviceId, @FormParam(Constrants.SYSTEMACCOUNT) String systemAccount, @FormParam(Constrants.SYSTEM_URL) String systemUrl, @FormParam(Constrants.ALIAS) String alias) {
        return bindAccount(systemNo,deviceId,systemAccount,systemUrl,alias);
    }
        @POST
    @Path("/rest/account/bind")
    @Produces("application/json;charset=utf-8")
    public String bindAccount(@FormParam(Constrants.SYSTEM_NO) String systemNo, @FormParam(Constrants.DEVICE_ID) String deviceId, @FormParam(Constrants.SYSTEMACCOUNT) String systemAccount, @FormParam(Constrants.SYSTEM_URL) String systemUrl, @FormParam(Constrants.ALIAS) String alias) {
        Map<String, String> map = new HashMap<String, String>();
        map.put(Constrants.DEVICE_ID, deviceId);
        map.put(Constrants.SYSTEM_NO, systemNo);
        map.put(Constrants.SYSTEMACCOUNT, systemAccount);
        map.put(Constrants.SYSTEM_URL, systemUrl);
        logger.info("deviceId:" + deviceId + ",systemAccount：" + systemAccount + ",systemNo：" + systemNo + ",systemUrl:" + systemUrl);
        if (!Validator.validArgs(map)) {
            return JsonWrapUtil.reMsg(ReturnTypeEnum.PARAMS_ERROR);
        }
        BusinessSystem businessSystem = accountService.selectBySystemNo(systemNo);
        if (null == businessSystem) {
            return JsonWrapUtil.reMsg(ReturnTypeEnum.BUSINESSNO_ERROR);
        }
        BindingInfo isBind = accountService.selectBindInfoByDidAndSysIdAndSysAccount(deviceId, businessSystem.getSystemId(), systemAccount);
        if (null != isBind) {
            return JsonWrapUtil.reMsg(ReturnTypeEnum.HAVE_BIND);
        }
        if (DeviceTerminalTypeEnum.ONETOMANY.getCode().equals(businessSystem.getIsMultipleBinding())) {
            List<BindingInfo> isMutipartBind = accountService.selectBindInfosBySystemIdAndAccount(businessSystem.getSystemId(), systemAccount);
            if (null != isMutipartBind && !isMutipartBind.isEmpty()) {
                return JsonWrapUtil.reMsg(ReturnTypeEnum.OTHER_HAVE_BIND);
            }
        }
        if (DeviceTerminalTypeEnum.ONETOONE.getCode().equals(businessSystem.getIsMultipleBinding())) {
            List<BindingInfo> isMutipartBind = accountService.selectBindInfosBySystemIdAndAccount(businessSystem.getSystemId(), systemAccount);
            if (null != isMutipartBind && !isMutipartBind.isEmpty()) {
                return JsonWrapUtil.reMsg(ReturnTypeEnum.OTHER_HAVE_BIND);
            }
            BindingInfo isMutipartBindTwo = accountService.selectBindInfoBySystemIdAndDeviceId(businessSystem.getSystemId(), deviceId);
            if (null != isMutipartBindTwo) {
                return JsonWrapUtil.reMsg(ReturnTypeEnum.ONE_BIND);
            }
        }
        BusinessSystemCallback businessSystemCallback = accountService.selectBySystemIdAndType(businessSystem.getSystemId(), CallbackTypeEnum.BINDING.getCode());
        if (null != businessSystemCallback) {
            HashMap<String, String> paramMapSend = new HashMap<String, String>();
            paramMapSend.put(Constrants.DEVICE_ID, deviceId);
            paramMapSend.put("uid", systemAccount);
            paramMapSend.put("type", "bind");
            String result = WSUtil.sendSignature(businessSystemCallback.getCallbackUrl(), businessSystem.getAppId(), businessSystem.getAppKey(), paramMapSend);
            JSONObject json = JSONObject.fromObject(result);
            String sendStatus = json.getString(Constrants.STATUS);
            if (!Constrants.SUCCESS_STATUS.equals(sendStatus)) {
                return StringUtil.jsonExceptionMsg(Integer.parseInt(sendStatus), json.getString(Constrants.MESSAGE));
            }
        }
        BindingInfo bindingInfo = new BindingInfo();
        bindingInfo.setDeviceId(deviceId);
        bindingInfo.setEnterpriseId(businessSystem.getEnterpriseId());
        bindingInfo.setSystemId(businessSystem.getSystemId());
        bindingInfo.setSystemAccount(systemAccount);
        bindingInfo.setBindingTime(DateUtil.getCurrentDateString());
        bindingInfo.setOnlineStatus(OnlineStatusEnum.OFFLINE.getCode());
        bindingInfo.setCreateTime(DateUtil.getCurrentDateString());
        List<BindingInfoEnterprise> list = accountService.selectBySystemNoAndSystemAccount(systemNo, systemAccount);
        if (list == null || list.isEmpty()) {
            bindingInfo.setIsDefault(Constrants.IS_DEFAULT_DEVICE_YES);//首次绑定的账号，设为默认账号
        } else {
            bindingInfo.setIsDefault(Constrants.IS_DEFAULT_DEVICE_NO);
        }
        BindingLog bindingLog = new BindingLog();
        bindingLog.setDeviceId(deviceId);
        bindingLog.setEnterpriseId(businessSystem.getEnterpriseId());
        bindingLog.setSystemId(businessSystem.getSystemId());
        bindingLog.setSystemAccount(systemAccount);
        bindingLog.setBindingLogType(BindTypeEnum.BINDING.getCode());
        BindingInfoEnterprise infoEnterprise = new BindingInfoEnterprise();
        String systemLogoHead = "";
        SysEnterpriseConfig config = accountService.selectSysConfigByEnterId(businessSystem.getEnterpriseId());
        if (null != config) {
            systemLogoHead = accountService.selectSysConfigByEnterId(businessSystem.getEnterpriseId()).getServerUrl();
        }
        EnterpriseInfo enterpriseInfo = accountService.selectEnterpriceById(businessSystem.getEnterpriseId());
        infoEnterprise.setSystemNo(systemNo);
        infoEnterprise.setSystemLogoUrl(systemLogoHead + businessSystem.getSystemLogoUrl());
        infoEnterprise.setSystemName(businessSystem.getSystemName());
        infoEnterprise.setSystemAccount(systemAccount);
        infoEnterprise.setBusinessType(businessSystem.getSystemUseScene());
        infoEnterprise.setSystemUrl(systemUrl);
        infoEnterprise.setEnterpriseName(null == enterpriseInfo ? "" : enterpriseInfo.getEnterpriseName());
        accountService.saveBindInfo(bindingInfo, bindingLog, infoEnterprise);

        if (!StringUtil.isBlank(alias)) {
            //设置别名和默认手势密码
            Map<String, Object> requesMap = new HashMap<String, Object>();
            requesMap.put(Constrants.DEVICE_ID, deviceId);
            requesMap.put(Constrants.ALIAS, alias);
            requesMap.put(Constrants.SYSTEM_NO, systemNo);
            WSUtil.sendRequest(ConfigFileUtil.getLockSetUrl(), requesMap);
        }
        List<BindingInfo> bindingInfoList = accountService.selectBindInfosBySystemIdAndAccount(businessSystem.getSystemId(), systemAccount);
        messageSend(bindingInfoList, businessSystem, Constrants.SYSTEM, systemAccount, Constrants.BIND, null, null, null, null);
        BusinessSystemCallback businessSystemLoginCallback = accountService.selectBySystemIdAndType(businessSystem.getSystemId(), CallbackTypeEnum.LOGIN.getCode());
        if (null != businessSystemLoginCallback)
            accountService.updateOnlineStatusWithNoLog(deviceId, businessSystem.getSystemId(), systemAccount, OnlineStatusEnum.ONLINE.getCode(), businessSystem.getSystemNo());
        else
            accountService.updateOnlineStatusWithNoLog(deviceId, businessSystem.getSystemId(), systemAccount, OnlineStatusEnum.OFFLINE.getCode(), businessSystem.getSystemNo());
        return StringUtil.jsonSuccessData(0, Constrants.BIND_SUCCESS, infoEnterprise);
    }


    /**
     * 用户解绑
     * @return
     */

    @POST
    @Path("/{version}/unbind")
    @Produces("application/json;charset=utf-8")
    public String unbindAccountVersion(@PathParam(Constrants.VERSION) String version,@FormParam(Constrants.SYSTEMACCOUNT) String systemAccount, @FormParam(Constrants.DEVICE_ID) String deviceId, @FormParam(Constrants.SYSTEM_NO) String systemNo) {
        return unbindAccount(systemAccount,deviceId,systemNo);
    }
    @POST
    @Path("/rest/account/unbind")
    @Produces("application/json;charset=utf-8")
    public String unbindAccount(@FormParam(Constrants.SYSTEMACCOUNT) String systemAccount, @FormParam(Constrants.DEVICE_ID) String deviceId, @FormParam(Constrants.SYSTEM_NO) String systemNo) {
        Map<String, String> map = new HashMap<String, String>();
        map.put(Constrants.DEVICE_ID, deviceId);
        map.put(Constrants.SYSTEM_NO, systemNo);
        map.put(Constrants.SYSTEMACCOUNT, systemAccount);

        if (!Validator.validArgs(map)) {
            return JsonWrapUtil.reMsg(ReturnTypeEnum.PARAMS_ERROR);
        }
        BusinessSystem businessSystem = accountService.selectBySystemNo(systemNo);
        if (null == businessSystem) {
            return JsonWrapUtil.reMsg(ReturnTypeEnum.BUSINESSNO_ERROR);
        }
        BindingInfo isBind = accountService.selectBindInfoByDidAndSysIdAndSysAccount(deviceId, businessSystem.getSystemId(), systemAccount);
        if (null == isBind) {
            return JsonWrapUtil.reMsg(ReturnTypeEnum.NO_BIND);
        }
        BusinessSystemCallback businessSystemCallback = accountService.selectBySystemIdAndType(businessSystem.getSystemId(), CallbackTypeEnum.UNBINDING.getCode());
        if (null != businessSystemCallback) {
            HashMap<String, String> paramMapSend = new HashMap<String, String>();
            paramMapSend.put(Constrants.DEVICE_ID, deviceId);
            paramMapSend.put("uid", systemAccount);
            paramMapSend.put("type", "unbind");
            String result = WSUtil.sendSignature(businessSystemCallback.getCallbackUrl(), businessSystem.getAppId(), businessSystem.getAppKey(), paramMapSend);
            JSONObject json = JSONObject.fromObject(result);
            String sendStatus = json.getString(Constrants.STATUS);
            if (!Constrants.SUCCESS_STATUS.equals(sendStatus)) {
                return StringUtil.jsonExceptionMsg(Integer.parseInt(sendStatus), json.getString(Constrants.MESSAGE));
            }
        }
        BindingInfoEnterprise infoEnterprise = new BindingInfoEnterprise();
        infoEnterprise.setDeviceId(deviceId);
        infoEnterprise.setSystemAccount(systemAccount);
        infoEnterprise.setSystemNo(systemNo);
        accountService.deleteBindInfo(deviceId, businessSystem.getSystemId(), systemAccount, infoEnterprise);
        JSONObject msgContent = new JSONObject();
        msgContent.put("type", Constrants.SYSTEM);
        msgContent.put("ctx", "您的" + businessSystem.getSystemName() + "账号:" + systemAccount + ",于" + DateUtil.getCurrentDateString() + "成功解绑");
        msgPushMethod(deviceId, "", msgContent.toString(), null, null, null);
        try {
            sendWeChatMsg(deviceId, businessSystem.getSystemName(), systemAccount, DateUtil.getCurrentDateString(), Constrants.UNBIND);
        } catch (Exception e) {
            e.printStackTrace();
        }

        List<BindingInfo> bindingInfoList = accountService.selectBindInfosBySystemIdAndAccount(businessSystem.getSystemId(), systemAccount);
        messageSend(bindingInfoList, businessSystem, Constrants.SYSTEM, systemAccount, Constrants.UNBIND, null, null, null, null);
        return StringUtil.jsonSuccessMsg(Constrants.UNBIND_SUCCESS);
    }



    @POST
    @Path("/{version}/isBind")
    @Produces("application/json;charset=utf-8")
    public String isBindVersion(@PathParam(Constrants.VERSION) String version,@FormParam(Constrants.SYSTEM_NO) String systemNo, @FormParam(Constrants.SYSTEM_ACCOUNT) String systemAccount) {
        return isBind(systemNo,systemAccount);
    }

    @POST
    @Path("/rest/account/isBind")
    @Produces("application/json;charset=utf-8")
    public String isBind(@FormParam(Constrants.SYSTEM_NO) String systemNo, @FormParam(Constrants.SYSTEM_ACCOUNT) String systemAccount) {
        Map<String, String> map = new HashMap<String, String>();
        map.put(Constrants.SYSTEM_NO, systemNo);
        map.put(Constrants.SYSTEM_ACCOUNT, systemAccount);
        if (!Validator.validArgs(map)) {
            return JsonWrapUtil.reMsg(ReturnTypeEnum.PARAMS_ERROR);
        }
        BusinessSystem businessSystem = accountService.selectBySystemNo(systemNo);
        if (null == businessSystem) {
            return JsonWrapUtil.reMsg(ReturnTypeEnum.BUSINESSNO_ERROR);
        }
        List<BindingInfo> isBind = accountService.selectBindInfosBySystemIdAndAccount(businessSystem.getSystemId(), systemAccount);
        if (null != isBind && !isBind.isEmpty()) {
            return JsonWrapUtil.reMsg(ReturnTypeEnum.DEVICE_HAS_BOUND_THE_ACCOUNT);
        }
        return JsonWrapUtil.reMsg(ReturnTypeEnum.ACCOUNT_IS_NOT_BOUND_BY_DEVICE);
    }

    @POST
    @Path("/{version}/isBound")
    @Produces("application/json;charset=utf-8")
    public String isBound(@PathParam(Constrants.VERSION) String version,@FormParam(Constrants.DEVICE_ID) String deviceId, @FormParam(Constrants.SYSTEM_NO) String systemNo, @FormParam(Constrants.SYSTEM_ACCOUNT) String systemAccount) {
        return isDeviceBind(deviceId,systemNo,systemAccount);
    }
    @POST
    @Path("/rest/account/isDeviceBind")
    @Produces("application/json;charset=utf-8")
    public String isDeviceBind(@FormParam(Constrants.DEVICE_ID) String deviceId, @FormParam(Constrants.SYSTEM_NO) String systemNo, @FormParam(Constrants.SYSTEM_ACCOUNT) String systemAccount) {
        Map<String, String> map = new HashMap<String, String>();
        map.put(Constrants.DEVICE_ID, deviceId);
        map.put(Constrants.SYSTEM_NO, systemNo);
        map.put(Constrants.SYSTEM_ACCOUNT, systemAccount);
        if (!Validator.validArgs(map)) {
            return JsonWrapUtil.reMsg(ReturnTypeEnum.PARAMS_ERROR);
        }
        BusinessSystem businessSystem = accountService.selectBySystemNo(systemNo);
        if (null == businessSystem) {
            return JsonWrapUtil.reMsg(ReturnTypeEnum.BUSINESSNO_ERROR);
        }
        List<BindingInfo> bindInfos = accountService.selectBindInfosBySystemIdAndAccount(businessSystem.getSystemId(), systemAccount);
        if (bindInfos == null || bindInfos.isEmpty()) {
            return JsonWrapUtil.reMsg(ReturnTypeEnum.ACCOUNT_NEVER_BIND);
        }
        BindingInfo isBind = accountService.selectBindInfoByDidAndSysIdAndSysAccount(deviceId, businessSystem.getSystemId(), systemAccount);
        if (null == isBind) {
            return JsonWrapUtil.reMsg(ReturnTypeEnum.ACCOUNT_IS_NOT_BOUND_BY_THE_DEVICE);
        }
        return JsonWrapUtil.reMsg(ReturnTypeEnum.DEVICE_HAS_BOUND_THE_ACCOUNT);
    }

    @POST
    @Path("/{version}/getRefDevicesByAccount")
    @Produces("application/json;charset=utf-8")
    public String getRefDevicesByAccount(@PathParam(Constrants.VERSION) String version,@FormParam(Constrants.SYSTEM_NO) String systemNo, @FormParam(Constrants.SYSTEMACCOUNT) String systemAccount) {
        return listBindinfoByAccountAndSystemNo(systemNo,systemAccount);
    }
    @POST
    @Path("/rest/account/listBindInfo")
    @Produces("application/json;charset=utf-8")
    public String listBindinfoByAccountAndSystemNo(@FormParam(Constrants.SYSTEM_NO) String systemNo, @FormParam(Constrants.SYSTEMACCOUNT) String systemAccount) {
        Map<String, String> map = new HashMap<String, String>();
        map.put(Constrants.SYSTEM_NO, systemNo);
        map.put(Constrants.SYSTEMACCOUNT, systemAccount);
        if (!Validator.validArgs(map)) {
            return JsonWrapUtil.reMsg(ReturnTypeEnum.PARAMS_ERROR);
        }
        BusinessSystem businessSystem = accountService.selectBySystemNo(systemNo);
        if (null == businessSystem) {
            return JsonWrapUtil.reMsg(ReturnTypeEnum.BUSINESSNO_ERROR);
        }
        List<BindingInfoEnterprise> bindInfos = accountService.selectBySystemNoAndSystemAccount(systemNo, systemAccount);
        if (null != bindInfos && !bindInfos.isEmpty()) {
            for (BindingInfoEnterprise be : bindInfos) {
                be.setSystemNo(systemNo);
            }
        }
        JSONObject json = new JSONObject();
        json.put("bindInfos", bindInfos);
        return StringUtil.jsonSuccessData(json);
    }


    @POST
    @Path("/{version}/updateBindAlias")
    @Produces("application/json;charset=utf-8")
    public String updateBindAliasVersion(@PathParam(Constrants.VERSION) String version,@FormParam(Constrants.DEVICE_ID) String deviceId, @FormParam(Constrants.ALIAS) String alias) {
        return updateBindAlias(deviceId,alias);
    }

    @POST
    @Path("/rest/account/updateBindAlias")
    @Produces("application/json;charset=utf-8")
    public String updateBindAlias(@FormParam(Constrants.DEVICE_ID) String deviceId, @FormParam(Constrants.ALIAS) String alias) {
        Map<String, String> map = new HashMap<String, String>();
        map.put(Constrants.ALIAS, alias);
        map.put(Constrants.DEVICE_ID, deviceId);
        if (!Validator.validArgs(map)) {
            return JsonWrapUtil.reMsg(ReturnTypeEnum.PARAMS_ERROR);
        }
        BindingTerminal bt = new BindingTerminal();
        bt.setDeviceId(deviceId);
        bt.setAlias(alias);
        int res = accountService.updateBindDeviceAlias(bt);
        if (res == 1)
            return JsonWrapUtil.reMsg(ReturnTypeEnum.UPDATE_SUCCESS);
        return JsonWrapUtil.reMsg(ReturnTypeEnum.UPDATE_FAIL);
    }


    @POST
    @Path("/{version}/setDefaultDevice")
    @Produces("application/json;charset=utf-8")
    public String setDefaultDeviceVersion(@PathParam(Constrants.VERSION) String version,@FormParam(Constrants.DEVICE_ID) String deviceId, @FormParam(Constrants.SYSTEM_NO) String systemNo, @FormParam(Constrants.SYSTEMACCOUNT) String systemAccount) {
        return setDefaultDevice(deviceId,systemNo,systemAccount);
    }
    @POST
    @Path("/rest/account/setDefaultDevice")
    @Produces("application/json;charset=utf-8")
    public String setDefaultDevice(@FormParam(Constrants.DEVICE_ID) String deviceId, @FormParam(Constrants.SYSTEM_NO) String systemNo, @FormParam(Constrants.SYSTEMACCOUNT) String systemAccount) {
        Map<String, String> map = new HashMap<String, String>();

        map.put(Constrants.DEVICE_ID, deviceId);

        map.put(Constrants.SYSTEM_NO, systemNo);

        map.put(Constrants.SYSTEMACCOUNT, systemAccount);

        if (!Validator.validArgs(map)) {
            return JsonWrapUtil.reMsg(ReturnTypeEnum.PARAMS_ERROR);
        }

        BusinessSystem businessSystem = accountService.selectBySystemNo(systemNo);
        if (null == businessSystem) {
            return JsonWrapUtil.reMsg(ReturnTypeEnum.BUSINESSNO_ERROR);
        }
        int systemId = businessSystem.getSystemId();

        accountService.updateDeviceNoDefault(systemId, systemAccount);
        int res = accountService.updateDeviceDefault(deviceId, systemId, systemAccount);
        if (res == 1)
            return JsonWrapUtil.reMsg(ReturnTypeEnum.UPDATE_SUCCESS);
        return JsonWrapUtil.reMsg(ReturnTypeEnum.UPDATE_FAIL);
    }


    @POST
    @Path("/rest/account/unbindPush")
    @Produces("application/json;charset=utf-8")
    public String unbindAccount0(@FormParam(Constrants.SYSTEMACCOUNT) String systemAccount, @FormParam(Constrants.DEVICE_ID) String deviceId, @FormParam(Constrants.SYSTEM_NO) String systemNo) {
        Map<String, String> map = new HashMap<String, String>();
        map.put(Constrants.DEVICE_ID, deviceId);
        map.put(Constrants.SYSTEM_NO, systemNo);
        map.put(Constrants.SYSTEMACCOUNT, systemAccount);
        if (!Validator.validArgs(map)) {
            return JsonWrapUtil.reMsg(ReturnTypeEnum.PARAMS_ERROR);
        }
        BusinessSystem businessSystem = accountService.selectBySystemNo(systemNo);
        if (null == businessSystem) {
            return JsonWrapUtil.reMsg(ReturnTypeEnum.BUSINESSNO_ERROR);
        }
        BindingInfo isBind = accountService.selectBindInfoByDidAndSysIdAndSysAccount(deviceId, businessSystem.getSystemId(), systemAccount);
        if (null == isBind) {
            return JsonWrapUtil.reMsg(ReturnTypeEnum.NO_BIND);
        }
        BusinessSystemCallback businessSystemCallback = accountService.selectBySystemIdAndType(businessSystem.getSystemId(), CallbackTypeEnum.UNBINDING.getCode());
        if (null != businessSystemCallback) {
            HashMap<String, String> paramMapSend = new HashMap<String, String>();
            paramMapSend.put(Constrants.DEVICE_ID, deviceId);
            paramMapSend.put("uid", systemAccount);
            paramMapSend.put("type", "unbind");
            String result = WSUtil.sendSignature(businessSystemCallback.getCallbackUrl(), businessSystem.getAppId(), businessSystem.getAppKey(), paramMapSend);
            JSONObject json = JSONObject.fromObject(result);
            String sendStatus = json.getString(Constrants.STATUS);
            if (!Constrants.SUCCESS_STATUS.equals(sendStatus)) {
                return StringUtil.jsonExceptionMsg(Integer.parseInt(sendStatus), json.getString(Constrants.MESSAGE));
            }
        }
        BindingInfoEnterprise infoEnterprise = new BindingInfoEnterprise();
        infoEnterprise.setDeviceId(deviceId);
        infoEnterprise.setSystemAccount(systemAccount);
        infoEnterprise.setSystemNo(systemNo);
        accountService.deleteBindInfo(deviceId, businessSystem.getSystemId(), systemAccount, infoEnterprise);
        JSONObject msgContent = new JSONObject();
        JSONObject ctx = new JSONObject();
        msgContent.put("type", LogTypeEnum.UNBINDING.getCode());
        ctx.put(Constrants.SYSTEM_NO, systemNo);
        ctx.put(Constrants.SYSTEM_ACCOUNT, systemAccount);
        ctx.put(Constrants.FROM, "customer");
        msgContent.put("ctx", ctx);
        msgPushMethod(deviceId, "", msgContent.toString(), null, null, null);

        List<BindingInfo> bindingInfoList = accountService.selectBindInfosBySystemIdAndAccount(businessSystem.getSystemId(), systemAccount);
        messageSend(bindingInfoList, businessSystem, Constrants.SYSTEM, systemAccount, Constrants.UNBIND, null, null, null, null);
        return StringUtil.jsonSuccessMsg(Constrants.UNBIND_SUCCESS);
    }


    @POST
    @Path("/rest/bindinfo/save")
    @Produces("application/json;charset=utf-8")
    public String saveBindinfo(@FormParam(Constrants.DEVICE_ID) String deviceId, @FormParam(Constrants.SYSTEM_NO) String systemNo, @FormParam(Constrants.SYSTEM_LOGO_URL) String systemLogoUrl, @FormParam(Constrants.SYSTEM_ACCOUNT) String systemAccount, @FormParam(Constrants.SYSTEM_URL) String systemUrl, @FormParam(Constrants.SYSTEM_NAME) String systemName, @FormParam(Constrants.BUSINESS_TYPE) String businessType, @FormParam(Constrants.ENTERPRISE_NAME) String enterpriseName, @FormParam(Constrants.IS_DEFAULT) String isDefault) {
        Map<String, String> map = new HashMap<String, String>();
        map.put(Constrants.DEVICE_ID, deviceId);
        map.put(Constrants.SYSTEM_NO, systemNo);
        map.put(Constrants.SYSTEM_LOGO_URL, systemLogoUrl);
        map.put(Constrants.SYSTEM_ACCOUNT, systemAccount);
        map.put(Constrants.SYSTEM_URL, systemUrl);
        map.put(Constrants.SYSTEM_NAME, systemName);
        map.put(Constrants.BUSINESS_TYPE, businessType);
        //map.put(Constrants.ENTERPRISE_NAME, enterpriseName);
        if (!Validator.validArgs(map)) {
            return JsonWrapUtil.reMsg(ReturnTypeEnum.PARAMS_ERROR);
        }
        BindingInfoEnterprise bindInfo = bindInfoService.selectByDeviceIdAndSystemNoAndSystemAccount(deviceId, systemNo, systemAccount);
        if (null != bindInfo) {
            //return StringUtil.jsonExceptionMsg(Constrants.FAIL_STATUS, Constrants.FAIL);
            bindInfo.setSystemLogoUrl(systemLogoUrl);
            bindInfo.setSystemUrl(systemUrl);
            bindInfo.setSystemName(systemName);
            bindInfo.setBusinessType(businessType);
            bindInfo.setEnterpriseName(enterpriseName);
            bindInfoService.updateBindInfo(bindInfo);
        } else {
            bindInfo = new BindingInfoEnterprise();
            bindInfo.setDeviceId(deviceId);
            bindInfo.setSystemAccount(systemAccount);
            bindInfo.setSystemLogoUrl(systemLogoUrl);
            bindInfo.setSystemNo(systemNo);
            bindInfo.setSystemUrl(systemUrl);
            bindInfo.setSystemName(systemName);
            bindInfo.setBindingTime(DateUtil.getCurrentDateString());
            bindInfo.setBusinessType(businessType);
            bindInfo.setEnterpriseName(enterpriseName);
            BindingLogEnterprise logInfo = new BindingLogEnterprise();
            logInfo.setBindingLogType(BindTypeEnum.BINDING.getCode());
            logInfo.setDeviceId(deviceId);
            logInfo.setEnterpriseName(enterpriseName);
            logInfo.setOperationTime(DateUtil.getCurrentDateString());
            logInfo.setSystemAccount(systemAccount);
            logInfo.setSystemName(systemName);
            logInfo.setSystemNo(systemNo);
            bindInfoService.saveBindInfo(bindInfo, logInfo);
        }
        return StringUtil.jsonSuccessMsg(Constrants.SUCCESS);
    }

    @POST
    @Path("/rest/bindinfo/delete")
    @Produces("application/json;charset=utf-8")
    public String deleteBindinfo(@FormParam(Constrants.DEVICE_ID) String deviceId, @FormParam(Constrants.SYSTEM_ACCOUNT) String systemAccount, @FormParam(Constrants.SYSTEM_NO) String systemNo) {
        Map<String, String> map = new HashMap<String, String>();
        map.put(Constrants.DEVICE_ID, deviceId);
        map.put(Constrants.SYSTEM_ACCOUNT, systemAccount);
        map.put(Constrants.SYSTEM_NO, systemNo);
        if (!Validator.validArgs(map)) {
            return JsonWrapUtil.reMsg(ReturnTypeEnum.PARAMS_ERROR);
        }
        BindingInfoEnterprise bindInfo = bindInfoService.selectByDeviceIdAndSystemNoAndSystemAccount(deviceId, systemNo, systemAccount);
        if (null == bindInfo) {
            return StringUtil.jsonSuccessMsg(Constrants.SUCCESS);
        }
        BindingLogEnterprise logInfo = new BindingLogEnterprise();
        logInfo.setBindingLogType(BindTypeEnum.UNBINDING.getCode());
        logInfo.setDeviceId(deviceId);
        logInfo.setEnterpriseName(bindInfo.getEnterpriseName());
        logInfo.setOperationTime(DateUtil.getCurrentDateString());
        logInfo.setSystemAccount(systemAccount);
        logInfo.setSystemName(bindInfo.getSystemName());
        logInfo.setSystemNo(systemNo);
        bindInfoService.deleteBindInfo(bindInfo.getBingdingId(), logInfo);
        return StringUtil.jsonSuccessMsg(Constrants.SUCCESS);
    }

    @POST
    @Path("/rest/bindinfo/update")
    @Produces("application/json;charset=utf-8")
    public String updateBindinfo(@FormParam(Constrants.DEVICE_ID) String deviceId, @FormParam(Constrants.SYSTEM_NO) String systemNo, @FormParam(Constrants.SYSTEM_LOGO_URL) String systemLogoUrl, @FormParam(Constrants.SYSTEM_ACCOUNT) String systemAccount, @FormParam(Constrants.SYSTEM_URL) String systemUrl, @FormParam(Constrants.SYSTEM_NAME) String systemName, @FormParam(Constrants.BUSINESS_TYPE) String businessType, @FormParam(Constrants.ENTERPRISE_NAME) String enterpriseName) {
        Map<String, String> map = new HashMap<String, String>();
        map.put(Constrants.BIND_ID, deviceId);
        map.put(Constrants.SYSTEM_NO, systemNo);
        map.put(Constrants.SYSTEM_LOGO_URL, systemLogoUrl);
        map.put(Constrants.SYSTEM_ACCOUNT, systemAccount);
        map.put(Constrants.SYSTEM_URL, systemUrl);
        map.put(Constrants.SYSTEM_NAME, systemName);
        map.put(Constrants.BUSINESS_TYPE, businessType);
        map.put(Constrants.ENTERPRISE_NAME, enterpriseName);
        if (!Validator.validArgs(map)) {
            return JsonWrapUtil.reMsg(ReturnTypeEnum.PARAMS_ERROR);
        }
        BindingInfoEnterprise bindInfo = bindInfoService.selectByDeviceIdAndSystemNoAndSystemAccount(deviceId, systemNo, systemAccount);
        if (null == bindInfo) {
            return StringUtil.jsonExceptionMsg(Constrants.FAIL_STATUS, Constrants.FAIL);
        }
        bindInfo.setSystemAccount(systemAccount);
        bindInfo.setSystemLogoUrl(systemLogoUrl);
        bindInfo.setSystemNo(systemNo);
        bindInfo.setSystemUrl(systemUrl);
        bindInfo.setSystemName(systemName);
        bindInfo.setEditTime(DateUtil.getCurrentDateString());
        bindInfo.setBusinessType(businessType);
        bindInfo.setEnterpriseName(enterpriseName);
        bindInfoService.updateBindInfo(bindInfo);
        return StringUtil.jsonSuccessMsg(Constrants.SUCCESS);
    }

    @POST
    @Path("/rest/bindinfo/updateOnlineStatus")
    @Produces("application/json;charset=utf-8")
    public String updateOnlineStatus(@FormParam(Constrants.SYSTEM_NO) String systemNo, @FormParam(Constrants.SYSTEM_ACCOUNT) String systemAccount, @FormParam(Constrants.ONLINE_STATUS) String onlineStatus) {
        Map<String, String> map = new HashMap<String, String>();
        map.put(Constrants.ONLINE_STATUS, onlineStatus);
        map.put(Constrants.SYSTEM_NO, systemNo);
        map.put(Constrants.SYSTEM_ACCOUNT, systemAccount);
        if (!Validator.validArgs(map)) {
            return JsonWrapUtil.reMsg(ReturnTypeEnum.PARAMS_ERROR);
        }
        BindingInfoEnterprise bindInfo = new BindingInfoEnterprise();
        bindInfo.setSystemAccount(systemAccount);
        bindInfo.setSystemNo(systemNo);
        bindInfo.setOnlineStatus(onlineStatus);
        bindInfo.setEditTime(DateUtil.getCurrentDateString());
        bindInfoService.updateBindInfoOlineStatus(bindInfo);
        return StringUtil.jsonSuccessMsg(Constrants.SUCCESS);
    }

    @POST
    @Path("/{version}/listByDevice")
    @Produces("application/json;charset=utf-8")
    public String listBindinfoVersion(@PathParam(Constrants.VERSION) String version,@FormParam(Constrants.DEVICE_ID) String deviceId, @FormParam(Constrants.SYSTEM_NO) String systemNo) {
        return listBindinfo(deviceId,systemNo);
    }

    @POST
    @Path("/rest/bindinfo/list")
    @Produces("application/json;charset=utf-8")
    public String listBindinfo(@FormParam(Constrants.DEVICE_ID) String deviceId, @FormParam(Constrants.SYSTEM_NO) String systemNo) {
        Map<String, String> map = new HashMap<String, String>();
        map.put(Constrants.DEVICE_ID, deviceId);
        if (!Validator.validArgs(map)) {
            return JsonWrapUtil.reMsg(ReturnTypeEnum.PARAMS_ERROR);
        }
        if (StringUtils.isNotBlank(systemNo)) {
            BusinessSystem businessSystem = accountService.selectBySystemNo(systemNo);
            if (null == businessSystem) {
                return JsonWrapUtil.reMsg(ReturnTypeEnum.BUSINESSNO_ERROR);
            }
        }
        Map<String, Object> param = new HashMap<String, Object>();
        param.put(Constrants.DEVICE_ID, deviceId);
        if (StringUtils.isNotBlank(systemNo)) param.put(Constrants.SYSTEM_NO, systemNo);
        List<BindInfoDto> bindInfos = bindInfoService.selectBindInfoList(param);
        JSONObject json = new JSONObject();
        json.put("bindInfos", bindInfos);
        return StringUtil.jsonSuccessData(json);
    }

/*************************************************************************Bind/Account Api End*****************************************************************************************************************/


    /**
     * 扫码登录第三方系统账户列表
     *
     * @return
     */
    @POST
    @Path("/rest/account/loginList")
    @Produces("application/json;charset=utf-8")
    public String loginList(@FormParam(Constrants.SYSTEM_NO) String systemNo, @FormParam(Constrants.DEVICE_ID) String deviceId, @FormParam(Constrants.SESSIONID) String sessionId) {
        Map<String, String> map = new HashMap<String, String>();
        map.put(Constrants.DEVICE_ID, deviceId);
        map.put(Constrants.SYSTEM_NO, systemNo);
        map.put(Constrants.SESSIONID, sessionId);
        if (!Validator.validArgs(map)) {
            return JsonWrapUtil.reMsg(ReturnTypeEnum.PARAMS_ERROR);
        }
        BusinessSystem businessSystem = accountService.selectBySystemNo(systemNo);
        if (null == businessSystem) {
            return JsonWrapUtil.reMsg(ReturnTypeEnum.BUSINESSNO_ERROR);
        }
        List<AccountInfoDto> accountInfos = accountService.selectBydeviceIdAndSystemId(deviceId, businessSystem.getSystemId());
        JSONObject json = new JSONObject();
        json.put("accountInfos", accountInfos);
        json.put("sessionId", sessionId);
        return StringUtil.jsonSuccessData(0, Constrants.SUCCESS, json);
    }

    /**
     * 扫码登录第三方系统
     */
    @POST
    @Path("/rest/account/login")
    @Produces("application/json;charset=utf-8")
    public String login(@FormParam(Constrants.LOGIN_CODE) String loginCode, @FormParam(Constrants.DEVICE_ID) String deviceId, @FormParam(Constrants.SYSTEMACCOUNT) String systemAccount, @FormParam(Constrants.SYSTEM_NO) String systemNo, @FormParam(Constrants.SESSIONID) String sessionId, @FormParam(Constrants.SYSTEM_URL) String systemUrl) {
        Map<String, String> map = new HashMap<String, String>();
        map.put(Constrants.DEVICE_ID, deviceId);
        map.put(Constrants.LOGIN_CODE, loginCode);
        map.put(Constrants.SYSTEMACCOUNT, systemAccount);
        map.put(Constrants.SYSTEM_NO, systemNo);
        map.put(Constrants.SESSIONID, sessionId);
        map.put(Constrants.SYSTEM_URL, systemUrl);
        logger.info("deviceId:" + deviceId + ",loginCode:" + loginCode + ",systemAccount：" + systemAccount + ",systemNo：" + systemNo + ",sessionId:" + sessionId + ",systemUrl:" + systemUrl);
        if (!Validator.validArgs(map)) {
            return JsonWrapUtil.reMsg(ReturnTypeEnum.PARAMS_ERROR);
        }
        BusinessSystem businessSystem = accountService.selectBySystemNo(systemNo);
        if (null == businessSystem) {
            return JsonWrapUtil.reMsg(ReturnTypeEnum.BUSINESSNO_ERROR);
        }
        BindingInfo isBind = accountService.selectBindInfoByDidAndSysIdAndSysAccount(deviceId, businessSystem.getSystemId(), systemAccount);
        if (null == isBind) {
            return JsonWrapUtil.reMsg(ReturnTypeEnum.NO_BIND);
        }
        HashMap<String, String> paramMap = new HashMap<String, String>();
        JSONObject tmp = new JSONObject();
        tmp.put(Constrants.DEVICE_ID, deviceId);
        tmp.put(Constrants.PARTNERCODE, ConfigFileUtil.getPartnerCode());
        tmp.put(Constrants.APP_ID, ConfigFileUtil.getAppId());
        tmp.put(Constrants.SHORT_TOKEN, loginCode);
        paramMap.put("requestData", tmp.toString());
        String jsonResult = WSUtil.validateShortCode(paramMap);
        logger.info(">>>>>>>> jsonResult: " + jsonResult);
        JSONObject jobj = JSONObject.fromObject(jsonResult);
        String valiStatus = jobj.getString(Constrants.STATUS);
        if (!Constrants.SUCCESS_STATUS.equals(valiStatus)) {
            return StringUtil.jsonExceptionMsg(Integer.parseInt(valiStatus), jobj.getString(Constrants.MESSAGE));
        }

        BusinessSystemCallback businessSystemCallback = accountService.selectBySystemIdAndType(businessSystem.getSystemId(), CallbackTypeEnum.LOGIN.getCode());
        if (null == businessSystemCallback) {
            return JsonWrapUtil.reMsg(ReturnTypeEnum.NO_CALLBACK);
        }
        if (ConfigFileUtil.getIdentityValidate()) {
            Map<String, String> paramMapCount = new HashMap<String, String>();
            paramMapCount.put("serverCode", "TimeSpaceCode");
            paramMapCount.put("billing", Constrants.YES);
            paramMapCount.put("url", systemUrl);
            paramMapCount.put("requestTimeStamp", String.valueOf(System.currentTimeMillis()));
            String[] strs = WSUtil.getCountSig(businessSystem.getAppId(), businessSystem.getAppKey(), paramMapCount).split(",");
            paramMapCount.put("kvStr", strs[0]);
            paramMapCount.put("clientSignature", strs[1]);
            String countResult = WSUtil.countDcCode(paramMapCount);
            JSONObject countJson = JSONObject.fromObject(countResult);
            String countStatus = countJson.getString(Constrants.STATUS);
            if (!Constrants.SUCCESS_STATUS.equals(countStatus)) {
                return StringUtil.jsonExceptionMsg(Integer.parseInt(countStatus), countJson.getString(Constrants.MESSAGE));
            }
        }
        HashMap<String, String> paramMapSend = new HashMap<String, String>();
        paramMapSend.put("did", deviceId);
        paramMapSend.put("sid", sessionId);
        paramMapSend.put("uid", systemAccount);
        logger.info(">>>>>>>> callbackurl:" + businessSystemCallback.getCallbackUrl() + "; param:" + paramMapSend.toString());
        String result = WSUtil.sendSignature(businessSystemCallback.getCallbackUrl(), businessSystem.getAppId(), businessSystem.getAppKey(), paramMapSend);
        JSONObject json = JSONObject.fromObject(result);
        String sendStatus = json.getString(Constrants.STATUS);
        if (!Constrants.SUCCESS_STATUS.equals(sendStatus)) {
            return StringUtil.jsonExceptionMsg(Integer.parseInt(sendStatus), json.getString(Constrants.MESSAGE));
        }
        //accountService.updateOnlineStatus(deviceId, businessSystem.getSystemId(), systemAccount, OnlineStatusEnum.ONLINE.getCode(),businessSystem.getSystemNo());
        JSONObject jsonObject = new JSONObject();
        jsonObject.put(Constrants.SYSTEM_NO, systemNo);
        String systemLogoHead = "";
        SysEnterpriseConfig config = accountService.selectSysConfigByEnterId(businessSystem.getEnterpriseId());
        if (null != config) {
            systemLogoHead = accountService.selectSysConfigByEnterId(businessSystem.getEnterpriseId()).getServerUrl();
        }
        jsonObject.put(Constrants.SYSTEM_LOGO_URL, systemLogoHead + businessSystem.getSystemLogoUrl());
        jsonObject.put(Constrants.SYSTEM_NAME, businessSystem.getSystemName());
        jsonObject.put(Constrants.ONLINE_STATUS, OnlineStatusEnum.ONLINE.getCode());
        jsonObject.put(Constrants.SYSTEM_ACCOUNT, systemAccount);
        jsonObject.put(Constrants.BUSINESS_TYPE, businessSystem.getSystemUseScene());
        jsonObject.put(Constrants.SYSTEM_URL, systemUrl);
        EnterpriseInfo enterpriseInfo = accountService.selectEnterpriceById(businessSystem.getEnterpriseId());
        jsonObject.put(Constrants.ENTERPRISE_NAME, null == enterpriseInfo ? "" : enterpriseInfo.getEnterpriseName());
        messageSend(null, businessSystem, LogTypeEnum.LOGIN.getCode(), systemAccount, "登录成功", null, null, null, null);
        return StringUtil.jsonSuccessData(0, Constrants.LOGIN_SUCCESS, jsonObject);
    }


    /**
     * 开门
     *
     * @return
     */
    @POST
    @Path("/rest/account/open")
    @Produces("application/json;charset=utf-8")
    public String open(@FormParam(Constrants.LOGIN_CODE) String loginCode, @FormParam(Constrants.DEVICE_ID) String deviceId, @FormParam(Constrants.SYSTEMACCOUNT) String systemAccount, @FormParam(Constrants.SYSTEM_NO) String systemNo, @FormParam(Constrants.SESSIONID) String sessionId, @FormParam(Constrants.SYSTEM_URL) String systemUrl, @FormParam(Constrants.BSSID) String bssid) {
        long allStart = System.currentTimeMillis();
        Map<String, String> map = new HashMap<String, String>();
        map.put(Constrants.DEVICE_ID, deviceId);
        map.put(Constrants.LOGIN_CODE, loginCode);
        map.put(Constrants.SYSTEMACCOUNT, systemAccount);
        map.put(Constrants.SYSTEM_NO, systemNo);
        map.put(Constrants.SESSIONID, sessionId);
        map.put(Constrants.SYSTEM_URL, systemUrl);
        if (!Validator.validArgs(map)) {
            return JsonWrapUtil.reMsg(ReturnTypeEnum.PARAMS_ERROR);
        }
        BusinessSystem businessSystem = accountService.selectBySystemNo(systemNo);
        if (null == businessSystem) {
            return JsonWrapUtil.reMsg(ReturnTypeEnum.BUSINESSNO_ERROR);
        }
        BindingInfo isBind = accountService.selectBindInfoByDidAndSysIdAndSysAccount(deviceId, businessSystem.getSystemId(), systemAccount);
        if (null == isBind) {
            return JsonWrapUtil.reMsg(ReturnTypeEnum.NO_BIND);
        }
        long verifyStart = System.currentTimeMillis();
        HashMap<String, String> paramMap = new HashMap<String, String>();
        JSONObject tmp = new JSONObject();
        tmp.put(Constrants.DEVICE_ID, deviceId);
        tmp.put(Constrants.PARTNERCODE, ConfigFileUtil.getPartnerCode());
        tmp.put(Constrants.APP_ID, ConfigFileUtil.getAppId());
        tmp.put(Constrants.SHORT_TOKEN, loginCode);
        paramMap.put("requestData", tmp.toString());
        String jsonResult = WSUtil.validateShortCode(paramMap);
        logger.info(">>>>>>>> jsonResult: " + jsonResult);
        JSONObject jobj = JSONObject.fromObject(jsonResult);
        String valiStatus = jobj.getString(Constrants.STATUS);
        if (!Constrants.SUCCESS_STATUS.equals(valiStatus)) {
            return StringUtil.jsonExceptionMsg(Integer.parseInt(valiStatus), jobj.getString(Constrants.MESSAGE));
        }
        long verifyStop = System.currentTimeMillis();
        logger.info("---------------------------------------------------verify use time : " + (verifyStop - verifyStart));
        BusinessSystemCallback businessSystemCallback = accountService.selectBySystemIdAndType(businessSystem.getSystemId(), CallbackTypeEnum.OPEN.getCode());
        if (null == businessSystemCallback) {
            return JsonWrapUtil.reMsg(ReturnTypeEnum.NO_CALLBACK);
        }
        if (ConfigFileUtil.getIdentityValidate()) {
            long countStart = System.currentTimeMillis();
            Map<String, String> paramMapCount = new HashMap<String, String>();
            paramMapCount.put("serverCode", "TimeSpaceCode");
            paramMapCount.put("billing", Constrants.YES);
            paramMapCount.put("url", systemUrl);
            paramMapCount.put("requestTimeStamp", String.valueOf(System.currentTimeMillis()));
            String[] strs = WSUtil.getCountSig(businessSystem.getAppId(), businessSystem.getAppKey(), paramMapCount).split(",");
            paramMapCount.put("kvStr", strs[0]);
            paramMapCount.put("clientSignature", strs[1]);
            String countResult = WSUtil.countDcCode(paramMapCount);
            JSONObject countJson = JSONObject.fromObject(countResult);
            String countStatus = countJson.getString(Constrants.STATUS);
            if (!Constrants.SUCCESS_STATUS.equals(countStatus)) {
                return StringUtil.jsonExceptionMsg(Integer.parseInt(countStatus), countJson.getString(Constrants.MESSAGE));
            }
            long countStop = System.currentTimeMillis();
            logger.info("---------------------------------------------------count use time : " + (countStop - countStart));
        }
        long openStart = System.currentTimeMillis();
        HashMap<String, String> paramMapSend = new HashMap<String, String>();
        paramMapSend.put(Constrants.DEVICE_ID, deviceId);
        paramMapSend.put("sid", sessionId);
        paramMapSend.put("uid", systemAccount);
        paramMapSend.put(Constrants.BSSID, bssid);
        String result = WSUtil.sendSignature(businessSystemCallback.getCallbackUrl(), businessSystem.getAppId(), businessSystem.getAppKey(), paramMapSend);
        JSONObject json = JSONObject.fromObject(result);
        String sendStatus = json.getString(Constrants.STATUS);
        if (!Constrants.SUCCESS_STATUS.equals(sendStatus)) {
            return StringUtil.jsonExceptionMsg(Integer.parseInt(sendStatus), json.getString(Constrants.MESSAGE));
        }
        long openStop = System.currentTimeMillis();
        logger.info("---------------------------------------------------open use time : " + (openStop - openStart));
        //accountService.updateOnlineStatus(deviceId, businessSystem.getSystemId(), systemAccount, OnlineStatusEnum.ESCAPE.getCode(),businessSystem.getSystemNo());
        JSONObject jsonObject = new JSONObject();
        jsonObject.put(Constrants.SYSTEM_NO, systemNo);
        String systemLogoHead = "";
        SysEnterpriseConfig config = accountService.selectSysConfigByEnterId(businessSystem.getEnterpriseId());
        if (null != config) {
            systemLogoHead = accountService.selectSysConfigByEnterId(businessSystem.getEnterpriseId()).getServerUrl();
        }
        jsonObject.put(Constrants.SYSTEM_LOGO_URL, systemLogoHead + businessSystem.getSystemLogoUrl());
        jsonObject.put(Constrants.SYSTEM_NAME, businessSystem.getSystemName());
        jsonObject.put(Constrants.ONLINE_STATUS, OnlineStatusEnum.ESCAPE.getCode());
        jsonObject.put(Constrants.SYSTEM_ACCOUNT, systemAccount);
        jsonObject.put(Constrants.BUSINESS_TYPE, businessSystem.getSystemUseScene());
        jsonObject.put(Constrants.SYSTEM_URL, systemUrl);
        EnterpriseInfo enterpriseInfo = accountService.selectEnterpriceById(businessSystem.getEnterpriseId());
        jsonObject.put(Constrants.ENTERPRISE_NAME, null == enterpriseInfo ? "" : enterpriseInfo.getEnterpriseName());
        List<BindingInfo> bindingInfoList = accountService.selectBindInfosBySystemIdAndAccount(businessSystem.getSystemId(), systemAccount);
        messageSend(bindingInfoList, businessSystem, Constrants.SYSTEM, systemAccount, Constrants.OPEN, null, null, null, null);
        return StringUtil.jsonSuccessData(0, Constrants.OPEN_SUCCESS, jsonObject);
    }

    /**
     * 退出登录第三方系统
     *
     * @return
     */
    @POST
    @Path("/rest/account/logout")
    @Produces("application/json;charset=utf-8")
    public String logOut(@FormParam(Constrants.SYSTEMACCOUNT) String systemAccount, @FormParam(Constrants.SYSTEM_NO) String systemNo, @FormParam(Constrants.DEVICE_ID) String deviceId) {
        Map<String, String> map = new HashMap<String, String>();
        map.put(Constrants.SYSTEMACCOUNT, systemAccount);
        map.put(Constrants.SYSTEM_NO, systemNo);
        map.put(Constrants.DEVICE_ID, deviceId);
        if (!Validator.validArgs(map)) {
            return JsonWrapUtil.reMsg(ReturnTypeEnum.PARAMS_ERROR);
        }
        BusinessSystem businessSystem = accountService.selectBySystemNo(systemNo);
        if (null == businessSystem) {
            return JsonWrapUtil.reMsg(ReturnTypeEnum.BUSINESSNO_ERROR);
        }
        BusinessSystemCallback businessSystemCallback = accountService.selectBySystemIdAndType(businessSystem.getSystemId(), CallbackTypeEnum.LOGOUT.getCode());
        if (null == businessSystemCallback) {
            return JsonWrapUtil.reMsg(ReturnTypeEnum.NO_CALLBACK);
        }
        HashMap<String, String> paramMapSend = new HashMap<String, String>();
        paramMapSend.put("userId", systemAccount);
        String result = WSUtil.sendSignature(businessSystemCallback.getCallbackUrl(), businessSystem.getAppId(), businessSystem.getAppKey(), paramMapSend);
        JSONObject json = JSONObject.fromObject(result);
        String sendStatus = json.getString(Constrants.STATUS);
        if (!Constrants.SUCCESS_STATUS.equals(sendStatus)) {
            return StringUtil.jsonExceptionMsg(Integer.parseInt(sendStatus), json.getString(Constrants.MESSAGE));
        }
        //accountService.updateOnlineStatus(deviceId, businessSystem.getSystemId(), systemAccount, OnlineStatusEnum.OFFLINE.getCode(),businessSystem.getSystemNo());
        /*JSONObject msgContent = new JSONObject();
        msgContent.put("type", Constrants.SYSTEM);
        msgContent.put("ctx", "您的" + businessSystem.getSystemName() + "账号:" + systemAccount + ",于" + DateUtil.getCurrentDateString() + "成功登出");
        msgPushMethod(deviceId, "", msgContent.toString());*/
        messageSend(null, businessSystem, LogTypeEnum.LOGOUT.getCode(), systemAccount, Constrants.LOGOUT_SUCCESS, null, null, null, null);
        return StringUtil.jsonSuccessMsg(Constrants.LOGOUT_SUCCESS);
    }


    @POST
    @Path("/rest/account/checkPass")
    @Produces("application/json;charset=utf-8")
    public String checkPass(@FormParam(Constrants.SYSTEM_NO) String systemNo, @FormParam(Constrants.DC_CODE) String dcCode, @FormParam(Constrants.SYSTEM_ACCOUNT) String systemAccount, @FormParam(Constrants.SYSTEM_URL) String systemUrl) {
        Map<String, String> map = new HashMap<String, String>();
        map.put(Constrants.SYSTEM_NO, systemNo);
        map.put(Constrants.DC_CODE, dcCode);
        map.put(Constrants.SYSTEM_ACCOUNT, systemAccount);
        map.put(Constrants.SYSTEM_URL, systemUrl);
        if (!Validator.validArgs(map)) {
            return JsonWrapUtil.reMsg(ReturnTypeEnum.PARAMS_ERROR);
        }
        BusinessSystem businessSystem = accountService.selectBySystemNo(systemNo);
        if (null == businessSystem) {
            return JsonWrapUtil.reMsg(ReturnTypeEnum.BUSINESSNO_ERROR);
        }
        List<BindingInfo> bindInfos = accountService.selectBindInfosBySystemIdAndAccount(businessSystem.getSystemId(), systemAccount);
        if (bindInfos.size() == 0) {
            return JsonWrapUtil.reMsg(ReturnTypeEnum.NO_BIND);
        }
        String returnStatus = "";
        String jsonResult = "";
        for (BindingInfo bindInfo : bindInfos) {
            HashMap<String, String> paramMap = new HashMap<String, String>();
            JSONObject tmp = new JSONObject();
            tmp.put(Constrants.DEVICE_ID, bindInfo.getDeviceId());
            tmp.put(Constrants.PARTNERCODE, ConfigFileUtil.getPartnerCode());
            tmp.put(Constrants.APP_ID, ConfigFileUtil.getAppId());
            tmp.put(Constrants.SHORT_TOKEN, dcCode);
            paramMap.put("requestData", tmp.toString());
            jsonResult = WSUtil.validateShortCode(paramMap);
            logger.info(">>>>>>>>> jsonResult: " + jsonResult);
            JSONObject jobj = JSONObject.fromObject(jsonResult);
            returnStatus = jobj.getString(Constrants.STATUS);
            if (Constrants.SUCCESS_STATUS.equals(returnStatus)) {
                break;
            }
        }
        if (!Constrants.SUCCESS_STATUS.equals(returnStatus)) {
            return jsonResult;
        }
        if (ConfigFileUtil.getIdentityValidate()) {
            Map<String, String> paramMapCount = new HashMap<String, String>();
            paramMapCount.put("serverCode", "TimeSpacePass");
            paramMapCount.put("billing", Constrants.YES);
            paramMapCount.put("url", systemUrl);
            paramMapCount.put("requestTimeStamp", String.valueOf(System.currentTimeMillis()));
            String[] strs = WSUtil.getCountSig(businessSystem.getAppId(), businessSystem.getAppKey(), paramMapCount).split(",");
            paramMapCount.put("kvStr", strs[0]);
            paramMapCount.put("clientSignature", strs[1]);
            String countResult = WSUtil.countDcCode(paramMapCount);
            JSONObject countJson = JSONObject.fromObject(countResult);
            String countStatus = countJson.getString(Constrants.STATUS);
            if (!Constrants.SUCCESS_STATUS.equals(countStatus)) {
                return StringUtil.jsonExceptionMsg(Integer.parseInt(countStatus), countJson.getString(Constrants.MESSAGE));
            }
        }
        return StringUtil.jsonSuccessMsg("校验通过");
    }


    /*************************************************************************HUE Api Begin*****************************************************************************************************************/

    /**
     * 获取HUE配置
     *
     * @param version            api版本
     * @param systemNo           业务系统编码
     * @param systemAccount      用户账号
     * @param ipAddr             发起认证的IP
     * @param trustedDeviceToken 可信设备
     */
    @POST
    @Path("/{version}/preAuth")
    @Produces("application/json;charset=utf-8")
    public String preAuth(@PathParam(Constrants.VERSION) String version, @FormParam(Constrants.SYSTEM_NO) String systemNo, @FormParam(Constrants.SYSTEM_ACCOUNT) String systemAccount, @FormParam(Constrants.IP_ADDR) String ipAddr, @FormParam(Constrants.TRUSTED_DEVICE_TOKEN) String trustedDeviceToken) {
        return preAuthOld(systemNo);
    }

    /**
     * 获取HUE配置FOR WEB
     */
    @GET
    @Path("/{version}/preAuth")
    @Produces("application/javascript")
    public JSONWithPadding preAuth(@PathParam(Constrants.VERSION) String version, @QueryParam("jsoncallback") String callback, @QueryParam(Constrants.SYSTEM_NO) String systemNo, @QueryParam(Constrants.SYSTEM_ACCOUNT) String systemAccount, @QueryParam(Constrants.IP_ADDR) String ipAddr, @QueryParam(Constrants.TRUSTED_DEVICE_TOKEN) String trustedDeviceToken) {
        return preAuthOld(callback, systemNo);
    }

    /**
     * 获取HUE配置
     */
    @POST
    @Path("/rest/account/getHUEStrategy")
    @Produces("application/json;charset=utf-8")
    public String preAuthOld(@FormParam(Constrants.SYSTEM_NO) String systemNo) {
        JSONObject json = new JSONObject();
        Map<String, String> map = new HashMap<String, String>();
        map.put(Constrants.SYSTEM_NO, systemNo);
        if (!Validator.validArgs(map)) {
            return JsonWrapUtil.reMsg(ReturnTypeEnum.PARAMS_ERROR);
        }
        BusinessSystem businessSystem = accountService.selectBySystemNo(systemNo);
        if (null == businessSystem) {
            return JsonWrapUtil.reMsg(ReturnTypeEnum.BUSINESSNO_ERROR);
        }
        StrategyConfig strategyConfig = strategyService.findObjBySystemNo(systemNo);
        if (strategyConfig == null || (strategyConfig != null && strategyConfig.getStrategyId() == null)) {
            return JsonWrapUtil.reMsg(ReturnTypeEnum.NOT_FIND_SYSTEM_CONFIGURATION);
        }
        JSONObject jo = new JSONObject();
        if(Constrants.SECURITY_IDENTIFY_OPEN.equals(strategyConfig.getIsOpenSecIden())){
            jo.put(Constrants.CODE,ReturnTypeEnum.AUTH_IS_REQUIRED.getCode());
            jo.put(Constrants.DES,ReturnTypeEnum.AUTH_IS_REQUIRED.getDescription());
        }else if(Constrants.SECURITY_IDENTIFY_CLOSE.equals(strategyConfig.getIsOpenSecIden())){
            jo.put(Constrants.CODE,ReturnTypeEnum.AUTH_IS_IGNORED.getCode());
            jo.put(Constrants.DES,ReturnTypeEnum.AUTH_IS_IGNORED.getDescription());
        }else{
            jo.put(Constrants.CODE,ReturnTypeEnum.AUTH_IS_IGNORED.getCode());
            jo.put(Constrants.DES,ReturnTypeEnum.AUTH_IS_IGNORED.getDescription());
        }
        jo.put(Constrants.DEVICES,new JSONArray());
        jo.put(Constrants.ENROLL_PORTAL_URL,"");
        return JsonWrapUtil.buildJSON(ReturnTypeEnum.QUERY_SUCCESS,jo);
    }

    /**
     * 获取HUE配置
     */
    @GET
    @Path("/rest/account/getHUEStrategy")
    @Produces("application/javascript")
    public JSONWithPadding preAuthOld(@QueryParam("jsoncallback") String callback, @QueryParam(Constrants.SYSTEM_NO) String systemNo) {
        JSONObject json = new JSONObject();
        Map<String, String> map = new HashMap<String, String>();
        map.put(Constrants.SYSTEM_NO, systemNo);
        if (!Validator.validArgs(map)) {
            return JsonWrapUtil.reMsgJSONWithPadding(ReturnTypeEnum.PARAMS_ERROR, json, callback);
        }
        BusinessSystem businessSystem = accountService.selectBySystemNo(systemNo);
        if (null == businessSystem) {
            return JsonWrapUtil.reMsgJSONWithPadding(ReturnTypeEnum.BUSINESSNO_ERROR, json, callback);
        }
        StrategyConfig strategyConfig = strategyService.findObjBySystemNo(systemNo);
        if (strategyConfig == null) {
            return JsonWrapUtil.reMsgJSONWithPadding(ReturnTypeEnum.NOT_FIND_SYSTEM_CONFIGURATION, json, callback);
        }
        JSONObject jo = new JSONObject();
        if(Constrants.SECURITY_IDENTIFY_OPEN.equals(strategyConfig.getIsOpenSecIden())){
            jo.put(Constrants.CODE,ReturnTypeEnum.AUTH_IS_REQUIRED.getCode());
        }else if(Constrants.SECURITY_IDENTIFY_CLOSE.equals(strategyConfig.getIsOpenSecIden())){
            jo.put(Constrants.CODE,ReturnTypeEnum.AUTH_IS_IGNORED.getCode());
        }else{
            jo.put(Constrants.CODE,ReturnTypeEnum.AUTH_IS_IGNORED.getCode());
        }
        jo.put(Constrants.DEVICES,new JSONArray());
        jo.put(Constrants.ENROLL_PORTAL_URL,"");
        return JsonWrapUtil.reMsgJSONWithPadding(ReturnTypeEnum.QUERY_SUCCESS,jo,callback);
    }

    /**
     * 二次认证中的第一次校验接口
     *
     * @param otp           otp/数字令
     * @param systemNo      业务系统编码
     * @param systemAccount 用户账号
     * @param data          交易信息
     * @param factor        交易方式
     * @param ipAddr        发起认证的IP
     * @param deviceId      进行校验的设备的设备指纹
     */
    @GET
    @Path("/{version}/auth")
    @Produces("application/javascript")
    public JSONWithPadding firstAuth(@PathParam(Constrants.VERSION) String version, @QueryParam("jsoncallback") String callback, @QueryParam(Constrants.SYSTEM_NO) String systemNo, @QueryParam(Constrants.OTP) String otp, @QueryParam(Constrants.SYSTEM_ACCOUNT) String systemAccount, @QueryParam(Constrants.DATA) String data, @QueryParam(Constrants.FACTOR) String factor, @QueryParam(Constrants.IP_ADDR) String ipAddr, @QueryParam(Constrants.DEVICE_ID) String deviceId, @Context HttpServletRequest request) {
        JSONObject json = new JSONObject();
        //json.put("JSON_KEY_MESSAGE","校验未通过");
        String message = "";
        String content = "";
        String did = "";
        String deviceName = "PC";
        String clientIp = ClientHelper.getClientIp(request);
        String alertInfo = "您有一条新的交易信息，请确认！";
        String serialId = otp;
        try {
            data = URLDecoder.decode(data, "utf-8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        Map<String, String> map = new HashMap<String, String>();
        map.put(Constrants.SYSTEM_NO, systemNo);
        map.put(Constrants.DC_CODE, otp);
        map.put(Constrants.SYSTEM_ACCOUNT, systemAccount);
        map.put(Constrants.DATA, data);
        logger.info("data is:" + data);
        if (!Validator.validArgs(map)) {
            return JsonWrapUtil.reMsgJSONWithPadding(ReturnTypeEnum.PARAMS_ERROR, json, callback);
        }
        try {
            JSONObject jo = JSONObject.fromObject(data);
            if (null != jo) {
                message = jo.optString(Constrants.DESCRTPTION, "");
                content = jo.optString(Constrants.BUSSINESS_INFO, "");
                did = jo.optString(Constrants.DEVICE_ID, "");
                if (!"".equals(did)) {
                    HashMap<String, String> paramMap = new HashMap<String, String>();
                    paramMap.put(Constrants.DEVICE_ID, did);
                    paramMap.put(Constrants.SYSTEM_NO, systemNo);
                    String result = WSUtil.getAlias(paramMap);
                    logger.info(">>>>>>>>> get alias result: " + result);
                    JSONObject jobj = JSONObject.fromObject(result);
                    String status = jobj.getString(Constrants.STATUS);
                    if (Constrants.SUCCESS_STATUS.equals(status)) {
                        deviceName = jobj.getJSONObject(Constrants.DATA).optString(Constrants.ALIAS, "");
                    }
                }
                if (!"".equals(jo.optString(Constrants.TX_ID, "")))
                    serialId = String.valueOf(jo.optString(Constrants.TX_ID).hashCode());

            }
        } catch (Exception e) {
            logger.error(e.getMessage());
            return JsonWrapUtil.reMsgJSONWithPadding(ReturnTypeEnum.PARAMS_ERROR, json, callback);
        }
        json.put(Constrants.TX_ID, serialId);
        json.put(Constrants.TRUSTED_DEVICE_TOKEN, "");
        Object cache = cacheMgr.getMemcache(serialId);
        if (null != cache) {
            return JsonWrapUtil.reMsgJSONWithPadding(ReturnTypeEnum.REPEAT_CHECK, json, callback);
        }
        BusinessSystem businessSystem = accountService.selectBySystemNo(systemNo);
        if (null == businessSystem) {
            return JsonWrapUtil.reMsgJSONWithPadding(ReturnTypeEnum.BUSINESSNO_ERROR, json, callback);
        }
        List<BindingInfo> bindInfos = accountService.selectBindInfosBySystemIdAndAccount(businessSystem.getSystemId(), systemAccount);
        if (bindInfos == null || bindInfos.size() == 0) {
            return JsonWrapUtil.reMsgJSONWithPadding(ReturnTypeEnum.NO_BIND, json, callback);
        }

        TxnLog txnLog = new TxnLog();
        txnLog.setTxnId(serialId);
        txnLog.setEnterpriseId(businessSystem.getEnterpriseId());
        txnLog.setSystemNo(systemNo);
        txnLog.setSystemName(businessSystem.getSystemName());
        txnLog.setSystemAccount(systemAccount);
        txnLog.setDeviceId(did);
        txnLog.setDeviceName(deviceName);
        txnLog.setoType(LogTypeEnum.AUTH.getCode());
        txnLog.setMessage(message);
        txnLog.setClientIp(clientIp);

        String returnStatus = "";
        String jsonResult = "";
        for (BindingInfo bindInfo : bindInfos) {
            HashMap<String, String> paramMap = new HashMap<String, String>();
            JSONObject tmp = new JSONObject();
            tmp.put(Constrants.DEVICE_ID, bindInfo.getDeviceId());
            tmp.put(Constrants.PARTNERCODE, ConfigFileUtil.getPartnerCode());
            tmp.put(Constrants.APP_ID, businessSystem.getAppId());
            tmp.put(Constrants.SHORT_TOKEN, otp);
            paramMap.put("requestData", tmp.toString());
            jsonResult = WSUtil.validateShortCode(paramMap);
            logger.info(">>>>>>>>> jsonResult: " + jsonResult);
            JSONObject jobj = JSONObject.fromObject(jsonResult);
            returnStatus = jobj.getString(Constrants.STATUS);
            if (Constrants.SUCCESS_STATUS.equals(returnStatus)) {
                //数字令校验通过，需要向手机端push消息进行二次确认
                cache = cacheMgr.getMemcache(serialId);
                logger.info("cache value:" + serialId + "_" + cache);


                if (null == cache) {
                    cacheMgr.setMemcache(serialId, Constrants.WAIT, expTime);
                    if (Constrants.VALIDATE_MODE_WITHOUT_PUSH.equals(businessSystem.getValidateMode())) {
                        cacheMgr.setMemcache(serialId, Constrants.YES, expTime);
                        BusinessSystemCallback businessSystemCallback = accountService.selectBySystemIdAndType(businessSystem.getSystemId(), CallbackTypeEnum.AUTH.getCode());
                        if (null != businessSystemCallback) {
                            cachedThreadPool.execute(new BusinessNotify(businessSystemCallback, systemAccount, content, businessSystem));
                        }
                        //Success：交易成功
                        txnLog.setStatus(StatusEnum.SUCCESS.getCode());
                        systemTxnService.saveTxnLog(txnLog);
                        return JsonWrapUtil.reMsgJSONWithPadding(ReturnTypeEnum.PASS_VALIDATE, json, callback);
                    }
                    messageSend(null, businessSystem, CallbackTypeEnum.AUTH.getCode(), systemAccount, alertInfo, serialId, message, deviceName, clientIp);
                    cacheMgr.setMemcache(serialId + "_" + Constrants.DATA, content, expTime * 2);
                    //Wait：等待用户确认
                    txnLog.setStatus(StatusEnum.WAITING.getCode());
                    systemTxnService.saveTxnLog(txnLog);
                    return JsonWrapUtil.reMsgJSONWithPadding(ReturnTypeEnum.CONFIRMING, json, callback);
                }
            }
        }
        //Failed：校验失败
        logger.info("---->>>> 校验失败");
        txnLog.setStatus(StatusEnum.FAILED.getCode());
        systemTxnService.saveTxnLog(txnLog);
        return JsonWrapUtil.reMsgJSONWithPadding(ReturnTypeEnum.NOT_PASS_VALIDATE, json, callback);
    }

    @POST
    @Path("/{version}/auth")
    @Produces("application/json;charset=utf-8")
    public String firstAuth(@PathParam(Constrants.VERSION) String version, @FormParam(Constrants.SYSTEM_NO) String systemNo, @FormParam(Constrants.OTP) String otp, @FormParam(Constrants.SYSTEM_ACCOUNT) String systemAccount, @FormParam(Constrants.DATA) String data, @QueryParam(Constrants.FACTOR) String factor, @QueryParam(Constrants.IP_ADDR) String ipAddr, @QueryParam(Constrants.DEVICE_ID) String deviceId, @Context HttpServletRequest request) {
        JSONObject json = new JSONObject();
        logger.info("data is:" + data);
        String message = "";
        String content = "";
        String did = "";
        String deviceName = "PC";
        String clientIp = ClientHelper.getClientIp(request);
        String serialId = otp;
        //String tradId = getRandomId();
        //json.put("JSON_KEY_MESSAGE","校验未通过");
        Map<String, String> map = new HashMap<String, String>();
        map.put(Constrants.SYSTEM_NO, systemNo);
        map.put(Constrants.DC_CODE, otp);
        map.put(Constrants.SYSTEM_ACCOUNT, systemAccount);
        map.put(Constrants.DATA, data);
        if (!Validator.validArgs(map)) {
            return JsonWrapUtil.buildJSON(ReturnTypeEnum.PARAMS_ERROR, json);
        }
        try {
            JSONObject jo = JSONObject.fromObject(data);
            if (null != jo) {
                message = jo.optString(Constrants.DESCRTPTION, "");
                content = jo.optString(Constrants.BUSSINESS_INFO, "");
                did = jo.optString(Constrants.DEVICE_ID, "");
                if (!"".equals(did)) {
                    HashMap<String, String> paramMap = new HashMap<String, String>();
                    paramMap.put(Constrants.DEVICE_ID, did);
                    paramMap.put(Constrants.SYSTEM_NO, systemNo);
                    String result = WSUtil.getAlias(paramMap);
                    logger.info(">>>>>>>>> get alias result: " + result);
                    JSONObject jobj = JSONObject.fromObject(result);
                    String status = jobj.getString(Constrants.STATUS);
                    if (Constrants.SUCCESS_STATUS.equals(status)) {
                        deviceName = jobj.getJSONObject(Constrants.DATA).optString(Constrants.ALIAS, "");
                    }
                }
                if (!"".equals(jo.optString(Constrants.TX_ID, "")))
                    serialId = String.valueOf(jo.optString(Constrants.TX_ID).hashCode());

            }
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
        json.put(Constrants.TX_ID, serialId);
        json.put(Constrants.TRUSTED_DEVICE_TOKEN, "");
        logger.info("serialId:" + serialId);
        Object cache = cacheMgr.getMemcache(serialId);
        if (null != cache) {
            return JsonWrapUtil.buildJSON(ReturnTypeEnum.REPEAT_CHECK, json);
        }
        BusinessSystem businessSystem = accountService.selectBySystemNo(systemNo);
        if (null == businessSystem) {
            return JsonWrapUtil.buildJSON(ReturnTypeEnum.BUSINESSNO_ERROR, json);
        }
        List<BindingInfo> bindInfos = accountService.selectBindInfosBySystemIdAndAccount(businessSystem.getSystemId(), systemAccount);
        if (bindInfos.size() == 0) {
            return JsonWrapUtil.buildJSON(ReturnTypeEnum.NO_BIND, json);
        }

        TxnLog txnLog = new TxnLog();
        txnLog.setLogId(UUID.randomUUID().toString().replace("-", ""));
        txnLog.setEnterpriseId(businessSystem.getEnterpriseId());
        txnLog.setTxnId(serialId);
        txnLog.setSystemNo(systemNo);
        txnLog.setSystemName(businessSystem.getSystemName());
        txnLog.setSystemAccount(systemAccount);
        txnLog.setDeviceId(did);
        txnLog.setDeviceName(deviceName);
        txnLog.setoType(LogTypeEnum.AUTH.getCode());
        txnLog.setMessage(message);
        txnLog.setClientIp(clientIp);

        String returnStatus = "";
        String jsonResult = "";
        for (BindingInfo bindInfo : bindInfos) {
            HashMap<String, String> paramMap = new HashMap<String, String>();
            JSONObject tmp = new JSONObject();
            tmp.put(Constrants.DEVICE_ID, bindInfo.getDeviceId());
            tmp.put(Constrants.PARTNERCODE, ConfigFileUtil.getPartnerCode());
            tmp.put(Constrants.APP_ID, businessSystem.getAppId());
            tmp.put(Constrants.SHORT_TOKEN, otp);
            paramMap.put("requestData", tmp.toString());
            jsonResult = WSUtil.validateShortCode(paramMap);
            logger.info(">>>>>>>>> jsonResult: " + jsonResult);
            JSONObject jobj = JSONObject.fromObject(jsonResult);
            returnStatus = jobj.getString(Constrants.STATUS);
            if (Constrants.SUCCESS_STATUS.equals(returnStatus)) {
                //数字令校验通过，需要向手机端push消息进行二次确认
                cache = cacheMgr.getMemcache(serialId);
                if (null == cache) {
                    cacheMgr.setMemcache(serialId, Constrants.WAIT, expTime);

                    if (Constrants.VALIDATE_MODE_WITHOUT_PUSH.equals(businessSystem.getValidateMode())) {
                        cacheMgr.setMemcache(serialId, Constrants.YES, expTime);
                        //Success：交易成功

                        txnLog.setStatus(StatusEnum.SUCCESS.getCode());
                        systemTxnService.saveTxnLog(txnLog);

                        cachedThreadPool.execute(new MsgNotify(systemAccount, systemNo, serialId, ReturnTypeEnum.PASS_VALIDATE));
                        BusinessSystemCallback businessSystemCallback = accountService.selectBySystemIdAndType(businessSystem.getSystemId(), CallbackTypeEnum.AUTH.getCode());
                        if (null != businessSystemCallback) {
                            cachedThreadPool.execute(new BusinessNotify(businessSystemCallback, systemAccount, content, businessSystem));
                        }
                        return JsonWrapUtil.buildJSON(ReturnTypeEnum.PASS_VALIDATE, json);
                    }
                    //Wait：等待用户确认
                    txnLog.setStatus(StatusEnum.WAITING.getCode());
                    systemTxnService.saveTxnLog(txnLog);

                    messageSend(null, businessSystem, CallbackTypeEnum.AUTH.getCode(), systemAccount, Constrants.ALERT_INFO, serialId, message, deviceName, clientIp);
                    cacheMgr.setMemcache(serialId + "_" + Constrants.DATA, content, expTime * 2);
                    return JsonWrapUtil.buildJSON(ReturnTypeEnum.CONFIRMING, json);
                }
            }
        }
        cachedThreadPool.execute(new MsgNotify(systemAccount, systemNo, serialId, ReturnTypeEnum.NOT_PASS_VALIDATE));
        //Failed：校验失败
        txnLog.setStatus(StatusEnum.FAILED.getCode());
        systemTxnService.saveTxnLog(txnLog);
        return JsonWrapUtil.buildJSON(ReturnTypeEnum.NOT_PASS_VALIDATE, json);
    }

    @GET
    @Path("/rest/account/checkPassHUE")
    @Produces("application/javascript")
    public JSONWithPadding firstAuthOld(@QueryParam("jsoncallback") String callback, @QueryParam(Constrants.SYSTEM_NO) String systemNo, @QueryParam(Constrants.DC_CODE) String dcCode, @QueryParam(Constrants.SYSTEM_ACCOUNT) String systemAccount, @QueryParam(Constrants.DATA) String data, @Context HttpServletRequest request) {
        JSONObject json = new JSONObject();
        //json.put("JSON_KEY_MESSAGE","校验未通过");
        String message = "";
        String content = "";
        String did = "";
        String deviceName = "PC";
        String clientIp = ClientHelper.getClientIp(request);
        String alertInfo = "您有一条新的交易信息，请确认！";
        String serialId = dcCode;
        try {
            data = URLDecoder.decode(data, "utf-8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        Map<String, String> map = new HashMap<String, String>();
        map.put(Constrants.SYSTEM_NO, systemNo);
        map.put(Constrants.DC_CODE, dcCode);
        map.put(Constrants.SYSTEM_ACCOUNT, systemAccount);
        map.put(Constrants.DATA, data);
        logger.info("data is:" + data);
        if (!Validator.validArgs(map)) {
            return JsonWrapUtil.reMsgJSONWithPadding(ReturnTypeEnum.PARAMS_ERROR, json, callback);
        }
        try {
            JSONObject jo = JSONObject.fromObject(data);
            if (null != jo) {
                message = jo.optString(Constrants.MESSAGE, "");
                content = jo.optString(Constrants.CONTENT, "");
                did = jo.optString(Constrants.DID, "");
                if (!"".equals(did)) {
                    HashMap<String, String> paramMap = new HashMap<String, String>();
                    paramMap.put(Constrants.DEVICE_ID, did);
                    paramMap.put(Constrants.SYSTEM_NO, systemNo);
                    String result = WSUtil.getAlias(paramMap);
                    JSONObject jobj = JSONObject.fromObject(result);
                    String status = jobj.getString(Constrants.STATUS);
                    if (Constrants.SUCCESS_STATUS.equals(status)) {
                        deviceName = jobj.getJSONObject(Constrants.DATA).optString(Constrants.ALIAS, "");
                    }
                }
                if (!"".equals(jo.optString(Constrants.SERIAL_ID, "")))
                    serialId = String.valueOf(jo.optString(Constrants.SERIAL_ID).hashCode());

            }
        } catch (Exception e) {
            logger.error(e.getMessage());
            return JsonWrapUtil.reMsgJSONWithPadding(ReturnTypeEnum.PARAMS_ERROR, json, callback);
        }
        Object cache = cacheMgr.getMemcache(serialId);
        if (null != cache) {
            return JsonWrapUtil.reMsgJSONWithPadding(ReturnTypeEnum.REPEAT_CHECK, json, callback);
        }
        BusinessSystem businessSystem = accountService.selectBySystemNo(systemNo);
        if (null == businessSystem) {
            return JsonWrapUtil.reMsgJSONWithPadding(ReturnTypeEnum.BUSINESSNO_ERROR, json, callback);
        }
        List<BindingInfo> bindInfos = accountService.selectBindInfosBySystemIdAndAccount(businessSystem.getSystemId(), systemAccount);
        if (bindInfos == null || bindInfos.size() == 0) {
            return JsonWrapUtil.reMsgJSONWithPadding(ReturnTypeEnum.NO_BIND, json, callback);
        }

        TxnLog txnLog = new TxnLog();
        txnLog.setTxnId(serialId);
        txnLog.setEnterpriseId(businessSystem.getEnterpriseId());
        txnLog.setSystemNo(systemNo);
        txnLog.setSystemName(businessSystem.getSystemName());
        txnLog.setSystemAccount(systemAccount);
        txnLog.setDeviceId(did);
        txnLog.setDeviceName(deviceName);
        txnLog.setoType(LogTypeEnum.AUTH.getCode());
        txnLog.setMessage(message);
        txnLog.setClientIp(clientIp);

        String returnStatus = "";
        String jsonResult = "";
        for (BindingInfo bindInfo : bindInfos) {
            HashMap<String, String> paramMap = new HashMap<String, String>();
            JSONObject tmp = new JSONObject();
            tmp.put(Constrants.DEVICE_ID, bindInfo.getDeviceId());
            tmp.put(Constrants.PARTNERCODE, ConfigFileUtil.getPartnerCode());
            tmp.put(Constrants.APP_ID, businessSystem.getAppId());
            tmp.put(Constrants.SHORT_TOKEN, dcCode);
            paramMap.put("requestData", tmp.toString());
            jsonResult = WSUtil.validateShortCode(paramMap);
            //logger.info(">>>>>>>>> jsonResult: " + jsonResult);
            JSONObject jobj = JSONObject.fromObject(jsonResult);
            returnStatus = jobj.getString(Constrants.STATUS);
            if (Constrants.SUCCESS_STATUS.equals(returnStatus)) {
                //数字令校验通过，需要向手机端push消息进行二次确认
                cache = cacheMgr.getMemcache(serialId);
                if (null == cache) {
                    cacheMgr.setMemcache(serialId, Constrants.WAIT, expTime);
                    if (Constrants.VALIDATE_MODE_WITHOUT_PUSH.equals(businessSystem.getValidateMode())) {
                        cacheMgr.setMemcache(serialId, Constrants.YES, expTime);
                        BusinessSystemCallback businessSystemCallback = accountService.selectBySystemIdAndType(businessSystem.getSystemId(), CallbackTypeEnum.AUTH.getCode());
                        if (null != businessSystemCallback) {
                            cachedThreadPool.execute(new BusinessNotify(businessSystemCallback, systemAccount, content, businessSystem));
                        }
                        //Success：交易成功
                        txnLog.setStatus(StatusEnum.SUCCESS.getCode());
                        systemTxnService.saveTxnLog(txnLog);
                        return JsonWrapUtil.reMsgJSONWithPadding(ReturnTypeEnum.PASS_VALIDATE, json, callback);
                    }
                    messageSend(null, businessSystem, CallbackTypeEnum.AUTH.getCode(), systemAccount, alertInfo, serialId, message, deviceName, clientIp);
                    cacheMgr.setMemcache(serialId + "_" + Constrants.DATA, content, expTime * 2);
                    //Wait：等待用户确认
                    txnLog.setStatus(StatusEnum.WAITING.getCode());
                    systemTxnService.saveTxnLog(txnLog);
                    return JsonWrapUtil.reMsgJSONWithPadding(ReturnTypeEnum.CONFIRMING, json, callback);
                }
            }
        }
        logger.info("---->>>> 校验失败 dcCode: "+dcCode);
        txnLog.setStatus(StatusEnum.FAILED.getCode());
        systemTxnService.saveTxnLog(txnLog);
        return JsonWrapUtil.reMsgJSONWithPadding(ReturnTypeEnum.NOT_PASS_VALIDATE, json, callback);
    }

    @POST
    @Path("/rest/account/checkPassHUE")
    @Produces("application/json;charset=utf-8")
    public String firstAuthOld(@FormParam(Constrants.SYSTEM_NO) String systemNo, @FormParam(Constrants.DC_CODE) String dcCode, @FormParam(Constrants.SYSTEM_ACCOUNT) String systemAccount, @FormParam(Constrants.DATA) String data, @Context HttpServletRequest request) {
        JSONObject json = new JSONObject();
        logger.info("data is:" + data);
        String message = "";
        String content = "";
        String did = "";
        String deviceName = "PC";
        String clientIp = ClientHelper.getClientIp(request);
        String alertInfo = "您有一条新的交易信息，请确认！";
        String serialId = dcCode;
        //String tradId = getRandomId();
        //json.put("JSON_KEY_MESSAGE","校验未通过");
        Map<String, String> map = new HashMap<String, String>();
        map.put(Constrants.SYSTEM_NO, systemNo);
        map.put(Constrants.DC_CODE, dcCode);
        map.put(Constrants.SYSTEM_ACCOUNT, systemAccount);
        map.put(Constrants.DATA, data);
        if (!Validator.validArgs(map)) {
            return JsonWrapUtil.reMsg(ReturnTypeEnum.PARAMS_ERROR);
        }
        try {
            JSONObject jo = JSONObject.fromObject(data);
            if (null != jo) {
                message = jo.optString(Constrants.MESSAGE, "");
                content = jo.optString(Constrants.CONTENT, "");
                did = jo.optString(Constrants.DID, "");
                if (!"".equals(did)) {
                    HashMap<String, String> paramMap = new HashMap<String, String>();
                    paramMap.put(Constrants.DEVICE_ID, did);
                    paramMap.put(Constrants.SYSTEM_NO, systemNo);
                    String result = WSUtil.getAlias(paramMap);
                    JSONObject jobj = JSONObject.fromObject(result);
                    String status = jobj.getString(Constrants.STATUS);
                    if (Constrants.SUCCESS_STATUS.equals(status)) {
                        deviceName = jobj.getJSONObject(Constrants.DATA).optString(Constrants.ALIAS, "");
                    }
                }
                if (!"".equals(jo.optString(Constrants.SERIAL_ID, "")))
                    serialId = String.valueOf(jo.optString(Constrants.SERIAL_ID).hashCode());
            }
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
        Object cache = cacheMgr.getMemcache(serialId);
        if (null != cache) {
            return JsonWrapUtil.reMsg(ReturnTypeEnum.REPEAT_CHECK);
        }
        BusinessSystem businessSystem = accountService.selectBySystemNo(systemNo);
        if (null == businessSystem) {
            return JsonWrapUtil.reMsg(ReturnTypeEnum.BUSINESSNO_ERROR);
        }
        List<BindingInfo> bindInfos = accountService.selectBindInfosBySystemIdAndAccount(businessSystem.getSystemId(), systemAccount);
        if (bindInfos.size() == 0) {
            return JsonWrapUtil.reMsg(ReturnTypeEnum.NO_BIND);
        }

        TxnLog txnLog = new TxnLog();
        txnLog.setLogId(UUID.randomUUID().toString().replace("-", ""));
        txnLog.setEnterpriseId(businessSystem.getEnterpriseId());
        txnLog.setTxnId(serialId);
        txnLog.setSystemNo(systemNo);
        txnLog.setSystemName(businessSystem.getSystemName());
        txnLog.setSystemAccount(systemAccount);
        txnLog.setDeviceId(did);
        txnLog.setDeviceName(deviceName);
        txnLog.setoType(LogTypeEnum.AUTH.getCode());
        txnLog.setMessage(message);
        txnLog.setClientIp(clientIp);

        String returnStatus = "";
        String jsonResult = "";
        for (BindingInfo bindInfo : bindInfos) {
            HashMap<String, String> paramMap = new HashMap<String, String>();
            JSONObject tmp = new JSONObject();
            tmp.put(Constrants.DEVICE_ID, bindInfo.getDeviceId());
            tmp.put(Constrants.PARTNERCODE, ConfigFileUtil.getPartnerCode());
            tmp.put(Constrants.APP_ID, businessSystem.getAppId());
            tmp.put(Constrants.SHORT_TOKEN, dcCode);
            paramMap.put("requestData", tmp.toString());
            jsonResult = WSUtil.validateShortCode(paramMap);
           // logger.info(">>>>>>>>> jsonResult: " + jsonResult);
            JSONObject jobj = JSONObject.fromObject(jsonResult);
            returnStatus = jobj.getString(Constrants.STATUS);
            if (Constrants.SUCCESS_STATUS.equals(returnStatus)) {
                //数字令校验通过，需要向手机端push消息进行二次确认
                cache = cacheMgr.getMemcache(serialId);
                if (null == cache) {
                    cacheMgr.setMemcache(serialId, Constrants.WAIT, expTime);

                    if (Constrants.VALIDATE_MODE_WITHOUT_PUSH.equals(businessSystem.getValidateMode())) {
                        cacheMgr.setMemcache(serialId, Constrants.YES, expTime);
                        //Success：交易成功

                        txnLog.setStatus(StatusEnum.SUCCESS.getCode());
                        systemTxnService.saveTxnLog(txnLog);

                        cachedThreadPool.execute(new MsgNotify(systemAccount, systemNo, serialId, ReturnTypeEnum.PASS_VALIDATE));
                        BusinessSystemCallback businessSystemCallback = accountService.selectBySystemIdAndType(businessSystem.getSystemId(), CallbackTypeEnum.AUTH.getCode());
                        if (null != businessSystemCallback) {
                            cachedThreadPool.execute(new BusinessNotify(businessSystemCallback, systemAccount, content, businessSystem));
                        }
                        return JsonWrapUtil.reMsg(ReturnTypeEnum.PASS_VALIDATE);
                    }
                    //Wait：等待用户确认
                    txnLog.setStatus(StatusEnum.WAITING.getCode());
                    systemTxnService.saveTxnLog(txnLog);

                    messageSend(null, businessSystem, CallbackTypeEnum.AUTH.getCode(), systemAccount, alertInfo, serialId, message, deviceName, clientIp);
                    cacheMgr.setMemcache(serialId + "_" + Constrants.DATA, content, expTime * 2);
                    return JsonWrapUtil.reMsg(ReturnTypeEnum.CONFIRMING);
                }
            }
        }
        logger.info("---->>>> 校验失败 bindInfosinfo:"+bindInfos.isEmpty()+","+bindInfos.size()+"dcCode: "+dcCode+",systemAccount:"+systemAccount+",systemNo:"+systemNo);
        cachedThreadPool.execute(new MsgNotify(systemAccount, systemNo, serialId, ReturnTypeEnum.NOT_PASS_VALIDATE));
        //Failed：校验失败
        txnLog.setStatus(StatusEnum.FAILED.getCode());
        systemTxnService.saveTxnLog(txnLog);
        return JsonWrapUtil.reMsg(ReturnTypeEnum.NOT_PASS_VALIDATE);
    }

    /**
     * APP端发送的二次确认接口
     */

    @POST
    @Path("/{version}/accept")
    @Produces("application/json;charset=utf-8")
    public String accept(@PathParam(Constrants.VERSION) String version,@FormParam(Constrants.SYSTEM_NO) String systemNo, @FormParam(Constrants.OTP) String otp, @FormParam(Constrants.SYSTEM_ACCOUNT) String systemAccount, @FormParam(Constrants.TX_ID) String txId) {
        return confirm(systemNo,otp,systemAccount,txId);
    }

    @POST
    @Path("/rest/account/checkPassHUEConfirm")
    @Produces("application/json;charset=utf-8")
    public String confirm(@FormParam(Constrants.SYSTEM_NO) String systemNo, @FormParam(Constrants.DC_CODE) String dcCode, @FormParam(Constrants.SYSTEM_ACCOUNT) String systemAccount, @FormParam(Constrants.MSG_ID) String msgId) {
        logger.info("msgId:" + msgId);
        Map<String, String> map = new HashMap<String, String>();
        map.put(Constrants.SYSTEM_NO, systemNo);
        map.put(Constrants.DC_CODE, dcCode);
        map.put(Constrants.SYSTEM_ACCOUNT, systemAccount);
        map.put(Constrants.MSG_ID, msgId);
        if (!Validator.validArgs(map)) {
            return JsonWrapUtil.reMsg(ReturnTypeEnum.PARAMS_ERROR);
        }
        BusinessSystem businessSystem = accountService.selectBySystemNo(systemNo);
        if (null == businessSystem) {
            return JsonWrapUtil.reMsg(ReturnTypeEnum.BUSINESSNO_ERROR);
        }
        List<BindingInfo> bindInfos = accountService.selectBindInfosBySystemIdAndAccount(businessSystem.getSystemId(), systemAccount);
        if (null == bindInfos || bindInfos.size() == 0) {
            return JsonWrapUtil.reMsg(ReturnTypeEnum.NO_BIND);
        }
        Object cache = cacheMgr.getMemcache(msgId);
        if (null != cache) {
            String val = (String) cache;
            if (Constrants.YES.equals(val)) {
                //已经被确认成功过
                return JsonWrapUtil.reMsg(ReturnTypeEnum.HAS_BEEN_CONFIRMED);
            } else if (Constrants.NO.equals(val)) {
                //已经被确认失败
                return JsonWrapUtil.reMsg(ReturnTypeEnum.HAS_BEEN_CANCELLED);
            } else if (Constrants.WAIT.equals(val)) {
                //尚未被二次确认
                String returnStatus = "";
                String jsonResult = "";
                for (BindingInfo bindInfo : bindInfos) {
                    HashMap<String, String> paramMap = new HashMap<String, String>();
                    JSONObject tmp = new JSONObject();
                    tmp.put(Constrants.DEVICE_ID, bindInfo.getDeviceId());
                    tmp.put(Constrants.PARTNERCODE, ConfigFileUtil.getPartnerCode());
                    tmp.put(Constrants.APP_ID, businessSystem.getAppId());
                    tmp.put(Constrants.SHORT_TOKEN, dcCode);
                    paramMap.put("requestData", tmp.toString());
                    jsonResult = WSUtil.validateShortCode(paramMap);
                    JSONObject jobj = JSONObject.fromObject(jsonResult);
                    returnStatus = jobj.getString(Constrants.STATUS);
                    if (Constrants.SUCCESS_STATUS.equals(returnStatus)) {
                        //数字令校验通过，需要向手机端push消息进行二次确认
                        cache = cacheMgr.getMemcache(msgId);
                        if (null != cache) {
                            val = (String) cache;
                            if (Constrants.WAIT.equals(val)) {
                                cacheMgr.setMemcache(msgId, Constrants.YES, expTime / 2);
                                logger.info("set cache msgId:" + msgId + ", and val is :" + cacheMgr.getMemcache(msgId));
                                cachedThreadPool.execute(new MsgNotify(systemAccount, systemNo, msgId, ReturnTypeEnum.PASS_VALIDATE));
                                Object value = cacheMgr.getMemcache(msgId + "_" + Constrants.DATA);
                                logger.info("call back data is:" + value);
                                String data = null;
                                if (null != value)
                                    data = (String) value;
                                //回调业务系统接口
                                BusinessSystemCallback businessSystemCallback = accountService.selectBySystemIdAndType(businessSystem.getSystemId(), CallbackTypeEnum.AUTH.getCode());
                                if (null != businessSystemCallback) {
                                    cachedThreadPool.execute(new BusinessNotify(businessSystemCallback, systemAccount, data, businessSystem));
                                }
                                //Success
                                TxnLogBo paramBo = new TxnLogBo();
                                paramBo.setTxnId(msgId);
                                paramBo.setSystemNo(systemNo);
                                paramBo.setSystemAccount(systemAccount);
                                paramBo.setStartTime(DateUtil.getNewDateByAddSecond(-1 * expTime));
                                paramBo.setEndTime(DateUtil.getCurrentDateString());
                                TxnLog txnLog = systemTxnService.findLatestTxnLog(paramBo);
                                logger.info(">>>> txnLog=" + (txnLog == null));
                                if (txnLog != null) {
                                    txnLog.setStatus(StatusEnum.SUCCESS.getCode());
                                    systemTxnService.updateTxnLog(txnLog);
                                }

                                return JsonWrapUtil.reMsg(ReturnTypeEnum.PASS_VALIDATE);
                            } else if (Constrants.YES.equals(val)) {
                                //已经被确认成功过
                                return JsonWrapUtil.reMsg(ReturnTypeEnum.HAS_BEEN_CONFIRMED);
                            } else if (Constrants.NO.equals(val)) {
                                //已经被确认失败
                                return JsonWrapUtil.reMsg(ReturnTypeEnum.HAS_BEEN_CANCELLED);
                            }
                        }

                    }
                }
                cacheMgr.setMemcache(dcCode, Constrants.NO, expTime / 2);
            }
        } else {
            return JsonWrapUtil.reMsg(ReturnTypeEnum.CONFIRM_ERROR);
        }
        //failed
        TxnLogBo paramBo = new TxnLogBo();
        paramBo.setTxnId(msgId);
        paramBo.setSystemNo(systemNo);
        paramBo.setSystemAccount(systemAccount);
        paramBo.setStartTime(DateUtil.getNewDateByAddSecond(-1 * expTime));
        paramBo.setEndTime(DateUtil.getCurrentDateString());
        /*logger.info(">>>> startTime ******" + paramBo.getStartTime());
        logger.info(">>>> endTime ******" + paramBo.getEndTime());
        logger.info(">>>> msgId=" + msgId);
        logger.info(">>>> systemNo=" + systemNo);
        logger.info(">>>> systemAccount=" + systemAccount);*/
        TxnLog txnLog = systemTxnService.findLatestTxnLog(paramBo);
        if (txnLog != null) {
            txnLog.setStatus(StatusEnum.FAILED.getCode());
            systemTxnService.updateTxnLog(txnLog);
        }

        return JsonWrapUtil.reMsg(ReturnTypeEnum.NOT_PASS_VALIDATE);
    }

    /**
     * @return 0 取消成功，其余均失败
     * @ APP端发送的二次取消确认接口
     */

    @POST
    @Path("/{version}/refuse")
    @Produces("application/json;charset=utf-8")
    public String refuse(@PathParam(Constrants.VERSION) String version,@FormParam(Constrants.SYSTEM_NO) String systemNo, @FormParam(Constrants.SYSTEM_ACCOUNT) String systemAccount,@FormParam(Constrants.TX_ID) String txId) {
        return cancel(systemNo,systemAccount,txId);
    }
    @POST
    @Path("/rest/account/checkPassHUECansel")
    @Produces("application/json;charset=utf-8")
    public String cancel(@FormParam(Constrants.SYSTEM_NO) String systemNo, @FormParam(Constrants.SYSTEM_ACCOUNT) String systemAccount,@FormParam(Constrants.MSG_ID) String msgId) {
        //取消失败的情形：过期，已经被确认，已经被取消
        Map<String, String> map = new HashMap<String, String>();
        map.put(Constrants.SYSTEM_NO, systemNo);
        map.put(Constrants.SYSTEM_ACCOUNT, systemAccount);
        map.put(Constrants.MSG_ID, msgId);
        if (!Validator.validArgs(map)) {
            return JsonWrapUtil.reMsg(ReturnTypeEnum.PARAMS_ERROR);
        }
        BusinessSystem businessSystem = accountService.selectBySystemNo(systemNo);
        if (null == businessSystem) {
            return JsonWrapUtil.reMsg(ReturnTypeEnum.BUSINESSNO_ERROR);
        }
        List<BindingInfo> bindInfos = accountService.selectBindInfosBySystemIdAndAccount(businessSystem.getSystemId(), systemAccount);
        if (null == bindInfos || bindInfos.size() == 0) {
            return JsonWrapUtil.reMsg(ReturnTypeEnum.NO_BIND);
        }
        Object cache = cacheMgr.getMemcache(msgId);
        if (null != cache) {
            String val = (String) cache;
            if (Constrants.WAIT.equals(val)) {
                //尚未被确认或者取消
                cacheMgr.setMemcache(msgId, Constrants.NO, expTime / 2);
                cachedThreadPool.execute(new MsgNotify(systemAccount, systemNo, msgId, ReturnTypeEnum.NOT_PASS_VALIDATE));
                //Refuse
                TxnLogBo paramBo = new TxnLogBo();
                paramBo.setTxnId(msgId);
                paramBo.setSystemNo(systemNo);
                paramBo.setSystemAccount(systemAccount);
                paramBo.setStartTime(DateUtil.getNewDateByAddSecond(-1 * expTime));
                paramBo.setEndTime(DateUtil.getCurrentDateString());
                logger.info(">>>>2 startTime ******" + paramBo.getStartTime());
                logger.info(">>>>2 endTime ******" + paramBo.getEndTime());
                logger.info(">>>>2 msgId=" + msgId);
                logger.info(">>>>2 systemNo=" + systemNo);
                logger.info(">>>>2 systemAccount=" + systemAccount);
                TxnLog txnLog = systemTxnService.findLatestTxnLog(paramBo);
                if (txnLog != null) {
                    txnLog.setStatus(StatusEnum.REFUSED.getCode());
                    systemTxnService.updateTxnLog(txnLog);
                }

                return JsonWrapUtil.reMsg(ReturnTypeEnum.CANSEL_SUCCESS);
            } else if (Constrants.YES.equals(val)) {
                //交易已经被确认了
                return JsonWrapUtil.reMsg(ReturnTypeEnum.HAS_BEEN_CONFIRMED);
            } else if (Constrants.NO.equals(val)) {
                //交易已经被取消了
                return JsonWrapUtil.reMsg(ReturnTypeEnum.HAS_BEEN_CANCELLED);
            }
        } else {
            //交易已经过期了
            return JsonWrapUtil.reMsg(ReturnTypeEnum.HAS_EXPIRED);
        }
        return JsonWrapUtil.reMsg(ReturnTypeEnum.CANSEL_FAIL);
    }


    /**
     * WEB端发起的查询二次校验是否通过接口
     *
     * @return 0 校验成功
     */

    @GET
    @Path("/{version}/auth_status")
    @Produces("application/javascript")
    public JSONWithPadding authStatusForWeb(@PathParam(Constrants.VERSION) String version, @QueryParam("jsoncallback") String callback, @QueryParam(Constrants.SYSTEM_NO) String systemNo, @QueryParam(Constrants.SYSTEM_ACCOUNT) String systemAccount, @QueryParam(Constrants.TX_ID) String txId) {
        JSONObject json = new JSONObject();
        Map<String, String> map = new HashMap<String, String>();
        map.put(Constrants.SYSTEM_NO, systemNo);
        map.put(Constrants.SYSTEM_ACCOUNT, systemAccount);
        map.put(Constrants.TX_ID, txId);
        if (!Validator.validArgs(map)) {
            return JsonWrapUtil.reMsgJSONWithPadding(ReturnTypeEnum.PARAMS_ERROR, json, callback);
        }
        if (txId.length() > 6)
            txId = String.valueOf(txId.hashCode());
        Object cache = cacheMgr.getMemcache(txId);
        json.put(Constrants.TRUSTED_DEVICE_TOKEN, "");
        BusinessSystem businessSystem = accountService.selectBySystemNo(systemNo);
        if (null == businessSystem) {
            return JsonWrapUtil.reMsgJSONWithPadding(ReturnTypeEnum.BUSINESSNO_ERROR, json, callback);
        }
        List<BindingInfo> bindInfos = accountService.selectBindInfosBySystemIdAndAccount(businessSystem.getSystemId(), systemAccount);
        if (null == bindInfos || bindInfos.size() == 0) {
            return JsonWrapUtil.reMsgJSONWithPadding(ReturnTypeEnum.NO_BIND, json, callback);
        }
        if (null != cache) {
            String val = (String) cache;
            if (Constrants.WAIT.equals(val)) {
                return JsonWrapUtil.reMsgJSONWithPadding(ReturnTypeEnum.WAIT_CONFIRM, json, callback);
            } else if (Constrants.YES.equals(val))
                return JsonWrapUtil.reMsgJSONWithPadding(ReturnTypeEnum.PASS_VALIDATE, json, callback);
        } else
            return JsonWrapUtil.reMsgJSONWithPadding(ReturnTypeEnum.CONFIRM_ERROR, json, callback);
        return JsonWrapUtil.reMsgJSONWithPadding(ReturnTypeEnum.NOT_PASS_VALIDATE, json, callback);
    }


    @GET
    @Path("/rest/account/checkPassHUEValidate")
    @Produces("application/javascript")
    public JSONWithPadding checkPassHUEValidateForWeb(@QueryParam("jsoncallback") String callback, @QueryParam(Constrants.SYSTEM_NO) String systemNo, @QueryParam(Constrants.SYSTEM_ACCOUNT) String systemAccount, @QueryParam(Constrants.DC_CODE) String dcCode) {
        JSONObject json = new JSONObject();
        Map<String, String> map = new HashMap<String, String>();
        map.put(Constrants.SYSTEM_NO, systemNo);
        map.put(Constrants.SYSTEM_ACCOUNT, systemAccount);
        map.put(Constrants.DC_CODE, dcCode);
        if (!Validator.validArgs(map)) {
            return JsonWrapUtil.reMsgJSONWithPadding(ReturnTypeEnum.PARAMS_ERROR, json, callback);
        }
        if (dcCode.length() > 6)
            dcCode = String.valueOf(dcCode.hashCode());
        Object cache = cacheMgr.getMemcache(dcCode);
        BusinessSystem businessSystem = accountService.selectBySystemNo(systemNo);
        if (null == businessSystem) {
            return JsonWrapUtil.reMsgJSONWithPadding(ReturnTypeEnum.BUSINESSNO_ERROR, json, callback);
        }
        List<BindingInfo> bindInfos = accountService.selectBindInfosBySystemIdAndAccount(businessSystem.getSystemId(), systemAccount);
        if (null == bindInfos || bindInfos.size() == 0) {
            return JsonWrapUtil.reMsgJSONWithPadding(ReturnTypeEnum.NO_BIND, json, callback);
        }
        if (null != cache) {
            String val = (String) cache;
            if (Constrants.WAIT.equals(val)) {
                return JsonWrapUtil.reMsgJSONWithPadding(ReturnTypeEnum.WAIT_CONFIRM, json, callback);
            } else if (Constrants.YES.equals(val))
                return JsonWrapUtil.reMsgJSONWithPadding(ReturnTypeEnum.PASS_VALIDATE, json, callback);
        } else
            return JsonWrapUtil.reMsgJSONWithPadding(ReturnTypeEnum.CONFIRM_ERROR, json, callback);
        return JsonWrapUtil.reMsgJSONWithPadding(ReturnTypeEnum.NOT_PASS_VALIDATE, json, callback);
    }


    /**
     * APP端发起的查询二次校验是否通过接口
     *
     */

    @POST
    @Path("/{version}/auth_status")
    @Produces("application/json;charset=utf-8")
    public String authStatus(@PathParam(Constrants.VERSION) String version, @FormParam(Constrants.SYSTEM_NO) String systemNo, @FormParam(Constrants.SYSTEM_ACCOUNT) String systemAccount, @FormParam(Constrants.TX_ID) String txId) {
        JSONObject json = new JSONObject();
        Map<String, String> map = new HashMap<String, String>();
        map.put(Constrants.SYSTEM_NO, systemNo);
        map.put(Constrants.SYSTEM_ACCOUNT, systemAccount);
        map.put(Constrants.TX_ID, txId);
        json.put(Constrants.TRUSTED_DEVICE_TOKEN, "");
        if (!Validator.validArgs(map)) {
            return JsonWrapUtil.buildJSON(ReturnTypeEnum.PARAMS_ERROR,json);
        }
        if (txId.length() > 6)
            txId = String.valueOf(txId.hashCode());
        Object cache = cacheMgr.getMemcache(txId);
        BusinessSystem businessSystem = accountService.selectBySystemNo(systemNo);
        if (null == businessSystem) {
            return JsonWrapUtil.buildJSON(ReturnTypeEnum.BUSINESSNO_ERROR,json);
        }
        List<BindingInfo> bindInfos = accountService.selectBindInfosBySystemIdAndAccount(businessSystem.getSystemId(), systemAccount);
        if (null == bindInfos || bindInfos.size() == 0) {
            return JsonWrapUtil.buildJSON(ReturnTypeEnum.NO_BIND,json);
        }
        if (null != cache) {
            String val = (String) cache;
            if (Constrants.WAIT.equals(val)) {
                return JsonWrapUtil.buildJSON(ReturnTypeEnum.WAIT_CONFIRM,json);
            } else if (Constrants.YES.equals(val))
                return JsonWrapUtil.buildJSON(ReturnTypeEnum.PASS_VALIDATE,json);
        } else
            return JsonWrapUtil.buildJSON(ReturnTypeEnum.CONFIRM_ERROR,json);
        return JsonWrapUtil.buildJSON(ReturnTypeEnum.NOT_PASS_VALIDATE,json);
    }

    @POST
    @Path("/rest/account/checkPassHUEValidate")
    @Produces("application/json;charset=utf-8")
    public String checkPassHUEValidateForApp(@FormParam(Constrants.SYSTEM_NO) String systemNo, @FormParam(Constrants.SYSTEM_ACCOUNT) String systemAccount, @FormParam(Constrants.DC_CODE) String dcCode) {

        Map<String, String> map = new HashMap<String, String>();
        map.put(Constrants.SYSTEM_NO, systemNo);
        map.put(Constrants.SYSTEM_ACCOUNT, systemAccount);
        map.put(Constrants.DC_CODE, dcCode);

        if (!Validator.validArgs(map)) {
            return JsonWrapUtil.reMsg(ReturnTypeEnum.PARAMS_ERROR);
        }
        if (dcCode.length() > 6)
            dcCode = String.valueOf(dcCode.hashCode());
        Object cache = cacheMgr.getMemcache(dcCode);
        BusinessSystem businessSystem = accountService.selectBySystemNo(systemNo);
        if (null == businessSystem) {
            return JsonWrapUtil.reMsg(ReturnTypeEnum.BUSINESSNO_ERROR);
        }
        List<BindingInfo> bindInfos = accountService.selectBindInfosBySystemIdAndAccount(businessSystem.getSystemId(), systemAccount);
        if (null == bindInfos || bindInfos.size() == 0) {
            return JsonWrapUtil.reMsg(ReturnTypeEnum.NO_BIND);
        }
        if (null != cache) {
            String val = (String) cache;
            if (Constrants.WAIT.equals(val)) {
                return JsonWrapUtil.reMsg(ReturnTypeEnum.WAIT_CONFIRM);
            } else if (Constrants.YES.equals(val))
                return JsonWrapUtil.reMsg(ReturnTypeEnum.PASS_VALIDATE);
        } else
            return JsonWrapUtil.reMsg(ReturnTypeEnum.CONFIRM_ERROR);
        return JsonWrapUtil.reMsg(ReturnTypeEnum.NOT_PASS_VALIDATE);
    }
    /*************************************************************************HUE Api End*****************************************************************************************************************/

/*************************************************************************Alias Api Begin*****************************************************************************************************************/
    /**
     * 查询设备别名
     *
     * @param deviceId
     * @param systemNo
     * @return
     */

    @POST
    @Path("/{version}/getDeviceAlias")
    @Produces("application/json;charset=utf-8")
    public String getDeviceAliasVersion(@PathParam(Constrants.VERSION) String version, @FormParam(Constrants.DEVICE_ID) String deviceId, @FormParam(Constrants.SYSTEM_NO) String systemNo) {
        return getDeviceAlias(deviceId, systemNo);
    }

    @POST
    @Path("/rest/alias/query")
    @Produces("application/json;charset=utf-8")
    public String getDeviceAlias(@FormParam(Constrants.DEVICE_ID) String deviceId, @FormParam(Constrants.SYSTEM_NO) String systemNo) {
        Map<String, String> map = new HashMap<String, String>();
        map.put(Constrants.DEVICE_ID, deviceId);
        if (!Validator.validArgs(map)) {
            return JsonWrapUtil.reMsg(ReturnTypeEnum.PARAMS_ERROR);
        }
        if (StringUtils.isNotBlank(systemNo)) {
            BusinessSystem businessSystem = accountService.selectBySystemNo(systemNo);
            if (null == businessSystem) {
                return JsonWrapUtil.reMsg(ReturnTypeEnum.BUSINESSNO_ERROR);
                // return StringUtil.jsonExceptionMsg(ErrorTypeEnum.BUSINESSNO_ERROR.getCode(), ErrorTypeEnum.BUSINESSNO_ERROR.getDescription());
            }
        }
        Map<String, Object> param = new HashMap<String, Object>();
        param.put(Constrants.DEVICE_ID, deviceId);
        if (StringUtils.isNotBlank(systemNo)) param.put(Constrants.SYSTEM_NO, systemNo);
        BindingTerminal bindingTerminal = patternLockService.findBindingTerminal(param);
        if (bindingTerminal == null) {
            return JsonWrapUtil.reMsg(ReturnTypeEnum.QUERY_FAIL);
        }
        JSONObject json = new JSONObject();
        json.put(Constrants.ALIAS, null == bindingTerminal.getAlias() ? "" : bindingTerminal.getAlias());
        return StringUtil.jsonSuccessData(json);
    }

    /**
     * 修改设备别名
     *
     * @param deviceId
     * @param alias
     * @param systemNo
     * @return
     */


    @POST
    @Path("/{version}/modifyDeviceAlias")
    @Produces("application/json;charset=utf-8")
    public String modifyDeviceAliasVersion(@PathParam(Constrants.VERSION) String version, @FormParam(Constrants.DEVICE_ID) String deviceId, @FormParam(Constrants.ALIAS) String alias, @FormParam(Constrants.SYSTEM_NO) String systemNo) {
        return modifyDeviceAlias(deviceId, alias, systemNo);
    }

    @POST
    @Path("/rest/alias/update")
    @Produces("application/json;charset=utf-8")
    public String modifyDeviceAlias(@FormParam(Constrants.DEVICE_ID) String deviceId, @FormParam(Constrants.ALIAS) String alias, @FormParam(Constrants.SYSTEM_NO) String systemNo) {
        Map<String, String> map = new HashMap<String, String>();
        map.put(Constrants.DEVICE_ID, deviceId);
        map.put(Constrants.ALIAS, alias);
        if (!Validator.validArgs(map)) {
            return JsonWrapUtil.reMsg(ReturnTypeEnum.PARAMS_ERROR);
        }
        if (StringUtils.isNotBlank(systemNo)) {
            BusinessSystem businessSystem = accountService.selectBySystemNo(systemNo);
            if (null == businessSystem) {
                return JsonWrapUtil.reMsg(ReturnTypeEnum.BUSINESSNO_ERROR);
            }
        }
        Map<String, Object> param = new HashMap<String, Object>();
        param.put(Constrants.DEVICE_ID, deviceId);
        if (StringUtils.isNotBlank(systemNo)) param.put(Constrants.SYSTEM_NO, systemNo);
        BindingTerminal bindingTerminal = patternLockService.findBindingTerminal(param);
        if (bindingTerminal == null) {
            return JsonWrapUtil.reMsg(ReturnTypeEnum.UPDATE_FAIL);
        }
        bindingTerminal.setAlias(alias);
        bindingTerminal.setSystemNo(systemNo);
        patternLockService.updateLock(bindingTerminal);
        return JsonWrapUtil.reMsg(ReturnTypeEnum.UPDATE_SUCCESS);
    }
    /*************************************************************************Alias Api End*****************************************************************************************************************/


    /**
     * **********************************************************************Push Api Begin****************************************************************************************************************
     */

    @POST
    @Path("/rest/instructions/list")
    @Produces("application/json;charset=utf-8")
    public String getPush(@FormParam(Constrants.DEVICE_ID) String deviceId) {
        Map<String, String> map = new HashMap<String, String>();
        map.put(Constrants.DEVICE_ID, deviceId);
        if (!Validator.validArgs(map)) {
            return JsonWrapUtil.reMsg(ReturnTypeEnum.PARAMS_ERROR);
        }
        List<BindingInstructions> bindInstructions = service.selectByDeviceId(deviceId);
        JSONObject json = new JSONObject();
        json.put("bindInstructions", bindInstructions);
        service.updateByRecords(bindInstructions);
        return StringUtil.jsonSuccessData(json);
    }

    @POST
    @Path("/{version}/getPush")
    @Produces("application/json;charset=utf-8")
    public String getPushVersion(@PathParam(Constrants.VERSION) String version, @FormParam(Constrants.DEVICE_ID) String deviceId) {
        return getPush(deviceId);
    }

    @POST
    @Path("/rest/instructions/read")
    @Produces("application/json;charset=utf-8")
    public String read(@FormParam(Constrants.INSTRUCTIONS_ID) String instructionsId) {
        Map<String, String> map = new HashMap<String, String>();
        map.put(Constrants.INSTRUCTIONS_ID, instructionsId);
        if (!Validator.validArgs(map)) {
            return JsonWrapUtil.reMsg(ReturnTypeEnum.PARAMS_ERROR);
        }
        BindingInstructions bindInstructions = service.selectById(Integer.parseInt(instructionsId));
        if (null == bindInstructions) {
            return JsonWrapUtil.reMsg(ReturnTypeEnum.NO_INSTRUCTION_FOUND);
        }
        bindInstructions.setIsDo(Constrants.YES);
        service.updateByRecord(bindInstructions);
        return StringUtil.jsonSuccessData(Constrants.SUCCESS);
    }

    @POST
    @Path("/rest/instructions/save")
    @Produces("application/json;charset=utf-8")
    public String save(@FormParam(Constrants.DEVICE_ID) String deviceId, @FormParam(Constrants.SYSTEM_NO) String systemNo, @FormParam(Constrants.SYSTEM_NAME) String systemName, @FormParam(Constrants.SYSTEM_ACCOUNT) String systemAccount, @FormParam(Constrants.FROM) String from, @FormParam(Constrants.INSTRUCTIONS_TYPE) String instructionsType, @FormParam(Constrants.MESSAGE) String message, @FormParam(Constrants.DEVICE_NAME) String deviceName, @FormParam(Constrants.CLIENT_IP) String clientIp, @FormParam(Constrants.MSG_ID) String msgId) {
        Map<String, String> map = new HashMap<String, String>();
        map.put(Constrants.DEVICE_ID, deviceId);
        map.put(Constrants.SYSTEM_NO, systemNo);
        map.put(Constrants.SYSTEM_ACCOUNT, systemAccount);
        //map.put(Constrants.FROM, from);
        map.put(Constrants.INSTRUCTIONS_TYPE, instructionsType);
        if (!Validator.validArgs(map)) {
            return JsonWrapUtil.reMsg(ReturnTypeEnum.PARAMS_ERROR);
        }
        BindingInstructions bindInstructions = new BindingInstructions();
        bindInstructions.setDeviceId(deviceId);
        bindInstructions.setInstructionsType(instructionsType);
        bindInstructions.setIsDo(Constrants.NO);
        bindInstructions.setSystemAccount(systemAccount);
        bindInstructions.setSystemNo(systemNo);
        bindInstructions.setCreateTime(DateUtil.getCurrentDateString());
        bindInstructions.setOrigin(from);
        bindInstructions.setMessage(message);
        bindInstructions.setDeviceName(deviceName);
        bindInstructions.setSystemName(systemName);
        bindInstructions.setTransactionId(msgId);
        bindInstructions.setClientIp(clientIp);
        service.saveByRecord(bindInstructions);
        return StringUtil.jsonSuccessData(Constrants.SUCCESS);
    }

    @POST
    @Path("/rest/account/msgPush")
    @Produces("application/json;charset=utf-8")
    public String msgPush(@FormParam(Constrants.DEVICE_ID) String deviceId, @FormParam(Constrants.MSG_TITLE) String msgTitle, @FormParam(Constrants.MSG_CONTENT) String msgContent) {
        Map<String, String> map = new HashMap<String, String>();
        //map.put(Constrants.DEVICE_ID, deviceId);
        map.put(Constrants.MSG_TITLE, msgTitle);
        map.put(Constrants.MSG_CONTENT, msgContent);
        if (!Validator.validArgs(map)) {
            return JsonWrapUtil.reMsg(ReturnTypeEnum.PARAMS_ERROR);
        }
        if (!StringUtils.isNotBlank(deviceId)) {
            JSONObject json = JSONObject.fromObject(msgContent);
            JSONObject ctxJson = JSONObject.fromObject(json.getString("ctx"));
            String systemNo = ctxJson.getString(Constrants.SYSTEM_NO);
            String systemAccount = ctxJson.getString(Constrants.SYSTEM_ACCOUNT);
            BusinessSystem businessSystem = accountService.selectBySystemNo(systemNo);
            if (null == businessSystem) {
                return JsonWrapUtil.reMsg(ReturnTypeEnum.BUSINESSNO_ERROR);
            }
            List<BindingInfo> bindinfos = accountService.selectBindInfosBySystemIdAndAccount(businessSystem.getSystemId(), systemAccount);
            if (bindinfos.size() > 0) {
                for (BindingInfo bindingInfo : bindinfos) {
                    msgPushMethod(bindingInfo.getDeviceId(), msgTitle, msgContent, null, null, null);
                }
                return JsonWrapUtil.reMsg(ReturnTypeEnum.UNBIND_SUCCESS);
            } else {
                return JsonWrapUtil.reMsg(ReturnTypeEnum.PARAMS_ERROR);
            }
        } else {
            return msgPushMethod(deviceId, msgTitle, msgContent, null, null, null);
        }
    }
    /*************************************************************************Push Api End*****************************************************************************************************************/


    /**
     * **********************************************************************Tscsecurid Base Api Begin****************************************************************************************************************
     */

    @POST
    @Path("/rest/message/check")
    @Produces("application/json;charset=utf-8")
    public String update(@FormParam(Constrants.VERSION_NO) String versionNo, @FormParam(Constrants.VERSION_TYPE) String versionType) {
        Map<String, String> map = new HashMap<String, String>();
        map.put(Constrants.VERSION_NO, versionNo);
        map.put(Constrants.VERSION_TYPE, versionType);
        if (!Validator.validArgs(map)) {
            return JsonWrapUtil.reMsg(ReturnTypeEnum.PARAMS_ERROR);
        }
        VersionManage version = messageService.selectVersionByVersionType(versionType);
        if (null == version || versionNo.equals(version.getVersionNo())) {
            return StringUtil.jsonSuccessMsg("当前已是最高版本，无需更新");
        }
        JSONObject json = new JSONObject();
        if ("Android".endsWith(versionType)) {
            json.put("downloadurl", ConfigFileUtil.getDownLoadHeadUrl() + version.getFilePath());
        } else {
            json.put("downloadurl", "itms-services://?action=download-manifest&url=" + ConfigFileUtil.getDownLoadHeadUrl() + version.getIosPlistPath());
        }
        json.put("force", "force".equals(version.getUpdateType()) ? "1" : "0");
        json.put("description", version.getVersionDesc());
        return StringUtil.jsonSuccessData(1, "存在新版本", json);
    }

    @POST
    @Path("/rest/message/feedback")
    @Produces("application/json;charset=utf-8")
    public String feedbackMessage(@FormParam(Constrants.DEVICE_ID) String deviceId, @FormParam(Constrants.FEEDBACK_CONTENT) String feedbackContent) {
        Map<String, String> map = new HashMap<String, String>();
        map.put(Constrants.DEVICE_ID, deviceId);
        map.put(Constrants.FEEDBACK_CONTENT, feedbackContent);
        if (!Validator.validArgs(map)) {
            return JsonWrapUtil.reMsg(ReturnTypeEnum.PARAMS_ERROR);
        }
        FeedbackInfo feedBackInfo = new FeedbackInfo();
        feedBackInfo.setEnterpriseId(0);
        feedBackInfo.setDeviceId(deviceId);
        feedBackInfo.setFeedbackContent(feedbackContent);
        feedBackInfo.setFeedbackType(FeedbackTypeEnum.APP.getCode());
        feedBackInfo.setFeedbackTime(DateUtil.getCurrentDateString());
        feedBackInfo.setOperationState(Constrants.NO);
        feedBackService.saveFeedBack(feedBackInfo);
        return StringUtil.jsonSuccessMsg("提交成功，感谢您的反馈");
    }

    /**
     * 是否设置密宝
     *
     * @param deviceId
     * @return
     */
    @POST
    @Path("/rest/protect/isSet")
    @Produces("application/json;charset=utf-8")
    public String isSetProtect(@FormParam(Constrants.DEVICE_ID) String deviceId) {
        Map<String, String> map = new HashMap<String, String>();
        map.put(Constrants.DEVICE_ID, deviceId);
        if (!Validator.validArgs(map)) {
            return JsonWrapUtil.reMsg(ReturnTypeEnum.PARAMS_ERROR);
        }
        List<BindingTerminalPwdProtection> protection = passwordProtectService.selectByDeviceId(deviceId);
        if (protection.size() == 0) {
            return StringUtil.jsonSuccessData(Constrants.SUCCESS);
        }
        return StringUtil.jsonExceptionMsg(Constrants.FAIL_STATUS, Constrants.FAIL);
    }


    /**
     * 设置密宝
     *
     * @param deviceId
     * @param questionAnswers
     * @return
     */
    @POST
    @Path("/rest/protect/set")
    @Produces("application/json;charset=utf-8")
    public String setProtect(@FormParam(Constrants.DEVICE_ID) String deviceId, @FormParam(Constrants.QUESTION_ANSWERS) String questionAnswers) {
        Map<String, String> map = new HashMap<String, String>();
        map.put(Constrants.DEVICE_ID, deviceId);
        map.put(Constrants.QUESTION_ANSWERS, questionAnswers);
        if (!Validator.validArgs(map)) {
            return JsonWrapUtil.reMsg(ReturnTypeEnum.PARAMS_ERROR);
        }
        passwordProtectService.saveQuestions(deviceId, questionAnswers);
        return StringUtil.jsonSuccessMsg("密保问题设置成功");
    }

    /**
     * 找回手势密码
     *
     * @param deviceId
     * @param questionAnswers
     * @return
     */
    @POST
    @Path("/rest/protect/findBack")
    @Produces("application/json;charset=utf-8")
    public String checkProtect(@FormParam(Constrants.DEVICE_ID) String deviceId, @FormParam(Constrants.QUESTION_ANSWERS) String questionAnswers) {
        Map<String, String> map = new HashMap<String, String>();
        map.put(Constrants.DEVICE_ID, deviceId);
        map.put(Constrants.QUESTION_ANSWERS, questionAnswers);
        if (!Validator.validArgs(map)) {
            return JsonWrapUtil.reMsg(ReturnTypeEnum.PARAMS_ERROR);
        }
        JSONArray jsonArray = JSONArray.fromObject(questionAnswers);
        JSONObject json = null;
        BindingTerminalPwdProtection protection = null;
        for (int i = 0; i < jsonArray.size(); i++) {
            json = (JSONObject) jsonArray.get(i);
            if (null != json) {
                protection = passwordProtectService.selectByDeviceIdAndQuestionOrder(deviceId, Integer.parseInt(json.getString("questionDispOrder")));
                if (!json.getString("questionAnswer").equals(protection.getQuestionAnswer())) {
                    return StringUtil.jsonExceptionMsg(Constrants.FAIL_STATUS, Constrants.FAIL);
                }
            } else {
                return StringUtil.jsonExceptionMsg(Constrants.FAIL_STATUS, Constrants.FAIL);
            }
        }
        BindingTerminal bindingTerminal = patternLockService.findById(deviceId);
        bindingTerminal.setDevicePassword("");
        patternLockService.updateLock(bindingTerminal);
        return StringUtil.jsonSuccessMsg(Constrants.SUCCESS);
    }

    /**
     * 查找客服电话
     *
     * @param deviceId
     * @return
     */
    @POST
    @Path("/rest/protect/queryPhone")
    @Produces("application/json;charset=utf-8")
    public String queryPhone(@FormParam(Constrants.DEVICE_ID) String deviceId) {
        JSONObject json = new JSONObject();
        json.put("phoneNo", ConfigFileUtil.getPhoneNo());
        return StringUtil.jsonSuccessData(json);
    }

    /**
     * 是否设置手势密码
     *
     * @param deviceId
     * @return
     */
    @POST
    @Path("/rest/lock/isSet")
    @Produces("application/json;charset=utf-8")
    public String isSetLock(@FormParam(Constrants.DEVICE_ID) String deviceId) {
        Map<String, String> map = new HashMap<String, String>();
        map.put(Constrants.DEVICE_ID, deviceId);
        if (!Validator.validArgs(map)) {
            JsonWrapUtil.reMsg(ReturnTypeEnum.PARAMS_ERROR);
        }
        BindingTerminal bindingTerminal = patternLockService.findById(deviceId);
        if (null != bindingTerminal && StringUtils.isNotBlank(bindingTerminal.getDevicePassword())) {
            return StringUtil.jsonSuccessMsg(Constrants.SUCCESS);
        }
        return JsonWrapUtil.reMsg(ReturnTypeEnum.NO_DEVICE_PWD_FOUND);
    }

    /**
     * 设置手势密码
     *
     * @param deviceId
     * @param osType
     * @param phoneNo
     * @param devicePassword
     * @return
     */
    @POST
    @Path("/rest/lock/set")
    @Produces("application/json;charset=utf-8")
    public String setLock(@FormParam(Constrants.DEVICE_ID) String deviceId, @FormParam(Constrants.OS_TYPE) String osType,
                          @FormParam(Constrants.PHONE_NO) String phoneNo, @FormParam(Constrants.DEVICE_PASSWORD) String devicePassword,
                          @FormParam(Constrants.ALIAS) String alias, @FormParam(Constrants.SYSTEM_NO) String systemNo) {
        Map<String, String> map = new HashMap<String, String>();
        map.put(Constrants.DEVICE_ID, deviceId);
        //map.put(Constrants.OS_TYPE, osType);
        //map.put(Constrants.DEVICE_PASSWORD, devicePassword);
        if (!Validator.validArgs(map)) {
            return JsonWrapUtil.reMsg(ReturnTypeEnum.PARAMS_ERROR);
        }
        if (StringUtils.isNotBlank(systemNo)) {
            BusinessSystem businessSystem = accountService.selectBySystemNo(systemNo);
            if (null == businessSystem) {
                return JsonWrapUtil.reMsg(ReturnTypeEnum.BUSINESSNO_ERROR);
            }
        }
        Map<String, Object> param = new HashMap<String, Object>();
        param.put(Constrants.DEVICE_ID, deviceId);
        if (StringUtils.isNotBlank(systemNo))
            param.put(Constrants.SYSTEM_NO, systemNo);
        BindingTerminal bindingTerminal = patternLockService.findBindingTerminal(param);
        if (null == bindingTerminal) {
            bindingTerminal = new BindingTerminal();
            bindingTerminal.setDeviceId(deviceId);
            bindingTerminal.setDeviceMobile(phoneNo);
            if (StringUtils.isEmpty(devicePassword))
                devicePassword = "0,1,3,4";
            bindingTerminal.setDevicePassword(devicePassword);
            bindingTerminal.setOsType(osType);
            bindingTerminal.setAlias(alias);
            bindingTerminal.setRegisterTime(DateUtil.getCurrentDateString());
            bindingTerminal.setTimes("0");
            bindingTerminal.setSystemNo(systemNo);
            bindingTerminal.setUnlockTime(DateUtil.getCurrentDateString(DateUtil.FORMAT_DATE_YYYY_MM_DD));
            patternLockService.saveLock(bindingTerminal);
        } else {
            if (StringUtils.isNotEmpty(devicePassword))
                bindingTerminal.setDevicePassword(devicePassword);
            bindingTerminal.setRegisterTime(DateUtil.getCurrentDateString());
            bindingTerminal.setTimes("0");
            bindingTerminal.setUnlockTime(DateUtil.getCurrentDateString(DateUtil.FORMAT_DATE_YYYY_MM_DD));
            if (StringUtils.isNotEmpty(alias))
                bindingTerminal.setAlias(alias);
            bindingTerminal.setSystemNo(systemNo);
            patternLockService.updateLock(bindingTerminal);
        }
        return StringUtil.jsonSuccessMsg(Constrants.SUCCESS);
    }

    @POST
    @Path("/rest/lock/setLock")
    @Produces("application/json;charset=utf-8")
    public String setLock0(@FormParam(Constrants.DEVICE_ID) String deviceId, @FormParam(Constrants.OS_TYPE) String osType,
                           @FormParam(Constrants.PHONE_NO) String phoneNo, @FormParam(Constrants.DEVICE_PASSWORD) String devicePassword) {
        Map<String, String> map = new HashMap<String, String>();
        map.put(Constrants.DEVICE_ID, deviceId);
        map.put(Constrants.OS_TYPE, osType);
        map.put(Constrants.DEVICE_PASSWORD, devicePassword);
        BindingTerminal bindingTerminal = patternLockService.findById(deviceId);
        if (null == bindingTerminal) {
            bindingTerminal = new BindingTerminal();
            bindingTerminal.setDeviceId(deviceId);
            bindingTerminal.setDeviceMobile(phoneNo);
            bindingTerminal.setDevicePassword(devicePassword);
            bindingTerminal.setOsType(osType);
            bindingTerminal.setRegisterTime(DateUtil.getCurrentDateString());
            bindingTerminal.setTimes("0");
            bindingTerminal.setUnlockTime(DateUtil.getCurrentDateString(DateUtil.FORMAT_DATE_YYYY_MM_DD));
            bindingTerminal.setAlias("我的微信设备");
            patternLockService.saveLock(bindingTerminal);
        } else {
            bindingTerminal.setDevicePassword(devicePassword);
            bindingTerminal.setRegisterTime(DateUtil.getCurrentDateString());
            bindingTerminal.setTimes("0");
            bindingTerminal.setUnlockTime(DateUtil.getCurrentDateString(DateUtil.FORMAT_DATE_YYYY_MM_DD));
            patternLockService.updateLock(bindingTerminal);
        }
        return StringUtil.jsonSuccessMsg(Constrants.SUCCESS);
    }

    /**
     * 检查手势密码
     *
     * @param deviceId
     * @param devicePassword
     * @return
     */
    @POST
    @Path("/rest/lock/check")
    @Produces("application/json;charset=utf-8")
    public String checkLock(@FormParam(Constrants.DEVICE_ID) String deviceId, @FormParam(Constrants.DEVICE_PASSWORD) String devicePassword) {
        Map<String, String> map = new HashMap<String, String>();
        map.put(Constrants.DEVICE_ID, deviceId);
        map.put(Constrants.DEVICE_PASSWORD, devicePassword);
        if (!Validator.validArgs(map)) {
            JsonWrapUtil.reMsg(ReturnTypeEnum.PARAMS_ERROR);
        }
        BindingTerminal bindingTerminal = patternLockService.findById(deviceId);
        if (null == bindingTerminal) {
            return StringUtil.jsonExceptionMsg(Constrants.FAIL_STATUS, "对不起，您还没有设置手势密码");
        }
        if ("5".equals(bindingTerminal.getTimes()) && bindingTerminal.getUnlockTime().equals(DateUtil.getCurrentDateString(DateUtil.FORMAT_DATE_YYYY_MM_DD))) {
            return StringUtil.jsonExceptionMsg(2, "手势密码已经连续输错5次，该设备已经锁定，请联系客服");
        }
        if (devicePassword.equals(bindingTerminal.getDevicePassword())) {
            bindingTerminal.setActivityTime(DateUtil.getCurrentDateString());
            bindingTerminal.setTimes("0");
            bindingTerminal.setUnlockTime(DateUtil.getCurrentDateString(DateUtil.FORMAT_DATE_YYYY_MM_DD));
            patternLockService.updateLock(bindingTerminal);
            return StringUtil.jsonSuccessMsg(Constrants.SUCCESS);
        }
        String times = bindingTerminal.getTimes();
        if (!bindingTerminal.getUnlockTime().equals(DateUtil.getCurrentDateString(DateUtil.FORMAT_DATE_YYYY_MM_DD)) || StringUtil.isBlank(times))
            times = "0";
        bindingTerminal.setTimes((Integer.parseInt(times) + 1) + "");
        bindingTerminal.setUnlockTime(DateUtil.getCurrentDateString(DateUtil.FORMAT_DATE_YYYY_MM_DD));
        patternLockService.updateLock(bindingTerminal);
        JSONObject json = new JSONObject();
        json.put("times", bindingTerminal.getTimes());
        return StringUtil.jsonSuccessData(Constrants.FAIL_STATUS, Constrants.FAIL, json);
    }

    /**
     * 获取配置文件
     *
     * @return
     */
    @POST
    @Path("/{version}/config")
    @Produces("application/json;charset=utf-8")
    public String sysConfigVersion(@PathParam(Constrants.VERSION) String version) {
        return sysConfig();
    }


    /**
     * 获取配置文件
     *
     * @return
     */
    @POST
    @Path("/rest/account/config")
    @Produces("application/json;charset=utf-8")
    public String sysConfig() {
        return StringUtil.jsonSuccessData(ConfigFileUtil.getAppConfig().replaceAll(";", ","));
    }

    /**
     * 生成did
     *
     * @return
     */
    @POST
    @Path("/rest/rest/device/deviceId")
    @Produces("application/json;charset=utf-8")
    public String getDid(@FormParam("fp") String fp) {
        String did = InternalDeviceId.makeId();
        String param = new String(Base64.decode(fp, Base64.DEFAULT));
        String[] params = param.split("&");
        String osType = "";
        for (String string : params) {
            if (string.startsWith("app-type")) {
                osType = string.split("=")[1];
            }
        }
        if ("ios".equals(osType)) {
            did = "2" + did;
        }
        if ("android".equals(osType)) {
            did = "3" + did;
        }
        if ("winphone".equals(osType)) {
            did = "4" + did;
        }
        JSONObject json = new JSONObject();
        json.put(Constrants.STATUS, 1);
        json.put("errorMessage", "");
        json.put(Constrants.DEVICE_ID, did);
        json.put("uuid", "");
        return json.toString();
    }

    /**
     * **********************************************************************Tscsecurid Base Api Begin****************************************************************************************************************
     */


    public void sendWeChatMsg(String openId, String systemName, String systemAccount, String currentTime, String operateContent) throws Exception {
        String accessToken = getAccessToken();
        String json = "{\"touser\": \"" + openId + "\",\"template_id\": \"" + PropertyUtil.getPropertyValue("tscsecurid-api.properties", "wx.templetId") + "\",\"url\": \"\", \"topcolor\": \"#FF0000\", "
                + "\"data\":{"
                + "\"first\":{\"value\":\"" + "您的账号" + operateContent + "成功\"" + ",\"color\":\"#000000\"},"
                + "\"keyword1\":{\"value\":\"" + systemAccount + "\",\"color\":\"#173177\"},"
                + "\"keyword2\":{\"value\":\"" + systemName + "\",\"color\":\"#173177\"},"
                + "\"keyword3\":{\"value\":\"" + operateContent + "\",\"color\":\"#173177\"},"
                + "\"keyword4\":{\"value\":\"" + currentTime + "\",\"color\":\"#173177\"},"
                + "\"remark\":{\"value\":\"" + "如非您本人操作，请尽快查明原因" + "\",\"color\":\"#000000\"}}}";

        String action = "https://api.weixin.qq.com/cgi-bin/message/template/send?access_token=" + accessToken;
        try {
            connectWeiXinInterface(action, json);
        } catch (Exception e) {
        }
    }

    public String getAccessToken() throws Exception {
        String accessToken = null;
        if (com.payegis.tscsecurid.common.util.StringUtil.isEmpty(Config.getInstance().getAccessToken())) {
            accessToken = initParam();
            if (com.payegis.tscsecurid.common.util.StringUtil.isNotEmpty(accessToken)) {
                Config.getInstance().setAccessToken(accessToken);
                Config.getInstance().setTime(System.currentTimeMillis() / 1000);
            }
        } else {
            long now = System.currentTimeMillis() / 1000;
            if (now - config.getInstance().getTime() > 7000) {
                accessToken = initParam();
                Config.getInstance().setAccessToken(accessToken);
                Config.getInstance().setTime(System.currentTimeMillis() / 1000);
            } else
                accessToken = Config.getInstance().getAccessToken();
        }
        return accessToken;
    }

    public String initParam() throws Exception {
        wxMpConfigStorage = new WxMpInMemoryConfigStorage();
        wxMpConfigStorage.setAppId(PropertyUtil.getPropertyValue("tscsecurid-api.properties", "wx.appid")); // 设置微信公众号的appid
        wxMpConfigStorage.setSecret(PropertyUtil.getPropertyValue("tscsecurid-api.properties", "wx.secret")); // 设置微信公众号的app corpSecret
        wxMpConfigStorage.setToken(PropertyUtil.getPropertyValue("tscsecurid-api.properties", "wx.token")); // 设置微信公众号的token
        wxMpService = new WxMpServiceImpl();
        wxMpService.setWxMpConfigStorage(wxMpConfigStorage);
        return wxMpService.getAccessToken();
    }

    /**
     * 连接请求微信后台接口
     *
     * @param action 接口url
     * @param json   请求接口传送的json字符串
     */
    public void connectWeiXinInterface(String action, String json) {
        URL url;
        try {
            url = new URL(action);
            HttpURLConnection http = (HttpURLConnection) url.openConnection();
            http.setRequestMethod("POST");
            http.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            http.setDoOutput(true);
            http.setDoInput(true);
            System.setProperty("sun.net.client.defaultConnectTimeout", "30000");// 连接超时30秒
            System.setProperty("sun.net.client.defaultReadTimeout", "30000"); // 读取超时30秒
            http.connect();
            OutputStream os = http.getOutputStream();
            os.write(json.getBytes("UTF-8"));// 传入参数
            InputStream is = http.getInputStream();
            int size = is.available();
            byte[] jsonBytes = new byte[size];
            is.read(jsonBytes);
            String result = new String(jsonBytes, "UTF-8");
            // logger.info("请求返回结果:" + result);
            os.flush();
            os.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    class MessageSendThread implements Runnable {
        private List<BindingInfo> bindingInfoList;
        private BusinessSystem businessSystem;
        private String type;
        private String systemAccount;
        private String operateContent;
        private String messageContent;
        private String desc;
        private String deviceName;
        private String clientIp;

        public MessageSendThread(List<BindingInfo> bindingInfoList, BusinessSystem businessSystem, String type, String systemAccount, String operateContent, String messageContent, String desc, String deviceName, String clientIp) {
            this.bindingInfoList = bindingInfoList;
            this.businessSystem = businessSystem;
            this.type = type;
            this.systemAccount = systemAccount;
            this.operateContent = operateContent;
            this.messageContent = messageContent;
            this.desc = desc;
            this.deviceName = deviceName;
            this.clientIp = clientIp;
        }

        @Override
        public void run() {
            if (null != bindingInfoList && null != businessSystem && StringUtils.isNotEmpty(type)) {
                String deviceId = "";
                String msg = "";
                for (BindingInfo bi : bindingInfoList) {
                    logger.info("bi..................." + bi.getDeviceId());
                    deviceId = bi.getDeviceId();
                    msg = "您的" + businessSystem.getSystemName() + "账号:" + systemAccount + ",于" + DateUtil.getCurrentDateString() + "成功" + operateContent;
                    AppUser appUser = new AppUser();
                    appUser.setAppId(ConfigFileUtil.getAppId());
                    appUser.setClientName(deviceId.startsWith("3") ? "Android" : "IOS");
                    appUser.setDeviceId(deviceId);
                    appUser.setDeviceToken(null != accountService.selectTokenByDeviceId(deviceId) ? accountService.selectTokenByDeviceId(deviceId).getToken() : "");
                    appUser.setEmail("");
                    appUser.setLoginName(deviceId);
                    appUser.setPartnerCode(ConfigFileUtil.getPartnerCode());
                    appUser.setPhoneNum("");
                    String[] sendtypes = new String[]{"msg", "push"};
                    MsgBean msgBean = new MsgBean();
                    msgBean.setTitle("");
                    msgBean.setContent(msg);
                    try {
                        if (null != businessSystem)
                            sendWeChatMsg(deviceId, businessSystem.getSystemName(), systemAccount, DateUtil.getCurrentDateString(), operateContent);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    MessageAssembleUtil.sendDefaultMessage(sendtypes, appUser, msgBean, ConfigFileUtil.getPushUrl());
                }
            } else {
                msgPush0("", operateContent, messageContent, desc, deviceName, clientIp);
            }
        }
    }

    class BusinessNotify implements Runnable {
        private BusinessSystemCallback businessSystemCallback;
        private String systemAccount;
        private String data;
        private BusinessSystem businessSystem;


        BusinessNotify(BusinessSystemCallback businessSystemCallback, String systemAccount, String data, BusinessSystem businessSystem) {
            this.businessSystemCallback = businessSystemCallback;
            this.systemAccount = systemAccount;
            this.data = data;
            this.businessSystem = businessSystem;
        }

        @Override
        public void run() {
            HashMap<String, String> paramMapSend = new HashMap<String, String>();
            paramMapSend.put(Constrants.SYSTEM_ACCOUNT, systemAccount);
            paramMapSend.put(Constrants.SYSTEM_NO, businessSystem.getSystemNo());
            paramMapSend.put(Constrants.DATA, data);
            String result = WSUtil.sendSignature(businessSystemCallback.getCallbackUrl(), businessSystem.getAppId(), businessSystem.getAppKey(), paramMapSend);
            JSONObject json = JSONObject.fromObject(result);
            logger.info(json);
        }
    }

    class MsgNotify implements Runnable {
        private String systemAccount;
        private String systemNo;
        private String msgId;
        private ReturnTypeEnum result;

        MsgNotify(String systemAccount, String systemNo, String msgId, ReturnTypeEnum result) {
            this.systemAccount = systemAccount;
            this.systemNo = systemNo;
            this.msgId = msgId;
            this.result = result;
        }

        @Override
        public void run() {
            Object sessionId = cacheMgr.getMemcache(msgId + "_session");
            logger.info("msgId:" + msgId);
            logger.info("session -----------" + sessionId);
            logger.info("session size:" + Config.getInstance().getMap() == null ? 0 : Config.getInstance().getMap().size());
            if (null != sessionId) {
                String key = (String) sessionId;
                logger.info("key:" + key);
                if (StringUtils.isNotEmpty(key)) {
                    logger.info(key + "_session");
                    logger.info(Config.getInstance() == null);
                    Session session = Config.getInstance().getMap().get(key + "_session");
                    logger.info("session info:" + session == null + "," + session.isOpen());
                    if (null != session && session.isOpen()) {
                        JSONObject reJson = new JSONObject();
                        reJson.put(Constrants.SYSTEM_NO, systemNo);
                        reJson.put(Constrants.DC_CODE, msgId);
                        reJson.put(Constrants.SYSTEM_ACCOUNT, systemAccount);
                        reJson.put(Constrants.STATUS, result.getCode());
                        reJson.put(Constrants.MESSAGE, result.getDescription());
                        try {
                            logger.info("send msg:" + result.getDescription());

                            session.getBasicRemote().sendText(reJson.toString());
                            cacheMgr.deleteMemcache(msgId + "_session");
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }
            }

        }
    }

    public String msgPush0(String deviceId, String msgTitle, String msgContent, String desc, String deviceName, String clientIp) {
        Map<String, String> map = new HashMap<String, String>();
        //map.put(Constrants.DEVICE_ID, deviceId);
        map.put(Constrants.MSG_TITLE, msgTitle);
        map.put(Constrants.MSG_CONTENT, msgContent);
        if (!Validator.validArgs(map)) {
            return JsonWrapUtil.reMsg(ReturnTypeEnum.PARAMS_ERROR);
        }
        if (!StringUtils.isNotBlank(deviceId)) {
            JSONObject json = JSONObject.fromObject(msgContent);
            logger.info("json:" + json);
            JSONObject ctxJson = JSONObject.fromObject(json.getString("ctx"));
            String systemNo = ctxJson.getString(Constrants.SYSTEM_NO);
            String systemAccount = ctxJson.getString(Constrants.SYSTEM_ACCOUNT);
            BusinessSystem businessSystem = accountService.selectBySystemNo(systemNo);
            if (null == businessSystem) {
                return JsonWrapUtil.reMsg(ReturnTypeEnum.BUSINESSNO_ERROR);
            }
            List<BindingInfo> bindinfos = accountService.selectBindInfosBySystemIdAndAccount(businessSystem.getSystemId(), systemAccount);
            logger.info("bindinfos size:" + bindinfos.size());
            if (bindinfos.size() > 0) {
                for (BindingInfo bindingInfo : bindinfos) {
                    msgPushMethod(bindingInfo.getDeviceId(), msgTitle, msgContent, desc, deviceName, clientIp);
                }
                return JsonWrapUtil.reMsg(ReturnTypeEnum.UNBIND_SUCCESS);
            } else {
                return JsonWrapUtil.reMsg(ReturnTypeEnum.PARAMS_ERROR);
            }
        } else {
            return msgPushMethod(deviceId, msgTitle, msgContent, desc, deviceName, clientIp);
        }
    }


    private void messageSend(List<BindingInfo> bindingInfoList, BusinessSystem businessSystem, String type, String systemAccount, String operateContent, String msgId, String message, String deviceName, String clientIp) {
        if (null != bindingInfoList && null != businessSystem && StringUtils.isNotEmpty(type)) {
            cachedThreadPool.execute(new MessageSendThread(bindingInfoList, businessSystem, type, systemAccount, operateContent, null, message, deviceName, clientIp));
        } else {
            String system = businessSystem.getSystemNo();
            final String messageContent = "{\"type\":\"" + type + "\"," +
                    "\"ctx\":{\"systemNo\":\"" + system + "\",\"from\":\"other" + "\",\"msgId\":\"" + msgId + "\",\"systemAccount\":\"" + systemAccount + "\"}}";
            cachedThreadPool.execute(new MessageSendThread(null, null, null, null, operateContent, messageContent, message, deviceName, clientIp));
        }
    }


    private String msgPushMethod(String deviceId, String msgTitle, String msgContent, String desc, String deviceName, String clientIp) {

        JSONObject json = JSONObject.fromObject(msgContent);


        //通过deviceId到app_relation表中(在此表中为openId)查，看看能否查到数据，如果查到了，则表明用户用微信版时空令进行过绑定，则需要将消息通过微信公众号推送到openId
        //System.out.println("======pramdeviceId========" + deviceId);
      /*  AppRelationBean appRelationBean = appRelationService.getAppRelationByOpenId(deviceId);
        if(appRelationBean!=null && "1".equals(appRelationBean.getStatus())){
        	//向微信版时空令推送消息
        	try {
				sendWeChatMsg(deviceId,json.getString("ctx"));
			} catch (Exception e) {
				e.printStackTrace();
			}

        } */
        String pushAppId = "";
        logger.info("json:" + json.toString());
        if (Constrants.SYSTEM.equals(json.get("type"))) {
            msgContent = json.getString("ctx");
        }
        BusinessSystem businessSystem = null;
        String systemAccount = null;
        if (LogTypeEnum.UNBINDING.getCode().equals(json.get("type"))) {
            JSONObject ctxJson = JSONObject.fromObject(json.getString("ctx"));
            String systemNo = ctxJson.getString(Constrants.SYSTEM_NO);
            systemAccount = ctxJson.getString(Constrants.SYSTEM_ACCOUNT);
            String from = ctxJson.getString(Constrants.FROM);
            businessSystem = accountService.selectBySystemNo(systemNo);
            if (null == businessSystem) {
                return JsonWrapUtil.reMsg(ReturnTypeEnum.BUSINESSNO_ERROR);
            }
            Map<String, Object> requesMap = new HashMap<String, Object>();
            requesMap.put(Constrants.DEVICE_ID, deviceId);
            requesMap.put(Constrants.SYSTEM_NO, systemNo);
            requesMap.put(Constrants.SYSTEM_ACCOUNT, systemAccount);
            requesMap.put(Constrants.FROM, from);
            requesMap.put(Constrants.INSTRUCTIONS_TYPE, LogTypeEnum.UNBINDING.getCode());
            WSUtil.sendRequest(ConfigFileUtil.getTscSecuridCloudInstructionsUrl(), requesMap);
            BusinessSystemCallback businessSystemCallback = accountService.selectBySystemIdAndType(businessSystem.getSystemId(), CallbackTypeEnum.UNBINDING.getCode());
            if ("customer".equals(from)) {
                if (null != businessSystemCallback) {
                    HashMap<String, String> paramMapSend = new HashMap<String, String>();
                    paramMapSend.put(Constrants.DEVICE_ID, deviceId);
                    paramMapSend.put("uid", systemAccount);
                    paramMapSend.put("type", "unbind");
                    String result = WSUtil.sendSignature(businessSystemCallback.getCallbackUrl(), businessSystem.getAppId(), businessSystem.getAppKey(), paramMapSend);
                    JSONObject jsonRe = JSONObject.fromObject(result);
                    String sendStatus = jsonRe.getString(Constrants.STATUS);
                    if (!Constrants.SUCCESS_STATUS.equals(sendStatus)) {
                        return StringUtil.jsonExceptionMsg(Integer.parseInt(sendStatus), jsonRe.getString(Constrants.MESSAGE));
                    }
                }
                Map<String, Object> requesMapUnbindCloud = new HashMap<String, Object>();
                requesMapUnbindCloud.put(Constrants.DEVICE_ID, deviceId);
                requesMapUnbindCloud.put(Constrants.SYSTEM_NO, systemNo);
                requesMapUnbindCloud.put(Constrants.SYSTEM_ACCOUNT, systemAccount);
                logger.info("getTscSecuridCloudUnbindUrl:" + ConfigFileUtil.getTscSecuridCloudUnbindUrl());
                WSUtil.sendRequest(ConfigFileUtil.getTscSecuridCloudUnbindUrl(), requesMapUnbindCloud);
            } else if ("other".equals(from)) {
                logger.info("other:");
                BindingInfoEnterprise infoEnterprise = new BindingInfoEnterprise();
                infoEnterprise.setDeviceId(deviceId);
                infoEnterprise.setSystemAccount(systemAccount);
                infoEnterprise.setSystemNo(systemNo);
                accountService.deleteBindInfo(deviceId, businessSystem.getSystemId(), systemAccount, infoEnterprise);
            }
            if ("cloud".equals(from)) {
                if (null != businessSystemCallback) {
                    HashMap<String, String> paramMapSend = new HashMap<String, String>();
                    paramMapSend.put(Constrants.DEVICE_ID, deviceId);
                    paramMapSend.put("uid", systemAccount);
                    paramMapSend.put("type", "unbind");
                    String result = WSUtil.sendSignature(businessSystemCallback.getCallbackUrl(), businessSystem.getAppId(), businessSystem.getAppKey(), paramMapSend);
                    JSONObject jsonRe = JSONObject.fromObject(result);
                    String sendStatus = jsonRe.getString(Constrants.STATUS);
                    if (!Constrants.SUCCESS_STATUS.equals(sendStatus)) {
                        return StringUtil.jsonExceptionMsg(Integer.parseInt(sendStatus), jsonRe.getString(Constrants.MESSAGE));
                    }
                }
                msgContent = "nopush";
            } else {
                msgContent = "您的" + businessSystem.getSystemName() + "账号:" + systemAccount + ",于" + DateUtil.getCurrentDateString() + "成功解绑";
            }
        }
        if (LogTypeEnum.LOGIN.getCode().equals(json.get("type"))) {
            JSONObject ctxJson = JSONObject.fromObject(json.getString("ctx"));
            String systemNo = ctxJson.getString(Constrants.SYSTEM_NO);
            systemAccount = ctxJson.getString(Constrants.SYSTEM_ACCOUNT);
            String from = ctxJson.getString(Constrants.FROM);
            Map<String, Object> requesMap = new HashMap<String, Object>();
            requesMap.put(Constrants.DEVICE_ID, deviceId);
            requesMap.put(Constrants.SYSTEM_NO, systemNo);
            requesMap.put(Constrants.SYSTEM_ACCOUNT, systemAccount);
            requesMap.put(Constrants.FROM, from);
            requesMap.put(Constrants.INSTRUCTIONS_TYPE, LogTypeEnum.LOGIN.getCode());
            logger.info("send login instruction " + deviceId);
            String result = WSUtil.sendRequest(ConfigFileUtil.getTscSecuridCloudInstructionsUrl(), requesMap);
            JSONObject resultJson = JSONObject.fromObject(result);
            String sendStatus = resultJson.getString(Constrants.STATUS);
            if (!Constrants.SUCCESS_STATUS.equals(sendStatus)) {
                return StringUtil.jsonExceptionMsg(Integer.parseInt(sendStatus), resultJson.getString(Constrants.MESSAGE));
            }
            businessSystem = accountService.selectBySystemNo(systemNo);
            msgContent = "您的" + businessSystem.getSystemName() + "账号:" + systemAccount + ",于" + DateUtil.getCurrentDateString() + "成功登录";
            accountService.updateOnlineStatus(deviceId, businessSystem.getSystemId(), systemAccount, OnlineStatusEnum.ONLINE.getCode(), businessSystem.getSystemNo());

        }

        /*if (LogTypeEnum.AUTH.getCode().equals(json.get("type"))) {
            JSONObject ctxJson = JSONObject.fromObject(json.getString("ctx"));
            String systemNo = ctxJson.getString(Constrants.SYSTEM_NO);
            systemAccount = ctxJson.getString(Constrants.SYSTEM_ACCOUNT);
            String from = ctxJson.getString(Constrants.FROM);
            businessSystem = accountService.selectBySystemNo(systemNo);
            Map<String, Object> requesMap = new HashMap<String, Object>();
            requesMap.put(Constrants.DEVICE_ID, deviceId);
            //requesMap.put(Constrants.SYSTEM_NO, systemNo);
            requesMap.put(Constrants.SYSTEM_NO, systemNo + "|" + businessSystem.getSystemName());
            requesMap.put(Constrants.SYSTEM_ACCOUNT, systemAccount);
            requesMap.put(Constrants.FROM, from);
            requesMap.put(Constrants.INSTRUCTIONS_TYPE, LogTypeEnum.AUTH.getCode());
            logger.info("send login instruction " + deviceId);
            String result = WSUtil.sendRequest(ConfigFileUtil.getTscSecuridCloudInstructionsUrl(), requesMap);
            JSONObject resultJson = JSONObject.fromObject(result);
            String sendStatus = resultJson.getString(Constrants.STATUS);
            if (!Constrants.SUCCESS_STATUS.equals(sendStatus)) {
                return StringUtil.jsonExceptionMsg(Integer.parseInt(sendStatus), resultJson.getString(Constrants.MESSAGE));
            }
            businessSystem = accountService.selectBySystemNo(systemNo);
            msgContent = "您的" + businessSystem.getSystemName() + "账号:" + systemAccount + ",于" + DateUtil.getCurrentDateString() + "成功验证";
        }*/

        if (LogTypeEnum.LOGOUT.getCode().equals(json.get("type"))) {
            JSONObject ctxJson = JSONObject.fromObject(json.getString("ctx"));
            String systemNo = ctxJson.getString(Constrants.SYSTEM_NO);
            systemAccount = ctxJson.getString(Constrants.SYSTEM_ACCOUNT);
            String from = ctxJson.getString(Constrants.FROM);
            Map<String, Object> requesMap = new HashMap<String, Object>();
            requesMap.put(Constrants.DEVICE_ID, deviceId);
            requesMap.put(Constrants.SYSTEM_NO, systemNo);
            requesMap.put(Constrants.SYSTEM_ACCOUNT, systemAccount);
            requesMap.put(Constrants.FROM, from);
            requesMap.put(Constrants.INSTRUCTIONS_TYPE, LogTypeEnum.LOGOUT.getCode());
            String result = WSUtil.sendRequest(ConfigFileUtil.getTscSecuridCloudInstructionsUrl(), requesMap);
            JSONObject resultJson = JSONObject.fromObject(result);
            String sendStatus = resultJson.getString(Constrants.STATUS);
            if (!Constrants.SUCCESS_STATUS.equals(sendStatus)) {
                return StringUtil.jsonExceptionMsg(Integer.parseInt(sendStatus), resultJson.getString(Constrants.MESSAGE));
            }
            businessSystem = accountService.selectBySystemNo(systemNo);
            msgContent = "您的" + businessSystem.getSystemName() + "账号:" + systemAccount + ",于" + DateUtil.getCurrentDateString() + "成功登出";
            accountService.updateOnlineStatus(deviceId, businessSystem.getSystemId(), systemAccount, OnlineStatusEnum.OFFLINE.getCode(), businessSystem.getSystemNo());

        }

        if (CallbackTypeEnum.AUTH.getCode().equals(json.get("type"))) {
            JSONObject ctxJson = JSONObject.fromObject(json.getString("ctx"));
            String systemNo = ctxJson.getString(Constrants.SYSTEM_NO);
            systemAccount = ctxJson.getString(Constrants.SYSTEM_ACCOUNT);
            String from = ctxJson.getString(Constrants.FROM);
            String msgId = ctxJson.getString(Constrants.MSG_ID);
            Map<String, Object> requesMap = new HashMap<String, Object>();
            requesMap.put(Constrants.DEVICE_ID, deviceId);
            businessSystem = accountService.selectBySystemNo(systemNo);
            requesMap.put(Constrants.SYSTEM_NO, systemNo);
            requesMap.put(Constrants.SYSTEM_NAME, businessSystem.getSystemName());
            requesMap.put(Constrants.SYSTEM_ACCOUNT, systemAccount);
            requesMap.put(Constrants.INSTRUCTIONS_TYPE, CallbackTypeEnum.AUTH.getCode());
            pushAppId = businessSystem.getAppId();
            if (msgId.equals("null") || msgId.equals(""))
                msgId = null;
            requesMap.put(Constrants.FROM, from);
            requesMap.put(Constrants.MSG_ID, msgId);
            requesMap.put(Constrants.MESSAGE, desc);
            requesMap.put(Constrants.DEVICE_NAME, deviceName);
            requesMap.put(Constrants.CLIENT_IP, clientIp);
            logger.info("save msgId:" + msgId);
            String result = WSUtil.sendRequest(ConfigFileUtil.getTscSecuridCloudInstructionsUrl(), requesMap);
            JSONObject resultJson = JSONObject.fromObject(result);
            String sendStatus = resultJson.getString(Constrants.STATUS);
            if (!Constrants.SUCCESS_STATUS.equals(sendStatus)) {
                return StringUtil.jsonExceptionMsg(Integer.parseInt(sendStatus), resultJson.getString(Constrants.MESSAGE));
            }
            businessSystem = accountService.selectBySystemNo(systemNo);
            msgContent = "您的" + businessSystem.getSystemName() + "账号:" + systemAccount + ",于" + DateUtil.getCurrentDateString() + "有一条新的交易消息";
        }

        if (!"nopush".equals(msgContent)) {
            AppUser appUser = new AppUser();
            pushAppId = StringUtils.isEmpty(pushAppId) ? ConfigFileUtil.getAppId() : pushAppId;
            appUser.setAppId(pushAppId);
            appUser.setClientName(deviceId.startsWith("3") ? "Android" : "IOS");
            appUser.setDeviceId(deviceId);
            appUser.setDeviceToken(null != accountService.selectTokenByDeviceId(deviceId) ? accountService.selectTokenByDeviceId(deviceId).getToken() : "");
            appUser.setEmail("");
            appUser.setLoginName(deviceId);
            appUser.setPartnerCode(ConfigFileUtil.getPartnerCode());
            appUser.setPhoneNum("");
            String[] sendtypes = new String[]{"msg", "push"};
            MsgBean msgBean = new MsgBean();
            msgBean.setTitle(msgTitle);
            msgBean.setContent(msgContent);
            logger.info("begin push :" + appUser.getDeviceId() + ",detail:" + msgContent);
            String res = MessageAssembleUtil.sendDefaultMessage(sendtypes, appUser, msgBean, ConfigFileUtil.getPushUrl());
            logger.info(res);
            try {
                if (null != businessSystem)
                    sendWeChatMsg(deviceId, businessSystem.getSystemName(), systemAccount, DateUtil.getCurrentDateString(), LogTypeEnum.getDescription((String) json.get("type")));
            } catch (Exception e) {
                e.printStackTrace();
            }
            return res;
        } else {
            return JsonWrapUtil.reMsg(ReturnTypeEnum.UNBIND_SUCCESS);
        }
    }

}