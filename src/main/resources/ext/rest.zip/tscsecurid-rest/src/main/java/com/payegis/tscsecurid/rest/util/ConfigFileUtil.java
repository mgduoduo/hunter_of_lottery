package com.payegis.tscsecurid.rest.util;

import org.apache.commons.configuration.Configuration;
import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.ConfigurationFactory;
import org.apache.log4j.Logger;

import java.io.File;
import java.io.IOException;
import java.io.StringReader;
import java.util.Properties;

public class ConfigFileUtil {
	
	protected final static Logger logger = Logger.getLogger(ConfigFileUtil.class);

	private static Configuration config = null;
	
	private static long lastModifyTime = 0l;
	
	private static String configFilePath ="/tscsecurid-api.properties";


	public static void getConfig(){
		try{
			if (config == null) {
				lastModifyTime = new File(configFilePath).lastModified();
				loadConfig(configFilePath);
			}else{
				if(getReload()){
					long nowLastModifyTime=new File(configFilePath).lastModified();
					if(nowLastModifyTime!=lastModifyTime){
						logger.info("检测到配置文件有变动,重新加载配置文件");
						loadConfig(configFilePath);
						lastModifyTime=nowLastModifyTime;
					}
				}
			}
		}catch (ConfigurationException e){
			logger.error(e.getMessage());
		}
	}

	private static void loadConfig(String configFilePath) throws ConfigurationException{
		System.setProperty("config.file", configFilePath);
		ConfigurationFactory factory = new ConfigurationFactory("tscsecurid-api.xml");
		config = factory.getConfiguration();
	}
	
	public static Boolean getReload(){
		if(config==null){
			return true;
		}else{
			return config.getBoolean("config.reload",true);
		}
	}

	public static void setConfig(String message){
		getConfig();
		Properties pro = new Properties();
		try {
			pro.load(new StringReader(message));
		} catch (IOException e) {
			logger.error(e.getMessage());
		}
		for(Object t:pro.keySet()){
			config.clearProperty(t.toString());
			config.addProperty(t.toString(), pro.getProperty(t.toString()));
		}  
	}
	public static String getPushUrl(){
		getConfig();
		return config.getString("push.url");
	}
	
	public static String getAppId(){
		getConfig();
		return config.getString("app.appid");
	}
	
	
	public static String getAppKey(){
		getConfig();
		return config.getString("app.appkey");
	}
	
	
	public static String getPartnerCode(){
		getConfig();
		return config.getString("app.partnercode");
	}
	
	public static String getTSCUrl(){
		getConfig();
		return config.getString("tsc.url");
	}
	
	public static String getValidateShortCodeUrl(){
		getConfig();
		return config.getString("validate.short.code.url");
	}
	
	public static String getPhoneNo(){
		getConfig();
		return config.getString("phone.no");
	}
	
	public static String getVerifySercuridUrl(){
		getConfig();
		return config.getString("verify.sercurid.url");
	}
	public static String getTscSecuridCloudInstructionsUrl(){
		getConfig();
		return config.getString("securid.cloud.instructions.url");
	}
	public static String getTscSecuridCloudBindUrl(){
		getConfig();
		return config.getString("securid.cloud.bind.url");
	}
	public static String getTscSecuridCloudUnbindUrl(){
		getConfig();
		return config.getString("securid.cloud.unbind.url");
	}
	public static Boolean getIdentityValidate(){
		getConfig();
		return config.getBoolean("identity.validate");
	}

    public static String getUpdateOnlineStatusUrl(){
        getConfig();
        return config.getString("securid.cloud.updateOnlineStatus.url");
    }

	public static String getLockSetUrl(){
		getConfig();
		return config.getString("tscsecurid.rest.cloud.lockset.url");
	}

    public static String getTscSecuridCloudAliasQueryUrl(){
        getConfig();
        return config.getString("securid.cloud.alias.query.url");
    }

    public static String getValue(String key){
        getConfig();
        return config.getString(key);
    }

	public static String getAppConfig(){
		getConfig();
		return config.getString("app.config");
	}

	public static String getDownLoadHeadUrl(){
		getConfig();
		return config.getString("download.url.head");
	}

	public static String getMemcacheExpireTime(){
		getConfig();
		return config.getString("memcache.expTime");
	}
}
