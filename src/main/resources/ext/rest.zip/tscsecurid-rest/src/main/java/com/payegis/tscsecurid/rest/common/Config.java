package com.payegis.tscsecurid.rest.common;

import com.payegis.tscsecurid.common.util.PropertyUtil;
import com.payegis.tscsecurid.rest.util.ConfigFileUtil;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;

import javax.websocket.Session;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Created by zzg on 2015/7/24.
 */
@Controller
public class Config {
    private static String accessToken = null;
    private static long time = 0l;
    private static ConcurrentHashMap<String,Session> map = new ConcurrentHashMap<String,Session> ();
    private static List<String> authUrlList = null;
    protected Logger logger = Logger.getLogger(this.getClass());

    static {
        String apis= ConfigFileUtil.getValue(Constrants.KEY_AUTH_API);
        if(StringUtils.isNotEmpty(apis)){
            authUrlList = java.util.Arrays.asList(apis.split(";"));
        }
    }
    public static String getAccessToken() {
        return accessToken;
    }

    public static void setAccessToken(String accessToken) {
        Config.accessToken = accessToken;
    }

    public static long getTime() {
        return time;
    }

    public static void setTime(long time) {
        Config.time = time;
    }

    public static ConcurrentHashMap<String, Session> getMap() {
        return map;
    }

    public static void setMap(ConcurrentHashMap<String, Session> map) {
        Config.map = map;
    }

    private Config() {
    }

    private static Config instance = new Config();

    public static Config getInstance() {
        return instance;
    }

    public static List<String> getAuthUrlList() {
        return authUrlList;
    }

    public static void setAuthUrlList(List<String> authUrlList) {
        Config.authUrlList = authUrlList;
    }

    public static void main(String[] args) {
        System.out.println(PropertyUtil.getPropertyValue("tscsecurid-api.properties", "wx.appid"));

    }
}
