package com.payegis.tscsecurid.rest.util;

import net.sf.json.JSONException;
import net.sf.json.JSONObject;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import java.util.Random;


public class StringUtil {

	private static final String STATUS = "status";
	private static final String MESSAGE = "message";
	private static final String DATA = "data";
	
	private static Logger logger = Logger.getLogger(StringUtil.class);

	public static final String jsonExceptionMsg(int status, String message){
		JSONObject json = new JSONObject();
		try {
			json.put(STATUS, String.valueOf(status));
            json.put(DATA,"");
			if(isBlank(message)){			
				json.put(MESSAGE, "");
			}else{
				json.put(MESSAGE, message);
			}
		} catch (JSONException e) {
			e.printStackTrace();
		}
		logger.info("return json fail string: " + json.toString());
		return json.toString();
	}

	public static final String jsonSuccessMsg(String message){
		return jsonString(0, message, null);
	}

	public static final String jsonSuccessMsg(int status, String message){
		return jsonString(status, message, null);
	}

	public static final String jsonSuccessData(Object data){
		return jsonString(0, "", data);
	}

	public static final String jsonSuccessData(int status, Object data){
		return jsonString(status, "", data);
	}

	public static final String jsonSuccessData(String message, Object data){
		return jsonString(0, message, data);
	}

	public static final String jsonSuccessData(int status, String message, Object data){
		return jsonString(status, message, data);
	}

	private static final String jsonString(int status, String message, Object data){
		JSONObject json = new JSONObject();
		try {
			json.put(STATUS, String.valueOf(status));
			if(isBlank(message)){			
				json.put(MESSAGE, "");
			}else{
				json.put(MESSAGE, message);
			}
			if(data == null){
				json.put(DATA, "");
			}else{
				json.put(DATA, data);
			}
		} catch (JSONException e) {
			e.printStackTrace();
		}
		
		logger.info("return json string: " + json.toString());
		
		return json.toString();
	}

	public static final boolean isBlank(String value){
		if(value == null) 
			return true;
		if(value.trim().length() == 0) 
			return true;
		return false;
	} 
	
	public static final String confusePhoneNo(String phoneNo){
		if(isBlank(phoneNo) || phoneNo.length()<4){
			return phoneNo;
		}
		return phoneNo.substring(phoneNo.length()-4, phoneNo.length());
	}

    public static String append4AppointPayDesc(String deskNoLbl, String deskNo, String invoiceLbl, String receipt){
        StringBuffer fullDesc=new StringBuffer();
        if(deskNo!=null&&!"".equals(deskNo)){
            fullDesc.append(deskNoLbl);
            fullDesc.append(deskNo);
        }
        if(receipt!=null&&!"".equals(receipt)){
            if(fullDesc.length()>0){
                fullDesc.append(";");
            }
            fullDesc.append(invoiceLbl);
            fullDesc.append(receipt);
        }
        return fullDesc.toString();
    }
    

   
    public static String generateAuthCode() {
		Random generator = new Random();
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < 6; i++) {
			sb.append(Math.abs(generator.nextInt(10)));
		}
		return sb.toString();
	}
    public static String rightPadWithStr(String org){
       return rightPadWithStr(org,null);
    }
    public static String rightPadWithStr(String org,String pad){
       if(StringUtils.isNotBlank(org)){
          if(StringUtils.isBlank(pad)){
             pad="：";
          }
          if(StringUtils.endsWith(org, pad)){
             return org;
          }else if(StringUtils.endsWith(org.trim(), ":")){
             return StringUtils.replace(org.trim(), ":", pad);
          }else{
             return org+pad;
          }
       }
       return null;
    }
	public static String[] parse2DimensionCode(String code){
		if(StringUtils.isEmpty(code)){
			return null;
		}

		return code.split("\\|");
	}
}
