package com.payegis.tscsecurid.rest.service.impl;

import com.payegis.tscsecurid.common.data.entity.FeedbackInfo;
import com.payegis.tscsecurid.common.mapper.FeedbackInfoMapper;
import com.payegis.tscsecurid.rest.service.FeedBackService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class FeedBackServiceImpl implements FeedBackService{
	
	@Autowired
	private FeedbackInfoMapper feedbackInfoMapper;

	@Override
	public void saveFeedBack(FeedbackInfo feedBackInfo) {
		feedbackInfoMapper.insert(feedBackInfo);
	}
	
}
