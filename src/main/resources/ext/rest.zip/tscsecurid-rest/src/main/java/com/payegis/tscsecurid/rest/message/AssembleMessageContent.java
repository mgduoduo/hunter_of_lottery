package com.payegis.tscsecurid.rest.message;

import net.sf.json.JSONObject;

public interface AssembleMessageContent {
	
	/**
	 * 获取消息内容
	 * @param obj 动态参数
	 * @param dc 动态内容
	 * @return
	 */
	public JSONObject getMessageContent(MessageContent messageContent);

}
