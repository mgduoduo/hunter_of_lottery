package com.payegis.tscsecurid.rest.service;

import com.payegis.tscsecurid.common.data.bo.AccountInfoDto;
import com.payegis.tscsecurid.common.data.entity.*;

import java.util.List;

public interface AccountService {
	void saveBindInfo(BindingInfo bindingInfo, BindingLog bindingLog,BindingInfoEnterprise  infoEnterprise);
	List<AccountInfoDto> selectAccountInfo(String deviceId);
	void deleteBindInfo(String deviceId,Integer systemId,String systemAccount,BindingInfoEnterprise infoEnterprise);
	List<AccountInfoDto> selectBydeviceIdAndSystemId(String deviceId,Integer systemId);
	BusinessSystemCallback selectBySystemIdAndType(Integer systemId,String callbackType);
	BusinessSystem selectBySystemNo(String systemNo);
	void updateOnlineStatus(String deviceId, Integer systemId, String systemAccount,String code,String systemNo);
    void updateOnlineStatusWithNoLog(String deviceId, Integer systemId, String systemAccount,String code,String systemNo);
    BindingInfo selectBindInfoByDidAndSysIdAndSysAccount(String deviceId,Integer systemId,String systemAccount);
	DeviceToken selectTokenByDeviceId(String deviceId);
	void saveDeviceToken(DeviceToken deviceToken);
	//BindingInfo selectBindInfoBySystemIdAndAccount(Integer systemId,String systemAccount);//unused
	List<BindingInfo> selectBindInfosBySystemIdAndAccount(Integer systemId,String systemAccount);
	void updateDeviceToken(DeviceToken deviceToken);
	BindingInfo selectBindInfoBySystemIdAndDeviceId(Integer systemId,String deviceId);
	EnterpriseInfo selectEnterpriceById(Integer enterpriceId);
	SysEnterpriseConfig selectSysConfigByEnterId(Integer enterId);
    List<BindingInfoEnterprise> selectBySystemNoAndSystemAccount(String systemNo,String systemAccount);
    int updateBindDeviceAlias(BindingTerminal record);
    int updateDeviceNoDefault(Integer systemId,String systemAccount);
    int updateDeviceDefault(String deviceId,Integer systemId,String systemAccount);
}
