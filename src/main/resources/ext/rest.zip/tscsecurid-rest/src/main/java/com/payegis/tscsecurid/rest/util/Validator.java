package com.payegis.tscsecurid.rest.util;

import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;




public class Validator{
	
	private static Logger logger = Logger.getLogger(Validator.class);

   public static boolean validArgs(Map<String, String> map){
      for (Map.Entry<String, String> entry : map.entrySet()){
         String value = entry.getValue();
     	 logger.info("param key :"+entry.getKey() + "-------" + "param value :" + entry.getValue());
         if(!StringUtils.isNotBlank(value)){
        	 return false;
          }
      }
      return true;
   }
   
}
