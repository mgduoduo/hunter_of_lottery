package com.payegis.tscsecurid.rest.service.impl;

import com.payegis.tscsecurid.common.data.bo.TxnLogBo;
import com.payegis.tscsecurid.common.data.entity.TxnLog;
import com.payegis.tscsecurid.common.data.entity.TxnStatus;
import com.payegis.tscsecurid.common.mapper.SystemTxnMapper;
import com.payegis.tscsecurid.common.util.DateUtil;
import com.payegis.tscsecurid.rest.service.SystemTxnService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
public class SystemTxnServiceImpl implements SystemTxnService {

    @Autowired
    private SystemTxnMapper systemTxnMapper;

    @Override
    public void saveTxnLog(TxnLog txnLog) {
        txnLog.setLogId(UUID.randomUUID().toString().replace("-", ""));
        txnLog.setCreateTime(DateUtil.getCurrentDateString());
        systemTxnMapper.insertTxnLog(txnLog);

        TxnStatus status = new TxnStatus();
        status.setLogId(txnLog.getLogId());
        status.setOperateStatus(txnLog.getStatus());
        saveTxnStatus(status);
    }

    @Override
    public void saveTxnStatus(TxnStatus txnStatus) {
        txnStatus.setOperateTime(DateUtil.getCurrentDateString());
        systemTxnMapper.insertTxnStatus(txnStatus);
    }

    @Override
    public TxnLog findLatestTxnLog(TxnLogBo txnLogBo) {
        List<TxnLog> list = systemTxnMapper.selectTxnLog(txnLogBo);
        if(list!=null && !list.isEmpty()){
            return list.get(0);
        }
        return null;
    }

    @Override
    public int updateTxnLog(TxnLog txnLog) {

        int n = systemTxnMapper.updateTxnLog(txnLog);

        TxnStatus status = new TxnStatus();
        status.setLogId(txnLog.getLogId());
        status.setOperateStatus(txnLog.getStatus());
        saveTxnStatus(status);
        return n;
    }

    @Override
    public int updateTxnLogStatus(String logId, String status) {
        TxnLog txnLog = new TxnLog();
        txnLog.setLogId(logId);
        txnLog.setStatus(status);
        return systemTxnMapper.updateTxnLogStatus(txnLog);
    }
}
