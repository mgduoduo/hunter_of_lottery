package com.payegis.tscsecurid.rest.message;

import net.sf.json.JSONObject;

/**
 * 组装邮件消息通用类
 * 针对用户有可能在配置文件中自定义
 * @author xuman.xu
 *
 */
public class AssembleMailMessageContent implements AssembleMessageContent {

	@Override
	public JSONObject getMessageContent(MessageContent messageContent) {
		// TODO Auto-generated method stub
		JSONObject msg = new JSONObject();
		msg.put("type", messageContent.getType());
		msg.put("from", messageContent.getFrom());
		msg.put("title", messageContent.getTitle());
		msg.put("body", messageContent.getBody());
		msg.put("to", messageContent.getTo());
		return msg;
	}

	 
	
}
