package com.payegis.tscsecurid.rest.message;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.WebResource;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import javax.ws.rs.core.MediaType;
import java.util.List;

/**
 * 消息发送工厂类
 * @author xuman.xu
 *
 */
public class MessageSendFactory {
	
	
	/**
	 * 消息内容列表
	 */
	private List<MessageContent> msglist;
	
	private String pushUrl;
	
	private String userStatusUrl;
	
	/**
	 * 获取邮件内容接口
	 */
	private AssembleMessageContent assembleMail;
	
	/**
	 * 获取PUSH内容接口
	 */
	private AssembleMessageContent assemblePush;
	
	/**
	 * 获取消息内容接口
	 */
	private AssembleMessageContent assembleMsg;
	
	/**
	 * 获取短信内容接口
	 */
	private AssembleMessageContent assembleSms;
	
	/**
	 * 获取短信内容接口
	 */
	private AssembleMessageContent assembleSmsx;
	
	/**
	 * 动态参数 内容一般包括 [邮件帐号,手机号码,消息通知对象用户ID,deviceId,消息类型对应的code.......]
	 */
	
	private JSONArray jsonArray;
	
	/**
	 * 构造参数
	 * @param msglist 消息内容列表
	 */
	public MessageSendFactory(List<MessageContent> msglist,String pushUrl){
		this.msglist=msglist;
		this.pushUrl=pushUrl;
	}
	
	public MessageSendFactory(List<MessageContent> msglist,String pushUrl,String userStatusUrl){
		this.msglist=msglist;
		this.pushUrl=pushUrl;
		this.userStatusUrl=userStatusUrl;
	}
	
	
	/**
	 * 组装发送的消息列表
	 * @return
	 */
	private void packageMsgList(){
		jsonArray = new JSONArray();
		for(MessageContent msgContent:msglist){
			if(msgContent.getType()!=null&&msgContent.getType().equals(MessageConstants.type.EMAIL)){
				jsonArray.add(assembleMail.getMessageContent(msgContent));
			}else if(msgContent.getType()!=null&&msgContent.getType().equals(MessageConstants.type.MSG)){
				jsonArray.add(assembleMsg.getMessageContent(msgContent));
			}else if(msgContent.getType()!=null&&msgContent.getType().equals(MessageConstants.type.PUSH)){
				msgContent.setUserStatusUrl(userStatusUrl);
				jsonArray.add(assemblePush.getMessageContent(msgContent));
			}else if(msgContent.getType()!=null&&msgContent.getType().equals(MessageConstants.type.SMS)){
				jsonArray.add(assembleSms.getMessageContent(msgContent));
			}
		}
	}
	
	/**
	 * 实例化消息发送接口
	 */
	private void initAssemble(){
		if(assembleMail==null){
			assembleMail = new AssembleMailMessageContent();
		} 
		if(assembleSms==null){
			assembleSms = new AssembleSmsMessageContent();
		} 
		if(assembleMsg==null){
			assembleMsg = new AssembleMsgMessageContent();
		} 
		if(assemblePush==null){
			assemblePush = new AssemblePushMessageContent();
		} 
	}
	
	
	/**
	 * 发送消息
	 */
	public void sendMessage(){
		initAssemble();
		packageMsgList();
		if(jsonArray.size()>0){
			for(int i=0;i<jsonArray.size();i++){
				JSONObject tmp_msg = (JSONObject) jsonArray.get(i);
				//System.out.println(tmp_msg);
				Client client = new Client();
				WebResource rs = client.resource(pushUrl);
				String ms = rs.type(MediaType.APPLICATION_JSON_TYPE).entity(tmp_msg.toString()).post(String.class);
				System.out.println(ms);
			}
		}
	}


	public AssembleMessageContent getAssembleSmsx() {
		return assembleSmsx;
	}

	public void setAssembleSmsx(AssembleMessageContent assembleSmsx) {
		this.assembleSmsx = assembleSmsx;
	}

	public JSONArray getJsonArray() {
		return jsonArray;
	}

	public void setJsonArray(JSONArray jsonArray) {
		this.jsonArray = jsonArray;
	}

	public List<MessageContent> getMsglist() {
		return msglist;
	}


	public void setMsglist(List<MessageContent> msglist) {
		this.msglist = msglist;
	}

	public AssembleMessageContent getAssembleMail() {
		return assembleMail;
	}

	public void setAssembleMail(AssembleMessageContent assembleMail) {
		this.assembleMail = assembleMail;
	}

	public AssembleMessageContent getAssemblePush() {
		return assemblePush;
	}

	public void setAssemblePush(AssembleMessageContent assemblePush) {
		this.assemblePush = assemblePush;
	}

	public AssembleMessageContent getAssembleMsg() {
		return assembleMsg;
	}

	public void setAssembleMsg(AssembleMessageContent assembleMsg) {
		this.assembleMsg = assembleMsg;
	}

	public AssembleMessageContent getAssembleSms() {
		return assembleSms;
	}

	public void setAssembleSms(AssembleMessageContent assembleSms) {
		this.assembleSms = assembleSms;
	}

	public String getPushUrl() {
		return pushUrl;
	}

	public void setPushUrl(String pushUrl) {
		this.pushUrl = pushUrl;
	}

	public String getUserStatusUrl() {
		return userStatusUrl;
	}

	public void setUserStatusUrl(String userStatusUrl) {
		this.userStatusUrl = userStatusUrl;
	}
	
}
