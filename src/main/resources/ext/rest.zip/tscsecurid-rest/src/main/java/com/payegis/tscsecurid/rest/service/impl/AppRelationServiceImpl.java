package com.payegis.tscsecurid.rest.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.payegis.tscsecurid.common.data.entity.AppRelationBean;
import com.payegis.tscsecurid.common.mapper.AppRelationMapper;
import com.payegis.tscsecurid.common.mapper.BaseMapper;
import com.payegis.tscsecurid.common.service.BaseServiceImpl;
import com.payegis.tscsecurid.rest.service.AppRelationService;



@Service
public class AppRelationServiceImpl extends BaseServiceImpl implements AppRelationService {

	@Autowired
	private AppRelationMapper appRelationMapper;
	@Override
	public AppRelationBean getAppRelationStatus(String openId,String commonId) {
		// TODO Auto-generated method stub
		return appRelationMapper.selectByIds(openId,commonId);
	}
	
	public int create(AppRelationBean appRelationBean){
		return appRelationMapper.create(appRelationBean);
	}
	
	@Override
	public void updateAppRelation(AppRelationBean appRelationBean) {
		// TODO Auto-generated method stub
		appRelationMapper.updateAppRelation(appRelationBean);
		
	}

	@Override
	protected BaseMapper getMapper() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public AppRelationBean getAppRelationByOpenId(String openId) {
		// TODO Auto-generated method stub
		return appRelationMapper.selectByOpenId(openId);
		
	}

	

	

}
