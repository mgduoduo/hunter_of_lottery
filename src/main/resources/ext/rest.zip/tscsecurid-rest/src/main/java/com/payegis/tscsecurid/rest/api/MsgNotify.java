package com.payegis.tscsecurid.rest.api;

import com.payegis.tscsecurid.common.cache.CacheMgr;
import com.payegis.tscsecurid.common.data.entity.BindingInfo;
import com.payegis.tscsecurid.common.data.entity.BusinessSystem;
import com.payegis.tscsecurid.common.util.PropertyUtil;
import com.payegis.tscsecurid.rest.common.Config;
import com.payegis.tscsecurid.rest.common.Constrants;
import com.payegis.tscsecurid.rest.common.ReturnTypeEnum;
import com.payegis.tscsecurid.rest.service.AccountService;
import com.payegis.tscsecurid.rest.util.ApplicationUtil;
import com.payegis.tscsecurid.rest.util.Validator;
import net.sf.json.JSONObject;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import javax.websocket.*;
import javax.websocket.server.ServerEndpoint;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 账户接口
 *
 * @author user
 */


@Component
@ServerEndpoint(value = "/websocket")

public class MsgNotify {


    
    private static Logger logger = Logger.getLogger(MsgNotify.class);
    private int expTime = Integer.parseInt(PropertyUtil.getPropertyValue("tscsecurid-api.properties", "memcache.expTime"));
    public static  ConcurrentHashMap sessions = Config.getInstance().getMap();
    @OnOpen
    public void onOpen(Session session, EndpointConfig config) {
        session.setMaxIdleTimeout(60000);
        sessions.put(session.getId()+"_session",session);
        logger.info(session.getId() +" Client connected，and sessions count:"+sessions.size());
    }

    @OnClose
    public void onClose(Session session, CloseReason closeReason) {
        sessions.remove(session.getId()+"_session");
        logger.info(session.getId()+" Connection closed");
    }

    public static void sendMessage(String message, Session session) {
        try {
            session.getBasicRemote().sendText(message);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @OnMessage
    public void onMessage(String message, Session session) {
         AccountService accountService = (AccountService) ApplicationUtil.getBean("accountService");

        CacheMgr cacheMgr= (CacheMgr) ApplicationUtil.getBean("cacheMgr");
        JSONObject jo = new JSONObject();
        try {
            message = URLDecoder.decode(message, "utf-8");
            jo = JSONObject.fromObject(message);

            String systemNo = jo.optString(Constrants.SYSTEM_NO, "");
            String dcCode = jo.optString(Constrants.TX_ID, "");
            String systemAccount = jo.optString(Constrants.SYSTEM_ACCOUNT, "");

            Map<String, String> map = new HashMap<String, String>();
            map.put(Constrants.SYSTEM_NO, systemNo);
            map.put(Constrants.SYSTEM_ACCOUNT, systemAccount);
            map.put(Constrants.DC_CODE, dcCode);
            if (!Validator.validArgs(map)) {
                jo.put(Constrants.STATUS, ReturnTypeEnum.PARAMS_ERROR.getCode());
                jo.put(Constrants.MESSAGE, ReturnTypeEnum.PARAMS_ERROR.getDescription());
                sendMessage(jo.toString(), session);
                return;
            }
            if(dcCode.length() > 6)
                dcCode = String.valueOf(dcCode.hashCode());
            Object cache = cacheMgr.getMemcache(dcCode);
            BusinessSystem businessSystem = accountService.selectBySystemNo(systemNo);
            if (null == businessSystem) {
                jo.put(Constrants.STATUS, ReturnTypeEnum.BUSINESSNO_ERROR.getCode());
                jo.put(Constrants.MESSAGE, ReturnTypeEnum.BUSINESSNO_ERROR.getDescription());
                sendMessage(jo.toString(),session);
                return;
            }

            List<BindingInfo> bindInfos = accountService.selectBindInfosBySystemIdAndAccount(businessSystem.getSystemId(), systemAccount);
            if (null == bindInfos || bindInfos.size() == 0) {
                jo.put(Constrants.STATUS, ReturnTypeEnum.NO_BIND.getCode());
                jo.put(Constrants.MESSAGE, ReturnTypeEnum.NO_BIND.getDescription());
                sendMessage(jo.toString(),session);
                return;
            }
            cacheMgr.setMemcache(dcCode+"_session",session.getId());
            logger.info("session info-------------------------------"+session.getId()+"_session");
            if (null != cache) {
                String val = (String) cache;
                if (Constrants.WAIT.equals(val)) {
                    jo.put(Constrants.STATUS, ReturnTypeEnum.WAIT_CONFIRM.getCode());
                    jo.put(Constrants.MESSAGE, ReturnTypeEnum.WAIT_CONFIRM.getDescription());
                    sendMessage(jo.toString(), session);
                    return;
                }else if (Constrants.YES.equals(val)) {
                    jo.put(Constrants.STATUS, ReturnTypeEnum.PASS_VALIDATE.getCode());
                    jo.put(Constrants.MESSAGE, ReturnTypeEnum.PASS_VALIDATE.getDescription());
                    sendMessage(jo.toString(),session);
                    return;
                }
            } else {
                jo.put(Constrants.STATUS, ReturnTypeEnum.CONFIRM_ERROR.getCode());
                jo.put(Constrants.MESSAGE, ReturnTypeEnum.CONFIRM_ERROR.getDescription());
                sendMessage(jo.toString(),session);
                return;
            }

        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }

        jo.put(Constrants.STATUS, ReturnTypeEnum.NOT_PASS_VALIDATE.getCode());
        jo.put(Constrants.MESSAGE, ReturnTypeEnum.NOT_PASS_VALIDATE.getDescription());
        sendMessage(jo.toString(),session);

    }
}