package com.payegis.tscsecurid.rest.service.impl;

import com.payegis.tscsecurid.common.data.bo.AccountInfoDto;
import com.payegis.tscsecurid.common.data.entity.*;
import com.payegis.tscsecurid.common.mapper.*;
import com.payegis.tscsecurid.common.util.DateUtil;
import com.payegis.tscsecurid.rest.common.*;
import com.payegis.tscsecurid.rest.service.AccountService;
import com.payegis.tscsecurid.rest.util.ConfigFileUtil;
import com.payegis.tscsecurid.rest.util.WSUtil;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class AccountServiceImpl implements AccountService{
	
	@Autowired
	private BindingInfoMapper bindingInfoMapper;
	
	@Autowired
	private BindingLogMapper bindingLogMapper;
	
	@Autowired
	private BusinessSystemCallbackMapper businessSystemCallbackMapper;
	
	@Autowired
	private BusinessSystemMapper businessSystemMapper;
	
	@Autowired
	private DeviceTokenMapper deviceTokenMapper;
	
	@Autowired
	private SysLogMapper sysLogMapper;
	
	@Autowired
	private SysMsgMapper sysMsgMapper;
	
	@Autowired
	private EnterpriseInfoMapper enterpriceInfoMapper;
	
	@Autowired
	private SysEnterpriseConfigMapper sysEnterpriseConfigMapper;

    @Autowired
    private BindingInfoEnterpriseMapper bindingInfoEnterpriseMapper;

    @Autowired
    private BindingTerminalMapper bindingTerminalMapper;

	@Override
	public void saveBindInfo(BindingInfo bindingInfo, BindingLog bindingLog,BindingInfoEnterprise  infoEnterprise) {
		bindingInfoMapper.insert(bindingInfo);
		bindingLogMapper.insert(bindingLog);
		SysLog log = new SysLog();
		log.setBindingAccount(bindingInfo.getSystemAccount());
		log.setDeviceId(bindingInfo.getDeviceId());
		log.setEnterpriseId(bindingInfo.getEnterpriseId());
		log.setLogTime(DateUtil.getCurrentDateString());
		log.setLogType(LogTypeEnum.BINDING.getCode());
		log.setSystemId(bindingInfo.getSystemId());
		sysLogMapper.insert(log);
		Map<String,Object> requesMap = new HashMap<String, Object>();
		requesMap.put("deviceId", bindingInfo.getDeviceId());
		requesMap.put("systemNo", infoEnterprise.getSystemNo());
		requesMap.put("systemLogoUrl", infoEnterprise.getSystemLogoUrl());
		requesMap.put("systemAccount", infoEnterprise.getSystemAccount());
		requesMap.put("systemUrl",infoEnterprise.getSystemUrl() );
		requesMap.put("systemName",infoEnterprise.getSystemName() );
		requesMap.put("businessType",infoEnterprise.getBusinessType() );
		requesMap.put("enterpriseName",infoEnterprise.getEnterpriseName() );
		WSUtil.sendRequest(ConfigFileUtil.getTscSecuridCloudBindUrl(), requesMap);
	}

	@Override
	public List<AccountInfoDto> selectAccountInfo(String deviceId) {
		return bindingInfoMapper.selectAccountInfo(deviceId);
	}

	@Override
	public void deleteBindInfo(String deviceId,Integer systemId,String systemAccount,BindingInfoEnterprise infoEnterprise) {
		BindingInfo bindingInfo  = this.selectBindInfoByDidAndSysIdAndSysAccount(deviceId,systemId,systemAccount);
		if(null == bindingInfo){
			return;
		}
		BindingLog bindingLog = new BindingLog();
		bindingLog.setDeviceId(deviceId);
		bindingLog.setEnterpriseId(bindingInfo.getEnterpriseId());
		bindingLog.setSystemId(systemId);
		bindingLog.setSystemAccount(systemAccount);
		bindingLog.setBindingLogType(BindTypeEnum.UNBINDING.getCode());
		bindingLog.setUnbindingType(UnBindTypeEnum.SELF.getCode());
		bindingLogMapper.insert(bindingLog);
		bindingInfoMapper.deleteByPrimaryKey(bindingInfo.getBingdingId());
		SysLog log = new SysLog();
		log.setBindingAccount(bindingInfo.getSystemAccount());
		log.setDeviceId(bindingInfo.getDeviceId());
		log.setEnterpriseId(bindingInfo.getEnterpriseId());
		log.setLogTime(DateUtil.getCurrentDateString());
		log.setLogType(LogTypeEnum.UNBINDING.getCode());
		log.setSystemId(bindingInfo.getSystemId());
		sysLogMapper.insert(log);
		Map<String,Object> requesMap = new HashMap<String, Object>();
		requesMap.put("deviceId", infoEnterprise.getDeviceId());
		requesMap.put("systemNo", infoEnterprise.getSystemNo());
		requesMap.put("systemAccount", infoEnterprise.getSystemAccount());
		WSUtil.sendRequest(ConfigFileUtil.getTscSecuridCloudUnbindUrl(), requesMap);
	}

	@Override
	public List<AccountInfoDto> selectBydeviceIdAndSystemId(String deviceId,Integer systemId) {
		return bindingInfoMapper.selectByDeviceIdAndSystemId(deviceId, systemId);
	}

	@Override
	public BusinessSystemCallback selectBySystemIdAndType(Integer systemId,String callbackType) {
		return businessSystemCallbackMapper.selectBySystemIdAndType(systemId, callbackType);
	}

	@Override
	public BusinessSystem selectBySystemNo(String systemNo) {
		return businessSystemMapper.selectBySystemNo(systemNo);
	}

	@Override
	public void updateOnlineStatus(String deviceId, Integer systemId, String systemAccount,String code,String systemNo) {
		BindingInfo bindingInfo  = bindingInfoMapper.selectByDeviceIdAndSystemIdAndAccount(deviceId,systemId,systemAccount);
		if(null != bindingInfo){
			bindingInfo.setOnlineStatus(code);
			bindingInfoMapper.updateByPrimaryKeySelective(bindingInfo);
		}
		SysLog log = new SysLog();
		log.setBindingAccount(bindingInfo.getSystemAccount());
		log.setDeviceId(bindingInfo.getDeviceId());
		log.setEnterpriseId(bindingInfo.getEnterpriseId());
		log.setLogTime(DateUtil.getCurrentDateString());
		if(OnlineStatusEnum.ONLINE.getCode().equals(code)){
			log.setLogType(LogTypeEnum.LOGIN.getCode());
			SysMsg msg = new SysMsg();
			msg.setEnterpriseId(bindingInfo.getEnterpriseId());
			msg.setDeviceId(bindingInfo.getDeviceId());
			msg.setMsgType(MessageTypeEnum.SYSTEM.getCode());
			msg.setSendTime(DateUtil.getCurrentDateString());
			msg.setIsSend("Y");
			msg.setIsDelete("N");
			msg.setIsView("N");
			msg.setMsgContent("您的"+businessSystemMapper.selectByPrimaryKey(bindingInfo.getSystemId()).getSystemName()+"账号:"+bindingInfo.getSystemAccount()+",于"+DateUtil.getCurrentDateString()+"成功登录");
			msg.setMsgTopicId(0);
			sysMsgMapper.insert(msg);
            updateCloudOnlineStatus(systemNo,systemAccount,code);
		}else if(OnlineStatusEnum.ESCAPE.getCode().equals(code)){
			log.setLogType(LogTypeEnum.OPEN.getCode());
			SysMsg msg = new SysMsg();
			msg.setEnterpriseId(bindingInfo.getEnterpriseId());
			msg.setDeviceId(bindingInfo.getDeviceId());
			msg.setMsgType(MessageTypeEnum.SYSTEM.getCode());
			msg.setSendTime(DateUtil.getCurrentDateString());
			msg.setIsSend("Y");
			msg.setIsDelete("N");
			msg.setIsView("N");
			msg.setMsgContent("您的"+businessSystemMapper.selectByPrimaryKey(bindingInfo.getSystemId()).getSystemName()+"账号:"+bindingInfo.getSystemAccount()+",于"+DateUtil.getCurrentDateString()+"成功开门");
			msg.setMsgTopicId(0);
			sysMsgMapper.insert(msg);
		}else{
			log.setLogType(LogTypeEnum.LOGOUT.getCode());
			SysMsg msg = new SysMsg();
			msg.setEnterpriseId(bindingInfo.getEnterpriseId());
			msg.setDeviceId(bindingInfo.getDeviceId());
			msg.setMsgType(MessageTypeEnum.SYSTEM.getCode());
			msg.setSendTime(DateUtil.getCurrentDateString());
			msg.setIsSend("Y");
			msg.setIsDelete("N");
			msg.setIsView("N");
			msg.setMsgContent("您的"+businessSystemMapper.selectByPrimaryKey(bindingInfo.getSystemId()).getSystemName()+"账号:"+bindingInfo.getSystemAccount()+",于"+DateUtil.getCurrentDateString()+"成功登出");
			msg.setMsgTopicId(0);
			sysMsgMapper.insert(msg);
            updateCloudOnlineStatus(systemNo,systemAccount,code);
		}

		log.setSystemId(bindingInfo.getSystemId());
		sysLogMapper.insert(log);
	}

    @Override
    public void updateOnlineStatusWithNoLog(String deviceId, Integer systemId, String systemAccount, String code, String systemNo) {
        BindingInfo bindingInfo  = bindingInfoMapper.selectByDeviceIdAndSystemIdAndAccount(deviceId,systemId,systemAccount);
        if(null != bindingInfo){
            bindingInfo.setOnlineStatus(code);
            bindingInfoMapper.updateByPrimaryKeySelective(bindingInfo);
        }
        SysLog log = new SysLog();
        log.setBindingAccount(bindingInfo.getSystemAccount());
        log.setDeviceId(bindingInfo.getDeviceId());
        log.setEnterpriseId(bindingInfo.getEnterpriseId());
        log.setLogTime(DateUtil.getCurrentDateString());
        if(OnlineStatusEnum.ONLINE.getCode().equals(code)){
            updateCloudOnlineStatus(systemNo,systemAccount,code);
        }else{
            updateCloudOnlineStatus(systemNo,systemAccount,code);
        }
    }

    @Override
	public BindingInfo selectBindInfoByDidAndSysIdAndSysAccount(String deviceId,Integer systemId,String systemAccount){
		return  bindingInfoMapper.selectByDeviceIdAndSystemIdAndAccount(deviceId,systemId,systemAccount);
	}
	
	@Override
	public DeviceToken selectTokenByDeviceId(String deviceId) {
		return deviceTokenMapper.selectByPrimaryKey(deviceId);
	}

	@Override
	public void saveDeviceToken(DeviceToken deviceToken) {
		deviceTokenMapper.insert(deviceToken);
	}

	//unused
	/*@Override
	public BindingInfo selectBindInfoBySystemIdAndAccount(Integer systemId,
			String systemAccount) {
		return bindingInfoMapper.selectBySystemIdAndAccount(systemId, systemAccount);
	}*/

	@Override
	public void updateDeviceToken(DeviceToken deviceToken) {
		deviceTokenMapper.updateByPrimaryKey(deviceToken);
	}

	@Override
	public BindingInfo selectBindInfoBySystemIdAndDeviceId(Integer systemId,String deviceId) {
		return bindingInfoMapper.selectBySystemIdAndDeviceId(systemId, deviceId);
	}

	@Override
	public EnterpriseInfo selectEnterpriceById(Integer enterpriceId) {
		return enterpriceInfoMapper.selectByPrimaryKey(enterpriceId);
	}

	@Override
	public List<BindingInfo> selectBindInfosBySystemIdAndAccount(
			Integer systemId, String systemAccount) {
		return bindingInfoMapper.selectInfosBySystemIdAndAccount(systemId, systemAccount);
	}
	
	

	@Override
	public SysEnterpriseConfig selectSysConfigByEnterId(Integer enterId) {
		return sysEnterpriseConfigMapper.getSysEnterpriseByUser(enterId);
	}

    @Override
    public List<BindingInfoEnterprise> selectBySystemNoAndSystemAccount(String systemNo, String systemAccount) {
        int systemId = 0;
        BusinessSystem bs = businessSystemMapper.selectBySystemNo(systemNo);
        if(null != bs)
            systemId = bs.getSystemId();
        //System.out.println(systemId);
        return bindingInfoEnterpriseMapper.selectBySystemNoAndSystemAccount(systemId,systemAccount, systemNo);
    }
    @Override
    public int updateBindDeviceAlias(BindingTerminal record){
        return bindingTerminalMapper.updateByPrimaryKeySelective(record);
    }

    public void updateCloudOnlineStatus(String systemNo,String systemAccount,String status){
        Map<String,Object> requesMap = new HashMap<String, Object>();
        requesMap.put("systemNo", systemNo);
        requesMap.put("systemAccount", systemAccount);
        requesMap.put("onlineStatus", status);
        WSUtil.sendRequest(ConfigFileUtil.getUpdateOnlineStatusUrl(), requesMap);
    }

	@Override
	public int updateDeviceNoDefault(Integer systemId, String systemAccount) {
		// TODO Auto-generated method stub
		return bindingInfoMapper.updateDeviceNoDefault(systemId, systemAccount);
		
	}

	@Override
	public int updateDeviceDefault(String deviceId, Integer systemId,
			String systemAccount) {
		// TODO Auto-generated method stub
		return bindingInfoMapper.updateDeviceDefault(deviceId,systemId, systemAccount);
		
	}
}
