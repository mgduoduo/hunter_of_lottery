package com.payegis.tscsecurid.rest.common;

public enum ReturnTypeEnum {

    BIND_SUCCESS(0,"绑定成功"),

    UNBIND_SUCCESS(0,"解绑成功"),

    UPDATE_SUCCESS(0,"修改成功"),

    DEVICE_HAS_BOUND_THE_ACCOUNT(0, "该账号已与当前设备绑定"),

    PASS_VALIDATE(0, "校验成功"),

    QUERY_SUCCESS(0, "查询成功"),

    CHECKED(0, "确认成功"),

    CANSEL_SUCCESS(0, "拒绝成功"),

    CONFIRMING(0, "正在等待确认，请稍等..."),

    NO_INSTRUCTION_FOUND(1,"系统没有此指令"),

    NO_DEVICE_PWD_FOUND(1,"没有设置手势密码"),

    ACCOUNT_IS_NOT_BOUND_BY_DEVICE(1, "该账号没有被绑定"),

    NOT_PASS_VALIDATE(1, "校验失败"),

    UPDATE_FAIL(1,"修改失败"),

    QUERY_FAIL(1,"查询失败"),

    PARAMS_ERROR(-1, "参数异常"),

    AUTH_ERROR(10000, "非法调用"),

    CONFIRM_ERROR(10001, "校验失败或者已过期"),

    REPEAT_CHECK(10002, "请勿重复校验"),

    WAIT_CONFIRM(10003, "二次认证结果等待中..."),

    CALLING(10004, "正在进行电话回拨"),

    ANSWERED(10005, "电话回拨已确认"),

    PUSHED(10006, "推送消息已发出"),

    PUSH_FAILED(10007, "推送失败"),//需要提示用户手动拉取确认消息

    TIME_OUT(10008, "认证超时"),

    FRAUD(10009, "检测为欺诈请求"),

    BYPASS(10010, "跳过认证"),

    LOCKED_OUT(10011, "账号已锁定"),

    OTP_HAS_BEEN_SENT(10012, "验证码已发送"),

    ALLOW_FAILED(10013,"确认失败"),

    CANSEL_FAIL(10014, "拒绝失败"),

    HAS_BEEN_CONFIRMED(10015, "已经被确认过"),

    HAS_BEEN_CANCELLED(10016, "已经被拒绝"),

    HAS_EXPIRED(10017, "已过期或不合法"),


    AUTH_IS_REQUIRED(11001, "需要二次认证"),

    AUTH_IS_IGNORED(11002, "不需要二次认证"),//业务系统可认为HUE认证通过，后台把HUE开关关闭了

    AUTH_IS_DENIED(11003, "当前业务系统(或用户)不可进行认证请求"),

    AUTH_IS_NOT_ENROLLED(11004, "当前业务系统账户尚未绑定设备，需要先绑定设备再发起认证请求"),


    NO_BIND(20001, "您的账号尚未与当前设备绑定，请绑定后重试"),

    OTHER_HAVE_BIND(20002, "该账号已被其他设备绑定，请解绑后重试"),

    ACCOUNT_NEVER_BIND(20003, "当前账号尚未开通HUE服务"),

    BUSINESSNO_ERROR(20004, "当前业务系统编号不合法，请与企业管理员联系"),

    HAVE_BIND(20005, "您的设备已绑定该账号，请勿重复操作"),

    NO_CALLBACK(20006, "当前业务系统回调接口缺失，请与企业管理员联系"),

    ONE_BIND(20007, "当前业务系统只允许绑定一个账号，请勿绑定多个账号"),

    GET_SERVICE_SPACIFICATION_ERROR(20008, "获取服务规格信息失败"),

    NOT_FIND_SYSTEM_CONFIGURATION(20009, "未找到该业务系统的预认证配置"),

    ACCOUNT_IS_NOT_BOUND_BY_THE_DEVICE(30002, "该账号已与其他设备绑定，尚未与当前设备绑定");


    private int code;

    private String description;

    private ReturnTypeEnum(int code, String description) {
        this.code = code;
        this.description = description;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public static String getDescription(String code) {
        for (ReturnTypeEnum type : ReturnTypeEnum.values()) {
            if (code.equals(type.getCode())) {
                return type.getDescription();
            }
        }
        return null;
    }


}
