package com.payegis.tscsecurid.rest.message;


/**
 * 消息平台变量
 * @author xxmfypp
 *
 */
public interface MessageConstants {

	
	interface type{//发送类型
		/**
		 * 邮件
		 */
		public String EMAIL="mail";

		/**
		 * 短信
		 */
		public String SMS="sms";

		/**
		 * 推送
		 */
		public String PUSH="push";

		/**
		 * 消息
		 */
		public String MSG="msg";
		

	}



	interface date{//日期

		/**
		 * YYYY年MM月DD日HH_MM_SS
		 */
		public String YYYYMMDDHH_MM_SS = "yyyy年MM月dd日 HH:mm:ss";
		
		/**
		 * yyyy年MM月dd日
		 */
		public String YYYYMMDD = "yyyy年MM月dd日";
	}


}
