package com.payegis.tscsecurid.rest.message;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import net.sf.json.JSONObject;

/**
 * 组装PUSH消息通用类
 * @author xuman.xu
 *
 */
public class AssemblePushMessageContent implements AssembleMessageContent{

	@Override
	public JSONObject getMessageContent(MessageContent messageContent) {
		// TODO Auto-generated method stub
		if(messageContent.getDeviceId().startsWith("2")){
			JSONObject msg = new JSONObject();
			JSONObject json = new JSONObject();
			msg.put("type", messageContent.getType());
			msg.put("from", messageContent.getFrom());
			msg.put("platform", "ios");
			msg.put("to",messageContent.getTo());
			json.put("alert",  messageContent.getBody());
			json.put("badge", "0");
			json.put("sound", "default");
			if(messageContent.getCustomforPush()!=null){
				json.put("c_msg", messageContent.getCustomforPush());
			}else{
				json.put("c_msg", "");
			}
			json.put("appcode", messageContent.getPartnerCode()+"$"+messageContent.getAppId()+"$"+messageContent.getClientName());
			msg.put("body", json);
			return msg;
			
		}else if(messageContent.getDeviceId().startsWith("3")){
			JSONObject msg = new JSONObject();
			JSONObject json = new JSONObject();
			msg.put("type", "push");
			msg.put("from", "");
			msg.put("platform", "android");
			msg.put("to",messageContent.getTo());
			json.put("broadcast", "N");
			json.put("title", messageContent.getTitle());
			json.put("message", messageContent.getBody());
			json.put("uri", "");
			if(messageContent.getCustomforPush()!=null){
				json.putAll(toMap(messageContent.getCustomforPush()));
			}
			json.put("appcode",messageContent.getPartnerCode()+"$"+messageContent.getAppId());
			msg.put("body", json);
			return msg;
		}
		return null;
	}

	private  Map<String, String> toMap(JSONObject jsonObject){
		Map<String, String> result = new HashMap<String, String>();
		Iterator<String> iterator = jsonObject.keys();
		String key = null;
		String value = null;
		while (iterator.hasNext()){
			key = iterator.next();
			value = jsonObject.getString(key);
			result.put(key, value);
		}
		return result;
	} 

}
