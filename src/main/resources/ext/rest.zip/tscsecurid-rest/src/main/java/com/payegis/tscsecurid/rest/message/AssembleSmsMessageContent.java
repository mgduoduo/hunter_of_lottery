package com.payegis.tscsecurid.rest.message;

import net.sf.json.JSONObject;

/**
 * 组装短信消息通用类
 * @author xuman.xu
 *
 */
public class AssembleSmsMessageContent implements AssembleMessageContent{

	@Override
	public JSONObject getMessageContent(MessageContent messageContent) {
		// TODO Auto-generated method stub
		JSONObject msg = new JSONObject();
		msg.put("type", messageContent.getType());
		msg.put("from", messageContent.getFrom());
		msg.put("body", messageContent.getBody());
		msg.put("to", messageContent.getTo());
		return msg;
	}
	
	

}
