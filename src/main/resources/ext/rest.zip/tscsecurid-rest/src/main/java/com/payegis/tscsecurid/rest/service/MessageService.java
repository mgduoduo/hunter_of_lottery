package com.payegis.tscsecurid.rest.service;

import com.payegis.tscsecurid.common.data.entity.SysMsg;
import com.payegis.tscsecurid.common.data.entity.VersionManage;

import java.util.List;

public interface MessageService {
	List<SysMsg> selectByDeviceId(String deviceId, String rows, String page);
	void deleteById(String msgId);
	void updateById(String msgId);
	Integer isAllRead(String deviceId);
	VersionManage selectVersionByVersionType(String versionType);
}
