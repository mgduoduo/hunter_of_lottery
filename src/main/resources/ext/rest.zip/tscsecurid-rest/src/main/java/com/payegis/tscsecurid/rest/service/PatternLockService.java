package com.payegis.tscsecurid.rest.service;

import com.payegis.tscsecurid.common.data.entity.BindingTerminal;

import java.util.Map;

public interface PatternLockService {
	void saveLock(BindingTerminal bindingTerminal);
	BindingTerminal findById(String deviceId);
	BindingTerminal findBindingTerminal(Map<String, Object> param);
	void updateLock(BindingTerminal bindingTerminal);
	void deleteById(String deviceId);
}
