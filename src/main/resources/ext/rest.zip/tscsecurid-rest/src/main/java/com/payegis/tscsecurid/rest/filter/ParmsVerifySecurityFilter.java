package com.payegis.tscsecurid.rest.filter;

import com.payegis.tscsecurid.common.cache.CacheMgr;
import com.payegis.tscsecurid.common.util.EncryUtil;
import com.payegis.tscsecurid.common.util.ToolUtil;
import com.payegis.tscsecurid.rest.common.Config;
import com.payegis.tscsecurid.rest.common.Constrants;
import com.payegis.tscsecurid.rest.common.ReturnTypeEnum;
import com.payegis.tscsecurid.rest.util.*;
import com.sun.jersey.core.util.MultivaluedMapImpl;
import net.sf.json.JSONObject;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.*;

/**
 * Created by zzg on 2015/7/22.
 */
public class ParmsVerifySecurityFilter implements Filter {
    private static Logger logger = Logger.getLogger(ParmsVerifySecurityFilter.class);
    private List<String> apiList = null;

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
    }

    private boolean apiNeedAuth(String api) {
        if(ToolUtil.isEmpty(apiList))
            apiList = Config.getInstance().getAuthUrlList();
        if (ToolUtil.isNotEmpty(apiList))
            if (apiList.contains(api)) {
                return true;
            }
        return false;

    }

    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        ((HttpServletResponse) response).setHeader("Access-Control-Allow-Origin", "*");
        HttpServletRequest httpRequest = (HttpServletRequest) request;
        showParams(httpRequest);
        String url = httpRequest.getRequestURI();
        String fullUrl = httpRequest.getScheme() + "://" + httpRequest.getServerName() + ":" + httpRequest.getServerPort() + url;
        String apiName = null;
        if (!StringUtils.isBlank(url)) {
            String[] parten = url.split("\\/");
            if (parten != null && parten.length > 0) {
                apiName = parten[parten.length - 1];
            }
        }
        String requestTimeStamp = null;
        String clientSignature = null;

        boolean needSign = apiNeedAuth(apiName);
        boolean isWeb = false;
        List<String> keyFilter = new ArrayList<String>();
        if (!needSign) {
            chain.doFilter(request, response);
            return;
        }
        requestTimeStamp = httpRequest.getHeader(HmacAttributes.X_HMAC_AUTH_DATE);
        clientSignature = httpRequest.getHeader(HmacAttributes.X_HMAC_AUTH_SIGNATURE);
        if (StringUtils.isEmpty(clientSignature))
            isWeb = true;
        if (isWeb) {
            requestTimeStamp = httpRequest.getParameter(HmacAttributes.X_HMAC_AUTH_DATE);
            clientSignature = httpRequest.getParameter(HmacAttributes.X_HMAC_AUTH_SIGNATURE);
            if(StringUtils.isEmpty(clientSignature)){
                response.setContentType("application/json;charset=UTF-8");
                String message = StringUtil.jsonExceptionMsg(ReturnTypeEnum.AUTH_ERROR.getCode(), ReturnTypeEnum.AUTH_ERROR.getDescription());
                response.getWriter().write(message);
                return;
            }
            keyFilter.add("_");
            keyFilter.add("jsoncallback");
            keyFilter.add("x-hmac-auth-date");
            keyFilter.add("x-hmac-auth-signature");
        }
        WrappedRequest wrappedRequest = WrappedRequest.wrap(httpRequest);
        Enumeration s = httpRequest.getHeaderNames();
        String kvStr = CustomSigningUtil.getKvStringWithFilter(wrappedRequest, keyFilter, requestTimeStamp);
        String appId = "";
        String[] split = clientSignature.split(":");
        appId = split[0];
        if (StringUtils.isEmpty(appId) || StringUtils.isEmpty(clientSignature)) {
            response.setContentType("application/json;charset=UTF-8");
            String message = StringUtil.jsonExceptionMsg(ReturnTypeEnum.AUTH_ERROR.getCode(), ReturnTypeEnum.AUTH_ERROR.getDescription());
            response.getWriter().write(message);
            return;
        }
        if (appId != null && appId.equals("mobilePass")) {
            appId = "101";
        } else if (appId != null && appId.equals("dcsdk")) {
            appId = "102";
        } else if (appId != null && appId.equals("001")) {
            appId = "1";
        }
        //获取cache中的服务规格详情
        CacheMgr cacheMgr = (CacheMgr) ApplicationUtil.getBean("cacheMgr");
        Object mgrResult = cacheMgr.getMemcache("cloud_" + Constrants.TIME_SPACE_CODE + "_" + appId);
        if (mgrResult == null || StringUtils.isEmpty(String.valueOf(mgrResult))) {
            logger.info("获取服务规格信息失败");
            response.setContentType("application/json;charset=UTF-8");
            String message = StringUtil.jsonExceptionMsg(ReturnTypeEnum.AUTH_ERROR.getCode(), ReturnTypeEnum.AUTH_ERROR.getDescription());
            response.getWriter().write(message);
            return;
        }

        JSONObject json = JSONObject.fromObject(mgrResult);
        String appKey = json.optString("appKey", "");
        Boolean isTrue = EncryUtil.checkSign(clientSignature, appId, appKey, kvStr);
        if (isTrue) {
            logger.info("pass signiture");
            chain.doFilter(request, response);
        } else {
            logger.info("clientSignature : " + clientSignature);
            logger.info("requestTimeStamp : " + requestTimeStamp);
            logger.info("kvStr : " + kvStr);
            logger.info("not pass signiture");
            response.setContentType("application/json;charset=UTF-8");
            String message = StringUtil.jsonExceptionMsg(ReturnTypeEnum.AUTH_ERROR.getCode(), ReturnTypeEnum.AUTH_ERROR.getDescription());
            response.getWriter().write(message);
            return;
        }
    }

    @Override
    public void destroy() {
    }

    private static MultivaluedMapImpl constructWebserviceParams(Map<String, Object> paramMap) {
        if (paramMap == null || paramMap.isEmpty()) {
            return null;
        }

        MultivaluedMapImpl params = new MultivaluedMapImpl();

        for (Iterator<String> it = paramMap.keySet().iterator(); it.hasNext(); ) {
            String key = it.next();
            params.add(key, paramMap.get(key));
        }

        return params;

    }

    private void showParams(HttpServletRequest request) {
        Enumeration paramNames = request.getParameterNames();
        while (paramNames.hasMoreElements()) {
            String paramName = (String) paramNames.nextElement();
            //System.out.println("---------------" + paramName + "---------------");
        }

    }
}
