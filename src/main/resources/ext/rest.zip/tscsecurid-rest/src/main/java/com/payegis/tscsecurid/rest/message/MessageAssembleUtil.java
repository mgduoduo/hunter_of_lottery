package com.payegis.tscsecurid.rest.message;

import com.payegis.tscsecurid.rest.common.Constrants;
import com.payegis.tscsecurid.rest.util.StringUtil;
import org.apache.commons.lang.StringUtils;

import java.util.ArrayList;
import java.util.List;

public class MessageAssembleUtil {
	
	public static MessageContent assembleSMS(AppUser appUser,MsgBean msgBean){
		if(!StringUtils.isEmpty(appUser.getPhoneNum())){
			MessageContent mc = new MessageContent();
			mc.setSmsContent(MessageConstants.type.SMS, "", msgBean.getContent(), appUser.getPhoneNum());
			return mc;
		}else{
			return null;
		}
	}


	public static MessageContent assembleMAIL(AppUser appUser,MsgBean msgBean){
		if(!StringUtils.isEmpty(appUser.getEmail())){
			MessageContent mc = new MessageContent();
			mc.setMailContent(MessageConstants.type.EMAIL, "", msgBean.getTitle(), msgBean.getContent(), appUser.getEmail());
			return mc;
		}else{
			return null;
		}
	}

	public static MessageContent assemblePUSH(AppUser appUser,MsgBean msgBean){
		if(!StringUtils.isEmpty(appUser.getDeviceId())&&!StringUtils.isEmpty(appUser.getDeviceToken())&&!StringUtils.isEmpty(appUser.getPartnerCode())&&!StringUtils.isEmpty(appUser.getAppId())&&!StringUtils.isEmpty(appUser.getClientName())){
			MessageContent mc = new MessageContent();
			mc.setPushContent(MessageConstants.type.PUSH, "", msgBean.getContent(), appUser.getDeviceToken(), appUser.getPartnerCode(), appUser.getAppId(), appUser.getClientName(), null, appUser.getDeviceId());
			return mc;
		}else{
			return null;
		}

	}

	public static  MessageContent assembleMSG(AppUser appUser,MsgBean msgBean){
		
		if(!StringUtils.isEmpty(appUser.getLoginName())){
			MessageContent mc = new MessageContent();
			mc.setMsgContent(MessageConstants.type.MSG, "", msgBean.getTitle(), msgBean.getContent(), appUser.getLoginName(), appUser.getPartnerCode(), appUser.getAppId());
			return mc;
		}else{
			return null;
		}
	}
	
	public static String sendDefaultMessage(String[] sendTypes,AppUser appUser,MsgBean msgBean,String pushUrl){

        try {
			List<MessageContent> list = new ArrayList<MessageContent>();
			for(String sendtype:sendTypes){
				if(sendtype.equals(MessageConstants.type.SMS)){
					MessageContent mc=assembleSMS(appUser,msgBean);
					if(mc!=null){
						list.add(mc);
					}
				}else if(sendtype.equals(MessageConstants.type.EMAIL)){
					MessageContent mc=assembleMAIL(appUser,msgBean);
					if(mc!=null){
						list.add(mc);
					}
				}else if(sendtype.equals(MessageConstants.type.PUSH)){
					MessageContent mc=assemblePUSH(appUser,msgBean);
					if(mc!=null){
						list.add(mc);
					}
				}else if(sendtype.equals(MessageConstants.type.MSG)){
					MessageContent mc=assembleMSG(appUser,msgBean);
					if(mc!=null){
						list.add(mc);
					}
				}
			}
			MessageSendFactory msf = new MessageSendFactory(list,pushUrl);
			msf.sendMessage();
		} catch (Exception e) {
			e.printStackTrace();
            return StringUtil.jsonSuccessMsg(Constrants.FAIL);
		}
        return StringUtil.jsonSuccessMsg(Constrants.SUCCESS);
	}

}
