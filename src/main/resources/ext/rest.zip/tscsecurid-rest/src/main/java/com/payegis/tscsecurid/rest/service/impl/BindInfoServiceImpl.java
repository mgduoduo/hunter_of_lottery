package com.payegis.tscsecurid.rest.service.impl;

import com.payegis.tscsecurid.common.data.bo.BindInfoDto;
import com.payegis.tscsecurid.common.data.entity.BindingInfoEnterprise;
import com.payegis.tscsecurid.common.data.entity.BindingLogEnterprise;
import com.payegis.tscsecurid.common.mapper.BindingInfoEnterpriseMapper;
import com.payegis.tscsecurid.common.mapper.BindingLogEnterpriseMapper;
import com.payegis.tscsecurid.common.mapper.BusinessSystemMapper;
import com.payegis.tscsecurid.rest.service.BindInfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class BindInfoServiceImpl implements BindInfoService {
	
	@Autowired
	private BindingInfoEnterpriseMapper mapper;
	
	@Autowired
	private BindingLogEnterpriseMapper logMapper;

    @Autowired
    private BusinessSystemMapper businessSystemMapper;

	@Override
	public void saveBindInfo(BindingInfoEnterprise bindInfo,BindingLogEnterprise logInfo) {
		mapper.insert(bindInfo);
		logMapper.insert(logInfo);
	}

	@Override
	public void updateBindInfo(BindingInfoEnterprise bindInfo) {
		mapper.updateByPrimaryKey(bindInfo);
	}

	@Override
	public void deleteBindInfo(Integer bindId,BindingLogEnterprise logInfo) {
		mapper.deleteByPrimaryKey(bindId);
		logMapper.insert(logInfo);
	}

	@Override
	public List<BindInfoDto> selectByDeviceId(String deviceId) {
		return mapper.selectByDeviceId(deviceId);
	}

	@Override
	public BindingInfoEnterprise selectById(Integer bindId) {
		return mapper.selectByPrimaryKey(bindId);
	}

	@Override
	public List<BindInfoDto> selectBindInfoList(Map<String, Object> param) {
		return mapper.selectBindInfoList(param);
	}

	@Override
	public BindingInfoEnterprise selectByDeviceIdAndSystemNoAndSystemAccount(
			String deviceId, String systemNo, String systemAccount) {
		return mapper.selectByDeviceIdAndSystemNoAndSystemAccount(deviceId, systemNo, systemAccount);
	}

    @Override
    public void updateBindInfoOlineStatus(BindingInfoEnterprise record) {
        mapper.updateBindInfoOlineStatus(record);
    }


    @Override
    public List<BindingInfoEnterprise> selectBySystemAccountAndSystemNo(String systemAccount, String systemNo) {
        return mapper.selectBySystemNoAndSystemAccountFromCloud(systemAccount,systemNo);
    }
}
