package com.payegis.tscsecurid.rest.common;

public enum UnBindTypeEnum {
	
	SELF("self","扫码解绑"),
	
	SERVICE("service", "人工客服解绑");
	
	private String code;

	private String description;

	private UnBindTypeEnum(String code, String description) {
		this.code = code;
		this.description = description;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public static String getDescription(String code) {
		for (UnBindTypeEnum type : UnBindTypeEnum.values()) {
			if (code.equals(type.getCode())) {
				return type.getDescription();
			}
		}
		return null;
	}


}
