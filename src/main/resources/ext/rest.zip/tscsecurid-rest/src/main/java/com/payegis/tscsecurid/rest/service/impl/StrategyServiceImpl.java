package com.payegis.tscsecurid.rest.service.impl;

import com.payegis.tscsecurid.common.data.entity.StrategyConfig;
import com.payegis.tscsecurid.common.mapper.StrategyConfigMapper;
import com.payegis.tscsecurid.rest.service.StrategyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Created by wbl
 */
@Service
public class StrategyServiceImpl implements StrategyService {

    @Autowired
    private StrategyConfigMapper strategyManageMapper;

    @Override
    public int save(StrategyConfig param) {
        
        return strategyManageMapper.insert(param);
        
    }

    @Override
    public int update(StrategyConfig param) {
        
        return strategyManageMapper.update(param);
    }

	@Override
	public StrategyConfig findObj() {
		return strategyManageMapper.select();
	}

    @Override
    public StrategyConfig findObjBySystemNo(String systemNo) {
        return strategyManageMapper.findObjBySystemNo(systemNo);
    }
}
