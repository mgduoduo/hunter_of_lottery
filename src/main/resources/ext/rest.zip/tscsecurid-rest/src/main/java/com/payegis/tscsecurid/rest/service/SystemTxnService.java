package com.payegis.tscsecurid.rest.service;


import com.payegis.tscsecurid.common.data.bo.TxnLogBo;
import com.payegis.tscsecurid.common.data.entity.TxnLog;
import com.payegis.tscsecurid.common.data.entity.TxnStatus;

public interface SystemTxnService {
    void saveTxnLog(TxnLog txnLog);
    void saveTxnStatus(TxnStatus txnStatus);

    TxnLog findLatestTxnLog(TxnLogBo txnLogBo);

    int updateTxnLog(TxnLog txnLog);
    int updateTxnLogStatus(String logId, String statusCode);
}
