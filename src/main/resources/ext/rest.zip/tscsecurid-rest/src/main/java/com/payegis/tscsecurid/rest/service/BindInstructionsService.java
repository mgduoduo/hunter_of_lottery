package com.payegis.tscsecurid.rest.service;

import com.payegis.tscsecurid.common.data.entity.BindingInstructions;

import java.util.List;

public interface BindInstructionsService {
	List<BindingInstructions> selectByDeviceId(String deviceId);
	BindingInstructions selectById(Integer id);
	void updateByRecord(BindingInstructions record);
	void saveByRecord(BindingInstructions record);
	void updateByRecords(List<BindingInstructions> records);
}
