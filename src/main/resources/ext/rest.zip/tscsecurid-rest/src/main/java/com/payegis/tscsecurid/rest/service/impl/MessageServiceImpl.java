package com.payegis.tscsecurid.rest.service.impl;

import com.payegis.tscsecurid.common.data.bo.SysMsgQueryBo;
import com.payegis.tscsecurid.common.data.entity.SysMsg;
import com.payegis.tscsecurid.common.data.entity.VersionManage;
import com.payegis.tscsecurid.common.mapper.SysMsgMapper;
import com.payegis.tscsecurid.common.mapper.VersionManageMapper;
import com.payegis.tscsecurid.rest.service.MessageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MessageServiceImpl implements MessageService{

	@Autowired 
	private SysMsgMapper sysMsgMapper;
	
	@Autowired
	private VersionManageMapper versionMapper;
	
	@Override
	public List<SysMsg> selectByDeviceId(String deviceId,String rows,String page) {
		SysMsgQueryBo sysMsgQueryBo = new SysMsgQueryBo();
		sysMsgQueryBo.setDeviceId(deviceId);
		sysMsgQueryBo.setRows(Integer.parseInt(rows));
		sysMsgQueryBo.setPage(Integer.parseInt(page));
		return sysMsgMapper.selectByDeviceId(sysMsgQueryBo);
	}

	@Override
	public void deleteById(String msgId) {
		sysMsgMapper.deleteByPrimaryKey(Integer.parseInt(msgId));
	}

	@Override
	public void updateById(String msgId) {
		SysMsg msg = sysMsgMapper.selectByPrimaryKey(Integer.parseInt(msgId));
		msg.setIsView("Y");
		sysMsgMapper.updateByPrimaryKeySelective(msg);
	}

	@Override
	public Integer isAllRead(String deviceId) {
		return sysMsgMapper.isAllRead(deviceId);
	}

	@Override
	public VersionManage selectVersionByVersionType(String versionType) {
		return versionMapper.selectByVersionType(versionType);
	}
	
	
	
}
