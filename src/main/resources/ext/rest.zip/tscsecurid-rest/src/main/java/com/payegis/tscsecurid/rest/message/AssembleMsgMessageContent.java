package com.payegis.tscsecurid.rest.message;

import net.sf.json.JSONObject;

/**
 * 组装Msg消息通用类
 * @author xuman.xu
 *
 */
public class AssembleMsgMessageContent implements AssembleMessageContent {

	@Override
	public JSONObject getMessageContent(MessageContent messageContent) {
		// TODO Auto-generated method stub
		JSONObject msg = new JSONObject();
		msg.put("type", messageContent.getType());
		msg.put("from", messageContent.getFrom());
		msg.put("title", messageContent.getTitle());
		msg.put("body", messageContent.getBody());
		msg.put("to", messageContent.getTo());
		msg.put("partnerCode", messageContent.getPartnerCode());
		msg.put("appId", messageContent.getAppId());
		return msg;
	}

}
