package com.payegis.tscsecurid.rest.message;

import net.sf.json.JSONObject;


/**
 * 消息内容
 * @author xuman.xu
 *
 */
public class MessageContent {
	
	/**
	 * 发送类型
	 */
	private String type;
	
	/**
	 * 标题
	 */
	private String title;
	
	/**
	 * 来自谁
	 */
	private String from;
	
	/**
	 * 发送给谁
	 */
	private String to;
	
	/**
	 * 发送内容
	 */
	private String body;
	
	/**
	 * push 自定义内容
	 */
	private JSONObject customforPush;

	private String partnerCode;
	
	private String appId;
	
	private String clientName;
	
	/**
	 *  自定义内容
	 */
	private String customforMsg;
	
	private String deviceId;
	
	private String userStatusUrl;
	
	/**
	 * 邮件信息构造函数
	 * @param type
	 */
	public void setMailContent(String type,String from,String title,String body,String to){
		this.type=type;
		this.from=from;
		this.title=title;
		this.body=body;
		this.to=to;
	}
	
	/**
	 * 内部消息构造函数
	 * @param type
	 * @param from
	 * @param title
	 * @param body
	 * @param to
	 * @param partnerCode
	 * @param appId
	 */
	public void setMsgContent(String type,String from,String title,String body,String to,String partnerCode,String appId){
		this.type=type;
		this.from=from;
		this.title=title;
		this.body=body;
		this.to=to;
		this.partnerCode=partnerCode;
		this.appId=appId;
	}
	
	/**
	 * push构造函数
	 * @param type
	 * @param from
	 * @param body
	 * @param to
	 * @param partnerCode
	 * @param appId
	 * @param clientName
	 * @param customforPush
	 */
	public void setPushContent(String type,String from,String body,String to,String partnerCode,String appId,String clientName,JSONObject customforPush,String deviceId){
		this.type=type;
		this.from=from;
		this.body=body;
		this.to=to;
		this.partnerCode=partnerCode;
		this.appId=appId;
		this.clientName=clientName;
		this.customforPush=customforPush;
		this.deviceId=deviceId;
	}
	
	public void setSmsContent(String type,String from,String body,String to){
		this.type=type;
		this.from=from;
		this.body=body;
		this.to=to;
	}
	
	public void setSmsxContent(String type,String from,String body,String to,String partnerCode,String appId,String deviceId){
		this.type=type;
		this.from=from;
		this.body=body;
		this.to=to;
		this.partnerCode=partnerCode;
		this.appId=appId;
		this.deviceId=deviceId;
	}
	
	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getFrom() {
		return from;
	}

	public void setFrom(String from) {
		this.from = from;
	}

	public String getTo() {
		return to;
	}

	public void setTo(String to) {
		this.to = to;
	}

	public String getBody() {
		return body;
	}

	public void setBody(String body) {
		this.body = body;
	}

	public JSONObject getCustomforPush() {
		return customforPush;
	}

	public void setCustomforPush(JSONObject customforPush) {
		this.customforPush = customforPush;
	}

	public String getPartnerCode() {
		return partnerCode;
	}

	public void setPartnerCode(String partnerCode) {
		this.partnerCode = partnerCode;
	}

	public String getAppId() {
		return appId;
	}

	public void setAppId(String appId) {
		this.appId = appId;
	}

	public String getClientName() {
		return clientName;
	}

	public void setClientName(String clientName) {
		this.clientName = clientName;
	}

	public String getCustomforMsg() {
		return customforMsg;
	}

	public void setCustomforMsg(String customforMsg) {
		this.customforMsg = customforMsg;
	}

	public String getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}

	public String getUserStatusUrl() {
		return userStatusUrl;
	}

	public void setUserStatusUrl(String userStatusUrl) {
		this.userStatusUrl = userStatusUrl;
	}
	
	
	
}
