package com.payegis.tscsecurid.rest.util;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.core.util.MultivaluedMapImpl;
import org.apache.commons.codec.binary.Base64;
import org.apache.log4j.Logger;

import java.net.URLEncoder;
import java.util.*;

public class WSUtil {

	private static Logger logger=Logger.getLogger(WSUtil.class);
	
	/**
	 * @param url
	 * @return
	 */
	public static String sendRequest(String url, Map<String,Object> paramMap){
		//logger.info("Webservice sendRequest url:"+ url);
		MultivaluedMapImpl params=constructWebserviceParams(paramMap);
		Client client;
		if(url.startsWith("https")){
			client = Client.create(ClientHelper.configureClient());
		}else{
			client = Client.create();
		}
		WebResource rs = client.resource(url);
		
		ClientResponse cr= rs.post(ClientResponse.class, params);
		  
		return cr.getEntity(String.class);
	}
	
	public static String countDcCode(Map<String,String> paramMap){
		String url = ConfigFileUtil.getVerifySercuridUrl();
		//logger.info("Webservice countDcCode url:"+ url);
		MultivaluedMapImpl params=constructWebservice(paramMap);
		Client client;
		if(url.startsWith("https")){
			client = Client.create(ClientHelper.configureClient());
		}else{
			client = Client.create();
		}
		WebResource rs = client.resource(url);
		ClientResponse cr= rs.post(ClientResponse.class, params);
		String result = cr.getEntity(String.class);
		return result;
	}
	
	public static String sendSignature(String url,String appId,String appKey,HashMap<String,String> paramMap){
		//logger.info("Webservice sendSignature url:"+ url);
		MultivaluedMapImpl params=constructWebservice(paramMap);
		Client client;
		if(url.startsWith("https")){
			client = Client.create(ClientHelper.configureClient());
		}else{
			client = Client.create();
		}
		String dateTime = String.valueOf(System.currentTimeMillis());
		WebResource rs = client.resource(url);
		String sig =  getSig(appKey, dateTime, paramMap);
		ClientResponse cr= rs.header("x-hmac-auth-date", dateTime).header("x-hmac-auth-signature", appId+":"+sig).post(ClientResponse.class, params);
		String result = cr.getEntity(String.class);
		return result;
	}
	
	public static String validateDcCode(HashMap<String,String> paramMap){
		String url = ConfigFileUtil.getTSCUrl();
		//logger.info("Webservice validateDcCode url:"+ url);
		MultivaluedMapImpl params=constructWebservice(paramMap);
		Client client;
		if(url.startsWith("https")){
			client = Client.create(ClientHelper.configureClient());
		}else{
			client = Client.create();
		}
		String dateTime = String.valueOf(System.currentTimeMillis());
		WebResource rs = client.resource(url);
		String appId = ConfigFileUtil.getAppId();
		String appKey =ConfigFileUtil.getAppKey();
		String sig =  getSig(appKey, dateTime, paramMap);
		ClientResponse cr= rs.header("x-hmac-auth-date", dateTime).header("x-hmac-auth-signature", appId+":"+sig).post(ClientResponse.class, params);
		String result = cr.getEntity(String.class);
		return result;
	}
	public static String getCountSig(String appId,String appkey,  Map<String,String> parameter){
		try{
			String kvString = "";
			parameter.put("x-hmac-auth-date", parameter.get("requestTimeStamp"));
			//System.out.println("x-hmac-auth-date ==>" + parameter.get("requestTimeStamp"));
			Set<String> listKeys = parameter.keySet();
			int length = listKeys.size();
			Iterator<String> it = listKeys.iterator();
			List<String> list = new ArrayList<String>();
			while(it.hasNext()){
				list.add(it.next());
			}
			Collections.sort(list);
			for(int i=0; i<length; i++){
				String key = list.get(i);
				if(i == length -1){
					kvString += key + "=" + parameter.get(key);
				}else{
					kvString += key + "=" + parameter.get(key) + "&";
				}
			}
			String kvStringE = URLEncoder.encode(kvString,"UTF-8");
			kvString = kvStringE.replace("*", "%2A").replace(" ", "%20");
			//logger.info("keys升序排列处理 ==>" + kvString);
			
			//3.method,url,kvString 用&连接
			String firstStep =kvString;
			
			/** Step 2. 构造密钥 */
			String secretoauthkey = appkey;
			secretoauthkey += "&";
			//System.out.println("构造密钥 ==>" + secretoauthkey);
			
			/** step 3. 生成签名值*/
			//1.HMACSHA1加密
			String sig = "";
			byte[] encryption = null;
			try {
				encryption = HMACSHA1.getSignature(firstStep, secretoauthkey);
				//2.Base64编码
				sig = encodeBase64WithoutLinefeed(encryption);
			} catch (Exception e) {
				e.printStackTrace();
			}
			//logger.info("生成签名值 sig ==>" + sig);
			return kvString+","+appId+":"+sig;
		}catch(Exception e){
			e.printStackTrace();
			return "";
		}
		
	}
	
	public static String validateShortCode(HashMap<String,String> paramMap){
		String url = ConfigFileUtil.getValidateShortCodeUrl();
		//logger.info("Webservice validataShortCode url:"+ url);
		MultivaluedMapImpl params=constructWebservice(paramMap);
		Client client;
		if(url.startsWith("https")){
			client = Client.create(ClientHelper.configureClient());
		}else{
			client = Client.create();
		}
		String dateTime = String.valueOf(System.currentTimeMillis());
		WebResource rs = client.resource(url);
		String appId = ConfigFileUtil.getAppId();
		String appKey =ConfigFileUtil.getAppKey();
		String sig =  getSig(appKey, dateTime, paramMap);
		ClientResponse cr= rs.header("x-hmac-auth-date", dateTime).header("x-hmac-auth-signature", appId+":"+sig).post(ClientResponse.class, params);
		String result = cr.getEntity(String.class);
		return result;
	}

    public static String getAlias(HashMap<String,String> paramMap){
        String url = ConfigFileUtil.getTscSecuridCloudAliasQueryUrl();
        //logger.info("Webservice getAlias url:"+ url);
        MultivaluedMapImpl params=constructWebservice(paramMap);
        Client client;
        if(url.startsWith("https")){
            client = Client.create(ClientHelper.configureClient());
        }else{
            client = Client.create();
        }

        WebResource rs = client.resource(url);

        ClientResponse cr= rs.post(ClientResponse.class, params);
        String result = cr.getEntity(String.class);
        return result;
    }

	private static MultivaluedMapImpl constructWebserviceParams(Map<String,Object> paramMap){
		if(paramMap==null || paramMap.isEmpty()){
			return null;
		}
		
		MultivaluedMapImpl params = new MultivaluedMapImpl();
		
		for(Iterator<String> it=paramMap.keySet().iterator() ; it.hasNext();){
			String key= it.next();
			params.add(key, paramMap.get(key));
		}
		
		return params;
		
	}
	
	
	private static MultivaluedMapImpl constructWebservice(Map<String,String> paramMap){
		if(paramMap==null || paramMap.isEmpty()){
			return null;
		}
		
		MultivaluedMapImpl params = new MultivaluedMapImpl();
		
		for(Iterator<String> it=paramMap.keySet().iterator() ; it.hasNext();){
			String key= it.next();
			params.add(key, paramMap.get(key));
		}
		
		return params;
		
	}
	
	
	public static String getSig(String appkey, String requestTimeString, HashMap<String,String> parameter){
		try{
			String kvString = "";
			parameter.put("x-hmac-auth-date", requestTimeString);
			//System.out.println("x-hmac-auth-date ==>" + requestTimeString);
			Set<String> listKeys = parameter.keySet();
			int length = listKeys.size();
			Iterator<String> it = listKeys.iterator();
			List<String> list = new ArrayList<String>();
			while(it.hasNext()){
				list.add(it.next());
			}
			Collections.sort(list);
			for(int i=0; i<length; i++){
				String key = list.get(i);
				if(i == length -1){
					kvString += key + "=" + parameter.get(key);
				}else{
					kvString += key + "=" + parameter.get(key) + "&";
				}
			}
			String kvStringE = URLEncoder.encode(kvString,"UTF-8");
			kvString = kvStringE.replace("*", "%2A").replace(" ", "%20");
			//logger.info("keys升序排列处理 ==>" + kvString);
			
			//3.method,url,kvString 用&连接
			String firstStep =kvString;
			
			/** Step 2. 构造密钥 */
			String secretoauthkey = appkey;
			secretoauthkey += "&";
			//System.out.println("构造密钥 ==>" + secretoauthkey);
			
			/** step 3. 生成签名值*/
			//1.HMACSHA1加密
			String sig = "";
			byte[] encryption = null;
			try {
				encryption = HMACSHA1.getSignature(firstStep, secretoauthkey);
				//2.Base64编码
				sig = encodeBase64WithoutLinefeed(encryption);
			} catch (Exception e) {
				e.printStackTrace();
			}
			//logger.info("生成签名值 sig ==>" + sig);
			return sig;
		}catch(Exception e){
			e.printStackTrace();
			return "";
		}
		
	}
	
	protected static String encodeBase64WithoutLinefeed(byte[] result) {
        return Base64.encodeBase64String(result).trim();
    }
	
}
