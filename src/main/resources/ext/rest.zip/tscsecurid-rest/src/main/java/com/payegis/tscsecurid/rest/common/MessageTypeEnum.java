package com.payegis.tscsecurid.rest.common;

public enum MessageTypeEnum {

	SYSTEM("system","系统消息"),
	
	TOPIC("topic", "人工群发专题");
	
	private String code;

	private String description;

	private MessageTypeEnum(String code, String description) {
		this.code = code;
		this.description = description;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public static String getDescription(String code) {
		for (MessageTypeEnum type : MessageTypeEnum.values()) {
			if (code.equals(type.getCode())) {
				return type.getDescription();
			}
		}
		return null;
	}


}
