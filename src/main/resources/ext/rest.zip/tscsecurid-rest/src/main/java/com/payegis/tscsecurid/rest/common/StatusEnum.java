package com.payegis.tscsecurid.rest.common;

public enum StatusEnum {

	WAITING("W","等待用户确认"),
	FAILED("F", "校验失败"),
	REFUSED("R", "交易被用户拒绝"),
	SUCCESS("S", "交易成功");

	private String code;
	private String desc;

	private StatusEnum(String code, String desc) {
		this.code = code;
		this.desc = desc;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public static String getDesc(String code) {
		for (StatusEnum type : StatusEnum.values()) {
			if (code.equals(type.getCode())) {
				return type.getDesc();
			}
		}
		return null;
	}


}
