package com.payegis.tscsecurid.rest.common;

public enum OperationTypeEnum{

	BINDING("000","适用于所有场景"),
	
	UNBINDING("001","适用于所有场景"),
	
	LOGIN("002","适用于登录场景"),
	
	LOGOUT("003","适用于登出场景"),
	
	OPEN("004","适用于门禁场景"),
	
	VERIFY("005","适用于二次验证场景"),
	
	PAYMENT("006", "适用于支付场景"),

	OTHER("999","适用于其他场景,预留扩充");
	
	private String code;

	private String description;

	private OperationTypeEnum(String code, String description) {
		this.code = code;
		this.description = description;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public static String getDescription(String code) {
		for (OperationTypeEnum type : OperationTypeEnum.values()) {
			if (code.equals(type.getCode())) {
				return type.getDescription();
			}
		}
		return null;
	}

}
