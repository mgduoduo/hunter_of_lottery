package com.payegis.tscsecurid.rest.util;

/**
 * Created by zzg on 2015/10/15.
 */

import org.springframework.web.context.ContextLoader;
import org.springframework.web.context.WebApplicationContext;

public class ApplicationUtil {

    public static Object getBean(String name){
        WebApplicationContext wac = ContextLoader.getCurrentWebApplicationContext();
        return wac.getBean(name);
    }
}