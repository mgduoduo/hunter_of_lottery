package com.payegis.tscsecurid.rest.common;

public enum LogTypeEnum {

	LOGIN("login","登录"),
	
	LOGOUT("logout","登出"),
	
	BINDING("bind","绑定"),
	
	UNBINDING("unbind","解绑"),
	
	OPEN("open", "开门"),

    PAY("pay", "支付"),

    AUTH("auth","验证"),
	
	OTHER("other", "其他");
	
	private String code;

	private String description;

	private LogTypeEnum(String code, String description) {
		this.code = code;
		this.description = description;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public static String getDescription(String code) {
		for (LogTypeEnum type : LogTypeEnum.values()) {
			if (code.equals(type.getCode())) {
				return type.getDescription();
			}
		}
		return null;
	}


}
