package com.payegis.tscsecurid.rest.service;

import com.payegis.tscsecurid.common.data.entity.BindingTerminalPwdProtection;

import java.util.List;


public interface PasswordProtectService {
	void saveQuestions(String deviceId, String questionAnswers);
	BindingTerminalPwdProtection selectByDeviceIdAndQuestionOrder(String deviceId, Integer questionOrder);
	List<BindingTerminalPwdProtection> selectByDeviceId(String deviceId);
}
