package com.payegis.tscsecurid.rest.common;

public enum DeviceTerminalTypeEnum {

	ONETOONE("one2one","一对一绑定(一个设备只可绑定同一个系统的一个账号，同时一个账号也只允许被一个设备绑定)"),
	
	MANYTOMANY("many2many","多对多绑定（同一个设备可绑定多个账号，同一个账号也可绑定多个设备）"),
	
	ONETOMANY("one2many","一对多绑定（同一个设备可绑定多个不同账号，但一个账号只允许被一个设备绑定）");
	
	private String code;

	private String description;

	private DeviceTerminalTypeEnum(String code, String description) {
		this.code = code;
		this.description = description;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public static String getDescription(String code) {
		for (DeviceTerminalTypeEnum type : DeviceTerminalTypeEnum.values()) {
			if (code.equals(type.getCode())) {
				return type.getDescription();
			}
		}
		return null;
	}




}
