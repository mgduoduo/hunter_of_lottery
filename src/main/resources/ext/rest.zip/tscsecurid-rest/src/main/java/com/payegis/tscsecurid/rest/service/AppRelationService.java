package com.payegis.tscsecurid.rest.service;

import com.payegis.tscsecurid.common.data.entity.AppRelationBean;
import com.payegis.tscsecurid.common.service.BaseService;



public interface AppRelationService extends BaseService {


	public AppRelationBean getAppRelationStatus(String openId,String commonId);
	
	public AppRelationBean getAppRelationByOpenId(String openId);
	
	public int create(AppRelationBean appRelationBean);
	
	public void updateAppRelation(AppRelationBean appRelationBean);

	/*public void createPrivilege(MgrPrivilege privilege);

	public void updatePrivilege(MgrPrivilege privilege);

	public boolean checkPrivilegeExists(String privilegeId);

	public void deletePrivilege(String[] privilegeIds);

	public MgrPrivilege retrievePrivilegeById(String privilegeId);

	public List<MgrPrivilege> findPrivilegeList();
	
	public List<MgrPrivilege> getPrivilegeGroup();
	
	public List<MgrPrivilege> FindAllPrivilegeForEnterprise(MgrPrivilege privilege);*/

}
