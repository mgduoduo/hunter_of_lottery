package com.payegis.tscsecurid.rest.util;

import com.payegis.tscsecurid.rest.common.ReturnTypeEnum;
import com.sun.jersey.api.json.JSONWithPadding;
import net.sf.json.JSONObject;

/**
 * Created by zzg on 2015/10/15.
 */
public class JsonWrapUtil {
    private static String JSON_KEY_STATUS = "status";
    private static String JSON_KEY_MESSAGE = "message";
    private static String JSON_KEY_DATA = "data";

    public static String buildJSON(String status, String message, Object object) {
        JSONObject json = new JSONObject();
        json.put(JSON_KEY_STATUS, status);
        json.put(JSON_KEY_MESSAGE, message);
        json.put(JSON_KEY_DATA, object);
        return outputJson(json);
    }

    public static String buildJSON(ReturnTypeEnum e, Object object) {
        JSONObject json = new JSONObject();
        json.put(JSON_KEY_STATUS, String.valueOf(e.getCode()));
        json.put(JSON_KEY_MESSAGE, e.getDescription());
        json.put(JSON_KEY_DATA, object);
        return outputJson(json);
    }

    public static String outputJson(JSONObject json) {
        String str = json.toString();
        return str;
    }

    public static String reMsg(ReturnTypeEnum e) {
        return StringUtil.jsonExceptionMsg(e.getCode(), e.getDescription());
    }

    public static JSONWithPadding reMsgJSONWithPadding(ReturnTypeEnum e, JSONObject json, String callback) {
        return new JSONWithPadding(buildJSON(String.valueOf(e.getCode()), e.getDescription(), json).toString(), callback);
    }
}
