package com.payegis.tscsecurid.rest.common;


public enum OnlineStatusEnum {
	
	ONLINE("online","登录"),
	
	OFFLINE("offline", "未登录"),
	
	ESCAPE("escape", "忽略本状态");
	
	private String code;

	private String description;

	private OnlineStatusEnum(String code, String description) {
		this.code = code;
		this.description = description;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public static String getDescription(String code) {
		for (OnlineStatusEnum status : OnlineStatusEnum.values()) {
			if (code.equals(status.getCode())) {
				return status.getDescription();
			}
		}
		return null;
	}

}
