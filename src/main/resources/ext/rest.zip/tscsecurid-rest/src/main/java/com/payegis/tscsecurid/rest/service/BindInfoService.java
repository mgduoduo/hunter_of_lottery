package com.payegis.tscsecurid.rest.service;

import com.payegis.tscsecurid.common.data.bo.BindInfoDto;
import com.payegis.tscsecurid.common.data.entity.BindingInfoEnterprise;
import com.payegis.tscsecurid.common.data.entity.BindingLogEnterprise;

import java.util.List;
import java.util.Map;

public interface BindInfoService {
	void saveBindInfo(BindingInfoEnterprise bindInfo, BindingLogEnterprise logInfo);
	void updateBindInfo(BindingInfoEnterprise bindInfo);
	void deleteBindInfo(Integer bindId, BindingLogEnterprise logInfo);
	BindingInfoEnterprise selectById(Integer bindId);
	List<BindInfoDto> selectBindInfoList(Map<String, Object> param);
	List<BindInfoDto> selectByDeviceId(String deviceId);
    List<BindingInfoEnterprise> selectBySystemAccountAndSystemNo(String systemAccount, String systemNo);
	BindingInfoEnterprise selectByDeviceIdAndSystemNoAndSystemAccount(String deviceId, String systemNo, String systemAccount);
    void updateBindInfoOlineStatus(BindingInfoEnterprise record);
}
