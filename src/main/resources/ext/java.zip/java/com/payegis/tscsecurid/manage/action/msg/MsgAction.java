package com.payegis.tscsecurid.manage.action.msg;

import com.payegis.tscsecurid.common.aop.AvoidDuplicateSubmission;
import com.payegis.tscsecurid.common.constant.PropertyFileKeys;
import com.payegis.tscsecurid.common.data.bo.*;
import com.payegis.tscsecurid.common.data.entity.BusinessSystem;
import com.payegis.tscsecurid.common.data.entity.SysMsgTopic;
import com.payegis.tscsecurid.common.data.entity.SysUser;
import com.payegis.tscsecurid.common.result.ResultBean;
import com.payegis.tscsecurid.manage.action.customer.ManageBaseAction;
import com.payegis.tscsecurid.manage.common.Constant;
import com.payegis.tscsecurid.manage.service.business.enterprise.EnterpriseService;
import com.payegis.tscsecurid.manage.service.business.mgr.LogService;
import com.payegis.tscsecurid.manage.service.business.msg.MsgService;
import com.payegis.tscsecurid.manage.util.SessionUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/msg")
public class MsgAction extends ManageBaseAction {

	@Autowired
	private MsgService msgService;
	
	@Autowired
	private LogService logService;
	
	@Autowired
	private EnterpriseService enterpriseService;

	@ModelAttribute("businessTypes")
	public Map<String, String> getBusinessTypes(HttpSession session) {
		SysUser su = SessionUtil.getUser(session);
		Map<String, String> map = new HashMap<String, String>();
		List<BusinessSystem> bs =  null;
		if (null != su) {
			if(!su.getRoleNames().contains(Constant.SYSTEM_USER))
				bs = msgService.findBusinessSystemsByUserId(su
					.getUserId());
			else
				bs = logService.getBusinessSystemByEnterpriseId(null);
			if (null != bs && !bs.isEmpty()) {
				for (BusinessSystem b : bs) {
					map.put(String.valueOf(b.getSystemId()), b.getSystemName());
				}
			}
		}
		return map;
	}

	@ModelAttribute("osTypes")
	public Map<String, String> getOsTypes() {
		Map<String, String> map = new HashMap<String, String>();
		map.put("Android", "Android");
		map.put("iOS", "iOS");
		//map.put("WinPhone", "WinPhone");
		return map;
	}
	@ModelAttribute("enterpriseTypes")
	public Map<Integer, String> enterpriseTypes(HttpSession session) {
		SysUser su = SessionUtil.getUser(session);
		Map<Integer, String> map = new HashMap<Integer, String>();
		if (null != su && su.getRoleNames().contains(Constant.SYSTEM_USER)) {
			List<EnterpriseInfoBo> ebi = enterpriseService.findAllEnterprise();
			if (null != ebi && !ebi.isEmpty()) {
				for (EnterpriseInfoBo e : ebi) {
					map.put(e.getEnterpriseId(), e.getEnterpriseName());
				}
			}
		}
		return map;
	}
	@RequestMapping(value = "/msgQuery", method = RequestMethod.GET)
	public ModelAndView msgQuery(HttpServletRequest request,HttpSession session) {
        SysUser user = super.getSessionInfo(request.getSession()).getLoginUser();
        if(!user.getRoleNames().contains(Constant.SYSTEM_USER))
            return new ModelAndView("page/msg/msg_query");
        else
            return new ModelAndView("page/msg/msg_query_payegis");

	}
	
	@RequestMapping(value = "/msgQueryPayEgis", method = RequestMethod.GET)
	public ModelAndView msgQueryPayEgis(HttpServletRequest request,HttpSession session) {
		return new ModelAndView("page/msg/msg_query_payegis");
	}
	
	@RequestMapping(value = "/msgSearch")
	public ModelAndView msgSearch(SysMsgQueryBo sysMsgQueryBo,
			HttpServletRequest request, HttpSession session) {
		HashMap<String, Object> resMap = new HashMap<String, Object>();
		if (sysMsgQueryBo == null)
			sysMsgQueryBo = new SysMsgQueryBo();
		SysUser su = SessionUtil.getUser(session);
		String url = "page/msg/msg_query_list";
		if (null != su) {
			sysMsgQueryBo.setEnterpriseId(su.getEnterpriseId());
			ResultBean resBean = msgService.listAll(sysMsgQueryBo);
			resMap.put("dataList", resBean.getRows());
			resMap.put("total", resBean.getTotal());
		}

		ModelAndView mav = new ModelAndView(url, resMap);
		return mav;
	}

	@RequestMapping(value = "/msgSearchPayEgis")
	public ModelAndView msgSearchPayEgis(SysMsgQueryBo sysMsgQueryBo,
			HttpServletRequest request, HttpSession session) {
		HashMap<String, Object> resMap = new HashMap<String, Object>();
		if (sysMsgQueryBo == null)
			sysMsgQueryBo = new SysMsgQueryBo();
		SysUser su = SessionUtil.getUser(session);
		String url = "page/msg/msg_query_list_payegis";
		if (null != su) {
			ResultBean resBean = msgService.listAll(sysMsgQueryBo);
			resMap.put("dataList", resBean.getRows());
			resMap.put("total", resBean.getTotal());
		}

		ModelAndView mav = new ModelAndView(url, resMap);
		return mav;
	}
	
	@RequestMapping(value = "/msgTopicSearch")
	public ModelAndView msgTopicSearch(SysMsgTopicQueryBo sysMsgTopicQueryBo,
			HttpServletRequest request, HttpSession session) {
		HashMap<String, Object> resMap = new HashMap<String, Object>();
		SysUser su = SessionUtil.getUser(session);
		String url = "page/msg/msg_topic_query_list";
		if (null != su) {
			sysMsgTopicQueryBo.setEnterpriseId(su.getEnterpriseId());
			ResultBean resBean = msgService
					.listSysMsgTopics(sysMsgTopicQueryBo);
			resMap.put("dataList", resBean.getRows());
			resMap.put("total", resBean.getTotal());
		}

		ModelAndView mav = new ModelAndView(url,
				resMap);
		return mav;
	}

	@RequestMapping(value = "/msgTopicSearchPayEgis")
	public ModelAndView msgTopicSearchPayEgis(SysMsgTopicQueryBo sysMsgTopicQueryBo,
			HttpServletRequest request, HttpSession session) {
		HashMap<String, Object> resMap = new HashMap<String, Object>();
		SysUser su = SessionUtil.getUser(session);
		String url = "page/msg/msg_topic_query_list_payegis";
		if (null != su) {
			sysMsgTopicQueryBo.setEnterpriseId(sysMsgTopicQueryBo.getEnterpriseId1());
			ResultBean resBean = msgService
					.listSysMsgTopics(sysMsgTopicQueryBo);
			resMap.put("dataList", resBean.getRows());
			resMap.put("total", resBean.getTotal());
		}

		ModelAndView mav = new ModelAndView(url,
				resMap);
		return mav;
	}
	@RequestMapping(value = "/msgDetail/{id}/{name}", method = RequestMethod.GET)
	public ModelAndView msgDetail(HttpServletRequest request,
			@PathVariable Integer id, @PathVariable String name) {
		ModelAndView mav = new ModelAndView();
		SysMsgTopic smt = msgService.selectMsgTopicByPrimaryKey(id);
		if (null != smt)
			smt.setSendUserName(name);
		mav.addObject("sysMsgTopic", smt);
		mav.setViewName("page/msg/msg_topic_detail");
		return mav;
	}

	@RequestMapping(value = "/bindingDetail/{id}", method = RequestMethod.GET)
	public ModelAndView bingDetail(HttpServletRequest request,
			@PathVariable Integer id) {
		ModelAndView mav = new ModelAndView();

		mav.setViewName("page/msg/binding_detail");
		return mav;
	}

	@RequestMapping(value = "/goAddMsgTopic", method = RequestMethod.GET)
	@AvoidDuplicateSubmission(needSaveToken = true)
	public ModelAndView goAddMsgTopic() {
		ModelAndView mav = new ModelAndView("page/msg/msg_topic_add");
		DeviceQueryBo deviceQueryBo = new DeviceQueryBo();
		mav.addObject("deviceQueryBo", deviceQueryBo);
		return mav;
	}
	
	@AvoidDuplicateSubmission(needRemoveToken = true)
	@RequestMapping(value = "/saveMsgTopic", method = RequestMethod.POST)
	public ModelAndView saveMsgTopic(
			@ModelAttribute("deviceQueryBo") @Valid DeviceQueryBo deviceQueryBo,
			BindingResult result, HttpServletRequest request,
			RedirectAttributes redirectAttributes, HttpSession session) {
		ModelAndView mav = new ModelAndView("redirect:/msg/msgQuery");
		String msg = "";
		int res = -1;
		if (result.hasErrors()) {
			mav.setViewName("page/msg/msg_topic_add");
			return mav;
		}
		SysUser su = (SysUser) SessionUtil.getUser(session);
		if(null != su){
            if(!su.getEnterpriseNo().equals(PropertyFileKeys.ENTERPRISE_NO_PAYEGIS))
			    deviceQueryBo.setEnterpriseId(su.getEnterpriseId());
			deviceQueryBo = msgService.getNewDeviceQueryBo(deviceQueryBo);
			try {
				if (null != su) {
					deviceQueryBo.setSendUserId(su.getUserId());
					deviceQueryBo.setEnterpriseId(su.getEnterpriseId());
					res = msgService.saveMsgTopic(deviceQueryBo);
				}
			} catch (Exception e) {
				logger.info("save Msg:" + e.getMessage());
			}
		}
		

		switch (res) {
		case 1:
			msg = "增加成功";
			break;
		default:
			msg = "增加失败";
		}
		redirectAttributes.addFlashAttribute("success", msg);
		return mav;
	}

	@RequestMapping(value = "/findDevices", method = RequestMethod.GET)
	public ModelAndView findDevices() {
		ModelAndView mav = new ModelAndView("page/msg/device_query");
		DeviceSelectBo deviceSelectBo = new DeviceSelectBo();
		mav.addObject("deviceSelectBo", deviceSelectBo);
		return mav;
	}
	
	@RequestMapping(value = "/deviceSearch")
	public ModelAndView deviceSearch(DeviceSelectBo deviceSelectBo,
			HttpServletRequest request, HttpSession session) {
		HashMap<String, Object> resMap = new HashMap<String, Object>();
		if (deviceSelectBo == null)
			deviceSelectBo = new DeviceSelectBo();
		SysUser su = SessionUtil.getUser(session);
		if (null != su) {
            if(!su.getEnterpriseNo().equals(PropertyFileKeys.ENTERPRISE_NO_PAYEGIS))
			    deviceSelectBo.setEnterpriseId(su.getEnterpriseId());
			ResultBean resBean = msgService.listAllDeviceSelect(deviceSelectBo);
			resMap.put("dataList", resBean.getRows());
			resMap.put("total", resBean.getTotal());
		}

		ModelAndView mav = new ModelAndView("page/msg/device_query_list", resMap);
		return mav;
	}
/*
	public static void main(String[] args) {
		List<String> l = new ArrayList<String>();
		l.add("a");
		l.add("b");
		l.add("a");
		l.add("b");
		Map<String,String> map = new HashMap<String, String>();
		map.put("a", "a");map.put("a", "b");
		System.out.println(map.get("c"));
		System.out.println(StringUtils.join(l,"','"));
		System.out.println(StringUtils.isEmpty("    "));
		
		
		List<Integer> ll = new ArrayList<Integer>();
		ll.add(2);
		ll.add(3);
		ll.add(1);
		ll.add(8);
		
		for (int i = 0; i < ll.size(); i++) {
			for (int j = i+1; j < ll.size(); j++) {
				if(ll.get(i)<ll.get(j)){
					int temp = ll.get(i);
					ll.set(i, ll.get(j));
					ll.set(j, temp);
				}
			}
		}
		
		System.out.println();
	}*/
}
