package com.payegis.tscsecurid.manage.service.impl.customer;

import com.payegis.tscsecurid.common.data.BaseBo;
import com.payegis.tscsecurid.common.data.bo.BindingInfoEnterpriseQueryBo;
import com.payegis.tscsecurid.common.data.bo.BindingTerminalPwdProtectionBo;
import com.payegis.tscsecurid.common.data.bo.FeedbackInfoBo;
import com.payegis.tscsecurid.common.data.entity.*;
import com.payegis.tscsecurid.common.mapper.*;
import com.payegis.tscsecurid.common.result.ResultBean;
import com.payegis.tscsecurid.common.util.DateUtil;
import com.payegis.tscsecurid.manage.service.business.customer.CustomerInfoService;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class CustomerInfoServiceImpl implements CustomerInfoService {

    @Autowired
    FeedbackInfoMapper feedbackInfoMapper;

    @Autowired
    private SysMsgMapper sysMsgMapper;

    @Autowired
    private TerminalPwdResetMapper terminalPwdResetMapper;

    @Autowired
    private BindingTerminalMapper bindingTerminalMapper;

    @Autowired
    private BindingTerminalPwdProtectionMapper bindingTerminalPwdProtectionMapper;

    @Autowired
    private BindingInfoEnterpriseMapper bindingInfoEnterpriseMapper;

    protected BaseMapper getMapper() {
        return feedbackInfoMapper;
    }

    /**
     * 根据传入的BO参数，取得对应的分页数据
     * @return
     */
    public ResultBean getPageList(BaseBo param){
        ResultBean result = new ResultBean();
        List<Object> pageList = getMapper().listAll(param);
        List<FeedbackInfoBo> newPageList = new ArrayList<FeedbackInfoBo>();
        for (Object item : pageList) {
            FeedbackInfoBo terminalInfo = (FeedbackInfoBo) item;
            List<String> accounts = terminalPwdResetMapper.selectAccountWrapWithDeviceId(terminalInfo
                    .getDeviceId());
            if (null != accounts && !accounts.isEmpty()) {
                if (accounts.size() > 1) {
                    terminalInfo.setSystemAccount(StringUtils.join(accounts, ";  ") + "...");
                } else
                    terminalInfo.setSystemAccount(accounts.get(0));
            }
            newPageList.add(terminalInfo);
        }
        result.setRows(newPageList);
        result.setTotal(getMapper().count(param));
        return result;
    }

    @Override
    public Integer updateFeedBackInfo(FeedbackInfo fbi) {
        fbi.setOperationState("Y");
        fbi.setOperationTime(DateUtil.getCurrentDateString());
        return feedbackInfoMapper.updateByPrimaryKeySelective(fbi);
    }

    @Override
    public ResultBean getPageListForReset(BaseBo param) {
        ResultBean result = new ResultBean();
        List<Object> pageList = terminalPwdResetMapper.listAll(param);
        List<BindingInfoEnterpriseQueryBo> newPageList = new ArrayList<BindingInfoEnterpriseQueryBo>();
        for (Object item : pageList) {
            BindingInfoEnterpriseQueryBo terminalInfo = (BindingInfoEnterpriseQueryBo) item;
            List<String> accounts = terminalPwdResetMapper.selectAccountWrapWithDeviceId(terminalInfo
                    .getDeviceId());
            if (null != accounts && !accounts.isEmpty()) {
                if (accounts.size() > 1) {
                    terminalInfo.setSystemAccount(StringUtils.join(accounts, ";  ") + "...");
                } else
                    terminalInfo.setSystemAccount(accounts.get(0));
            }
            newPageList.add(terminalInfo);
        }
        result.setRows(newPageList);
        result.setTotal(terminalPwdResetMapper.count(param));
        return result;
    }

    @Override
    public boolean updatePwdReset(TerminalPwdReset tpr) {
        BindingTerminal bt = new BindingTerminal();
        bt.setDeviceId(tpr.getDeviceId());
        bt.setDevicePassword("");
        bindingTerminalMapper.updateByPrimaryKeySelective(bt);
        tpr.setOperationTime(DateUtil.getCurrentDateString());
        terminalPwdResetMapper.insertSelective(tpr);
        return true;
    }

    @Override
    public List<BindingTerminalPwdProtection> viewPwdQuestion(
            BindingTerminalPwdProtectionBo param) {
        List<BindingTerminalPwdProtection> questionList = bindingTerminalPwdProtectionMapper
                .selectProByDeviceId(param.getDeviceId());
        return questionList;
    }

    @Override
    public FeedbackInfo selectByPrimaryKey(Integer feedbackInfoId) {
        // TODO Auto-generated method stub
        return feedbackInfoMapper.selectByPrimaryKey(feedbackInfoId);
    }

    @Override
    public List<BindingInfoEnterprise> selectMoreAccountByDeviceId(
            String deviceId) {
        return bindingInfoEnterpriseMapper.selectMoreAccountByDeviceId(deviceId);
    }


}
