package com.payegis.tscsecurid.manage.common;


import com.payegis.tscsecurid.common.data.entity.SysUser;

import java.io.Serializable;



public class SessionInfo implements Serializable {

	private static final long serialVersionUID = 7859232412234858585L;

	private SysUser loginUser;

	public SysUser getLoginUser() {
		return loginUser;
	}

	public void setLoginUser(SysUser loginUser) {
		this.loginUser = loginUser;
	}

}
