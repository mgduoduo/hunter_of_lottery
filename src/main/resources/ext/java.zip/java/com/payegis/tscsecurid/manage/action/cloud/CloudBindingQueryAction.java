package com.payegis.tscsecurid.manage.action.cloud;

import com.alibaba.fastjson.JSON;
import com.payegis.tscsecurid.common.constant.PropertyFileKeys;
import com.payegis.tscsecurid.common.data.bo.BindInfoQueryBo;
import com.payegis.tscsecurid.common.data.bo.BindingInfoBo;
import com.payegis.tscsecurid.common.data.bo.EnterpriseInfoBo;
import com.payegis.tscsecurid.common.data.entity.BusinessSystem;
import com.payegis.tscsecurid.common.data.entity.SysUser;
import com.payegis.tscsecurid.common.result.ResultBean;
import com.payegis.tscsecurid.manage.service.business.customer.CustomerService;
import com.payegis.tscsecurid.manage.service.business.enterprise.EnterpriseService;
import com.payegis.tscsecurid.manage.util.SessionUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpSession;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 云管理内容 -- 绑定查询
 * Created by liucheng on 2014/11/20.
 */
@Controller
public class CloudBindingQueryAction {

    @ModelAttribute("bindingQuery_search_url")
    public String getSearchUrl() {
        return "/bindingQuery/search";
    }


    @Autowired
    CustomerService customerService;

    @Autowired
    private EnterpriseService enterpriseService;

    @RequestMapping("/bindingQuery")
    public String bindingQuery(Model model) {
        return "page/cloud/bindingQuery";
    }

    @ResponseBody
    @RequestMapping("/bindingQuery/getBusinessSystem")
    public String getBusinessSystem(@RequestParam Integer enterpriseId,Model model) {
        List<BusinessSystem> businessSystemList = customerService.getBusinessSystemByUser(enterpriseId);
        return JSON.toJSONString(businessSystemList);
    }

    @RequestMapping("/bindingQuery/search")
    public String search(BindInfoQueryBo queryBo,Model model,HttpSession session) {
        SysUser user = SessionUtil.getUser(session);
        if (!PropertyFileKeys.ENTERPRISE_NO_PAYEGIS.equals(user.getEnterpriseNo())) {
            queryBo.setEnterpriseId(user.getEnterpriseId());
        }
        ResultBean<BindingInfoBo> bindingInfoResultBean = customerService.getPageList(queryBo);
        model.addAttribute("result", bindingInfoResultBean);
        return "page/cloud/bindingQuery_list";
    }


    @ModelAttribute("enterpriseTypes")
    public Map<Integer, String> enterpriseTypes(HttpSession session) {
        SysUser su = SessionUtil.getUser(session);
        Map<Integer, String> map = new HashMap<Integer, String>();
        if (null != su && su.getEnterpriseNo().equals(PropertyFileKeys.ENTERPRISE_NO_PAYEGIS)) {
            List<EnterpriseInfoBo> ebi = enterpriseService.findAllEnterprise();
            if (null != ebi && !ebi.isEmpty()) {
                for (EnterpriseInfoBo e : ebi) {
                    map.put(e.getEnterpriseId(), e.getEnterpriseName());
                }
            }
        }
        return map;
    }

}

