package com.payegis.tscsecurid.manage.Interceptor;


import com.payegis.tscsecurid.common.data.entity.SysUser;
import com.payegis.tscsecurid.manage.common.Constant;
import com.payegis.tscsecurid.manage.common.SessionInfo;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author Dong.li
 */
public class LogicInterceptor extends HandlerInterceptorAdapter {

    private static final Logger logger = Logger.getLogger(LogicInterceptor.class);


    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        request.setCharacterEncoding("UTF-8");
        response.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");

        SessionInfo sessionInfo = (SessionInfo) request.getSession()
                .getAttribute(Constant.KEY_SESSION_INFO);

        SysUser user = null;
        if (null != sessionInfo) {
            user = sessionInfo.getLoginUser();
        }
        //为了生成绑定时空码
        if (user == null || StringUtils.isEmpty(user.getUserName())) {
            String servletPath = request.getServletPath();
            logger.info("try to access url:" + servletPath + ",but no login,redirect to login page.");
            String redirectURL = request.getContextPath() + "/login";
            response.sendRedirect(redirectURL);
            return false;
        }
        String menuId = request.getParameter("menuId");
        if (StringUtils.isEmpty(menuId)) {
            if (request.getSession().getAttribute("menuId") == null) {
//                menuId = "0";
            } else {
                menuId = (String) request.getSession().getAttribute("menuId");
            }
        }
        request.getSession().setAttribute("menuId", menuId);

        String subMenuId = request.getParameter("subMenuId");
        if (StringUtils.isEmpty(subMenuId)) {
            if (request.getSession().getAttribute("subMenuId") == null) {
//                subMenuId = "0";
            } else {
                subMenuId = (String) request.getSession().getAttribute("subMenuId");
            }
        }
        request.getSession().setAttribute("subMenuId", subMenuId);

        return super.preHandle(request, response, handler);
    }


    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception {

    }


    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {

    }
}
