package com.payegis.tscsecurid.manage.action.version;

import com.payegis.tscsecurid.common.action.BaseAction;
import com.payegis.tscsecurid.common.aop.AvoidDuplicateSubmission;
import com.payegis.tscsecurid.common.data.entity.SysUser;
import com.payegis.tscsecurid.common.data.entity.VersionManage;
import com.payegis.tscsecurid.common.result.ResultBean;
import com.payegis.tscsecurid.manage.service.business.version.VersionService;
import com.payegis.tscsecurid.manage.util.SessionUtil;
import net.sf.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

@Controller
@RequestMapping("/version")
public class VersionAction extends BaseAction {

    @Autowired
    private VersionService versionService;

    @ModelAttribute("versionTypes")
    public Map<String, String> getVersionTypes() {
        Map<String, String> map = new HashMap<String, String>();
        map.put("Android", "Android");
        map.put("iOS", "iOS");
        return map;
    }

    @ModelAttribute("updateLevels")
    public Map<String, String> getUpdateLevels() {
        Map<String, String> map = new LinkedHashMap<String, String>();
        map.put("general", "普通更新");
        map.put("force", "强制更新");
        return map;
    }

    @ModelAttribute("stateTypes")
    public Map<String, String> getStateTypes() {
        Map<String, String> map = new LinkedHashMap<String, String>();
        map.put("on", "上架");
        map.put("off", "下架");
        return map;
    }
    @RequestMapping(value = "/versionQuery", method = RequestMethod.GET)
    public ModelAndView msgQuery(HttpServletRequest request,HttpSession session) {
        return new ModelAndView("page/version/version_query");
    }

    @RequestMapping(value = "/versionSearch")
    public ModelAndView msgSearch(VersionManage versionManage,HttpServletRequest request, HttpSession session) {
        HashMap<String, Object> resMap = new HashMap<String, Object>();
        ResultBean resBean = versionService.listAll(versionManage);
        resMap.put("dataList", resBean.getRows());
        resMap.put("total", resBean.getTotal());
        ModelAndView mav = new ModelAndView("page/version/version_query_list", resMap);
        return mav;
    }

    @RequestMapping(value = "/goAddVersion", method = RequestMethod.GET)
    @AvoidDuplicateSubmission(needSaveToken = true)
    public ModelAndView goAddVersion() {
        ModelAndView mav = new ModelAndView("page/version/version_add");
        VersionManage versionManage = new VersionManage();
        mav.addObject("versionManage", versionManage);
        return mav;
    }

    @RequestMapping(value = "/saveVersion", method = RequestMethod.POST)
    @AvoidDuplicateSubmission(needRemoveToken = true)
    public ModelAndView doSave(
            @ModelAttribute("versionManage") @Valid VersionManage versionManage,BindingResult result,
            HttpServletRequest request, RedirectAttributes redirectAttributes,HttpSession session) {
        ModelAndView mav = new ModelAndView("redirect:/version/versionQuery");
        if (result.hasErrors()) {
            mav.setViewName("page/version/version_add");
            return mav;
        }
        SysUser su = (SysUser) SessionUtil.getUser(session);
        String msg = "增加成功";
        int res = -1;
        try {
            if(null != su ){
                if (versionService.findByVersionNoAndType(versionManage) <= 0) {
                    res = versionService.save(versionManage, su);
                    if (res == -1)   msg = "增加失败";
                }else
                    msg = "版本号已经存在";
            }
        } catch (Exception e) {
            logger.info("save versionManage:" + e.getMessage());
        }

        redirectAttributes.addFlashAttribute("success", msg);
        return mav;
    }

    @RequestMapping(value = "/versionEdit/{id}", method = RequestMethod.GET)
    @AvoidDuplicateSubmission(needSaveToken = true)
    public ModelAndView versionEdit(HttpServletRequest request,
                                    @PathVariable Integer id) {
        ModelAndView mav = new ModelAndView();
        VersionManage versionManage = versionService.findById(id);
        mav.addObject("versionManage", versionManage);
        mav.setViewName("page/version/version_update");
        return mav;
    }

    @RequestMapping(value = "/versionDetail/{id}", method = RequestMethod.GET)
    public ModelAndView versionDetail(HttpServletRequest request,
                                      @PathVariable Integer id) {
        ModelAndView mav = new ModelAndView();
        VersionManage versionManage = versionService.findById(id);
        mav.addObject("versionManage", versionManage);
        mav.setViewName("page/version/version_detail");
        return mav;
    }

    @RequestMapping(value = "/updateVersion", method = RequestMethod.POST)
    @AvoidDuplicateSubmission(needRemoveToken = true)
    public ModelAndView updateVersion(
            @ModelAttribute("versionManage")@Valid VersionManage versionManage,BindingResult result,
            HttpServletRequest request, RedirectAttributes redirectAttributes,HttpSession session) {
        ModelAndView mav = new ModelAndView(
                "redirect:/version/versionQuery");
        String msg = "更新失败";
        if (result.hasErrors()) {
            mav.setViewName("page/version/version_add");
            return mav;
        }
        SysUser su = (SysUser) SessionUtil.getUser(session);
        if (null != su) {
            try {
                int res = 0;
                res = versionService.update(versionManage,su);
                msg = (res == 1 ? "更新成功" : "更新失败");
            } catch (Exception e) {
                logger.info("update enterprise fail:"+e.getMessage());
            }
        }
        redirectAttributes.addFlashAttribute("success", msg);
        return mav;
    }

    @RequestMapping(value = "checkVersionNoExists", method = RequestMethod.POST)
    @ResponseBody
    public String checkVersionNoExists(String versionNo,String versionType) {
        JSONObject json = new JSONObject();
        VersionManage param = new VersionManage();
        param.setVersionNo(versionNo);
        param.setVersionType(versionType);
        if (versionService.findByVersionNoAndType(param) > 0) {
            json.put("status", "1");
        } else {
            json.put("status", "0");
        }
        return json.toString();
    }
}
