package com.payegis.tscsecurid.manage.service.business.mgr;

import com.payegis.tscsecurid.common.data.entity.BusinessSystem;
import com.payegis.tscsecurid.common.data.entity.SysCode;
import com.payegis.tscsecurid.common.data.entity.SysLog;
import com.payegis.tscsecurid.common.result.ResultBean;

import java.util.List;
import java.util.Map;

public interface LogService {
    public ResultBean listAll(SysLog param);
    public ResultBean listAllLogs(SysLog param);
    public List<Object> listAllRecords(String param);
    
    public List<Object> listAllRecordsOfEnterprise(SysLog param);
    
    public List<BusinessSystem> getBusinessSystemByEnterpriseId(Map<String, Object> map);
    
    public List<SysCode> getAllCodeBySystemNo(String codeTypeCallBack);

    ResultBean<SysLog> statisticsSearch(SysLog sysLog);
}
