package com.payegis.tscsecurid.manage.action.cloud;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.payegis.tscsecurid.common.constant.PropertyFileKeys;
import com.payegis.tscsecurid.common.data.bo.BindInfoQueryBo;
import com.payegis.tscsecurid.common.data.bo.BindingInfoBo;
import com.payegis.tscsecurid.common.data.bo.BindingLogBo;
import com.payegis.tscsecurid.common.data.entity.BindingLog;
import com.payegis.tscsecurid.common.data.entity.BusinessSystem;
import com.payegis.tscsecurid.common.data.entity.SysUser;
import com.payegis.tscsecurid.common.result.ResultBean;
import com.payegis.tscsecurid.common.util.DateUtil;
import com.payegis.tscsecurid.manage.service.business.customer.CustomerService;
import com.payegis.tscsecurid.manage.util.SessionUtil;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;
import java.util.List;

/**
 * Created by liucheng on 2014/11/12.
 */
@Controller
@RequestMapping("/cloud")
public class CloudUNBindingAction {

    private static final Logger logger = Logger.getLogger(CloudUNBindingAction.class);

    @ModelAttribute("search_url")
    public String getSearchUrl() {
        return "/cloud/unbind/search";
    }


    @Autowired
    CustomerService customerService;

    @ModelAttribute("systems")
    public List<BusinessSystem> getCallBackTypes(HttpSession session) {
        Object object = session.getAttribute("systems");
        if (object == null) {
//            SysUser user = SessionUtil.getUser(session);
            List<BusinessSystem> businessSystemList = customerService.getBusinessSystemByUser(null);
            session.setAttribute("systems", businessSystemList);
            return businessSystemList;
        } else {
            return (List<BusinessSystem>) object;
        }
    }

    @RequestMapping("/unbind")
    public String showUnbindSupply(Model model) {
        return "page/cloud/unbind";
    }

    @RequestMapping("/unbind/search")
    public String search(BindInfoQueryBo queryBo,Model model,HttpSession session) {
        SysUser user = SessionUtil.getUser(session);
//        queryBo.setEnterpriseId(user.getEnterpriseId());
        if (StringUtils.isNotEmpty(queryBo.getStartDate())) {
            queryBo.setStartDate(queryBo.getStartDate() + " 00:00:00");
        }
        if (StringUtils.isNotEmpty(queryBo.getEndDate())) {
            queryBo.setEndDate(queryBo.getEndDate() + " 23:59:59");
        }
        ResultBean<BindingInfoBo> bindingInfoResultBean = customerService.getPageList(queryBo);
        model.addAttribute("result", bindingInfoResultBean);
        return "page/cloud/unbind_list";
    }

    @ResponseBody
    @RequestMapping("/unbind/getBindingInfo")
    public String getBindingInfo(@RequestParam Integer bindId,Model model,HttpSession session) {
        JSONObject jsonObject = new JSONObject();

        BindingInfoBo infoBo = customerService.getBindingInfoByPrimaryKey(bindId);
        if (infoBo != null) {
            jsonObject.put("status", "success");
            infoBo.setSystemName(getSystemName(infoBo.getSystemId(), (List<BusinessSystem>) session.getAttribute("systems")));
            jsonObject.put("data", infoBo);
        } else {
            jsonObject.put("status", "error");
            jsonObject.put("message", "该账号已被解绑！");
        }
        return jsonObject.toJSONString();
    }

    private String getSystemName(Integer systemId, List<BusinessSystem> businessSystems) {
        for (BusinessSystem system : businessSystems) {
            if (systemId.intValue() == system.getSystemId().intValue()) {
                return system.getSystemName();
            }
        }
        return null;
    }

    @ResponseBody
    @RequestMapping(value = "/unbinding",method = RequestMethod.POST)
    public String unBinding(BindingLog log,@RequestParam Integer bindingInfoId,Model model,HttpSession session) {
        SysUser user = SessionUtil.getUser(session);
//        log.setEnterpriseId(user.getEnterpriseId());
        log.setBindingLogType(PropertyFileKeys.BINDING_LOG_TYPE_UNBINDING);
        log.setUnbindingType(PropertyFileKeys.UNBINDING_TYPE_SERVICE);
        log.setOperationUser(user.getUserId());
        log.setOperationTime(DateUtil.getCurrentDateString());
        try {
            customerService.saveUnBinding(log, bindingInfoId);
            return "success";
        } catch (Exception e) {
            logger.error(e);
            return "error";
        }
    }

    @ResponseBody
    @RequestMapping("/accountHistory")
    public String showAccountHistory(BindingLog bindingLog,Model model,HttpSession session) {
        SysUser user = SessionUtil.getUser(session);
//        bindingLog.setEnterpriseId(user.getEnterpriseId());
        bindingLog.setBindingLogType(PropertyFileKeys.BINDING_LOG_TYPE_UNBINDING);
        List<BindingLogBo> bindingLogs = customerService.selectAccountHistory(bindingLog);
        for (BindingLogBo log : bindingLogs) {
            log.setSystemName(getSystemName(log.getSystemId(),(List<BusinessSystem>) session.getAttribute("systems")));
        }
        return JSON.toJSONString(bindingLogs);
    }
}
