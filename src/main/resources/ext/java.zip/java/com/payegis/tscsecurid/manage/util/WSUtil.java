package com.payegis.tscsecurid.manage.util;

import com.payegis.tscsecurid.common.util.HMACSHA1;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.core.util.MultivaluedMapImpl;
import net.sf.json.JSONObject;
import org.apache.commons.codec.binary.Base64;
import org.apache.log4j.Logger;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.*;

public class WSUtil {

	private static Logger logger=Logger.getLogger(WSUtil.class);
	
	/**
	 * @param url
	 * @return
	 */
	public static String sendRequest(String url, Map<String,Object> paramMap){
		logger.info("Webservice sendRequest url:"+ url);
		MultivaluedMapImpl params=constructWebserviceParams(paramMap);
		Client client;
		if(url.startsWith("https")){
			client = Client.create(ClientHelper.configureClient());
		}else{
			client = Client.create();
		}
		WebResource rs = client.resource(url);
		
		ClientResponse cr= rs.post(ClientResponse.class, params);
		  
		return cr.getEntity(String.class);
	}
	
	private static MultivaluedMapImpl constructWebserviceParams(Map<String,Object> paramMap){
		if(paramMap==null || paramMap.isEmpty()){
			return null;
		}
		
		MultivaluedMapImpl params = new MultivaluedMapImpl();
		
		for(Iterator<String> it=paramMap.keySet().iterator() ; it.hasNext();){
			String key= it.next();
			params.add(key, paramMap.get(key));
		}
		
		return params;
		
	}
	
	
	private static MultivaluedMapImpl constructWebservice(Map<String,String> paramMap){
		if(paramMap==null || paramMap.isEmpty()){
			return null;
		}
		
		MultivaluedMapImpl params = new MultivaluedMapImpl();
		
		for(Iterator<String> it=paramMap.keySet().iterator() ; it.hasNext();){
			String key= it.next();
			params.add(key, paramMap.get(key));
		}
		
		return params;
		
	}
	
	
	public static String getSig(String appkey, String requestTimeString, HashMap<String,String> parameter){
		try{
			String kvString = "";
			parameter.put("x-hmac-auth-date", requestTimeString);
			//System.out.println("x-hmac-auth-date ==>" + requestTimeString);
			Set<String> listKeys = parameter.keySet();
			int length = listKeys.size();
			Iterator<String> it = listKeys.iterator();
			List<String> list = new ArrayList<String>();
			while(it.hasNext()){
				list.add(it.next());
			}
			Collections.sort(list);
			for(int i=0; i<length; i++){
				String key = list.get(i);
				if(i == length -1){
					kvString += key + "=" + parameter.get(key);
				}else{
					kvString += key + "=" + parameter.get(key) + "&";
				}
			}
			String kvStringE = URLEncoder.encode(kvString,"UTF-8");
			kvString = kvStringE.replace("*", "%2A").replace(" ", "%20");
			logger.info("keys升序排列处理 ==>" + kvString);
			
			//3.method,url,kvString 用&连接
			String firstStep =kvString;
			
			/** Step 2. 构造密钥 */
			String secretoauthkey = appkey;
			secretoauthkey += "&";
			//System.out.println("构造密钥 ==>" + secretoauthkey);
			
			/** step 3. 生成签名值*/
			//1.HMACSHA1加密
			String sig = "";
			byte[] encryption = null;
			try {
				encryption = HMACSHA1.getSignature(firstStep, secretoauthkey);
				//2.Base64编码
				sig = encodeBase64WithoutLinefeed(encryption);
			} catch (Exception e) {
				e.printStackTrace();
			}
			logger.info("生成签名值 sig ==>" + sig); 
			return sig;
		}catch(Exception e){
			e.printStackTrace();
			return "";
		}
		
	}
	
	protected static String encodeBase64WithoutLinefeed(byte[] result) {
        return Base64.encodeBase64String(result).trim();
    }


	public static String sendAppRequest(String tscCode, String url, String appID, String appKey){

		List<HTTPParam> list = new ArrayList<HTTPParam>();
		HTTPParam p = new HTTPParam();
		JSONObject tmp = new JSONObject();

		tmp.put("dcCode", tscCode);
		tmp.put("appId", appID);

		p.setKey("requestData");
		p.setValue(tmp.toString());
		list.add(p);

		String result = null;
		try {
			result = sendPost(url, list, appID, appKey);
		} catch (IOException e) {
			e.printStackTrace();
		}

		return JSONObject.fromObject(result).toString();
	}

	private static String sendPost(String url, List<HTTPParam> list, String appid, String appkey) throws IOException {
		StringBuffer buffer = new StringBuffer(); // 用来拼接参数
		StringBuffer result = new StringBuffer(); // 用来接受返回值

		URL httpUrl = null; // HTTP URL类 用这个类来创建连接
		URLConnection connection = null; // 创建的http连接
		PrintWriter printWriter = null;
		BufferedReader bufferedReader; // 接受连接受的参数
		// 创建URL
		httpUrl = new URL(url);
		// 建立连接
		connection = httpUrl.openConnection();
		connection
				.setRequestProperty("accept",
						"text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8");
		connection.setRequestProperty("connection", "keep-alive");
		connection
				.setRequestProperty("user-agent",
						"Mozilla/5.0 (Windows NT 6.1; WOW64; rv:34.0) Gecko/20100101 Firefox/34.0");

		String requestTimeString = String.valueOf(System.currentTimeMillis());
		connection.setRequestProperty("x-hmac-auth-date", requestTimeString);

		HashMap<String, String> params = new HashMap<String, String>();
		for (int i = 0; i < list.size(); i++) {
			HTTPParam p = list.get(i);
			params.put(p.getKey(), p.getValue());
		}
		String sigStr = SigTool.getSig(appkey, requestTimeString, params);
		connection.setRequestProperty("x-hmac-auth-signature", appid + ":"
				+ sigStr);

		connection.setDoOutput(true);
		connection.setDoInput(true);
		printWriter = new PrintWriter(connection.getOutputStream());
		if (list.size() > 0) {
			for (int i = 0; i < list.size(); i++) {
				buffer.append(list.get(i).getKey())
						.append("=")
						.append(URLEncoder.encode(list.get(i).getValue(),
								"utf-8"));
				// 如果不是最后一个参数，不需要添加&
				if ((i + 1) < list.size()) {
					buffer.append("&");
				}
			}
		}
		printWriter.print(buffer.toString());
		printWriter.flush();
		printWriter.close();
		connection.connect();
		// 接受连接返回参数
		bufferedReader = new BufferedReader(new InputStreamReader(
				connection.getInputStream(), "utf-8"));
		String line;
		while ((line = bufferedReader.readLine()) != null) {
			result.append(line);
		}
		bufferedReader.close();
		return result.toString();
	}
}
