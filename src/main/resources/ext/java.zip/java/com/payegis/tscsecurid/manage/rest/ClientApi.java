package com.payegis.tscsecurid.manage.rest;

import com.payegis.tscsecurid.common.data.entity.SysLog;
import com.payegis.tscsecurid.common.result.ResultBean;
import com.payegis.tscsecurid.common.util.EncryUtil;
import com.payegis.tscsecurid.common.util.StringUtil;
import com.payegis.tscsecurid.manage.common.Constant;
import com.payegis.tscsecurid.manage.service.business.mgr.LogService;
import com.sun.jersey.api.json.JSONWithPadding;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.ws.rs.*;
import java.util.HashMap;
import java.util.List;

@Component
@Path("/api")
public class ClientApi{
    @Autowired
    private LogService logService;
	private static Logger logger = Logger.getLogger(ClientApi.class);


    @Path("/logsApi")
    @POST
    @Produces("application/javascript")
    public JSONWithPadding logsQuery(@QueryParam("jsoncallback") String callback,
                                     @FormParam("enterprise") String enterprise,
                                     @FormParam("account") String account,
                                     @FormParam("logType") String logType,
                                     @FormParam("deviceId") String deviceId,
                                     @FormParam("endTime") String endTime,
                                     @FormParam("startTime") String startTime,
                                     @FormParam("x-hmac-auth-date") String requestTimeString,
                                     @FormParam("x-hmac-auth-signature") String oldSign,
                                     @FormParam("page") String page,
                                     @FormParam("rows") String rows) {
        net.sf.json.JSONObject json = new net.sf.json.JSONObject();
        HashMap<String, String> parameter = new HashMap<String, String>();
        boolean isTrue = false;
        if(null != requestTimeString && null != oldSign)
            isTrue = EncryUtil.checkSign0(requestTimeString, parameter, oldSign, Constant.CLOUD_APP_KEY);
        if (!isTrue) {
            return new JSONWithPadding(buildJSON(Constant.API_STATUS_FAIL, "签名校验未通过！", json).toString(),callback);
        }

        if (StringUtil.isEmpty(enterprise) && StringUtil.isEmpty(account)) {
            return new JSONWithPadding(buildJSON(Constant.API_STATUS_FAIL, "参数不合法！", json).toString(), callback);
        }

        SysLog sysLog = new SysLog();
        if (null != enterprise && StringUtil.isNotEmpty(enterprise.trim()))
            sysLog.setEnterpriseId(Integer.parseInt(enterprise));
        sysLog.setOrder("DESC");
        sysLog.setLogType(logType);
        sysLog.setDeviceId(deviceId);
        sysLog.setBindingAccount(account);
        sysLog.setEndTime(endTime);
        sysLog.setStartTime(startTime);
        if(null != page)
            sysLog.setPage(Integer.parseInt(page));
        if(null != rows)
            sysLog.setRows(Integer.parseInt(rows));
        ResultBean resBean = logService.listAllLogs(sysLog);
        if (null != resBean) {
            List<SysLog> sysLogs = resBean.getRows();
            int total = resBean.getTotal();
            json.put("total", total);
            net.sf.json.JSONObject logJson;
            net.sf.json.JSONArray result = new net.sf.json.JSONArray();
            for (SysLog log : sysLogs) {
                logJson = new net.sf.json.JSONObject();
                logJson.put("alias", log.getAlias());
                logJson.put("deviceId", log.getDeviceId());
                logJson.put("bindingAccount", log.getBindingAccount());
                logJson.put("logType", log.getLogType());
                logJson.put("logTime", log.getLogTime());
                result.add(logJson);
            }
            json.put(Constant.JSON_KEY_DATA, result);
        }
        return new JSONWithPadding(buildJSON(Constant.API_STATUS_SUCCESS, null, json).toString(), callback);
    }

    protected String buildJSON(String status, String message, Object object) {
        net.sf.json.JSONObject json = new net.sf.json.JSONObject();
        json.put(Constant.JSON_KEY_STATUS, status);
        json.put(Constant.JSON_KEY_MESSAGE, message);
        json.put(Constant.JSON_KEY_RESULT, object);
        return outputJson(json);
    }

    private String outputJson(net.sf.json.JSONObject json) {
        String str = json.toString();
        logger.info("output json >>> " + str + " <<<");
        return str;
    }
}
