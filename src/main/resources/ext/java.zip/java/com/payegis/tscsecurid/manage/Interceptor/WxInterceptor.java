package com.payegis.tscsecurid.manage.Interceptor;

import com.payegis.tscsecurid.common.util.PropertyUtil;
import com.payegis.tscsecurid.manage.bean.WxSessionManagerFactory;
import com.payegis.tscsecurid.manage.common.Constant;
import me.chanjar.weixin.common.exception.WxErrorException;
import me.chanjar.weixin.common.session.WxSession;
import me.chanjar.weixin.common.session.WxSessionManager;
import me.chanjar.weixin.mp.api.WxMpInMemoryConfigStorage;
import me.chanjar.weixin.mp.api.WxMpMessageInterceptor;
import me.chanjar.weixin.mp.api.WxMpService;
import me.chanjar.weixin.mp.api.WxMpServiceImpl;
import me.chanjar.weixin.mp.bean.WxMpXmlMessage;
import me.chanjar.weixin.mp.bean.WxMpXmlOutMessage;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Map;

/**
 * Created by zzg on 2015/7/20.
 */
public class WxInterceptor extends HandlerInterceptorAdapter implements WxMpMessageInterceptor   {
    @Override
    public boolean intercept(WxMpXmlMessage wxMpXmlMessage, Map<String, Object> stringObjectMap, WxMpService wxMpService, WxSessionManager wxSessionManager) throws WxErrorException {
        boolean flag = true;
        wxSessionManager = WxSessionManagerFactory.getInstance();
        WxSession session = wxSessionManager.getSession(wxMpXmlMessage.getFromUserName());
        if(null == session || null == session.getAttribute("hasLogin") || !session.getAttribute("hasLogin").equals("Y"))
            flag =  false;
        return flag;
    }

    public WxMpXmlOutMessage handle(WxMpXmlMessage wxMessage,
                                   Map<String, Object> context,
                                   WxMpService wxMpService,
                                   WxSessionManager sessionManager){
        return null;
    }
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        request.setCharacterEncoding("UTF-8");
        response.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");
        WxMpInMemoryConfigStorage config = new WxMpInMemoryConfigStorage();
        config.setAppId(PropertyUtil.getPropertyValue("config.properties", "wx.appid")); // 设置微信公众号的appid
        config.setSecret(PropertyUtil.getPropertyValue("config.properties", "wx.secret")); // 设置微信公众号的app corpSecret
        config.setToken(PropertyUtil.getPropertyValue("config.properties", "wx.token")); // 设置微信公众号的token
        config.setAesKey(Constant.WX_AESKEY); // 设置微信公众号的EncodingAESKey
        WxMpServiceImpl wxService = new WxMpServiceImpl();
        wxService.setWxMpConfigStorage(config);

        String signature = request.getParameter("signature");
        String nonce = request.getParameter("nonce");
        String timestamp = request.getParameter("timestamp");

        if (!wxService.checkSignature(timestamp, nonce, signature)) {
            // 消息签名不正确，说明不是公众平台发过来的消息
            response.getWriter().println("非法请求");
            return false;

        }
        return super.preHandle(request, response, handler);
    }







}
