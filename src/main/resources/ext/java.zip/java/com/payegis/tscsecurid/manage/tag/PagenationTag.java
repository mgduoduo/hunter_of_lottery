package com.payegis.tscsecurid.manage.tag;

import com.payegis.tscsecurid.manage.common.PageBean;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import com.payegis.tscsecurid.manage.util.PageUtil;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.TagSupport;
import java.io.IOException;



/**
 * @author zhangwei
 */
public class PagenationTag extends TagSupport {
	private static final long serialVersionUID = 1515336547386092165L;
	private static final Logger logger = Logger.getLogger(PagenationTag.class);

	private String resultKey;
	private int pageNo;
	private int pageSize;
	private int totalRecords = 0;
	private String url;
	private String style;
	private String javascript;
	private String onclick;
	private String param;

	@Override
	public int doStartTag() throws JspException {
		if (!StringUtils.isEmpty(resultKey)) {
			PageBean bean = getResult();
			if (bean != null) {
				totalRecords = bean.getTotalRows();
				pageNo = bean.getCurrentPage();
				pageSize = bean.getPageSize();

				if (pageNo < 1) {
					pageNo = 1;
				}
				if (pageSize < 1) {
					pageSize = 10;
				}

			}
		}

		if (totalRecords > 0) {
			PageUtil pu = new PageUtil(totalRecords, pageNo, pageSize, url,
					param, javascript, onclick, style);

			StringBuffer sb = new StringBuffer();
			sb.append(pu.descriptPageLink());

			try {
				pageContext.getOut().println(sb.toString());
			} catch (IOException e) {
				logger.warn("IOException", e);
				logger.debug("Encounter an exception when parse com.payegis.tscsecurid.manage.tag."
						+ e.getMessage());
			}

		}
		return SKIP_BODY;
	}

	@Override
	public int doEndTag() throws JspException {
		return EVAL_PAGE;
	}

	private PageBean getResult() {
		PageBean result = (PageBean) this.pageContext.getAttribute(resultKey);
		if (result == null) {
			result = (PageBean) this.pageContext.getRequest().getAttribute(
					resultKey);
		}

		if (result == null) {
			result = (PageBean) this.pageContext.getSession().getAttribute(
					resultKey);
		}

		return result;
	}

	public int getPageNo() {
		return pageNo;
	}

	public void setPageNo(int pageNo) {
		this.pageNo = pageNo;
	}

	public int getPageSize() {
		return pageSize;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

	public int getTotalRecords() {
		return totalRecords;
	}

	public void setTotalRecords(int totalRecords) {
		this.totalRecords = totalRecords;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getStyle() {
		return style;
	}

	public void setStyle(String style) {
		this.style = style;
	}

	public String getJavascript() {
		return javascript;
	}

	public void setJavascript(String javascript) {
		this.javascript = javascript;
	}

	public String getParam() {
		return param;
	}

	public void setParam(String param) {
		this.param = param;
	}

	public String getResultKey() {
		return resultKey;
	}

	public void setResultKey(String resultKey) {
		this.resultKey = resultKey;
	}

	public String getOnclick() {
		return onclick;
	}

	public void setOnclick(String onclick) {
		this.onclick = onclick;
	}

}
