package com.payegis.tscsecurid.manage.util;


import org.apache.commons.codec.digest.DigestUtils;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.*;

import javax.crypto.Mac;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

public class SigTool {

	public static String getSignature(String timestamp, String noncestr, String jsapiTicket, String requestUrl) {
		String[] array = {"jsapi_ticket=" + jsapiTicket, "noncestr=" + noncestr, "timestamp=" + timestamp, "url=" + requestUrl};
		//Arrays.sort(array);
		String signature = array[0].concat("&" + array[1]).concat("&" + array[2]).concat("&" + array[3]);
		signature = DigestUtils.sha1Hex(signature);
		return signature;
	}
	
	public static String getSig(String appkey, String requestTimeString,
			Map<String, String> parameter) throws UnsupportedEncodingException {
		String kvString = "";
		if (null == parameter) {
			parameter = new HashMap<String, String>();
		}
		parameter.put("x-hmac-auth-date", requestTimeString);
		Set<String> listKeys = parameter.keySet();
		int length = listKeys.size();
		Iterator<String> it = listKeys.iterator();
		List<String> list = new ArrayList<String>();
		while (it.hasNext()) {
			list.add(it.next());
		}
		Collections.sort(list);
		for (int i = 0; i < length; i++) {
			String key = list.get(i);
			if (i == length - 1) {
//				String value = parameter.get(key);
//				String deValue = URLDecoder.decode(value, "UTF-8");
//				kvString += key + "=" + deValue;
				kvString += key + "=" + parameter.get(key);
			} else {
//				String value = parameter.get(key);
//				String deValue = URLDecoder.decode(value, "UTF-8");
//				kvString += key + "=" + deValue + "&";
				kvString += key + "=" + parameter.get(key) + "&";
			}
		}
		String kvStringE = URLEncoder.encode(kvString, "UTF-8");
		kvString = kvStringE.replace("*", "%2A").replace("+", "%20");
		//Log.e("requestdata","keys升序排列处理 ==>" + kvString);

		// 3.method,url,kvString 用&连接
		String firstStep = kvString;

		/** Step 2. 构造密钥 */
		String secretoauthkey = appkey;
		secretoauthkey += "&";
		//Log.i("requestdata","构造密钥 ==>" + secretoauthkey);

		/** step 3. 生成签名值 */
		// 1.HMACSHA1加密
		String sig = "";
		byte[] encryption = null;
		try {
			encryption = HmacSHA1Encrypt(firstStep, secretoauthkey);
			// 2.Base64编码
			sig = encodeBase64WithoutLinefeed(encryption);
		} catch (Exception e) {
			e.printStackTrace();
		}
		//Log.i("requestdata","生成签名值 sig ==>" + sig);
		return sig;

	}

	/**
	 * 使用 HMAC-SHA1 签名方法对对encryptText进行签名
	 * 
	 * @param encryptText
	 *            被签名的字符串
	 * @param encryptKey
	 *            密钥
	 * @return
	 * @throws Exception
	 */
	public static byte[] HmacSHA1Encrypt(String encryptText, String encryptKey)
			throws Exception {
		byte[] data = encryptKey.getBytes("UTF-8");
		// 根据给定的字节数组构造一个密钥,第二参数指定一个密钥算法的名称
		SecretKey secretKey = new SecretKeySpec(data, "HmacSHA1");
		// 生成一个指定 Mac 算法 的 Mac 对象
		Mac mac = Mac.getInstance("HmacSHA1");
		// 用给定密钥初始化 Mac 对象
		mac.init(secretKey);

		byte[] text = encryptText.getBytes("UTF-8");
		// 完成 Mac 操作
		return mac.doFinal(text);
	}
	
	
	
	/**
	 * encode with base64
	 * 
	 * @param result
	 * @return
	 * @throws java.io.UnsupportedEncodingException
	 */
	protected static String encodeBase64WithoutLinefeed(byte[] result)
			throws UnsupportedEncodingException {
		return new String(Base64.encode(result, Base64.NO_WRAP), "UTF-8");
	}

}
