package com.payegis.tscsecurid.manage.util;

import com.payegis.tscsecurid.manage.spring.ApplicationContextProvider;

import java.util.Locale;



public class MessageUtil {

	/**
	 * 获取语言类型
	 * 
	 * @param language
	 *            语言
	 * @return
	 */
	private static Locale getLocal(String language) {
		Locale locale = Locale.SIMPLIFIED_CHINESE;
		if (language != null && language.startsWith("en")) {
			locale = Locale.ENGLISH;
		}
		if (language != null && language.equals("zh_TW")) {
			locale = Locale.TRADITIONAL_CHINESE;
		}
		return locale;
	}

	/**
	 * 获取国际化信息
	 * 
	 * @param code
	 *            信息key
	 * @param args
	 *            占位符参数
	 * @param language
	 *            语言
	 * @return 国家化信息
	 */
	public static String getMessage(String code, Object[] args, String language) {
		return ApplicationContextProvider.getApplicationContext().getMessage(
				code, args, getLocal(language));
	}
	
}
