package com.payegis.tscsecurid.manage.service.impl.mgr;


import com.payegis.tscsecurid.common.data.entity.MgrMenu;
import com.payegis.tscsecurid.common.mapper.BaseMapper;
import com.payegis.tscsecurid.common.mapper.MgrMenuMapper;
import com.payegis.tscsecurid.common.service.BaseServiceImpl;
import com.payegis.tscsecurid.manage.service.business.mgr.MenuService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MenuServiceImpl extends BaseServiceImpl implements MenuService {

	@Autowired
	private MgrMenuMapper menuMapper;

	@Override
	public List<MgrMenu> retrieveMenus() {
		return menuMapper.getMenus();
	}

	@Override
	public MgrMenu retrieveMenuById(String id) {
		return menuMapper.selectByPrimaryKey(Integer.valueOf(id));
	}

	@Override
	public void updateMenu(MgrMenu entity) {
		menuMapper.updateByPrimaryKeySelective(entity);
	}

	@Override
	public void createMenu(MgrMenu entity) {
		menuMapper.insertSelective(entity);
	}

	@Override
	public void delMenuById(int id) {
        List<MgrMenu> subMenus = menuMapper.getSubMenus(id);
        for (MgrMenu m:subMenus){
            menuMapper.deleteByPrimaryKey(m.getMenuId());
        }
		menuMapper.deleteByPrimaryKey(id);
	}

   @Override
   protected BaseMapper getMapper() {
      return menuMapper;
   }

}
