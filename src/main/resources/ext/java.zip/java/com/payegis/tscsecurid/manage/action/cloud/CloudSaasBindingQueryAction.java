package com.payegis.tscsecurid.manage.action.cloud;

import com.payegis.tscsecurid.common.data.bo.BindingInfoEnterpriseQueryBo;
import com.payegis.tscsecurid.common.data.entity.BindingInfoEnterprise;
import com.payegis.tscsecurid.common.result.ResultBean;
import com.payegis.tscsecurid.manage.service.business.system.BindingInfoEnterpriseService;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * Created by liucheng on 2014/12/9.
 */

@Controller
@RequestMapping("/saas")
public class CloudSaasBindingQueryAction {
    private static final Logger logger = Logger.getLogger(CloudUNBindingAction.class);

    @ModelAttribute("search_url")
    public String getSearchUrl() {
        return "/saas/bind/search";
    }

    @Autowired
    BindingInfoEnterpriseService bindingInfoEnterpriseService;

    @RequestMapping("/bind")
    public String showUnbindSupply(Model model) {
        return "page/saas/bind";
    }

    @RequestMapping("/bind/search")
    public String search(BindingInfoEnterpriseQueryBo queryBo,Model model) {
        if (StringUtils.isNotEmpty(queryBo.getStartDate())) {
            queryBo.setStartDate(queryBo.getStartDate() + " 00:00:00");
        }
        if (StringUtils.isNotEmpty(queryBo.getEndDate())) {
            queryBo.setEndDate(queryBo.getEndDate() + " 23:59:59");
        }
        ResultBean<BindingInfoEnterprise> bindingInfoResultBean = bindingInfoEnterpriseService.getPageList(queryBo);
        model.addAttribute("result", bindingInfoResultBean);
        return "page/saas/bind_list";
    }

}
