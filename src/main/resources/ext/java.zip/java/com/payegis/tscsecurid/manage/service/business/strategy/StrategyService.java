package com.payegis.tscsecurid.manage.service.business.strategy;


import com.payegis.tscsecurid.common.data.entity.StrategyConfig;
/**
 * Created by zzg on 2014/12/9.
 */
public interface StrategyService {



    /**
     * 保存配置
     * @return
     */
    public int save(StrategyConfig param);

    /**
     * 更新配置
     * @return
     */
    public int update(StrategyConfig param);


    /**
     * 查找数据库中有无配置记录
     * @return
     */
    public StrategyConfig findObj();

    int updateSecIden(StrategyConfig config);

    public StrategyConfig findObjBySystemNo(String systemNo);
}
