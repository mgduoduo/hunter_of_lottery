package com.payegis.tscsecurid.manage.service.business.customer;

import com.payegis.tscsecurid.common.data.bo.BindingInfoBo;
import com.payegis.tscsecurid.common.data.bo.BindingLogBo;
import com.payegis.tscsecurid.common.data.bo.DIDDetailBo;
import com.payegis.tscsecurid.common.data.entity.BindingLog;
import com.payegis.tscsecurid.common.data.entity.BusinessSystem;
import com.payegis.tscsecurid.common.service.BaseService;

import java.util.List;

/**
 * Created by liucheng on 2014/11/13.
 */
public interface CustomerService extends BaseService{

    BindingInfoBo getBindingInfoByPrimaryKey(Integer bindId);

    List<BusinessSystem> getBusinessSystemByUser(Integer user);

    void saveUnBinding(BindingLog log, Integer bindingInfoId);

    List<BindingLogBo> selectAccountHistory(BindingLog bindingLog);

    DIDDetailBo getDIDDetail(String did, Integer enterpriseId);
}
