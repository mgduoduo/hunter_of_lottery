package com.payegis.tscsecurid.manage.service.business.system;

import com.payegis.tscsecurid.common.data.bo.BindingInfoBo;
import com.payegis.tscsecurid.common.data.bo.BindingLogEnterpriseBo;
import com.payegis.tscsecurid.common.data.entity.BindingInfoEnterprise;
import com.payegis.tscsecurid.common.data.entity.BindingLog;
import com.payegis.tscsecurid.common.data.entity.BindingLogEnterprise;
import com.payegis.tscsecurid.common.service.BaseService;

import java.util.List;

/**
 * Created by liucheng on 2014/12/9.
 */

public interface BindingInfoEnterpriseService extends BaseService {
    BindingInfoEnterprise getBindingInfoByPrimaryKey(Integer bindId);

    void saveUnBinding(BindingLogEnterprise log, Integer bindingInfoId);

    List<BindingLogEnterpriseBo> selectAccountHistory(BindingLogEnterprise bindingLog);
}
