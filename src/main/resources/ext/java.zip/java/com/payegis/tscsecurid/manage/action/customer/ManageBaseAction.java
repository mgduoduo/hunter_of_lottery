package com.payegis.tscsecurid.manage.action.customer;

import com.alibaba.fastjson.JSONObject;
import com.payegis.tscsecurid.common.action.BaseAction;
import com.payegis.tscsecurid.common.data.entity.SysUser;
import com.payegis.tscsecurid.manage.common.Constant;
import com.payegis.tscsecurid.manage.common.MessageConstant;
import com.payegis.tscsecurid.manage.common.SessionInfo;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.io.Serializable;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;


public class ManageBaseAction extends BaseAction implements Constant, MessageConstant {

   protected SessionInfo getSessionInfo(HttpSession session) {
       SessionInfo sessionInfo = (SessionInfo) session
               .getAttribute(KEY_SESSION_INFO);
       if (sessionInfo == null) {
           sessionInfo = new SessionInfo();
           session.setAttribute(KEY_SESSION_INFO, sessionInfo);
       }
       return sessionInfo;

   }

   protected void setMessage(String type, String messageCode,
           HttpServletRequest request) {
       Map<String, String> messageMap = (Map<String, String>) request
               .getAttribute(KEY_REQUEST_MESSAGE);
       if (messageMap == null) {
           messageMap = new HashMap<String, String>();
       }

       messageMap.put(type, messageCode);
       request.setAttribute(KEY_REQUEST_MESSAGE, messageMap);
   }

   protected Map<String, String> getMessage(String type, String messageCode,
           HttpServletRequest request) {
       Map<String, String> messageMap = (Map<String, String>) request
               .getAttribute(KEY_REQUEST_MESSAGE);
       if (messageMap == null) {
           messageMap = new HashMap<String, String>();

       }
       messageMap.put(type, messageCode);
       return messageMap;
   }

   protected void setCurrentTopMenu(String menuKey, HttpServletRequest request) {
       request.setAttribute(KEY_REQUEST_CURRENT_TOP_MENU, menuKey);
   }

   protected void setCurrentLeftMenu(String menuKey, HttpServletRequest request) {
       request.setAttribute(KEY_REQUEST_CURRENT_LEFT_MENU, menuKey);
   }

   protected String getCurretnUserName(HttpServletRequest request) {
       SysUser user = this.getSessionInfo(request.getSession()).getLoginUser();
       if (user == null) {
           return "noboday";
       }
       return user.getUserName();
   }

   protected void clearSession(HttpServletRequest request) {
       HttpSession session = request.getSession();
       Enumeration names = session.getAttributeNames();

       while (names.hasMoreElements()) {
           String attrName = (String) names.nextElement();
           session.removeAttribute(attrName);
       }

   }

   /***************************************************************************************************************************
    * Common JSON object *
    * *************************************************************************************************************************/
   public class CommonJSON implements Serializable {
       /**
        * 
        */
       private static final long serialVersionUID = 6638198187315651901L;
       private String status;
       private String message;
       private Object data;

       public CommonJSON() {
       }

       public CommonJSON(String status, String message) {
           super();
           this.status = status;
           this.message = message;
       }

       public CommonJSON(String status, String message, Object data) {
           super();
           this.status = status;
           this.message = message;
           this.data = data;
       }

       public String getStatus() {
           return status;
       }

       public void setStatus(String status) {
           this.status = status;
       }

       public String getMessage() {
           return message;
       }

       public void setMessage(String message) {
           this.message = message;
       }

       public Object getData() {
           return data;
       }

       public void setData(Object data) {
           this.data = data;
       }

       @Override
       public String toString() {
           JSONObject job= (JSONObject) JSONObject.toJSON(this);
           String result = job.toString();
           //System.out.println(result);
           return result;
       }

   }
}
