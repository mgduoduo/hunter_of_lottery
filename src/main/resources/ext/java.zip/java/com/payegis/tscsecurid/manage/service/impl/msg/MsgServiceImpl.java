package com.payegis.tscsecurid.manage.service.impl.msg;

import com.alibaba.fastjson.JSONObject;
import com.payegis.tscsecurid.common.constant.PropertyFileKeys;
import com.payegis.tscsecurid.common.data.bo.DeviceQueryBo;
import com.payegis.tscsecurid.common.data.bo.DeviceSelectBo;
import com.payegis.tscsecurid.common.data.bo.SysMsgQueryBo;
import com.payegis.tscsecurid.common.data.bo.SysMsgTopicQueryBo;
import com.payegis.tscsecurid.common.data.entity.BusinessSystem;
import com.payegis.tscsecurid.common.data.entity.SysMsg;
import com.payegis.tscsecurid.common.data.entity.SysMsgTopic;
import com.payegis.tscsecurid.common.mapper.BusinessSystemMapper;
import com.payegis.tscsecurid.common.mapper.SysMsgMapper;
import com.payegis.tscsecurid.common.mapper.SysMsgTopicMapper;
import com.payegis.tscsecurid.common.mapper.SysUserMapper;
import com.payegis.tscsecurid.common.result.ResultBean;
import com.payegis.tscsecurid.common.util.DateUtil;
import com.payegis.tscsecurid.common.util.PropertyUtil;
import com.payegis.tscsecurid.common.util.StringUtil;
import com.payegis.tscsecurid.common.util.ToolUtil;
import com.payegis.tscsecurid.manage.common.MessageConstant;
import com.payegis.tscsecurid.manage.service.business.msg.MsgService;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.representation.Form;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.ws.rs.core.MediaType;

import java.util.*;

@Service
public class MsgServiceImpl implements MsgService, MessageConstant {

	@Autowired
	private SysMsgMapper sysMsgMapper;

	@Autowired
	private SysMsgTopicMapper sysMsgTopicMapper;

	@Autowired
	SysUserMapper sysUserMapper;

	@Autowired
	BusinessSystemMapper businessSystemMapper;

    /*@Autowired
    private AccountApi api;*/

	@Override
	public ResultBean listAll(SysMsgQueryBo param) {
		if (StringUtil.isNotEmpty(param.getStartTime()))
			param.setStartTime(param.getStartTime()
					+ " 00:00:00");
		if (StringUtil.isNotEmpty(param.getEndTime()))
			param.setEndTime(param.getEndTime() + " 23:59:59");
		ResultBean result = new ResultBean();
		List<Object> sms = sysMsgMapper.listAll(param);
		List<SysMsg> smsNew = new ArrayList<SysMsg>();
		List<String> accounts;
		for (Object sm : sms) {
			SysMsg msg = (SysMsg) sm;
			accounts = sysMsgMapper.selectAccountWrapWithDeviceId(msg
					.getDeviceId());
			if (null != accounts && !accounts.isEmpty()) {
				if (accounts.size() > 2) {
					accounts.remove(2);
					msg.setAccountWrap(StringUtils.join(accounts, ",") + "...");
				} else
					msg.setAccountWrap(StringUtils.join(accounts, ","));
			}
			smsNew.add(msg);
		}
		result.setRows(smsNew);
		result.setTotal(sysMsgMapper.count(param));
		return result;
	}

	@Override
	public int save(SysMsg param) {
		return 0;
	}

	@Override
	public int update(SysMsg param) {
		return 0;
	}

	@Override
	public SysMsg findById(Integer MsgId) {
		return null;
	}

	@Override
	public List<BusinessSystem> findBusinessSystemsByUserId(Integer userId) {
		return businessSystemMapper.selectBySysUserId(userId);
	}

	@Override
	public ResultBean listSysMsgTopics(SysMsgTopicQueryBo param) {
		if (StringUtil.isNotEmpty(param.getStartTime1()))
			param.setStartTime1(param.getStartTime1()
					+ " 00:00:00");
		if (StringUtil.isNotEmpty(param.getEndTime1()))
			param.setEndTime1(param.getEndTime1()
					+ " 23:59:59");
		ResultBean result = new ResultBean();
		List<Object> smts = sysMsgTopicMapper.listAll(param);
		result.setRows(smts);
		result.setTotal(sysMsgTopicMapper.count(param));
		return result;
	}

	@Override
	public SysMsgTopic selectMsgTopicByPrimaryKey(Integer msgTopicId) {
		SysMsgTopic sm = sysMsgTopicMapper.selectByPrimaryKey(msgTopicId);
		if (null != sm) {
			List<String> deviceIds = sysMsgTopicMapper
					.selectDeviceIdsByMsgTopicId(msgTopicId);
			if (null != deviceIds && !deviceIds.isEmpty()) {
				List<Map<String, String>> sendDetails = new ArrayList<Map<String, String>>();
				String accounts;
				Map<String, String> detail;
				for (String deviceId : deviceIds) {
                    detail = new HashMap<String, String>();
					accounts = StringUtils.join(sysMsgMapper
							.selectAccountWrapWithDeviceId(deviceId), ",");
					detail.put(deviceId, accounts);
					sendDetails.add(detail);
				}
				sm.setSendDetails(sendDetails);
			}
		}
		return sm;
	}

	@Override
	public int saveMsgTopic(DeviceQueryBo smt) {
		int msgTopicId = 1;
		List<String> deviceIds = smt.getDeviceIdLst();
		if (null != deviceIds && !deviceIds.isEmpty()) {
			smt.setSendAmount(deviceIds.size());
			smt.setSendTime(DateUtil.getCurrentDateString());
			msgTopicId = sysMsgTopicMapper.insertSelective(smt);
			if (msgTopicId > -1) {
				SysMsg sm ;
				List<SysMsg> sms = new ArrayList<SysMsg>();
				for (String deviceId : deviceIds) {
                    sm = new SysMsg();
					sm.setEnterpriseId(smt.getEnterpriseId());
					sm.setDeviceId(deviceId);
					sm.setMsgTopicId(smt.getMsgTopicId());
					sm.setMsgType("topic");
					sm.setMsgContent(smt.getMsgContent());
					sm.setSendTime(smt.getSendTime());
					sysMsgMapper.insertSelective(sm);
					sms.add(sm);
				}
				if(ToolUtil.isNotEmpty(sms)){
					new Thread(new MsgPush(sms,smt.getMsgTitle())).start();
				}
			}
		}

		return msgTopicId;
	}

	class MsgPush implements Runnable{
		private List<SysMsg> sms;
        private String title;
		public MsgPush(List<SysMsg> sms,String title) {
            this.sms = sms;
            this.title=title;
		}
		@Override
		public void run() {
			// 调接口
			if(ToolUtil.isNotEmpty(sms)){
				for(SysMsg sm : sms){
                    String url = PropertyUtil.getPropertyValue("config.properties", "push.url");
                    HashMap<String,String> param = new HashMap<String, String>();
                    final String messageContent = "{\"type\":\"" + PropertyFileKeys.MSG_PUSH_TYPE_SYSTEM + "\"," +
                            "\"ctx\":\"" + sm.getMsgContent()+ "\"}";
                    param.put("deviceId",sm.getDeviceId());
                    param.put("msgContent",messageContent);
                    param.put("msgTitle",title);

                    try {
                        String result = sendRequestPostWithFormData(url,param);
                        net.sf.json.JSONObject obj = net.sf.json.JSONObject.fromObject(result);
                        if(obj.get("status").equals("0")){
                            sm.setIsSend("Y");
                            sysMsgMapper.updateByPrimaryKeySelective(sm);
                        }

                    }catch (Exception e){
                        continue;
                    }

				}
			}
			
		}
	}
    public static String sendRequestPostWithFormData(String url, Map<String,String> param){
        Form formParam = new Form();
        for(Map.Entry<String,String> entry:param.entrySet()){
            formParam.add(entry.getKey(), entry.getValue());
        }
        Client client = Client.create();
        WebResource rs = client.resource(url);
        ClientResponse cr= rs.type(MediaType.APPLICATION_JSON_TYPE).post(ClientResponse.class, formParam);
        String result = cr.getEntity(String.class);
        return result;
    }
	@Override
	public List<String> selectDeviceIds(DeviceQueryBo param) {
		return sysMsgMapper.selectDeviceIds(param);
	}

	@Override
	public DeviceQueryBo getNewDeviceQueryBo(DeviceQueryBo deviceQueryBo) {
		if (deviceQueryBo.getRange() == 1) {
			deviceQueryBo.setSystemId(null);
			deviceQueryBo.setDeviceIdStr(null);
            deviceQueryBo.setDeviceIdLst(selectDeviceIds(deviceQueryBo));
		} else if (deviceQueryBo.getRange() == 2) {
			deviceQueryBo.setDeviceIdStr(null);
            deviceQueryBo.setDeviceIdLst(selectDeviceIds(deviceQueryBo));
		} else if (deviceQueryBo.getRange() == 3) {
			deviceQueryBo.setSystemId(null);
			if (!StringUtil.isEmptyStr(deviceQueryBo.getDeviceIdStr())) {
				String[] arr = deviceQueryBo.getDeviceIdStr().split(",");
				deviceQueryBo.setDeviceIdLst(Arrays.asList(arr));
			}

		}
		return deviceQueryBo;
	}

	@Override
	public ResultBean listAllDeviceSelect(DeviceSelectBo deviceSelectBo) {
		ResultBean result = new ResultBean();
		List<Object> ds = businessSystemMapper
				.listAllDeviceSelect(deviceSelectBo);
		List<DeviceSelectBo> smsNew = new ArrayList<DeviceSelectBo>();
		List<String> accounts;
		for (Object sm : ds) {
			if (sm == null)
				continue;
			DeviceSelectBo msg = (DeviceSelectBo) sm;
			accounts = sysMsgMapper.selectAccountWrapWithDeviceId(msg
					.getDeviceId());
			if (null != accounts && !accounts.isEmpty()) {
				if (accounts.size() > 2) {
					accounts.remove(2);
					msg.setAccountWrap(StringUtils.join(accounts, ",") + "...");
				} else
					msg.setAccountWrap(StringUtils.join(accounts, ","));
			}
			smsNew.add(msg);
		}
        result.setRows(smsNew);

        result.setTotal(businessSystemMapper
				.countAllDeviceSelect(deviceSelectBo));
		return result;
	}
}
