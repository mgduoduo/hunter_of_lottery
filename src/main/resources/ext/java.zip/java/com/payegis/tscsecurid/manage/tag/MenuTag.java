package com.payegis.tscsecurid.manage.tag;


import com.payegis.tscsecurid.common.data.entity.MgrMenu;
import com.payegis.tscsecurid.manage.common.Constant;
import com.payegis.tscsecurid.manage.common.SessionInfo;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.TagSupport;
import java.io.IOException;
import java.util.List;

public class MenuTag extends TagSupport {
    private static Logger logger = Logger.getLogger(MenuTag.class);

    private static final long serialVersionUID = -7586286213014517034L;
    private String id;
    private String cssClass;
    private String childClass;

    private String path;

    @Override
    public int doStartTag() throws JspException {
        path = ((HttpServletRequest) pageContext.getRequest()).getContextPath();
        StringBuffer sb = new StringBuffer(1024);

        sb.append("<div");
        if (!StringUtils.isEmpty(id)) {
            sb.append(" id=\"" + id + "\" ");
        }
        if (!StringUtils.isEmpty(cssClass)) {
            sb.append(" class=\"" + cssClass + "\"");
        }
        sb.append(">");

        SessionInfo sessionInfo = (SessionInfo) pageContext.getSession()
                .getAttribute(Constant.KEY_SESSION_INFO);

        if (null != sessionInfo) {
            List<MgrMenu> menus = sessionInfo.getLoginUser().getMenus();
            sb.append(buildMenuTag(menus));
            /*for (MgrMenu m : menus) {
                prepareView(m, sb);
            }*/
        }

        sb.append("</div>");
        logger.debug("menu:" + sb.toString());
        try {
            pageContext.getOut().println(sb.toString());
        } catch (IOException e) {
            logger.warn("IOException", e);
        }

        return SKIP_BODY;
    }

    private String buildMenuTag(List<MgrMenu> menus) {
        StringBuffer main = new StringBuffer(512);
        StringBuffer subMenu = new StringBuffer(1024);
        if (CollectionUtils.isNotEmpty(menus)) {
            main.append("<ul id=\"h-nav\">");
            subMenu.append("<div id=\"h-menu_con\">");
            for (int i = 0; i < menus.size(); i++) {
                final MgrMenu menu = menus.get(i);
                if (CollectionUtils.isEmpty(menu.getSubMenus())) continue;
                if (0 == i) {
                    main.append("<li><a id=\"mynav").append(i).append("\"")
                            .append(" href=\"").append(path).append(menu.getUrl()).append("?menuId=").append(i).append("&subMenuId=0")
                            .append("\" class=\"nav_off\" onmouseover=javascript:qiehuan(")
                            .append(i).append(")><span>").append("<img src=\"").append(path).append(menu.getMenuIconMdbKey()).append("\"/>")
                            .append(menu.getMenuName()).append("</span></a></li>");
                    subMenu.append("<div style=\"display: block\" id=\"qh_con").append(i).append("\">").append("<ul>");
                } else {
                    main.append("<li><a id=\"mynav").append(i).append("\"")
                            .append(" href=\"").append(path).append(menu.getUrl()).append("?menuId=").append(i).append("&subMenuId=0")
                            .append("\" class=\"nav_off\" onmouseover=javascript:qiehuan(")
                            .append(i).append(")><span>").append("<img src=\"").append(path).append(menu.getMenuIconMdbKey()).append("\"/>")
                            .append(menu.getMenuName()).append("</span></a></li>");
                    subMenu.append("<div style=\"display: none\" id=\"qh_con").append(i).append("\">").append("<ul>");
                }
                for (int j = 0; j < menu.getSubMenus().size(); j++) {
                    MgrMenu mgrMenu = menu.getSubMenus().get(j);
                    subMenu.append("<li id=\"subMenu").append(i).append("_").append(j).append("\"><a href=\"")
                            .append(path).append(mgrMenu.getUrl()).append("?menuId=").append(i)
                            .append("&subMenuId=").append(j)
                            .append("\"><span>").append(mgrMenu.getMenuName()).append("</span></a></li>");

                    subMenu.append("<li class=\"h-menu_line2\"></li>");
                }
                subMenu.append("</ul></div>");
            }
            main.append("</ul>");
            subMenu.append("</div>");
        }
        return main.append(subMenu).toString();
    }

    @Override
    public int doEndTag() throws JspException {
        return EVAL_PAGE;
    }

    private void prepareView(MgrMenu m, StringBuffer sb) {

        if (null != m.getSubMenus() && !m.getSubMenus().isEmpty()) {

            sb.append("<div class=\"title no_1\"><h3>" + m.getMenuName() + "</h3><a href='javascript:void(0)'  class=\"s1\" onclick=\"showMenu(" + m.getMenuId() + ");\"><img id=\"menuimg_" + m.getMenuId() + "\" src=\"" + path + "/images/s1.png\" /></a></div>");
            sb.append("<ul id=\"menuul_")
                    .append(m.getMenuId())
                    .append("\"> ");
            for (MgrMenu subMenu : m.getSubMenus()) {
                sb.append("<li><a href=\"")
                        .append(path)
                        .append(subMenu.getUrl())
                        .append("\">")
                        .append(subMenu.getMenuName())
                        .append("</a></li>");
            }
            sb.append("</ul>");
        }
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCssClass() {
        return cssClass;
    }

    public void setCssClass(String cssClass) {
        this.cssClass = cssClass;
    }

    public String getChildClass() {
        return childClass;
    }

    public void setChildClass(String childClass) {
        this.childClass = childClass;
    }

}
