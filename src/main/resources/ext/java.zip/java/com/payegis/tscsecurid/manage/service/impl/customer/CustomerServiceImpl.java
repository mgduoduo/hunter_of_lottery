package com.payegis.tscsecurid.manage.service.impl.customer;

import com.payegis.tscsecurid.common.constant.PropertyFileKeys;
import com.payegis.tscsecurid.common.data.bo.BindingInfoBo;
import com.payegis.tscsecurid.common.data.bo.BindingLogBo;
import com.payegis.tscsecurid.common.data.bo.DIDDetailBo;
import com.payegis.tscsecurid.common.data.entity.*;
import com.payegis.tscsecurid.common.mapper.*;
import com.payegis.tscsecurid.common.service.BaseServiceImpl;
import com.payegis.tscsecurid.common.util.DateUtil;
import com.payegis.tscsecurid.common.util.PropertyUtil;
import com.payegis.tscsecurid.manage.service.business.customer.CustomerService;
import com.payegis.tscsecurid.manage.util.WSUtil;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.representation.Form;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by liucheng on 2014/11/13.
 */
@Service
public class CustomerServiceImpl extends BaseServiceImpl implements CustomerService {

    @Autowired
    BindingInfoMapper mapper;

    @Autowired
    private SysMsgMapper sysMsgMapper;

    @Autowired
    BusinessSystemMapper systemMapper;

    @Autowired
    BindingLogMapper bindingLogMapper;

    @Autowired
    FeedbackInfoMapper feedbackInfoMapper;

    @Autowired
    BindingTerminalPwdProtectionMapper bindingTerminalPwdProtectionMapper;

    @Autowired
    TerminalPwdResetMapper terminalPwdResetMapper;

    protected BaseMapper getMapper() {
        return mapper;
    }

    public BindingInfoBo getBindingInfoByPrimaryKey(Integer bindId) {
        final BindingInfo bindingInfo = mapper.selectByPrimaryKey(bindId);
        if (bindingInfo == null) return null;
        BindingInfoBo infoBo = new BindingInfoBo();
        try {
            BeanUtils.copyProperties(infoBo,bindingInfo);
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }
        return infoBo;
    }

    public List<BusinessSystem> getBusinessSystemByUser(Integer enterpriseId) {
        Map<String,Object> map = new HashMap<String, Object>();
        map.put("enterpriseId", enterpriseId);
        return systemMapper.getBusinessSystemByEnterpriseId(map);
    }

    public void saveUnBinding(BindingLog log, Integer bindingInfoId) {
        final BindingInfo info = mapper.selectByPrimaryKey(bindingInfoId);
        mapper.deleteByPrimaryKey(bindingInfoId);
        bindingLogMapper.insertSelective(log);

        //unbind from cloud
        final BusinessSystem businessSystem = systemMapper.selectByPrimaryKey(info.getSystemId());
        Map<String,Object> requesMap = new HashMap<String, Object>();
        requesMap.put("deviceId", info.getDeviceId());
        requesMap.put("systemNo", businessSystem.getSystemNo());
        requesMap.put("systemAccount", info.getSystemAccount());
        WSUtil.sendRequest(PropertyUtil.getPropertyValue("config.properties", "securid.cloud.unbind.url"), requesMap);

        new Thread(new Runnable() {
            @Override
            public void run() {

                Client client = Client.create();
                WebResource rs = client.resource(PropertyUtil.getPropertyValue("config.properties", "push.url"));
                final String messageContent = "{\"type\":\"" + PropertyFileKeys.BINDING_LOG_TYPE_UNBINDING + "\"," +
                        "\"ctx\":{\"systemNo\":\"" + businessSystem.getSystemNo()+ "\",\"from\":\"customer"  + "\",\"systemAccount\":\"" + info.getSystemAccount() + "\"}}";
                Form formParam = new Form();
                formParam.add("msgContent",messageContent);
                formParam.add("msgTitle","解绑成功");
                formParam.add("deviceId",info.getDeviceId());
                final String result = rs.post(String.class, formParam);

                SysMsg msg = new SysMsg();
                msg.setEnterpriseId(info.getEnterpriseId());
                msg.setDeviceId(info.getDeviceId());
                msg.setMsgType("system");
                msg.setMsgContent("您的账号："+info.getSystemAccount()+"解绑成功");
                msg.setSendTime(DateUtil.getCurrentDateString());
                if (StringUtils.contains(result, "成功")) {
                    msg.setIsSend("Y");
                }
                sysMsgMapper.insertSelective(msg);
            }
        }).start();
    }


    public List<BindingLogBo> selectAccountHistory(BindingLog bindingLog) {

        return bindingLogMapper.selectByPOJO(bindingLog);
    }

    public DIDDetailBo getDIDDetail(String did, Integer enterpriseId) {
        DIDDetailBo didDetailBo = new DIDDetailBo();

        BindingInfo info = new BindingInfo();
        info.setDeviceId(did);
        info.setEnterpriseId(enterpriseId);
        didDetailBo.setBindingInfoBos(mapper.selectByPOJO(info));

        BindingLog log = new BindingLog();
        log.setDeviceId(did);
        log.setEnterpriseId(enterpriseId);
        log.setBindingLogType(PropertyFileKeys.BINDING_LOG_TYPE_BINDING);
        didDetailBo.setBindingLogs(bindingLogMapper.selectByPOJO(log));
        log.setBindingLogType(PropertyFileKeys.BINDING_LOG_TYPE_UNBINDING);
        didDetailBo.setUnBindingLogs(bindingLogMapper.selectByPOJO(log));

        FeedbackInfo feedbackInfo = new FeedbackInfo();
        feedbackInfo.setDeviceId(did);
//        feedbackInfo.setEnterpriseId(enterpriseId);
        didDetailBo.setFeedbackInfos(feedbackInfoMapper.selectByPOJO(feedbackInfo));

        BindingTerminalPwdProtection bindingTerminalPwdProtection = new BindingTerminalPwdProtection();
        bindingTerminalPwdProtection.setDeviceId(did);
        didDetailBo.setBindingTerminalPwdProtections(bindingTerminalPwdProtectionMapper.selectByPOJO(bindingTerminalPwdProtection));

        TerminalPwdReset terminalPwdReset = new TerminalPwdReset();
        terminalPwdReset.setDeviceId(did);
        terminalPwdReset.setEnterpriseId(enterpriseId);
        didDetailBo.setTerminalPwdResets(terminalPwdResetMapper.selectByPOJO(terminalPwdReset));
        return didDetailBo;
    }
}
