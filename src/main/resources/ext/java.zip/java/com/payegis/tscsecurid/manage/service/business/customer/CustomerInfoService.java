package com.payegis.tscsecurid.manage.service.business.customer;

import java.util.List;

import com.payegis.tscsecurid.common.data.BaseBo;
import com.payegis.tscsecurid.common.data.bo.BindInfoQueryBo;
import com.payegis.tscsecurid.common.data.bo.BindingTerminalPwdProtectionBo;
import com.payegis.tscsecurid.common.data.bo.FeedbackInfoBo;
import com.payegis.tscsecurid.common.data.entity.BindingInfoEnterprise;
import com.payegis.tscsecurid.common.data.entity.BindingTerminalPwdProtection;
import com.payegis.tscsecurid.common.data.entity.FeedbackInfo;
import com.payegis.tscsecurid.common.data.entity.TerminalPwdReset;
import com.payegis.tscsecurid.common.result.ResultBean;
import com.payegis.tscsecurid.common.service.BaseService;

public interface CustomerInfoService extends BaseService{

    /**
     * 更新反馈信息
     * @param fbi 反馈信息参数
     * @return 更新成功条数
     */
    Integer updateFeedBackInfo(FeedbackInfo fbi);

    ResultBean getPageListForReset(BaseBo param);

    /**
     * 手势密码重置
     * @param fbi 待清空的设备
     * @return 更新成功条数
     */
    boolean updatePwdReset(TerminalPwdReset tpr);

    /**
     * 查询
     * @param param
     * @return
     */
    List<BindingTerminalPwdProtection> viewPwdQuestion(BindingTerminalPwdProtectionBo param);

    /**
     * 根据反馈ID获取反馈信息
     * @param feedbackInfoId 反馈ID
     * @return 反馈记录
     */
    FeedbackInfo selectByPrimaryKey(Integer feedbackInfoId);

    /**
     * 根据DEVICEID查询绑定账号信息
     * @param deviceId
     * @return
     */
    List<BindingInfoEnterprise> selectMoreAccountByDeviceId(String deviceId);

}
