package com.payegis.tscsecurid.manage.service.business.msg;



import java.util.List;
import java.util.Map;

import com.payegis.tscsecurid.common.data.bo.DeviceQueryBo;
import com.payegis.tscsecurid.common.data.bo.DeviceSelectBo;
import com.payegis.tscsecurid.common.data.bo.SysMsgQueryBo;
import com.payegis.tscsecurid.common.data.bo.SysMsgTopicQueryBo;
import com.payegis.tscsecurid.common.data.entity.BusinessSystem;
import com.payegis.tscsecurid.common.data.entity.SysMsg;
import com.payegis.tscsecurid.common.data.entity.SysMsgTopic;
import com.payegis.tscsecurid.common.result.ResultBean;

public interface MsgService {

    /**
     * 根据查询条件过滤所有消息列表
     * @return
     */
    public ResultBean listAll(SysMsgQueryBo param);

    /**
     * 保存一个消息
     * @return
     */
    public int save(SysMsg param);
    
    /**
     * 更新一个消息
     * @return
     */
    public int update(SysMsg param);
    
    /**
     * 查找一个消息
     * @return
     */
    public SysMsg findById(Integer MsgId);
    
    /**
     * 查找用户所属企业下的业务系统列表
     * @return
     */
    public List<BusinessSystem> findBusinessSystemsByUserId(Integer userId);
    
    /**
     * 根据查询条件过滤所有人工消息列表
     * @return
     */
    public ResultBean listSysMsgTopics(SysMsgTopicQueryBo param);
    
    public SysMsgTopic selectMsgTopicByPrimaryKey(Integer msgTopicId);
    
    public int saveMsgTopic(DeviceQueryBo dqb);
    
    public List<String> selectDeviceIds(DeviceQueryBo param);
    
    public ResultBean listAllDeviceSelect(DeviceSelectBo deviceSelectBo);
    
    public DeviceQueryBo getNewDeviceQueryBo(DeviceQueryBo deviceQueryBo);
}
