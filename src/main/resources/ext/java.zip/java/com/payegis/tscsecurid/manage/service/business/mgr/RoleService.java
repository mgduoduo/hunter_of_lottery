package com.payegis.tscsecurid.manage.service.business.mgr;


import com.payegis.tscsecurid.common.data.entity.MgrRole;
import com.payegis.tscsecurid.common.service.BaseService;
import com.payegis.tscsecurid.manage.bean.RoleBean;

import java.util.List;

public interface RoleService extends BaseService {

	public List<MgrRole> findRoleList();

	public void saveRole(MgrRole role, String privilegeIds);

	public void updateRoler(MgrRole role, String privilegeIds);

	public void deleteRole(String roleIds);

	public RoleBean findRole(String roleId);

	public MgrRole findRoleById(String roleId);
	
	public List<MgrRole> findRoleListByCondition(MgrRole record);
}
