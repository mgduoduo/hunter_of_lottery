package com.payegis.tscsecurid.manage.service.impl.mgr;


import com.payegis.tscsecurid.common.data.entity.MgrRole;
import com.payegis.tscsecurid.common.data.entity.MgrRolePrivilege;
import com.payegis.tscsecurid.common.data.entity.MgrUserRole;
import com.payegis.tscsecurid.common.mapper.BaseMapper;
import com.payegis.tscsecurid.common.mapper.MgrRoleMapper;
import com.payegis.tscsecurid.common.mapper.MgrRolePrivilegeMapper;
import com.payegis.tscsecurid.common.mapper.MgrUserRoleMapper;
import com.payegis.tscsecurid.common.service.BaseServiceImpl;
import com.payegis.tscsecurid.manage.bean.RoleBean;
import com.payegis.tscsecurid.manage.common.ManageException;
import com.payegis.tscsecurid.manage.common.MessageConstant;
import com.payegis.tscsecurid.manage.service.business.mgr.RoleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class RoleServiceImpl extends BaseServiceImpl implements RoleService {

	@Autowired
	private MgrRoleMapper roleMapper;

	@Autowired
	private MgrUserRoleMapper userRoleMapper;

	@Autowired
	private MgrRolePrivilegeMapper rolePrivilegeMapper;

	@Override
	public List<MgrRole> findRoleList() {
		return roleMapper.findRoleList();
	}

	@Override
	public void saveRole(MgrRole role, String privilegeIds) {
		roleMapper.insertSelective(role);
		String[] privilegeids = privilegeIds.split("\\|");
		for (String privilegeid : privilegeids) {
			MgrRolePrivilege mrp = new MgrRolePrivilege();
			mrp.setPrivilegeId(privilegeid);
			mrp.setRoleId(role.getRoleId());
			rolePrivilegeMapper.insert(mrp);
		}
	}

	@Override
	public void updateRoler(MgrRole role, String privilegeIds) {
		roleMapper.updateByPrimaryKeySelective(role);
		List<MgrRolePrivilege> list = rolePrivilegeMapper.findRolePrivilegeByRoleId(role
                .getRoleId());
		List<String> addprivilegelist = new ArrayList<String>();
		List<String> deleprivilegelist = new ArrayList<String>();
		String[] privilegeids = privilegeIds.split("\\|");

		for (int i = 0; i < privilegeids.length; i++) {
			boolean ix = false;
			for (MgrRolePrivilege rolePrivilege : list) {
				if (rolePrivilege.getPrivilegeId()
						.equals(privilegeids[i])) {
					ix = true;
				}
			}
			if (!ix) {
				addprivilegelist.add(privilegeids[i]);
			}
		}

		for (int j = 0; j < list.size(); j++) {
			MgrRolePrivilege rolePrivilege = list.get(j);
			boolean ix = false;
			for (String id : privilegeids) {
				if (rolePrivilege.getPrivilegeId().equals(id)) {
					ix = true;
				}
			}
			if (!ix) {
				deleprivilegelist.add(rolePrivilege.getPrivilegeId());
			}
		}

		if (!addprivilegelist.isEmpty()) {
			for (String privilegeid : addprivilegelist) {
				MgrRolePrivilege rolePrivilege = new MgrRolePrivilege();
				rolePrivilege.setRoleId(role.getRoleId());
				rolePrivilege.setPrivilegeId(privilegeid);
				rolePrivilegeMapper.insert(rolePrivilege);
			}
		}

		if (!deleprivilegelist.isEmpty()) {
			for (String privilegeid : deleprivilegelist) {
			   MgrRolePrivilege rolePrivilege = new MgrRolePrivilege();
               rolePrivilege.setRoleId(role.getRoleId());
               rolePrivilege.setPrivilegeId(privilegeid);
               rolePrivilegeMapper.deleteByPrimaryKey(rolePrivilege);
			}
		}
	}

	@Override
	public RoleBean findRole(String roleId) {
		MgrRole role = roleMapper.selectByPrimaryKey(roleId);
		RoleBean roleBean = new RoleBean();
		roleBean.setRoleId(role.getRoleId());
		roleBean.setRoleName(role.getRoleName());
		List<MgrRolePrivilege> list = rolePrivilegeMapper.findRolePrivilegeByRoleId(roleId);
		StringBuilder sb = new StringBuilder();
		if (list != null && !list.isEmpty()) {
			for (MgrRolePrivilege rolePrivilege : list) {
				if (sb.length() > 0) {
					sb.append("|");
				}
				sb.append(rolePrivilege.getPrivilegeId());
			}
		}
		roleBean.setPrivilegeIds(sb.toString());
		return roleBean;
	}

	@Override
	public MgrRole findRoleById(String roleId) {
		return roleMapper.selectByPrimaryKey(roleId);
	}

	@Override
	public void deleteRole(String roleId) {

		// 删除用户角色关联
		List<MgrUserRole> list = userRoleMapper.findUserRoleByroleId(roleId);
		if (list != null && !list.isEmpty()) {
            throw new ManageException(
                    MessageConstant.ERROR_ROLE_IN_USE);
		}

		// 删除角色权限关联
		List<MgrRolePrivilege> list1 = rolePrivilegeMapper.findRolePrivilegeByRoleId(roleId);
		if (list1 != null && !list1.isEmpty()) {
			for (MgrRolePrivilege rolePrivilege : list1) {
				rolePrivilegeMapper.deleteByPrimaryKey(rolePrivilege);
			}
		}
		// 删除角色
        roleMapper.deleteByPrimaryKey(roleId);
	}

   @Override
   protected BaseMapper getMapper() {
      return roleMapper;
   }
   
   public List<MgrRole> findRoleListByCondition(MgrRole record){
	   return roleMapper.findRoleListByCondition(record);
   }
}
