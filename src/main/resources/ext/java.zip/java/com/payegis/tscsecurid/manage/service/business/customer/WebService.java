package com.payegis.tscsecurid.manage.service.business.customer;


import com.payegis.tscsecurid.common.data.entity.SysUser;

public interface WebService {
    public SysUser doUserLogin(String userId, String password);



    public SysUser getSysUserByEmail(String email);
}
