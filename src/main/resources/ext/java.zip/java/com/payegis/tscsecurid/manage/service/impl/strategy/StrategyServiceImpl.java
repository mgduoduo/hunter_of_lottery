package com.payegis.tscsecurid.manage.service.impl.strategy;

import com.payegis.tscsecurid.common.data.entity.StrategyConfig;
import com.payegis.tscsecurid.common.mapper.StrategyConfigMapper;
import com.payegis.tscsecurid.manage.common.MessageConstant;
import com.payegis.tscsecurid.manage.service.business.strategy.StrategyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Created by wbl
 */
@Service
public class StrategyServiceImpl implements StrategyService, MessageConstant {

    @Autowired
    private StrategyConfigMapper strategyManageMapper;

    @Override
    public int save(StrategyConfig param) {
        
        return strategyManageMapper.insert(param);
        
    }

    @Override
    public int update(StrategyConfig param) {
        
        return strategyManageMapper.update(param);
    }

	@Override
	public StrategyConfig findObj() {
		return strategyManageMapper.select();
	}

    @Override
    public int updateSecIden(StrategyConfig config) {
        return strategyManageMapper.updateSystemSecIden(config);
    }

    @Override
    public StrategyConfig findObjBySystemNo(String systemNo) {
        return strategyManageMapper.findObjBySystemNo(systemNo);
    }
}
