package com.payegis.tscsecurid.manage.service.business.mgr;


import com.payegis.tscsecurid.common.data.entity.MgrMenu;
import com.payegis.tscsecurid.common.service.BaseService;

import java.util.List;

public interface MenuService extends BaseService {

	public List<MgrMenu> retrieveMenus();

	public MgrMenu retrieveMenuById(String id);

	public void updateMenu(MgrMenu entity);

	public void createMenu(MgrMenu entity);

	public void delMenuById(int id);

}
