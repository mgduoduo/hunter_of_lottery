package com.payegis.tscsecurid.manage.util;


import com.payegis.tscsecurid.common.data.entity.MgrPrivilege;
import com.payegis.tscsecurid.common.data.entity.SysUser;
import com.payegis.tscsecurid.manage.common.Constant;
import com.payegis.tscsecurid.manage.common.SessionInfo;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.List;

/**
 * session utils
 * 
 * @author xuman.xu
 * 
 */
public class SessionUtil {

	/**
	 * get user loginname
	 * 
	 * @param request
	 *            user request
	 * @return loginame
	 */
	public static String getLoginName(HttpServletRequest request) {
		String loginName = null;
		Object object = request.getSession().getAttribute(
				Constant.KEY_SESSION_INFO);
		if (object != null) {
			SessionInfo sessioninfo = (SessionInfo) object;
			SysUser user = sessioninfo.getLoginUser();
			loginName = user.getUserName();
		}
		return loginName;
	}

    public static String getLoginName(HttpSession session) {
        String loginName = null;
        Object object = session.getAttribute(
                Constant.KEY_SESSION_INFO);
        if (object != null) {
            SessionInfo sessioninfo = (SessionInfo) object;
            SysUser user = sessioninfo.getLoginUser();
            loginName = user.getUserName();
        }
        return loginName;
    }

	/**
	 * get user id
	 * 
	 * @param request
	 *            user request
	 * @return id
	 */
	public static String getUserId(HttpServletRequest request) {
		String userId = "";
		Object object = request.getSession().getAttribute(
				Constant.KEY_SESSION_INFO);
		if (object != null) {
			SessionInfo sessioninfo = (SessionInfo) object;
			SysUser user = sessioninfo.getLoginUser();
			userId = user.getUserId().toString();
		}
		return userId;
	}

    public static SysUser getUser(HttpSession session) {
        Object object = session.getAttribute(Constant.KEY_SESSION_INFO);
        if (object != null) {
            SessionInfo sessioninfo = (SessionInfo) object;
            return sessioninfo.getLoginUser();
        }
        return null;
    }

	/**
	 * get priliege list
	 * 
	 * @param request
	 * @return
	 */
	public static List<MgrPrivilege> getPriliegeList(HttpServletRequest request) {
		List<MgrPrivilege> privileges = null;
		Object object = request.getSession().getAttribute(
				Constant.KEY_SESSION_INFO);
		SysUser user = null;
		if (object != null) {
			SessionInfo sessioninfo = (SessionInfo) object;
			user = sessioninfo.getLoginUser();
			privileges = user.getPrivileges();
		}
		return privileges;
	}
}
