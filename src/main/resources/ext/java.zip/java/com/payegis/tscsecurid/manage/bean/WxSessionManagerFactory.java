package com.payegis.tscsecurid.manage.bean;

import me.chanjar.weixin.common.session.WxSession;
import me.chanjar.weixin.common.session.WxSessionManager;

/**
 * Created by zzg on 2015/7/20.
 */
public class WxSessionManagerFactory {
    private static WxSessionManager manager = new WxSessionManager() {
        @Override
        public WxSession getSession(String s) {
            return manager.getSession(s);
        }

        @Override
        public WxSession getSession(String s, boolean b) {
            return null;
        }
    };

    private WxSessionManagerFactory (){}

    public static WxSessionManager getInstance(){
        return manager;
    }
}
