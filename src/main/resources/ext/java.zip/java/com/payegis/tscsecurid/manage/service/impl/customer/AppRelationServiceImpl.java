package com.payegis.tscsecurid.manage.service.impl.customer;

import com.payegis.tscsecurid.common.data.entity.AppRelationBean;
import com.payegis.tscsecurid.common.mapper.AppRelationMapper;
import com.payegis.tscsecurid.common.mapper.BaseMapper;
import com.payegis.tscsecurid.common.service.BaseServiceImpl;
import com.payegis.tscsecurid.common.util.PropertyUtil;
import com.payegis.tscsecurid.manage.common.Constant;
import com.payegis.tscsecurid.manage.service.business.customer.AppRelationService;
import com.payegis.tscsecurid.manage.util.WSUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;


@Service
public class AppRelationServiceImpl extends BaseServiceImpl implements AppRelationService {

	@Autowired
	private AppRelationMapper appRelationMapper;
	@Override
	public AppRelationBean getAppRelationStatus(String openId,String commonId) {
		// TODO Auto-generated method stub
        //System.out.println("openid:"+openId+",commonId:"+commonId);
        //System.out.println(appRelationMapper==null);
        return appRelationMapper.selectByIds(openId,commonId);
	}
	
	public int create(AppRelationBean appRelationBean){
        lockSet(appRelationBean.getOpenId());
		return appRelationMapper.create(appRelationBean);
	}
	
	@Override
	public void updateAppRelation(AppRelationBean appRelationBean) {
        lockSet(appRelationBean.getOpenId());
		appRelationMapper.updateAppRelation(appRelationBean);
		
	}

	@Override
	protected BaseMapper getMapper() {
		return null;
	}

	public void lockSet(String openId){
        Map<String,Object> params = new HashMap<String,Object>();
        params.put(Constant.DEVICE_ID,openId);
        params.put(Constant.OS_TYPE,"weixin");
        params.put(Constant.PHONE_NO,null);
        params.put(Constant.DEVICE_PASSWORD,null);
        String tscLockSetCloudUrl = PropertyUtil.getPropertyValue("config.properties", "tscsecurid.rest.cloud.lockset.url");
        String res = WSUtil.sendRequest(tscLockSetCloudUrl, params);
        //System.out.println(res);
    }

	

}
