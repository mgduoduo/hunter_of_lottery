package com.payegis.tscsecurid.manage.bean;


import com.payegis.tscsecurid.common.data.BaseDto;

public class PrivilegeSearchBean extends BaseDto {
	private static final long serialVersionUID = 8263062959112620562L;
	private String tprivilegeId = "";
	private String tprivilegeName = "";

	public String getTprivilegeId() {
		return tprivilegeId;
	}

	public void setTprivilegeId(String tprivilegeId) {
		this.tprivilegeId = tprivilegeId;
	}

	public String getTprivilegeName() {
		return tprivilegeName;
	}

	public void setTprivilegeName(String tprivilegeName) {
		this.tprivilegeName = tprivilegeName;
	}

}
