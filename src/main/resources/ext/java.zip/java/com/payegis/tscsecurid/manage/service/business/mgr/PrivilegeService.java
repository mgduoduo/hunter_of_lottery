package com.payegis.tscsecurid.manage.service.business.mgr;

import com.payegis.tscsecurid.common.data.entity.MgrPrivilege;
import com.payegis.tscsecurid.common.service.BaseService;
import com.payegis.tscsecurid.manage.bean.PrivilegeBean;
import com.payegis.tscsecurid.manage.common.PageBean;

import java.util.List;



public interface PrivilegeService extends BaseService {

	public List<MgrPrivilege> retrievePrivileges();

	public PageBean searchPrivileges(PrivilegeBean searchDto);

	public void createPrivilege(MgrPrivilege privilege);

	public void updatePrivilege(MgrPrivilege privilege);

	public boolean checkPrivilegeExists(String privilegeId);

	public void deletePrivilege(String[] privilegeIds);

	public MgrPrivilege retrievePrivilegeById(String privilegeId);

	public List<MgrPrivilege> findPrivilegeList();
	
	public List<MgrPrivilege> getPrivilegeGroup();
	
	public List<MgrPrivilege> FindAllPrivilegeForEnterprise(MgrPrivilege privilege);

}
