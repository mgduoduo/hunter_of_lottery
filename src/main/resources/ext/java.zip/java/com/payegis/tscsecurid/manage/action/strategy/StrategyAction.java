package com.payegis.tscsecurid.manage.action.strategy;

import com.payegis.tscsecurid.common.action.BaseAction;
import com.payegis.tscsecurid.common.aop.AvoidDuplicateSubmission;
import com.payegis.tscsecurid.common.data.entity.StrategyConfig;
import com.payegis.tscsecurid.common.data.entity.SysUser;
import com.payegis.tscsecurid.manage.service.business.strategy.StrategyService;
import com.payegis.tscsecurid.manage.service.business.system.SystemConfigService;
import com.payegis.tscsecurid.manage.util.SessionUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

@Controller
@RequestMapping("/strategy")
public class StrategyAction extends BaseAction {

    @Autowired
    private StrategyService strategyService;

    @Autowired
    SystemConfigService configService;
    
    @RequestMapping(value = "/strategyQuery", method = RequestMethod.GET)
    public ModelAndView strategyQuery(HttpServletRequest request,HttpSession session) {
    	ModelAndView mav = new ModelAndView("page/strategy/strategy_query");
//    	mav.addObject("strategyManage", strategyService.findObj());
        return mav;
    }

    @RequestMapping(value = "/saveStrategy", method = RequestMethod.POST)
    @AvoidDuplicateSubmission(needRemoveToken = true)
    public ModelAndView saveStrategy(
            @ModelAttribute("strategyManage") @Valid StrategyConfig strategyManage,BindingResult result,
            HttpServletRequest request, RedirectAttributes redirectAttributes,HttpSession session) {
        ModelAndView mav = new ModelAndView("redirect:/strategy/strategyQuery");
        if (result.hasErrors()) {
            mav.setViewName("page/version/version_add");
            return mav;
        }
        SysUser su = (SysUser) SessionUtil.getUser(session);
        String msg = "保存成功";
        try {
            if(null != su ){
            	String userId = su.getUserId().toString();
            	strategyManage.setUserId(userId);
            	if(strategyService.findObj()!=null){
            		strategyService.update(strategyManage);
            	}
            	else{
            		strategyService.save(strategyManage);
            	}
                
            }
        } catch (Exception e) {
            logger.info("save versionManage:" + e.getMessage());
        }
        redirectAttributes.addFlashAttribute("success", msg);
        return mav;
    }

}
