package com.payegis.tscsecurid.manage.service.impl.enterprise;


import com.payegis.tscsecurid.common.constant.PropertyFileKeys;
import com.payegis.tscsecurid.common.data.bo.BusinessSystemBo;
import com.payegis.tscsecurid.common.data.bo.EnterpriseInfoBo;
import com.payegis.tscsecurid.common.data.entity.*;
import com.payegis.tscsecurid.common.mapper.*;
import com.payegis.tscsecurid.common.result.ResultBean;
import com.payegis.tscsecurid.common.util.DateUtil;
import com.payegis.tscsecurid.common.util.EncryptionUtil;
import com.payegis.tscsecurid.common.util.ToolUtil;
import com.payegis.tscsecurid.manage.common.MessageConstant;
import com.payegis.tscsecurid.manage.service.business.enterprise.EnterpriseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
public class EnterpriseServiceImpl implements EnterpriseService, MessageConstant{

	@Autowired
	private EnterpriseInfoMapper enterpriseInfoMapper;
	
    @Autowired
    MgrUserRoleMapper mgrUserRoleMapper;
    
    @Autowired
    SysUserMapper sysUserMapper;
    
    @Autowired
    MgrRoleMapper mgrRoleMapper;
    
    @Autowired
    MgrPrivilegeMapper mgrPrivilegeMapper;
    
    @Autowired
    MgrRolePrivilegeMapper mgrRolePrivilegeMapper;
    
	@Override
	public ResultBean listAll(EnterpriseInfoBo param) {
		ResultBean result = new ResultBean();
		result.setRows(enterpriseInfoMapper.listAll(param));
		result.setTotal(enterpriseInfoMapper.count(param));
		return result;
	}
	@Override
	public int save(EnterpriseInfoBo enterpriseInfoBo,SysUser su) {
		enterpriseInfoBo.setAddUserId(su.getUserId());//**********************************************
		enterpriseInfoBo.setCreateTime(DateUtil.getCurrentDateString());
        enterpriseInfoBo.setEnterpriseNo(UUID.randomUUID().toString().replace("-", ""));
		enterpriseInfoMapper.insertSelective(enterpriseInfoBo);
		if(enterpriseInfoBo.getEnterpriseId() > -1){
			MgrRole role = new MgrRole();
			role.setEnterpriseId(enterpriseInfoBo.getEnterpriseId());
			role.setRoleName(PropertyFileKeys.ENTERPRISE_SUPER_ROLE_NAME_PREFIX+"("+enterpriseInfoBo.getEnterpriseName()+")");
			role.setRoleId(UUID.randomUUID().toString().replace("-", ""));
			role.setCreator(su.getUserName());
			role.setCreateTime(DateUtil.getCurrentDateString());
			mgrRoleMapper.insertSelective(role);
				MgrPrivilege mp = new MgrPrivilege();
				mp.setIsEnterpriseShare("Y");
				List<MgrPrivilege> privileges = mgrPrivilegeMapper.getAllPrivilegeForEnterprise(mp);
				if(ToolUtil.isNotEmpty(privileges)){
					MgrRolePrivilege mgrRolePrivilege;
					for (MgrPrivilege mr : privileges) {
						mgrRolePrivilege = new MgrRolePrivilege();
						mgrRolePrivilege.setCreateTime(DateUtil.getCurrentDateString());
						mgrRolePrivilege.setCreator(su.getUserName());
						mgrRolePrivilege.setEnterpriseId(enterpriseInfoBo.getEnterpriseId());
						mgrRolePrivilege.setPrivilegeId(mr.getPrivilegeId());
						mgrRolePrivilege.setRoleId(role.getRoleId());
						mgrRolePrivilegeMapper.insertSelective(mgrRolePrivilege);
					}
				}
				
				SysUser user = new SysUser();
				user.setEnterpriseId(enterpriseInfoBo.getEnterpriseId());
				user.setUserName(enterpriseInfoBo.getManagerAccount());
				user.setSystemNo(PropertyFileKeys.SYSTEM_NO);
				user.setUserEmail(enterpriseInfoBo.getManagerAccount());
				user.setIsDelete("N");
				user.setUserPassword(EncryptionUtil.md5(PropertyFileKeys.DEFAULT_PWD));
				user.setAddTime(DateUtil.getCurrentDateString());
				user.setAddUserId(su.getUserId());
				Integer userId = sysUserMapper.insert(user);
				if (userId >0) {
						MgrUserRole userRole = new MgrUserRole();
						userRole.setRoleId(role.getRoleId());
						userRole.setUserId(user.getUserId().toString());
						mgrUserRoleMapper.insert(userRole);
				}
		}
		return enterpriseInfoBo.getEnterpriseId();
	}

	@Override
	public int update(EnterpriseInfoBo param) {
		param.setEnterpriseNo(null);
		int res = enterpriseInfoMapper.updateByPrimaryKeySelective(param);
		/*MgrRole role = mgrRoleMapper.selectByPrimaryKey(PropertyFileKeys.ENTERPRISE_SUPER_ROLE+"_"+param.getEnterpriseId());
		String newRoleName = PropertyFileKeys.ENTERPRISE_SUPER_ROLE_NAME_PREFIX+"("+param.getEnterpriseName()+")";
		if(null != role && !newRoleName.equals(role.getRoleName())){
			role.setRoleName(newRoleName);
			mgrRoleMapper.updateByPrimaryKeySelective(role);
		}*/
		return res;
	}

	@Override
	public EnterpriseInfoBo findById(Integer enterpriseId) {
		return enterpriseInfoMapper.selectByPrimaryKey(enterpriseId);
	}
	
	@Override
	public EnterpriseInfoBo findByIdWithMembers(Integer enterpriseId) {
		EnterpriseInfoBo eb = enterpriseInfoMapper.selectByPrimaryKeyWithMembers(enterpriseId);
		if(null != eb ){
			if(!eb.getSysUserList().isEmpty()){
				List<String> roles = null;
				for(SysUser user : eb.getSysUserList()){
					roles = mgrUserRoleMapper.findUserRoleName(user.getUserId().toString());
					user.setRoleNameStr(roles.toString().replace("[", "").replaceAll("]", ""));
				}
			}
			if(!eb.getBusinessSystemBoList().isEmpty()){
				SysUser sysUser = null;
				for(BusinessSystemBo bs : eb.getBusinessSystemBoList()){
					sysUser = sysUserMapper.selectByPrimaryKey(bs.getAddUserId());
					if(null != sysUser)
						bs.setAddUser(sysUser.getUserName());
				}
			}
		}
		return eb;
	}
	@Override
	public List<EnterpriseInfoBo> findAllEnterprise() {
		return enterpriseInfoMapper.findAllEnterprise();
	}
	@Override
	public int updateDisable(Integer enterpriseId) {
		// TODO Auto-generated method stub
		return enterpriseInfoMapper.updateDisable(enterpriseId);
	}
	
	
}
