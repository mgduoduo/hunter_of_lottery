package com.payegis.tscsecurid.manage.bean;


import com.payegis.tscsecurid.common.data.BaseDto;

public class PrivilegeBean extends BaseDto {
	private static final long serialVersionUID = 8263062959112620562L;
	private String privilegeId = "";
	private String parentId = "";
	private String privilegeName = "";
	private String desc = "";
	private String isEnterpriseShare;
	
	public String getPrivilegeId() {
		return privilegeId;
	}

	public void setPrivilegeId(String privilegeId) {
		this.privilegeId = privilegeId;
	}

	public String getPrivilegeName() {
		return privilegeName;
	}

	public void setPrivilegeName(String privilegeName) {
		this.privilegeName = privilegeName;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public String getParentId() {
		return parentId;
	}

	public void setParentId(String parentId) {
		this.parentId = parentId;
	}

	public String getIsEnterpriseShare() {
		return isEnterpriseShare;
	}

	public void setIsEnterpriseShare(String isEnterpriseShare) {
		this.isEnterpriseShare = isEnterpriseShare;
	}
	
	
}
