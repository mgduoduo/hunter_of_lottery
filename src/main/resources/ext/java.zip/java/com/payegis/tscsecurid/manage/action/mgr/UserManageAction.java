package com.payegis.tscsecurid.manage.action.mgr;


import com.payegis.tscsecurid.common.data.entity.MgrRole;
import com.payegis.tscsecurid.common.data.entity.SysUser;
import com.payegis.tscsecurid.common.result.ResultBean;
import com.payegis.tscsecurid.common.util.DateUtil;
import com.payegis.tscsecurid.common.util.EncryptionUtil;
import com.payegis.tscsecurid.manage.action.customer.ManageBaseAction;
import com.payegis.tscsecurid.manage.bean.UserBean;
import com.payegis.tscsecurid.manage.common.Constant;
import com.payegis.tscsecurid.manage.service.business.mgr.RoleService;
import com.payegis.tscsecurid.manage.service.business.mgr.UserService;
import com.payegis.tscsecurid.manage.util.MessageUtil;
import com.payegis.tscsecurid.manage.util.SessionUtil;
import net.sf.json.JSONObject;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.regex.Pattern;

/**
 * uaer manager controller
 * 
 * @author xuman.xu
 * 
 */
@Controller
@RequestMapping("/user")
public class UserManageAction extends ManageBaseAction {

	private static Logger logger = Logger.getLogger(UserManageAction.class);

	@Autowired
	private UserService userService;

	@Autowired
	private RoleService roleService;
	
    @RequestMapping(value = "/list", method = RequestMethod.GET)
    public ModelAndView receivables(
            HttpServletRequest request) {
        ModelAndView mav = new ModelAndView("page/mgr/user_receivables");
        return mav;
    }

    @RequestMapping(value = "/userSearch")
    public ModelAndView search(SysUser oiqb,
            HttpServletRequest request) {
        HashMap<String, Object> resMap = new HashMap<String, Object>();
        SysUser user = super.getSessionInfo(request.getSession()).getLoginUser();
        if(!user.getRoleNames().contains(Constant.SYSTEM_USER))
            oiqb.setEnterpriseId(user.getEnterpriseId());
        ResultBean resBean = userService.getPageList(oiqb);
        resMap.put("dataList", resBean.getRows());
        resMap.put("total", resBean.getTotal());
        resMap.put("processType", "receivables");
        ModelAndView mav = new ModelAndView("page/mgr/user_query_list", resMap);
        return mav;
    }
	
	

	@RequestMapping(value = "/adduser")
	public ModelAndView toAddUser(HttpServletRequest request) {
		ModelAndView mav = new ModelAndView("page/mgr/adduser");
		mav.addObject(new UserBean());
		MgrRole record = new MgrRole();
		SysUser sysUser = super.getSessionInfo(request.getSession()).getLoginUser();
        if (null != sysUser) {
        	record.setEnterpriseId(sysUser.getEnterpriseId());
        }
		mav.addObject("role", roleService.findRoleListByCondition(record));
		return mav;
	}

	@RequestMapping(value = "/updateuser/{userId}")
	public ModelAndView toUpdateUser(@PathVariable String userId,HttpServletRequest request) {
		ModelAndView mav = new ModelAndView("page/mgr/updateuser");
		mav.addObject(userService.findUser(userId));
		MgrRole record = new MgrRole();
		SysUser sysUser = super.getSessionInfo(request.getSession()).getLoginUser();
        if (null != sysUser) {
        	record.setEnterpriseId(sysUser.getEnterpriseId());
        }
		mav.addObject("role", roleService.findRoleListByCondition(record));
		return mav;
	}

	@RequestMapping(value = "/dosaveuser")
	public ModelAndView saveUser(@ModelAttribute UserBean userBean,
			BindingResult result, HttpServletRequest request,
			HttpServletResponse response) {
		ModelAndView mav = new ModelAndView();
		boolean pass = true;
		if (userBean.getUserId() == null
				|| userBean.getUserId().trim().equals("")
				|| userBean.getUserId().length() < 6
				|| userBean.getUserId().length() > 40) {
			result.rejectValue("userId", "???", "登录名长度必须为6-200");
			pass = false;
		}else if (userBean.getUserId() == null
				|| userBean.getUserId().trim().equals("")
				|| userBean.getUserId().length() > 255) {
			result.rejectValue("email", "???", "邮件长度不能为空且长度不能超过200");
			pass = false;
		} else if (!(Pattern
				.matches(
						"([a-zA-Z0-9]+[-_|\\_|\\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[-_|\\_|\\.]?)*[a-zA-Z0-9]+\\.[a-zA-Z]{2,3}$",
						userBean.getUserId()))) {
			result.rejectValue("email", "???", "邮件格式不正确");
			pass = false;
		} else {
			if (userService.findUsersize(userBean.getUserId()) > 0) {
				result.rejectValue("userId", "???", "登录名已经存在");
				pass = false;
			}
		}
		if (userBean.getSystemNo() == null || userBean.getSystemNo().trim().equals("")
				|| userBean.getSystemNo().length() > 20) {
			result.rejectValue("systemNo", "???", "系统编码不能为空，最大长度20");
			pass = false;
		}
		if (userBean.getEmail() == null
				|| userBean.getEmail().trim().equals("")
				|| userBean.getEmail().length() > 255) {
			result.rejectValue("email", "???", "邮件长度不能为空且长度不能超过200");
			pass = false;
		} else if (!(Pattern
				.matches(
						"[A-Za-z0-9!#$%&'*+\\/=?^_`{|}~-]+(?:\\.[A-Za-z0-9!#$%&'*+\\/=?^_`{|}~-]+)*@(?:[A-Za-z0-9](?:[A-Za-z0-9-]*[a-z0-9])?\\.)+[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?$",
						userBean.getEmail()))) {
			result.rejectValue("email", "???", "邮件格式不正确");
			pass = false;
		}

		if (userBean.getStatus() == null
				|| userBean.getStatus().trim().equals("")) {
			result.rejectValue("status", "???", "必须选择用户状态");
			pass = false;
		}

		if (userBean.getRoleids() == null
				|| userBean.getRoleids().trim().equals("")) {
			result.rejectValue("roleids", "???", "用户必须拥有一个角色");
			pass = false;
		}
		if (pass) {
			try {
				SysUser user = new SysUser();
				
				user.setUserName(userBean.getUserId());
				user.setSystemNo(userBean.getSystemNo());
				user.setUserEmail(userBean.getEmail());
				user.setIsDelete(userBean.getStatus());
				user.setUserPassword(EncryptionUtil.md5("111111"));
				user.setAddTime(DateUtil.getCurrentDateString());
				user.setEditTime(DateUtil.getCurrentDateString());
				user.setAddUserId(Integer.valueOf(SessionUtil.getUserId(request)));
				SysUser sysUser = super.getSessionInfo(request.getSession()).getLoginUser();
                if (null != sysUser) {
                	user.setEnterpriseId(sysUser.getEnterpriseId());
                }
				userService.saveUser(user, userBean.getRoleids());
				mav = new ModelAndView("redirect:/user/list", getMessage(MESSAGE_TYPE_SUCCESS,
						SUCCESS_OPERATION, request));
			} catch (Exception e) {
				mav = new ModelAndView("redirect:/user/list", getMessage(MESSAGE_TYPE_ERROR,
						FAILED_OPERATION, request));
			}

		} else {
			mav.addObject(userBean);
			mav.setViewName("page/mgr/adduser");
		}
		return mav;
	}

	@RequestMapping(value = "/doupdateuser")
	public ModelAndView updateUser(@ModelAttribute UserBean userBean,
			BindingResult result, HttpServletRequest request,
			HttpServletResponse response) {
		ModelAndView mav = new ModelAndView();
		boolean pass = true;
		if (userBean.getUserId() == null
				|| userBean.getUserId().trim().equals("")
				|| userBean.getUserId().length() < 6
				|| userBean.getUserId().length() > 40) {
			result.rejectValue("userId", "???", "登录名长度必须为6-40");
			pass = false;
		}
		if (userBean.getSystemNo() == null || userBean.getSystemNo().trim().equals("")
				|| userBean.getSystemNo().length() > 20) {
			result.rejectValue("systemNo", "???", "系统编码不能为空，最大长度20");
			pass = false;
		}
		if (userBean.getEmail() == null
				|| userBean.getEmail().trim().equals("")
				|| userBean.getEmail().length() > 255) {
			result.rejectValue("email", "???", "邮件长度不能为空且长度不能超过255");
			pass = false;
		} else if (!(Pattern
				.matches(
						"[A-Za-z0-9!#$%&'*+\\/=?^_`{|}~-]+(?:\\.[A-Za-z0-9!#$%&'*+\\/=?^_`{|}~-]+)*@(?:[A-Za-z0-9](?:[A-Za-z0-9-]*[a-z0-9])?\\.)+[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?$",
						userBean.getEmail()))) {
			result.rejectValue("email", "???", "邮件格式不正确");
			pass = false;
		}

		if (userBean.getStatus() == null
				|| userBean.getStatus().trim().equals("")) {
			result.rejectValue("status", "???", "必须选择用户状态");
			pass = false;
		}

		if (userBean.getRoleids() == null
				|| userBean.getRoleids().trim().equals("")) {
			result.rejectValue("roleids", "???", "用户必须拥有一个角色");
			pass = false;
		}
		if (pass) {
			try {
				SysUser user = userService.findUserByLoginName(userBean.getUserId());
				user.setUserName(userBean.getUserId());
				user.setUserEmail(userBean.getEmail());
				user.setIsDelete(userBean.getStatus());
				user.setEditTime(DateUtil.getCurrentDateString());
				user.setSystemNo(userBean.getSystemNo());
				user.setEditUserId(Integer.valueOf(SessionUtil.getUserId(request)));
				userService.updateUserWithRole(user, userBean.getRoleids());
				RedirectView rv = new RedirectView("list");
				mav = new ModelAndView(rv, getMessage(MESSAGE_TYPE_SUCCESS,
						SUCCESS_OPERATION, request));
			} catch (Exception e) {
				logger.warn("exception when update user.", e);
				mav = new ModelAndView("redirect:/user/list", getMessage(MESSAGE_TYPE_ERROR,
						FAILED_OPERATION, request));
			}

		} else {
			mav.addObject(userBean);
			mav.setViewName("page/mgr/updateuser");
		}
		return mav;
	}

	@RequestMapping(value = "checkuserid", method = RequestMethod.POST)
	@ResponseBody
	public String checkUserid(String userid) {
		JSONObject json = new JSONObject();
		if (userService.findUsersize(userid) > 0) {
			json.put("status", "1");
			json.put("message",
					MessageUtil.getMessage(ERROR_USER_ID_EXISTS, null, null));
			json.put("data", "");
		} else {
			json.put("status", "0");
			json.put("message",
					MessageUtil.getMessage(ERROR_USER_ID_EXISTS, null, null));
			json.put("data", "");
		}
		return json.toString();
	}

	@RequestMapping(value = "toupdatepwd")
	public ModelAndView toUpdatePwd() {
		ModelAndView mav = new ModelAndView("page/mgr/updatepwd");
		mav.addObject(new UserBean());
		return mav;
	}

	@RequestMapping(value = "updatepwd")
	public ModelAndView updatePwd(@ModelAttribute UserBean userBean,
			BindingResult result, HttpServletRequest request,
			HttpServletResponse response) {
		ModelAndView mav = new ModelAndView("page/mgr/updatepwd");
		boolean pass = true;
		if (userBean.getNewpwd() == null
				|| userBean.getNewpwd().trim().length() < 6
				|| userBean.getNewpwd().length() > 50) {
			result.rejectValue("newpwd", "???", "密码长度必须为3-50");
			pass = false;
		}
		if (userBean.getNewpwd() != null
				&& (!userBean.getNewpwd().equals(userBean.getConfirmpwd()))) {
			result.rejectValue("confirmpwd", "???", "和新密码不一致");
			pass = false;
		}
		if (pass) {
			try {
				SysUser user = userService.findUserById(SessionUtil
						.getUserId(request));
				if (user != null) {
					if (user.getUserPassword().equals(userBean.getPwd())) {
						user.setUserPassword(userBean.getNewpwd());
                        user.setEditTime(DateUtil.getCurrentDateString());
						userService.updateUser(user);
						setMessage(MESSAGE_TYPE_SELFSUCCESS, "密码修改成功", request);
					} else {
						setMessage(MESSAGE_TYPE_SELFERROR, "原密码不正确", request);
					}
				} else {
					setMessage(MESSAGE_TYPE_SELFERROR, "用户不存在", request);
				}
			} catch (Exception e) {
				logger.warn("exception when update password.", e);
				setMessage(MESSAGE_TYPE_ERROR, FAILED_OPERATION, request);
			}
		}
		mav.addObject(userBean);
		return mav;
	}
}