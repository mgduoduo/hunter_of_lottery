package com.payegis.tscsecurid.manage.service.impl.system;

import com.payegis.tscsecurid.common.constant.PropertyFileKeys;
import com.payegis.tscsecurid.common.data.bo.BusinessSystemBo;
import com.payegis.tscsecurid.common.data.bo.SysEnterpriseConfigBo;
import com.payegis.tscsecurid.common.data.entity.*;
import com.payegis.tscsecurid.common.mapper.*;
import com.payegis.tscsecurid.common.service.BaseServiceImpl;
import com.payegis.tscsecurid.common.util.DateUtil;
import com.payegis.tscsecurid.common.util.FileUtils;
import com.payegis.tscsecurid.manage.service.business.system.SystemConfigService;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.lang.reflect.InvocationTargetException;
import java.util.*;

/**
 * Created by liucheng on 2014/11/6.
 */
@Service


public class SystemConfigServiceImpl extends BaseServiceImpl implements SystemConfigService {

    private static Logger logger = Logger.getLogger(SystemConfigServiceImpl.class);

    @Autowired
    SysEnterpriseConfigMapper mapper;

    @Autowired
    FileUtils fileUtils;

    @Autowired
    FeedbackInfoMapper feedbackInfoMapper;

    @Autowired
    BusinessSystemMapper businessSystemMapper;

    @Autowired
    BusinessSystemCallbackMapper callbackMapper;

    @Autowired
    private StrategyConfigMapper strategyManageMapper;

    @Autowired
    SysCodeMapper sysCodeMapper;

    @Autowired
    SysLogMapper sysLogMapper;


    protected BaseMapper getMapper() {
        return mapper;
    }

    public void saveConfig(SysEnterpriseConfigBo configBo) {
        SysEnterpriseConfig config = new SysEnterpriseConfig();
        try {
            BeanUtils.copyProperties(config, configBo);
        } catch (IllegalAccessException e) {
            logger.error(e);
        } catch (InvocationTargetException e) {
            logger.error(e);
        }
        if (configBo.getLogo() != null && configBo.getLogo().getSize() != 0) {
            config.setSystemLogoUrl(fileUtils.saveMultipartFile(configBo.getEnterpriseId(), configBo.getLogo()));
        }
//        config.setSystemBackgroundUrl(fileUtils.saveMultipartFile(configBo.getEnterpriseId(), configBo.getBackground()));
        if (config.getEnterpriseConfigId() != null && config.getEnterpriseConfigId() != 0) {
            mapper.updateByPrimaryKeySelective(config);
        } else {
            mapper.insertSelective(config);
        }
    }

    public SysEnterpriseConfig getSystemEnterpriseConfig(Integer enterpriseId) {

        return mapper.getSysEnterpriseByUser(enterpriseId);
    }

    public void saveFeedBackInfo(FeedbackInfo feedbackInfo) {
        feedbackInfoMapper.insertSelective(feedbackInfo);
    }

    public List<BusinessSystemBo> searchBusinessSystem(String businessName, String enterpriseNo, Integer enterpriseId) {
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("systemName", businessName);
        if (!PropertyFileKeys.ENTERPRISE_NO_PAYEGIS.equals(enterpriseNo)) {
            map.put("enterpriseId", enterpriseId);
        }
        return businessSystemMapper.searchBusinessSystem(map);
    }

    public List<SysCode> getCallBackTypes() {

        return sysCodeMapper.getAllCodeBySystemNo(PropertyFileKeys.CODE_TYPE_CALL_BACK);
    }

    public void createBusinessSystem(BusinessSystemBo businessSystemBo, StrategyConfig strategyConfig, SysUser user) {
        BusinessSystem businessSystem = new BusinessSystem();
        try {
            BeanUtils.copyProperties(businessSystem,businessSystemBo);
        } catch (IllegalAccessException e) {
            logger.error(e);
        } catch (InvocationTargetException e) {
            logger.error(e);
        }
        businessSystem.setSystemNo(UUID.randomUUID().toString().replaceAll("-", ""));
        businessSystem.setAddUserId(user.getUserId());
        businessSystem.setCreateTime(DateUtil.getCurrentDateString());
        if (businessSystemBo.getLogo() != null && businessSystemBo.getLogo().getSize() > 0) {
            businessSystem.setSystemLogoUrl(fileUtils.saveMultipartFile(user.getEnterpriseId(),businessSystemBo.getLogo()));
        } else {
            // 系统默认LOGO
            businessSystem.setSystemLogoUrl("images/sys-logo.png");
        }

        businessSystemMapper.insertSelective(businessSystem);

        StrategyConfig config = strategyManageMapper.findObjBySystemNo(businessSystem.getSystemNo());
        boolean saveOrUpdate = true;
        if(config==null){
            config = new StrategyConfig();
            config.setSystemNo(businessSystem.getSystemNo());
            saveOrUpdate = true;
        }else{
            saveOrUpdate = false;
        }
        //init
        config.setIsOpenSecIden("1");
        config.setDefaultOption("1");
        config.setMaxBind("3");
        config.setWaitTime("30");
        config.setIsOpenSecIden("1");
        config.setPushConfirm(strategyConfig==null?"DEFAULT":strategyConfig.getPushConfirm());
        config.setPushNotify(strategyConfig==null?"ALL":strategyConfig.getPushNotify());
        if(saveOrUpdate){
            strategyManageMapper.insert(config);
        }else{
            strategyManageMapper.update(config);
        }

        logger.debug("auto id:"+businessSystem.getSystemId());
        for (BusinessSystemCallback callback : businessSystemBo.getCallbacks()) {
            if (StringUtils.isEmpty(callback.getCallbackUrl())) continue;
            callback.setEnterpriseId(user.getEnterpriseId());
            callback.setSystemId(businessSystem.getSystemId());
            callback.setAddUserId(user.getUserId());
            callback.setCreateTime(DateUtil.getCurrentDateString());
            callbackMapper.insertSelective(callback);
        }
    }

    public BusinessSystemBo selectBusinessSystemBoById(Integer id) {
        BusinessSystemBo businessSystemBo = new BusinessSystemBo();
        BusinessSystem businessSystem = businessSystemMapper.selectByPrimaryKey(id);
        List<BusinessSystemCallback> callbacks = callbackMapper.selectBySystemId(id);
        try {
            BeanUtils.copyProperties(businessSystemBo,businessSystem);
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }
        businessSystemBo.setCallbacks(callbacks);
        return businessSystemBo;
    }


    public void updateBusinessSystem(BusinessSystemBo businessSystemBo, SysUser user) {
        businessSystemBo.setEditUserId(user.getEditUserId());
        businessSystemBo.setEditTime(DateUtil.getCurrentDateString());
        if (businessSystemBo.getLogo() != null && !businessSystemBo.getLogo().isEmpty()) {
            businessSystemBo.setSystemLogoUrl(fileUtils.saveMultipartFile(businessSystemBo.getEnterpriseId(),
                    businessSystemBo.getLogo()));
        }
        businessSystemMapper.updateByPrimaryKeySelective(businessSystemBo);

        List<BusinessSystemCallback> callbacks = callbackMapper.selectBySystemId(businessSystemBo.getSystemId());

//        List<Integer> deleteList = new ArrayList<Integer>();
        
        if(businessSystemBo.getCallbacks()!=null){
        	for (BusinessSystemCallback callbackPage : businessSystemBo.getCallbacks()) {
        		if (callbackPage.getCallbackId() == null ) {
        			if (StringUtils.isEmpty(callbackPage.getCallbackUrl())) continue;
        			callbackPage.setCreateTime(DateUtil.getCurrentDateString());
        			callbackPage.setAddUserId(user.getUserId());
        			callbackPage.setSystemId(businessSystemBo.getSystemId());
        			callbackPage.setEnterpriseId(businessSystemBo.getEnterpriseId());
        			callbackMapper.insert(callbackPage);
        		} else if (isUpdate(callbackPage.getCallbackId(),callbacks)) {
        			callbackPage.setEditUserId(user.getUserId());
        			callbackPage.setEditTime(DateUtil.getCurrentDateString());
        			callbackPage.setSystemId(businessSystemBo.getSystemId());
        			callbackPage.setEnterpriseId(businessSystemBo.getEnterpriseId());
        			callbackMapper.updateByPrimaryKeySelective(callbackPage);
        		}
        	}
        }


        for (BusinessSystemCallback callback : callbacks) {
            final Integer callbackId = callback.getCallbackId();
            if (isDelete(callbackId,businessSystemBo.getCallbacks())) {
                callbackMapper.deleteByPrimaryKey(callbackId);
            }
        }
    }

    public Integer deleteBusinessSystem(Integer id) {
        Integer count = sysLogMapper.selectCountBySystemId(id);
        if (count == 0) {
            callbackMapper.deleteBySystemId(id);
            businessSystemMapper.deleteByPrimaryKey(id);
        }
        return count == 0 ? 1 : 0;
    }

    public List<SysCode> getSysCodeByCodeNo(String codeTypeUseEnv) {

        return sysCodeMapper.getAllCodeBySystemNo(codeTypeUseEnv);
    }

    private boolean isDelete(Integer callbackId, List<BusinessSystemCallback> pageCallbacks) {
        for (BusinessSystemCallback pageCallback : pageCallbacks) {
            if (pageCallback.getCallbackId() == null) continue;
            if (callbackId.intValue() == pageCallback.getCallbackId().intValue()) {
                return false;
            }
        }
        return true;
    }


    private boolean isUpdate(Integer callbackId, List<BusinessSystemCallback> callbacks) {
        for (BusinessSystemCallback callback : callbacks) {
            if (callbackId.intValue() == callback.getCallbackId().intValue()) {
                return true;
            }
        }
        return false;

    }
}
