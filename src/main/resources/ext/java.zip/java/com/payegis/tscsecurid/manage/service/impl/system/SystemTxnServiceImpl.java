package com.payegis.tscsecurid.manage.service.impl.system;

import com.payegis.tscsecurid.common.data.bo.EnterpriseInfoBo;
import com.payegis.tscsecurid.common.data.entity.TxnLog;
import com.payegis.tscsecurid.common.data.entity.TxnStatus;
import com.payegis.tscsecurid.common.mapper.BaseMapper;
import com.payegis.tscsecurid.common.mapper.EnterpriseInfoMapper;
import com.payegis.tscsecurid.common.mapper.SystemTxnMapper;
import com.payegis.tscsecurid.common.service.BaseServiceImpl;
import com.payegis.tscsecurid.manage.service.business.system.SystemTxnService;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SystemTxnServiceImpl extends BaseServiceImpl implements SystemTxnService {

    private static Logger logger = Logger.getLogger(SystemTxnServiceImpl.class);

    @Autowired
    SystemTxnMapper systemTxnMapper;

    @Autowired
    EnterpriseInfoMapper enterpriseInfoMapper;

    @Override
    protected BaseMapper getMapper() {
        return systemTxnMapper;
    }

    @Override
    public List<TxnStatus> selectTxnStatusByLogId(String logId) {
        return systemTxnMapper.selectStatusByLogId(logId);
    }


    @Override
    public List<EnterpriseInfoBo> findAllEnterprise() {
        return enterpriseInfoMapper.findAllEnterprise();
    }

    @Override
    public TxnLog selectTxnLogByLogId(String logId) {
        return systemTxnMapper.selectTxnLogByLogId(logId);
    }
}
