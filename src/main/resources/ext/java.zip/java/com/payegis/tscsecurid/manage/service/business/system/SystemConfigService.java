package com.payegis.tscsecurid.manage.service.business.system;

import com.payegis.tscsecurid.common.data.bo.BusinessSystemBo;
import com.payegis.tscsecurid.common.data.bo.SysEnterpriseConfigBo;
import com.payegis.tscsecurid.common.data.entity.*;
import com.payegis.tscsecurid.common.service.BaseService;

import java.util.List;

/**
 * Created by liucheng on 2014/11/6.
 */
public interface SystemConfigService extends BaseService {
    void saveConfig(SysEnterpriseConfigBo configBo);

    SysEnterpriseConfig getSystemEnterpriseConfig(Integer enterpriseId);

    void saveFeedBackInfo(FeedbackInfo feedbackInfo);

    List<BusinessSystemBo> searchBusinessSystem(String businessName, String enterpriseNo, Integer enterpriseId);

    List<SysCode> getCallBackTypes();

    void createBusinessSystem(BusinessSystemBo businessSystemBo, StrategyConfig strategyConfig, SysUser user);

    BusinessSystemBo selectBusinessSystemBoById(Integer id);

    void updateBusinessSystem(BusinessSystemBo businessSystemBo, SysUser session);

    Integer deleteBusinessSystem(Integer id);

    List<SysCode> getSysCodeByCodeNo(String codeTypeUseEnv);

}
