package com.payegis.tscsecurid.manage.action.wx;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;

/**
 * Created by zzg on 2015/7/24.
 */
@Controller
public class Config {
    private static String tscServerUrl = null;
    private static String jsapiTicket = null;
    private static long time = 0l;
    private static boolean hasCreateButton = false;
    protected Logger logger = Logger.getLogger(this.getClass());

    public static String getTscServerUrl() {
        return tscServerUrl;
    }

    public static void setTscServerUrl(String tscServerUrl) {
        Config.tscServerUrl = tscServerUrl;
    }

    public static String getJsapiTicket() {
        return jsapiTicket;
    }

    public static void setJsapiTicket(String jsapiTicket) {
        Config.jsapiTicket = jsapiTicket;
    }

    public static boolean isHasCreateButton() {
        return hasCreateButton;
    }

    public static void setHasCreateButton(boolean hasCreateButton) {
        Config.hasCreateButton = hasCreateButton;
    }

    public static long getTime() {
        return time;
    }

    public static void setTime(long time) {
        Config.time = time;
    }

    private Config() {
    }

    private static Config instance = new Config();

    public static Config getInstance() {
        return instance;
    }


}
