package com.payegis.tscsecurid.manage.action.customer;

import com.alibaba.fastjson.JSON;
import com.payegis.tscsecurid.common.cache.CacheMgr;
import com.payegis.tscsecurid.common.constant.MessageKeys;
import com.payegis.tscsecurid.common.constant.PropertyFileKeys;
import com.payegis.tscsecurid.common.data.bo.ShortCodeLoginBo;
import com.payegis.tscsecurid.common.data.entity.MgrMenu;
import com.payegis.tscsecurid.common.data.entity.SysUser;
import com.payegis.tscsecurid.common.util.Base64;
import com.payegis.tscsecurid.common.util.Base64Util;
import com.payegis.tscsecurid.common.util.HttpUtil;
import com.payegis.tscsecurid.common.util.PropertyUtil;
import com.payegis.tscsecurid.manage.common.Constant;
import com.payegis.tscsecurid.manage.common.LoginBean;
import com.payegis.tscsecurid.manage.common.ManageException;
import com.payegis.tscsecurid.manage.service.business.customer.WebService;
import com.payegis.tscsecurid.manage.util.MessageUtil;
import com.payegis.tscsecurid.manage.util.SessionUtil;

import org.apache.commons.lang.StringUtils;
import org.codehaus.jettison.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author zw
 */
@Controller
public class WebAction extends ManageBaseAction {

    @Autowired
    private WebService webService;

    @Autowired
    CacheMgr cacheMgr;

    @RequestMapping("/")
    public String index() {
        return "forward:main";
    }
    @RequestMapping(value = "/login", method = RequestMethod.GET)
    public ModelAndView goLoginPage() {
        ModelAndView mav = new ModelAndView("login_simple");
        mav.addObject("loginBean", new LoginBean());
        mav.addObject("shortCodeLoginBo", new ShortCodeLoginBo());
        
        return mav;
    }
    
    @RequestMapping(value = "/loginShort", method = RequestMethod.GET)
    public ModelAndView loginShort(@RequestParam(value="systemNo") String systemNo) {
        ModelAndView mav = new ModelAndView("login");
        mav.addObject("loginBean", new LoginBean());
        ShortCodeLoginBo sclBo = new ShortCodeLoginBo();
        sclBo.setSystemNo(systemNo);
        mav.addObject("shortCodeLoginBo", sclBo);
        
        return mav;
    }

  //生成登录时空码
    @RequestMapping(value = "/logincode", method = RequestMethod.GET)
    public ModelAndView logincode(@RequestParam(value="systemNo") String systemNo,@RequestParam(value="serverUrl") String serverUrl,HttpServletRequest request) {
        ModelAndView mav = new ModelAndView("login");
        mav.addObject("loginBean", new LoginBean());
        mav.addObject("shortCodeLoginBo", new ShortCodeLoginBo());
        
        mav.addObject("systemNo", systemNo);
        String externalId = systemNo + "|" + request.getSession().getId()+"_payegis_manage" + "|" + serverUrl;
		mav.addObject("externalId",Base64Util.encodeToString(externalId.getBytes(), Base64Util.NO_WRAP));
        return mav;
    }
    //生成绑定时空码
    @RequestMapping(value = "/bindcode", method = RequestMethod.GET)
    public ModelAndView bindcode(@RequestParam(value="account",required=true)String account,
    		@RequestParam(value="systemNo",required=true) String systemNo,@RequestParam(value="serverUrl") String serverUrl) {
        ModelAndView mav = new ModelAndView("bind");
        mav.addObject("loginBean", new LoginBean());
        mav.addObject("shortCodeLoginBo", new ShortCodeLoginBo());
        	
         mav.addObject("account", account);
         mav.addObject("systemNo",	systemNo);
         String externalId = systemNo + "|" + account + "|" +serverUrl;
		 mav.addObject("externalId",Base64Util.encodeToString(externalId.getBytes(), Base64Util.NO_WRAP));
        return mav;
    }

    @RequestMapping(value = "/login", method = RequestMethod.POST)
    public ModelAndView doLogin(@ModelAttribute LoginBean loginBean,
                                BindingResult result, HttpServletRequest request) {
        ModelAndView mav = new ModelAndView();
        mav.addObject("shortCodeLoginBo", new ShortCodeLoginBo());
        mav.addObject("loginBean", loginBean);
        mav.addObject("loginType", "tradition-login");
        try {
            // validate user's input
            if (!validate(loginBean, mav, request)) {
                mav.setViewName("login");
                return mav;
            }
            SysUser user = webService.doUserLogin(loginBean.getLoginName(),
                    loginBean.getPassword());
            cacheMgr.setMemcache("manage_" + user.getUserName() + "_loginout", "N");
            super.getSessionInfo(request.getSession()).setLoginUser(user);
//            notifyUserLogin(true, user.getUserName());
            //同步时空码 绑定状态
            checkBindStatus(request);
            mav.setViewName("redirect:/log/logAnalysis");
        } catch (ManageException he) {
            mav.setViewName("login");
            mav.addObject("errorMsg", "用户名或密码有误");
        }

        return mav;
    }

    @RequestMapping(value = "/login_simple", method = RequestMethod.POST)
    public ModelAndView login_simple(@ModelAttribute LoginBean loginBean,
                                BindingResult result, HttpServletRequest request) {
        ModelAndView mav = new ModelAndView();
        mav.addObject("shortCodeLoginBo", new ShortCodeLoginBo());
        mav.addObject("loginBean", loginBean);
        mav.addObject("loginType", "tradition-login");
        try {
            // validate user's input
            if (!validate(loginBean, mav, request)) {
                mav.setViewName("login_simple");
                return mav;
            }
            SysUser user = webService.doUserLogin(loginBean.getLoginName(),
                    loginBean.getPassword());
            cacheMgr.setMemcache("manage_" + user.getUserName() + "_loginout", "N");
            super.getSessionInfo(request.getSession()).setLoginUser(user);
//            notifyUserLogin(true, user.getUserName());
            //同步时空码 绑定状态
            checkBindStatus(request);
            mav.setViewName("redirect:/log/logAnalysis");
        } catch (ManageException he) {
            mav.setViewName("login_simple");
            mav.addObject("errorMsg", "用户名或密码有误");
        }

        return mav;
    }
    
    @RequestMapping(value = "/main")
    public ModelAndView doMain(HttpServletRequest request) {
        //工作台信息查询
//        List<MgrMenu> menus = super.getSessionInfo(request.getSession()).getLoginUser().getMenus();
//        SysUser sysUser = (SysUser) SessionUtil.getUser(request.getSession());
//        String careId = null;
//        if (null != sysUser && !sysUser.isSystem()) {
//            careId = sysUser.getUserId().toString();
//        }

//        Map<String, Object> resMap = webService.findConsoleInfo(menus, careId);
        ModelAndView mav = new ModelAndView("redirect:/log/logAnalysis", null);
        mav.addObject("systemNo", "");
        return mav;
    }

    @RequestMapping(value = "/logout")
    public ModelAndView doLogout(HttpServletRequest request) {
        ModelAndView mav = new ModelAndView("forward:login");

        SysUser sysUser = super.getSessionInfo(request.getSession()).getLoginUser();
        if (null != sysUser) {
            notifyUserLogin(false, sysUser.getUserName());
        }
        // clear session
        super.clearSession(request);

        mav.addObject(new LoginBean());
        mav.addObject("shortCodeLoginBo", new ShortCodeLoginBo());
        return mav;
    }

    private boolean validate(LoginBean loginBean, ModelAndView mav,
                             HttpServletRequest request) {
        boolean valid = true;
        if (StringUtils.isEmpty(loginBean.getLoginName())) {
            valid = false;
            mav.addObject("errorMsg", "用户名不能为空");
        }

        if (StringUtils.isEmpty(loginBean.getPassword())) {
            valid = false;
            mav.addObject("errorMsg", "密码不能为空");
        }

        String verificationCode = (String) request.getSession().getAttribute(
                Constant.KAPTCHA_SESSION_KEY);
        if (verificationCode == null
                || !verificationCode.equals(loginBean.getValidCode())) {
            valid = false;
            mav.addObject("errorMsg", "验证码有误");

        }
        return valid;
    }

    @RequestMapping(value = "/checkquicklogin", method = RequestMethod.POST)
    @ResponseBody
    public String quickLogin(HttpServletRequest request) {

        JSONObject json = new JSONObject();
        String sid = request.getParameter("s");

        String loginName = (String) cacheMgr.getMemcache(sid);
        try {
            json.put("status", "F");
            json.put("message", "");
            if (!org.apache.commons.lang3.StringUtils.isEmpty(loginName)) {
                cacheMgr.setMemcache(request.getSession().getId() + "_payegis_manage", "");
                SysUser sysUser = webService.getSysUserByEmail(loginName);
                if (sysUser != null) {
                    String url = (String) request.getSession().getAttribute(
                            "url");
                    super.getSessionInfo(request.getSession()).setLoginUser(sysUser);
                    json.put("status", "S");
                    json.put("message", "");
                    cacheMgr.setMemcache("manage_" + sysUser.getUserName() + "_loginout", "N");
//                    notifyUserLogin(true, sysUser.getUserName());
                    //同步时空码 绑定状态
//                    checkBindStatus(request);
                    return json.toString();
                }
            }
        } catch (Exception e) {
            // ignore
        }
        return json.toString();
    }

    public void checkBindStatus(HttpServletRequest request) {


        SysUser sysUser = super.getSessionInfo(request.getSession()).getLoginUser();
        if (null != sysUser) {
            try {
                request.getSession().setAttribute("bindStatus", "unKnow");
                Map<String, String> param = new HashMap<String, String>();
                param.put("appId", PropertyFileKeys.MANAGE_APP_ID);
                param.put("partnerCode", PropertyFileKeys.MANAGE_PARTNERCODE);
                param.put("loginName", sysUser.getUserName());
                String url = PropertyUtil.getPropertyValue("config.properties", "mobile.pass.url");
                if (!org.apache.commons.lang3.StringUtils.endsWith(url, "/")) {
                    url += "/";
                }
//                ClientResponse cr = WSUtil.sendRequestPostWithFormData(url + "rest/client/check3rdPartyAccountforCloud", param);
                String re = HttpUtil.post(url + "rest/client/check3rdPartyAccountforCloud", param);
                if (StringUtils.isNotBlank(re)) {
                    com.alibaba.fastjson.JSONObject resJson = JSON
                            .parseObject(re);
                    String status = resJson.getString("status");
                    if ("10".equals(status)) {
                        request.getSession().setAttribute("bindStatus", "N");
                    } else if ("0".equals(status)) {
                        request.getSession().setAttribute("bindStatus", "Y");
                    }
                }

            } catch (Exception e) {
                // ignore
            }
        }
    }


    @RequestMapping(value = "/doShortCodeLogin", method = RequestMethod.POST)
    public ModelAndView doShortCodeLogin(
            @ModelAttribute("shortCodeLoginBo") @Valid ShortCodeLoginBo shortCodeLoginBo,
            BindingResult result, HttpServletRequest request,
            HttpServletResponse response) {
        ModelAndView mav = new ModelAndView();
        mav.addObject("loginType", "short-code-login");
        mav.addObject("shortCodeLoginBo", shortCodeLoginBo);
        mav.addObject("loginBean", new LoginBean());
        if (result.hasErrors()) {
            mav.addObject("errorMsg", "请输入帐号和时空令");
            mav.setViewName("login");
            return mav;
        }

        String validCode = (String) request.getSession().getAttribute(PropertyFileKeys.KAPTCHA_SESSION_KEY);
        if (!shortCodeLoginBo.getValidCode().equals(validCode) &&
                !"8888".equals(shortCodeLoginBo.getValidCode())) {
            mav.setViewName("login");
            mav.addObject("errorMsg", "验证码错误");
            return mav;
        }

        SysUser sysUser = webService.getSysUserByEmail(shortCodeLoginBo.getEmail());
        if (null == sysUser) {
            mav.setViewName("login");
            mav.addObject("errorMsg", "用户不存在");
            return mav;
        }


        Map<String, String> param = new HashMap<String, String>();
        String systemNo = shortCodeLoginBo.getSystemNo();
        if(null == systemNo || "".equals(systemNo)){
        	systemNo = "913e4d2d6f414ec4b9ae5cf092785437";
        }
        String url = PropertyUtil.getPropertyValue("config.properties", "tscsecurid.rest.url");
        if (!org.apache.commons.lang3.StringUtils.endsWith(url, "/")) {
            url += "/";
        }
        param.put("systemNo", systemNo);
        param.put("dcCode", shortCodeLoginBo.getShortCode());
        param.put("systemAccount", shortCodeLoginBo.getEmail());
        param.put("systemUrl", url);

        
        try {
//            ClientResponse cr = WSUtil.sendRequestPostWithFormData(url + "rest/client/shortCodeLogin", param);
            String res = HttpUtil.post(url + "account/checkPass", param);
            logger.info("short code login:" + res);

            com.alibaba.fastjson.JSONObject jsonRes = com.alibaba.fastjson.JSONObject.parseObject(res);

            if ("0".equals(jsonRes.getString("status"))) {
                    /*String from_url = (String) request.getSession().getAttribute("from_url");
                    if (org.apache.commons.lang3.StringUtils.isNotEmpty(from_url)) {
                        mav.setViewName("redirect:" + from_url);
                        request.getSession().removeAttribute("from_url");
                    } else {
                        mav.setViewName("redirect:/memberCenter/");
                    }*/
                mav.setViewName("redirect:/main/");
                super.getSessionInfo(request.getSession()).setLoginUser(sysUser);
                cacheMgr.setMemcache("manage_" + sysUser.getUserName() + "_loginout", "N");
//                notifyUserLogin(true, sysUser.getUserName());
                //同步时空码 绑定状态
                checkBindStatus(request);
                return mav;
            }
        } catch (Exception e) {
            logger.warn("short code login, failed." + e.getMessage());
        }

        mav.setViewName("login");
        mav.addObject("errorMsg", "登录失败，请重试");
        return mav;
    }


    @RequestMapping(value = "/core/quicklogin", method = RequestMethod.POST, produces = "application/json; charset=utf-8")
    @ResponseBody
    public String checkQuickLogin(HttpServletRequest request,
                                  @RequestParam("did") String did,
                                  @RequestParam("sid") String sid,
                                  @RequestParam("uid") String uid) {
        logger.info(">>>>>>>>>>>>>>>>>>>>> quick login:did:" + did + " , sessionId:" + sid + " , loginName:" + uid);
        JSONObject json = new JSONObject();

        try {
            json.put("status", "1");
            json.put("message", "登录失败");

            SysUser sysUser = webService.getSysUserByEmail(uid);
            if (null != sysUser) {
                cacheMgr.setMemcache(sid, uid, 120);
                json.put("status", "0");
                json.put("message", "登录成功");
            }else{
            	json.put("status", "2");
              json.put("message", "没有该用户");
            }
        } catch (Exception e) {
        }
        return json.toString();
    }
    /**
     * 退出回调接口
     * @param request  页面请求
     * @param userName 用户登录名
     * @return JSON字符串{"status":"0","message":"退出成功"} status=1退出不成功； status=1成功退出；
     */
    @RequestMapping(value = "/core/loginout", method = RequestMethod.POST, produces = "application/json; charset=utf-8")
    @ResponseBody
    public String coreLoginOut(HttpServletRequest request,
                               @RequestParam("userId") String userName) {
        logger.info("loginout loginName:" + userName);
        JSONObject json = new JSONObject();

        try {
            json.put("status", "1");
            json.put("message", "退出失败");

            if (StringUtils.isNotBlank(userName)) {
                cacheMgr.setMemcache("manage_" + userName + "_loginout", "Y");
                json.put("status", "0");
                json.put("message", "退出成功");
            }
        } catch (Exception e) {
            logger.warn("error when loginout," + e.getMessage());
        }
        return json.toString();
    }

    @RequestMapping(value = "/checkquickloginOut", method = RequestMethod.POST)
    @ResponseBody
    public String quickLoginOut(HttpServletRequest request) {
        JSONObject json = new JSONObject();
        String sid = request.getParameter("s");
        try {
            json.put("status", "0");
            SysUser sysUser = super.getSessionInfo(request.getSession()).getLoginUser();
            //获取当前登录用户是否存在
            if (null != sysUser) {
                String status = (String) cacheMgr.getMemcache("manage_" + sysUser.getUserName() + "_loginout");
                if ("Y".equals(status)) {
//                    notifyUserLogin(false, sysUser.getUserName());
                    request.getSession().invalidate();
                    json.put("status", "1");
                }
            }
        } catch (Exception e) {
            logger.warn("error :" + e.getMessage());
        }
        return json.toString();
    }

    @RequestMapping(value = "/unbind", method = RequestMethod.GET)
    public ModelAndView unbind(HttpServletRequest request, RedirectAttributes redirectAttributes) {
        SysUser sysUser = super.getSessionInfo(request.getSession()).getLoginUser();
        redirectAttributes.addFlashAttribute("msg",
                MessageUtil.getMessage(MessageKeys.ERROR_OPERATE, null, null));

        if (null != sysUser) {
            try {
                String url = PropertyUtil.getPropertyValue("config.properties",
                        "mobile.pass.url");
                if (!StringUtils.endsWith(url, "/")) {
                    url += "/";
                }
                Map<String, String> map = new HashMap<String, String>();
                map.put("loginName", sysUser.getUserName());
                map.put("appId", PropertyFileKeys.MANAGE_APP_ID);
                map.put("partnerCode", PropertyFileKeys.MANAGE_PARTNERCODE);
                /*ClientResponse cr = WSUtil.sendRequestPostWithFormData(url
                        + "rest/client/unbind3rdPartyAccountforCloud", map);*/
                String res = HttpUtil.post(url + "rest/client/unbind3rdPartyAccountforCloud", map);
                logger.info("unbind account:" + res);
                if (StringUtils.isNotBlank(res)) {
                    com.alibaba.fastjson.JSONObject resJson = JSON
                            .parseObject(res);
                    String status = resJson.getString("status");
                    if ("0".equals(status)) {
                        request.getSession().setAttribute("bindStatus", "N");
                        redirectAttributes.addFlashAttribute("msg", MessageUtil.getMessage(
                                MessageKeys.SUCCESS_OPERATE, null, null));
                    } else if ("20".equals(status)) {
                        redirectAttributes.addFlashAttribute("msg", MessageUtil.getMessage(
                                MessageKeys.ERROR_USER_HAVE_UNBIND, null, null));
                    }
                }
            } catch (Exception e) {
                logger.warn("erro when unbind status." + e.getMessage());
                redirectAttributes.addFlashAttribute("msg", MessageUtil.getMessage(MessageKeys.ERROR_OPERATE, null, null));
            }
        }
/*        String referer = request.getHeader("referer");
        ModelAndView mav = new ModelAndView("redirect:"+referer,mmap);*/
        ModelAndView mav = new ModelAndView("redirect:/main/");
        return mav;
    }

    //通知用户登录状态
    private void notifyUserLogin(boolean isLogin, String customerId) {
        new Thread(new NotifyUserLoginStatus(isLogin, customerId)).start();
    }

    class NotifyUserLoginStatus implements Runnable {
        private boolean isLogin;
        private String customerId;

        public NotifyUserLoginStatus(boolean isLogin, String customerId) {
            this.isLogin = isLogin;
            this.customerId = customerId;
        }

        @Override
        public void run() {
            logger.info("notify user:" + customerId + " login status:" + isLogin);
            Map<String, String> param = new HashMap<String, String>();
            param.put("appId", PropertyFileKeys.MANAGE_APP_ID);
            param.put("partnerCode", PropertyFileKeys.MANAGE_PARTNERCODE);
            param.put("userId", customerId);
            if (isLogin) {
                //通知登录状态
                param.put("onlineStatus", "1");
            } else {
                //通知退出状态
                param.put("onlineStatus", "2");
            }
            String url = PropertyUtil.getPropertyValue("config.properties", "mobile.pass.url");
            if (!org.apache.commons.lang3.StringUtils.endsWith(url, "/")) {
                url += "/";
            }
            try {
//                ClientResponse cr = WSUtil.sendRequestPostWithFormData(url + "rest/client/updateBindUserStatus", param);
//                logger.info("notify user status:" + cr.getStatus());
                String result = HttpUtil.post(url + "rest/client/updateBindUserStatus", param);
                logger.info("notify user result:" + result);
            } catch (Exception e) {
                logger.warn("update bind user status error." + e.getMessage());
            }
        }

    }
    
    /**
     * 校验时空令是否合法
     * @param shortCodeLoginBo
     * @return 0：合法  其余不合法
     */
    @RequestMapping(value = "/checkTscCode", method = RequestMethod.POST)
    @ResponseBody
    public String checkTscCode(ShortCodeLoginBo shortCodeLoginBo) {
        Map<String, String> param = new HashMap<String, String>();
        param.put("appId", PropertyFileKeys.MANAGE_APP_ID);
        param.put("partnerCode", "000");
        param.put("dcCode", shortCodeLoginBo.getShortCode());
        param.put("loginName", shortCodeLoginBo.getEmail());
        String url = PropertyUtil.getPropertyValue("config.properties", "mobile.pass.url");
        if (!org.apache.commons.lang3.StringUtils.endsWith(url, "/")) {
            url += "/";
        }
        String resStatus="";
        try {
            String res = HttpUtil.post(url + "rest/client/shortCodeLogin", param);
            com.alibaba.fastjson.JSONObject jsonRes = com.alibaba.fastjson.JSONObject.parseObject(res);
            resStatus = jsonRes.getString("status");
        } catch (Exception e) {
            logger.warn("short code check, failed." + e.getMessage());
        }
        return resStatus;
    }
}
