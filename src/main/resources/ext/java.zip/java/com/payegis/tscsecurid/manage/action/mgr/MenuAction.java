package com.payegis.tscsecurid.manage.action.mgr;


import com.payegis.tscsecurid.common.data.entity.MgrMenu;
import com.payegis.tscsecurid.common.util.DateUtil;
import com.payegis.tscsecurid.manage.action.customer.ManageBaseAction;
import com.payegis.tscsecurid.manage.service.business.mgr.MenuService;
import com.payegis.tscsecurid.manage.util.MessageUtil;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping(value="/menu")
public class MenuAction extends ManageBaseAction {
	
	@Autowired
	private MenuService menuService;

	@RequestMapping(value="/load")
	public ModelAndView prepareMenu(){
		ModelAndView mav=new ModelAndView();
		
		List<MgrMenu> menus=menuService.retrieveMenus();
		
		List<TreeJson> result=prepareMenuTree(menus);
		
		JSONArray jsonArray=JSONArray.fromObject(result);
		String arrayResult=jsonArray.toString();
		mav.setViewName("page/mgr/menulist");
		mav.addObject("menus", arrayResult);
		return mav;
	}
	
	@RequestMapping(value="/refresh")
	@ResponseBody
	public String refresh(){
		
		List<MgrMenu> menus=menuService.retrieveMenus();
		
		List<TreeJson> result=prepareMenuTree(menus);
		
		JSONArray jsonArray=JSONArray.fromObject(result);
		String arrayResult=jsonArray.toString();

		return arrayResult;
	}
	
	
	@RequestMapping(value="/loadMenu")
	@ResponseBody
	public String loadMenu(HttpServletRequest request){
		String id= request.getParameter("id");
		
		MgrMenu menu=menuService.retrieveMenuById(id);
		
		JSONObject json=JSONObject.fromObject(menu);
		return json.toString();
	}
	
	@RequestMapping(value="/del")
	@ResponseBody
	public String del(HttpServletRequest request){
		String id= request.getParameter("id");
		
		menuService.delMenuById(Integer.valueOf(id));
		
		CommonJSON cj=new CommonJSON(STATUS_SUCCESS, MessageUtil.getMessage(SUCCESS_OPERATION, null, null));
		return cj.toString();
	}
	
	@RequestMapping(value="/add")
	@ResponseBody
	public String add(HttpServletRequest request){
		String parentId=request.getParameter("menuId");
		String menuName=request.getParameter("menuName");
		String menuIcon=request.getParameter("menuIcon");
		String url=request.getParameter("url");
		String privilege=request.getParameter("privilege");
		String order=request.getParameter("order");
		CommonJSON cj=validateMenu(menuName, privilege);
		
		if( cj !=null){
			return cj.toString();
		}

		Map<String, String> params = new HashMap<String, String>();
		params.put("parent",parentId);
		params.put("menuName",menuName);
		params.put("menuIcon",menuIcon);
		params.put("url",url);
		params.put("privilege",privilege);
		params.put("order",order);
		menuService.createMenu(buildMenuEntity(params, request));
		
		cj=new CommonJSON(STATUS_SUCCESS, MessageUtil.getMessage(SUCCESS_OPERATION,null, null));
		return cj.toString();
		
		
	}
	
	@RequestMapping(value="/edit")
	@ResponseBody
	public String edit(HttpServletRequest request){
		String menuId=request.getParameter("menuId");
		String menuName=request.getParameter("menuName");
		String menuIcon=request.getParameter("menuIcon");
		String url=request.getParameter("url");
		String privilege=request.getParameter("privilege");
		String order=request.getParameter("order");
		
		MgrMenu entity=menuService.retrieveMenuById(menuId);
		
		CommonJSON cj=validateMenu(menuName, privilege);
		
		if( cj !=null){
			return cj.toString();
		}
		
		if(StringUtils.isEmpty(url)) url="#";
		
		entity.setMenuName(menuName);
		entity.setMenuIconMdbKey(menuIcon);
		entity.setUrl(url);
		entity.setPrivilegeId(privilege);
		if(StringUtils.isNumeric(order)){
		   entity.setOrder(Integer.valueOf(order));
		}else{
		   entity.setOrder(0);
		}

        entity.setUpdateTime(DateUtil.getCurrentDateString());
		entity.setUpdater(getCurretnUserName(request));
		menuService.updateMenu(entity);

		cj=new CommonJSON(STATUS_SUCCESS, MessageUtil.getMessage(SUCCESS_OPERATION,null, null));
		return cj.toString();
		
		
	}
	
	private CommonJSON validateMenu(String menuName,String privilege){
		CommonJSON cj=null;
		if(StringUtils.isEmpty(menuName)){
			cj=new CommonJSON();
			cj.setStatus(STATUS_ERROR);
			cj.setMessage(MessageUtil.getMessage(ERROR_MENU_NAME_MANDATORY, null, null));
		}
		if(StringUtils.isEmpty(privilege) || "null".equals(privilege)){
			cj=cj==null ? new CommonJSON() : cj;
			cj.setStatus(STATUS_ERROR);
			cj.setMessage(MessageUtil.getMessage(ERROR_MENU_PRIVILEGE_MANDATORY, null, null));
		}
		
		return cj;
	}
	
	private List<TreeJson> prepareMenuTree(List<MgrMenu> list){
		if(list==null) return null;
		List<TreeJson> jsonList=new ArrayList<TreeJson>();
		for(MgrMenu m: list){
			jsonList.add(new TreeJson(m.getMenuId(), m.getParent(), m.getMenuName(), true));
			
		}
		
		List<TreeJson> newTreeList=new ArrayList<TreeJson>();
		for(TreeJson tj: jsonList){
			arrangeMenu(tj, jsonList , newTreeList);
		}
		
		
		return newTreeList;
	}
	
	private void arrangeMenu(TreeJson m, List<TreeJson> list , List<TreeJson> newList){
		if(m.getpId()<0){
			newList.add(m);
			return;
		}else{
			for(TreeJson parentMenu: list){
				if(parentMenu.getId() == m.getpId()){
					parentMenu.getChildren().add(m);
				}
			}
		}
	}
	
	private MgrMenu buildMenuEntity(String parent,String menuName,String menuIcon, String url, String privilege,String order, HttpServletRequest request){
	   MgrMenu entity=new MgrMenu();
		entity.setMenuName(menuName);
		entity.setMenuIconMdbKey(menuIcon);
		if(StringUtils.isNumeric(parent)){
		   entity.setParent(Integer.parseInt(parent));
		}else{
		   entity.setParent(-1);
		}
		if(StringUtils.isEmpty(url)) url="#";
		entity.setUrl(url);
		if(StringUtils.isNumeric(order)){
		   entity.setOrder(Integer.valueOf(order));
		}else{
		   entity.setOrder(0);
		}
		entity.setPrivilegeId(privilege);
        entity.setCreateTime(DateUtil.getCurrentDateString());
        entity.setUpdateTime(DateUtil.getCurrentDateString());
		entity.setCreator(getCurretnUserName(request));
		entity.setUpdater(getCurretnUserName(request));
		return entity;
	}

	private MgrMenu buildMenuEntity(Map<String, String> params, HttpServletRequest request){
		MgrMenu entity=new MgrMenu();
		entity.setMenuName(params.get("menuName"));
		entity.setMenuIconMdbKey(params.get("menuIcon"));
		if(StringUtils.isNumeric(params.get("parent"))){
			entity.setParent(Integer.parseInt(params.get("parent")));
		}else{
			entity.setParent(-1);
		}
		if(StringUtils.isEmpty(params.get("url"))){
			entity.setUrl("#");
		}else{
			entity.setUrl(params.get("url"));
		}
		if(StringUtils.isNumeric(params.get("order"))){
			entity.setOrder(Integer.valueOf(params.get("order")));
		}else{
			entity.setOrder(0);
		}
		entity.setPrivilegeId(params.get("privilege"));
		entity.setCreateTime(DateUtil.getCurrentDateString());
		entity.setUpdateTime(DateUtil.getCurrentDateString());
		entity.setCreator(getCurretnUserName(request));
		entity.setUpdater(getCurretnUserName(request));
		return entity;
	}
	
	public class TreeJson implements Serializable{
		//{ id:1, pId:0, name:"普通的父节点", t:"我很普通，随便点我吧", open:true},
		/*
		 * [
			{id:1, name:"无右键菜单 1", open:true, noR:true,
				children:[
					   {id:11, name:"节点 1-1", noR:true},
					   {id:12, name:"节点 1-2", noR:true}

				]},
			{id:2, name:"右键操作 2", open:true,
				children:[
					   {id:21, name:"节点 2-1"},
					   {id:22, name:"节点 2-2"},
					   {id:23, name:"节点 2-3"},
					   {id:24, name:"节点 2-4"}
				]},
			{id:3, name:"右键操作 3", open:true,
				children:[
					   {id:31, name:"节点 3-1"},
					   {id:32, name:"节点 3-2"},
					   {id:33, name:"节点 3-3"},
					   {id:34, name:"节点 3-4"}
				]}
  	 	]
		 * */
		private int id;
		private int pId;
		private String name;
		private boolean open;
		private List<TreeJson> children=new ArrayList<TreeJson>();
		
		public TreeJson(){}
		
		public TreeJson(int id,int pId, String name, boolean open) {
			super();
			this.id = id;
			this.pId= pId;
			this.name = name;
			this.open = open;
		}
		public TreeJson(int id,int pId, String name, boolean open,
				List<TreeJson> children) {
			super();
			this.id = id;
			this.pId=pId;
			this.name = name;
			this.open = open;
			this.children = children;
		}
		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public boolean getOpen() {
			return open;
		}
		public void setOpen(boolean open) {
			this.open = open;
		}
		public List<TreeJson> getChildren() {
			return children;
		}
		public void setChildren(List<TreeJson> children) {
			this.children = children;
		}

		public int getpId() {
			return pId;
		}

		public void setpId(int pId) {
			this.pId = pId;
		}
		
		
		
	}
	
}