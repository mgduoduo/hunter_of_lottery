package com.payegis.tscsecurid.manage.filter;

import com.payegis.tscsecurid.common.util.StringUtil;
import org.apache.log4j.Logger;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;


/**
 * @author xuman.xu
 */
public class WxFilter implements Filter {
    private static Logger logger = Logger.getLogger(WxFilter.class);

    public void destroy() {

    }


    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        logger.debug("WxFilter.doFilter()");

        HttpServletRequest httpRequest = (HttpServletRequest) request;
        //String userAgent = httpRequest.getHeaders("User-Agent").toString();

        String agent=httpRequest.getHeader("User-Agent").toLowerCase();
        String url = httpRequest.getRequestURI();
        if("micromessenger".equals(getBrowserName(agent))){
            HttpServletRequest req = ((HttpServletRequest) request);
            req.getSession().setAttribute("requestUrl",url);
           // String openid = (String) request.getSession().getAttribute("openid");
            String openid = (String) req.getSession().getAttribute("openid");
            if(StringUtil.isEmpty(openid)){
                request.getRequestDispatcher("/wx/temp").forward(request,response);
                return;
            }
        }else{
            request.getRequestDispatcher("/wx/bussiness/promote").forward(request,response);
            return;
        }
        chain.doFilter(request,response);
    }

    /**
     * 获取浏览器版本信息
     * @Title: getBrowserName
     * @data:2015-1-12下午05:08:49
     * @author:wolf
     *
     * @param agent
     * @return
     */
    public String getBrowserName(String agent) {
        if(agent.indexOf("micromessenger")>0){
            return "micromessenger";
        }
        else{
            return "Others";
        }
     /*if(agent.indexOf("msie 7")>0){
      return "ie7";
     }else if(agent.indexOf("msie 8")>0){
      return "ie8";
     }else if(agent.indexOf("msie 9")>0){
      return "ie9";
     }else if(agent.indexOf("msie 10")>0){
      return "ie10";
     }else if(agent.indexOf("msie")>0){
      return "ie";
     }else if(agent.indexOf("opera")>0){
      return "opera";
     }else if(agent.indexOf("chrome")>0){
      return "chrome";
     }else if(agent.indexOf("firefox")>0){
      return "firefox";
     }
     else if(agent.indexOf("baidu")>0){
         return "firefox";
     }
     else if(agent.indexOf("micromessenger")>0){
      return "micromessenger";
     }
     else{
      return "Others";
     }*/
    }

    public void init(FilterConfig arg0) throws ServletException {

    }



}


