package com.payegis.tscsecurid.manage.aspect;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;

/**
 * 通用切面
 * 
 * @author xuman.xu
 * 
 */
public abstract class CommonAspect {

	/**
	 * 后置通知
	 * 
	 * @param jp
	 * @throws Exception
	 */
	public abstract void doAfter(JoinPoint jp) throws Exception;

	/**
	 * 环绕通知
	 * 
	 * @param pjp
	 * @return
	 * @throws Throwable
	 */
	public abstract Object doAround(ProceedingJoinPoint pjp) throws Throwable;

	/**
	 * 前置通知
	 * 
	 * @param jp
	 */
	public abstract void doBefore(JoinPoint jp);

	/**
	 * 异常通知
	 * 
	 * @param jp
	 * @param ex
	 */
	public abstract void doThrowing(JoinPoint jp, Throwable ex);

}
