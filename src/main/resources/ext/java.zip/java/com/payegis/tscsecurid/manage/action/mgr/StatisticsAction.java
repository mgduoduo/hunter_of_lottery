package com.payegis.tscsecurid.manage.action.mgr;

import com.payegis.tscsecurid.common.action.BaseAction;
import com.payegis.tscsecurid.common.constant.PropertyFileKeys;
import com.payegis.tscsecurid.common.data.entity.BusinessSystem;
import com.payegis.tscsecurid.common.data.entity.SysCode;
import com.payegis.tscsecurid.common.data.entity.SysLog;
import com.payegis.tscsecurid.common.data.entity.SysUser;
import com.payegis.tscsecurid.common.result.ResultBean;
import com.payegis.tscsecurid.common.util.UserAgentUtil;
import com.payegis.tscsecurid.manage.service.business.mgr.LogService;
import com.payegis.tscsecurid.manage.util.SessionUtil;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by liucheng on 2015/1/6.
 */
@Controller
@RequestMapping("/log")
public class StatisticsAction extends BaseAction {
    @Autowired
    private LogService logService;

    @ModelAttribute("businessTypes")
    public Map<Integer, String> getBusinessTypes(HttpSession session) {
        SysUser su = SessionUtil.getUser(session);
        Map<Integer, String> map = new HashMap<Integer, String>();
        if (null != su) {
            Map<String, Object> param = new HashMap<String, Object>();
            if (!su.getEnterpriseNo().equals(
                    PropertyFileKeys.ENTERPRISE_NO_PAYEGIS))
                param.put("enterpriseId", su.getEnterpriseId());
            List<BusinessSystem> bs = logService
                    .getBusinessSystemByEnterpriseId(param);
            if (null != bs && !bs.isEmpty()) {
                for (BusinessSystem b : bs) {
                    map.put(b.getSystemId(), b.getSystemName());
                }
            }
        }
        return map;
    }

    @ModelAttribute("logTypes")
    public Map<String, String> getLogTypes(HttpSession session) {
        Map<String, String> map = new HashMap<String, String>();
        List<SysCode> sysCodes = logService
                .getAllCodeBySystemNo(PropertyFileKeys.CODE_TYPE_CALL_BACK);
        if (null != sysCodes && !sysCodes.isEmpty()) {
            for (SysCode sc : sysCodes) {
                if (sc.getCodeNo().equals("login") || sc.getCodeNo().equals("open"))
                    map.put(sc.getCodeNo(), sc.getCodeValue());
            }
        }
        return map;
    }

    @RequestMapping("/statistics")
    public String logStatisticsQuery(Model model) {
        return "page/mgr/log_statistics";
    }

    @RequestMapping(value = "/statisticsSearch")
    public String logSearch(SysLog sysLog,Model model, HttpSession session) {
        SysUser su = SessionUtil.getUser(session);
        sysLog.setEnterpriseId(su.getEnterpriseId());
        sysLog.setOrder("DESC");
        ResultBean<SysLog> resultBean = logService.statisticsSearch(sysLog);
        model.addAttribute("result", resultBean);
        return "page/mgr/log_statistics_list";
    }

    @RequestMapping(value = "/statisticsSearch/export")
    public ModelAndView logSearchExport(SysLog sysLog, HttpServletResponse response,Model model,HttpServletRequest request) {
        SysUser su = SessionUtil.getUser(request.getSession());
        sysLog.setEnterpriseId(su.getEnterpriseId());
        sysLog.setOrder("DESC");
        sysLog.setRows(0);
        ResultBean<SysLog> resultBean = logService.statisticsSearch(sysLog);
        try {
            Workbook wb = new HSSFWorkbook();
            Sheet sheet =  wb.createSheet();
            Row row = sheet.createRow(0);
            row.createCell(0).setCellValue("设备ID");
            row.createCell(1).setCellValue("业务系统");
            row.createCell(2).setCellValue("关联账号");
            row.createCell(3).setCellValue("操作次数");
            row.createCell(4).setCellValue("日志类型");

            Map<String, String> logTypes = (Map<String, String>) model.asMap().get("logTypes");
            Map<Integer, String> businessTypes = (Map<Integer, String>) model.asMap().get("businessTypes");
            for (int i = 0; i < resultBean.getRows().size(); i++) {
                final int rowIndex = i + 1;
                Row rowLoop = sheet.createRow(rowIndex);
                SysLog log = resultBean.getRows().get(i);
                rowLoop.createCell(0).setCellValue(log.getDeviceId());
                rowLoop.createCell(1).setCellValue(businessTypes.get(log.getSystemId()));
                rowLoop.createCell(2).setCellValue(log.getBindingAccount());
                rowLoop.createCell(3).setCellValue(log.getLogCount());
                rowLoop.createCell(4).setCellValue(logTypes.get(log.getLogType()));
            }

            String filename = "日志报表.xls";//设置下载时客户端Excel的名称
            filename = UserAgentUtil.encodeFileName(request, filename);//处理中文文件名
            response.setContentType("application/vnd.ms-excel");
            response.setHeader("Content-disposition", "attachment;" + filename);
            OutputStream ouputStream = response.getOutputStream();
            wb.write(ouputStream);
            ouputStream.flush();
            ouputStream.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }


}
