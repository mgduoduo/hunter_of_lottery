package com.payegis.tscsecurid.manage.action.cloud;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.payegis.tscsecurid.common.constant.PropertyFileKeys;
import com.payegis.tscsecurid.common.data.bo.BindingInfoEnterpriseQueryBo;
import com.payegis.tscsecurid.common.data.bo.BindingLogEnterpriseBo;
import com.payegis.tscsecurid.common.data.entity.*;
import com.payegis.tscsecurid.common.result.ResultBean;
import com.payegis.tscsecurid.common.util.DateUtil;
import com.payegis.tscsecurid.manage.service.business.system.BindingInfoEnterpriseService;
import com.payegis.tscsecurid.manage.util.SessionUtil;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;
import java.util.List;

/**
 * Created by liucheng on 2014/12/9.
 */

@Controller
@RequestMapping("/saas")
public class CloudSaasUNBindingAction {
    private static final Logger logger = Logger.getLogger(CloudUNBindingAction.class);

    @ModelAttribute("search_url")
    public String getSearchUrl() {
        return "/saas/unbind/search";
    }

    @Autowired
    BindingInfoEnterpriseService bindingInfoEnterpriseService;

    @RequestMapping("/unbind")
    public String showUnbindSupply(Model model) {
        return "page/saas/unbind";
    }

    @RequestMapping("/unbind/search")
    public String search(BindingInfoEnterpriseQueryBo queryBo,Model model) {
        if (StringUtils.isNotEmpty(queryBo.getStartDate())) {
            queryBo.setStartDate(queryBo.getStartDate() + " 00:00:00");
        }
        if (StringUtils.isNotEmpty(queryBo.getEndDate())) {
            queryBo.setEndDate(queryBo.getEndDate() + " 23:59:59");
        }
        ResultBean<BindingInfoEnterprise> bindingInfoResultBean = bindingInfoEnterpriseService.getPageList(queryBo);
        model.addAttribute("result", bindingInfoResultBean);
        return "page/saas/unbind_list";
    }

    @ResponseBody
    @RequestMapping("/unbind/getBindingInfo")
    public String getBindingInfo(@RequestParam Integer bindId,Model model,HttpSession session) {
        JSONObject jsonObject = new JSONObject();
        BindingInfoEnterprise infoBo = bindingInfoEnterpriseService.getBindingInfoByPrimaryKey(bindId);
        if (infoBo != null) {
            jsonObject.put("status", "success");
            jsonObject.put("data", infoBo);
        } else {
            jsonObject.put("status", "error");
            jsonObject.put("message", "该账号已被解绑！");
        }
        return jsonObject.toJSONString();
    }

    @ResponseBody
    @RequestMapping(value = "/unbinding",method = RequestMethod.POST)
    public String unBinding(BindingLogEnterprise log,@RequestParam Integer bindingInfoId,Model model,HttpSession session) {
        SysUser user = SessionUtil.getUser(session);
        log.setBindingLogType(PropertyFileKeys.BINDING_LOG_TYPE_UNBINDING);
        log.setUnbindingType(PropertyFileKeys.UNBINDING_TYPE_SERVICE);
        log.setOperationUser(user.getUserId());
        log.setOperationTime(DateUtil.getCurrentDateString());
        try {
            bindingInfoEnterpriseService.saveUnBinding(log, bindingInfoId);
            return "success";
        } catch (Exception e) {
            logger.error(e);
            return "error";
        }
    }

    @ResponseBody
    @RequestMapping("/accountHistory")
    public String showAccountHistory(BindingLogEnterprise bindingLog) {
        bindingLog.setBindingLogType(PropertyFileKeys.BINDING_LOG_TYPE_UNBINDING);
        List<BindingLogEnterpriseBo> bindingLogs = bindingInfoEnterpriseService.selectAccountHistory(bindingLog);
        return JSON.toJSONString(bindingLogs);
    }

}
