package com.payegis.tscsecurid.manage.common;

public interface Constant {

	// Default database value
	public static final String SYSTEM_USER = "system";
	public static final String SITE_KEY="";

	public static final int DEFAULT_PAGE_SIZE = 10;

	// Keys for session
	public static final String KEY_SESSION_INFO = "loginUser";
	public static final String KEY_REQUEST_MESSAGE = "r_message";
	public static final String KEY_REQUEST_CURRENT_TOP_MENU = "r_current_top_menu"; // 当前用户所选择的Top
																					// menu
	public static final String KEY_REQUEST_CURRENT_LEFT_MENU = "r_current_left_menu"; // 当前用户所选择的Top
	
	String KAPTCHA_SESSION_KEY = "kaptcha";
	int COOKIE_DURATION = 7;// 自动登录Cookie默认保存时间

	public static final String STATUS_SUCCESS = "success";
	public static final String STATUS_ERROR = "error";

    public static  final String PUBLISH_STATE_ON = "on";

    public static final String JSON_KEY_STATUS="status";
    public static final String JSON_KEY_MESSAGE="message";
    public static final String JSON_KEY_DATA="data";
    public static final String JSON_KEY_RESULT="result";
    public static final String API_STATUS_SUCCESS="0"; //成功代码
    public static final String API_STATUS_FAIL="10";   //错误代码
    public static final String CLOUD_APP_KEY = "de82967019906571ae879c460358e148";
/*    public static final String WX_APPID="wxc54155a7d0e8d74b";//wx2080ce200137103c
    public static final String WX_SECRET="2534503c0b3eb2ab04c0b75057b1ff3e";//2be4183775a21a0d9d4be6b047358bfc
    public static final String WX_TOKEN="payegis";*/
    public static final String WX_AESKEY="";
    public static final String WX_OAUTH2_URL = "https://api.weixin.qq.com/sns/oauth2/access_token";

    public static final String BIND_URL = "/rest/account/bind";
    public static final String UNBIND_URL = "/rest/account/unbind";
    public static final String CHECK_PASS_URL = "/rest/protect/check";
    public static final String SET_PASS_URL = "/rest/protect/set";
    public static final String LOGIN_URL = "/rest/account/login";
    public static final String LOGOUT_URL = "/rest/account/logout";
    public static final String OPENDOOR_URL = "/rest/account/open";

    public static final String SUCCESS_STATUS = "0";
    public static final String USER_HELP_URL="http://mp.weixin.qq.com/s?__biz=MzA4NDEzNTU1NQ==&mid=213849191&idx=1&sn=f6a84975fcd5db7c3beb1dadb21140c6#rd</wx.user.help.url";
    public static final String SAFETY_PRIVACY_URL="http://mp.weixin.qq.com/s?__biz=MzA4NDEzNTU1NQ==&mid=213849365&idx=1&sn=20f20b373612827f99d8722fadb040ad#rd";
    public static final String OFFICIAL_WEBSITE="http://securid.payegis.com.cn/app";
    public static final String DEVICE_ID = "deviceId";
    public static final String OS_TYPE = "osType";
    public static final String PHONE_NO = "phoneNo";
    public static final String DEVICE_PASSWORD = "devicePassword";
}
