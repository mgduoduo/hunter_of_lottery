package com.payegis.tscsecurid.manage.action.mgr;


import com.payegis.tscsecurid.common.data.bo.OrderInfoQueryBo;
import com.payegis.tscsecurid.common.data.entity.MgrPrivilege;
import com.payegis.tscsecurid.common.result.ResultBean;
import com.payegis.tscsecurid.common.util.DateUtil;
import com.payegis.tscsecurid.manage.action.customer.ManageBaseAction;
import com.payegis.tscsecurid.manage.annotation.FuncNum;
import com.payegis.tscsecurid.manage.bean.PrivilegeBean;
import com.payegis.tscsecurid.manage.bean.PrivilegeSearchBean;
import com.payegis.tscsecurid.manage.common.ManageException;
import com.payegis.tscsecurid.manage.service.business.mgr.PrivilegeService;
import com.payegis.tscsecurid.manage.util.MessageUtil;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.List;

@Controller
@RequestMapping("/privilege")
public class PrivilegeAction extends ManageBaseAction {
	private static final Logger logger = Logger.getLogger(PrivilegeAction.class);
	@Autowired
	private PrivilegeService privilegeService;

	@RequestMapping(value = "/loadPrivileges", method = RequestMethod.POST)
	@ResponseBody
	public String loadPrivileges() {

		List<MgrPrivilege> privileges = privilegeService.retrievePrivileges();

		JSONArray array = JSONArray.fromObject(privileges);

		return array.toString();

	}
	
    @RequestMapping(value = "/list", method = RequestMethod.GET)
    @FuncNum(value = "p_privilege_mgr", remark = "")
    public ModelAndView receivables_Auth(OrderInfoQueryBo oiqb,
            HttpServletRequest request) {
        ModelAndView mav = new ModelAndView("page/mgr/privilege_receivables");
        return mav;
    }

    @RequestMapping(value = "/privilegeSearch")
    public ModelAndView orderSearch(MgrPrivilege oiqb,
            HttpServletRequest request) {
        HashMap<String, Object> resMap = new HashMap<String, Object>();
        ResultBean resBean = privilegeService.getPageList(oiqb);
        resMap.put("dataList", resBean.getRows());
        resMap.put("total", resBean.getTotal());
        resMap.put("processType", "receivables");
        resMap.put("processTypeName", "权限管理");
        ModelAndView mav = new ModelAndView("page/mgr/privilege_query_list", resMap);
        return mav;
    }

	@RequestMapping(value = "/del/{privilegeId}")
	public ModelAndView delPrivilege(HttpServletRequest request,@PathVariable String privilegeId) {
		ModelAndView mav = new ModelAndView();
		try {
            privilegeService.deletePrivilege(new String[] { privilegeId });
			mav.addObject("searchDto", new PrivilegeSearchBean());
			mav = new ModelAndView("redirect:/privilege/list", getMessage(MESSAGE_TYPE_SUCCESS,
					SUCCESS_OPERATION, request));
		} catch (ManageException he) {
			mav = new ModelAndView("redirect:/privilege/list", getMessage(MESSAGE_TYPE_ERROR,
					he.getErrorCode(), request));
		}
		return mav;
	}

	@RequestMapping(value = "prepareEditPrivilege")
	public ModelAndView prepareEditPrivilege(HttpServletRequest request) {
		ModelAndView mav = new ModelAndView();
		String privilegeId = request.getParameter("id");
		MgrPrivilege privilege = privilegeService
				.retrievePrivilegeById(privilegeId);
		mav.addObject("privilegeBean", buildPrivilegeBean(privilege));
		mav.setViewName("page/mgr/editprivilege");
		return mav;
	}

	@RequestMapping(value = "/goAddPrivilege")
	public ModelAndView goAddPrivilege() {
		ModelAndView mav = new ModelAndView("page/mgr/addprivilege");
		mav.addObject("privilegeBean", new PrivilegeBean());
		return mav;
	}

	@RequestMapping(value = "/checkeprivilege", method = RequestMethod.POST)
	@ResponseBody
	public String checkPrivilegeId(String privilegeId) {
		JSONObject json = new JSONObject();
		if (privilegeService.checkPrivilegeExists(privilegeId)) {
			json.put("status", "1");
			json.put("message",
					MessageUtil.getMessage(ERROR_PRIVILEGE_ID_EXISTS, null, null));
			json.put("data", "");
		} else {
			json.put("status", "0");
			json.put("message",
			      MessageUtil.getMessage(ERROR_PRIVILEGE_ID_EXISTS, null, null));
			json.put("data", "");
		}
		return json.toString();
	}

	@RequestMapping(value = "/saveprivilege", method = RequestMethod.POST)
	public ModelAndView doSavePrivilege(
			@ModelAttribute("privilegeBean") PrivilegeBean privilegeBean,
			BindingResult result, HttpServletRequest request) {
		ModelAndView mav = new ModelAndView();

		if (!validateAdd(privilegeBean, result)) {
			mav.setViewName("page/mgr/addprivilege");
			return mav;
		}
		
		privilegeService.createPrivilege(buildPrivilegeEntity(privilegeBean,
				null, request));
		privilegeBean.clear();
		RedirectView rv = new RedirectView("list");
		mav = new ModelAndView(rv, getMessage(MESSAGE_TYPE_SUCCESS,
				SUCCESS_OPERATION, request));
		return mav;
	}

	@RequestMapping(value = "/editprivilege", method = RequestMethod.POST)
	public ModelAndView doEditPrivilege(
			@ModelAttribute PrivilegeBean privilegeBean, BindingResult result,
			HttpServletRequest request) {
		ModelAndView mav = new ModelAndView();
		String oldId = request.getParameter("oldPrivilegeId");
		if (!validateEdit(privilegeBean, oldId, result)) {
			mav.setViewName("page/mgr/editprivilege");
			return mav;
		}

		MgrPrivilege oldEntity = privilegeService.retrievePrivilegeById(oldId);

		privilegeService.updatePrivilege(buildPrivilegeEntity(privilegeBean,
				oldEntity, request));

		privilegeBean.clear();
		RedirectView rv = new RedirectView("list");
		mav = new ModelAndView(rv, getMessage(MESSAGE_TYPE_SUCCESS,
				SUCCESS_OPERATION, request));
		return mav;
	}

	private boolean validateAdd(PrivilegeBean bean, BindingResult result) {
		boolean valid = true;
		if (StringUtils.isEmpty(bean.getPrivilegeId())) {
			valid = false;
			result.rejectValue("privilegeId", ERROR_PRIVILEGE_ID_MANDATORY);
		} else {
			if (privilegeService.checkPrivilegeExists(bean.getPrivilegeId())) {
				valid = false;
				result.rejectValue("privilegeId", ERROR_PRIVILEGE_ID_EXISTS);
			}
		}

		if (StringUtils.isEmpty(bean.getPrivilegeName())) {
			valid = false;
			result.rejectValue("privilegeName", ERROR_PRIVILEGE_NAME_MANDATORY);
		}

		return valid;
	}

	private boolean validateEdit(PrivilegeBean bean, String oldId,
			BindingResult result) {
		boolean valid = true;
		if (StringUtils.isEmpty(bean.getPrivilegeId())) {
			valid = false;
			result.rejectValue("privilegeId", ERROR_PRIVILEGE_ID_MANDATORY);
		} else {
			if (!bean.getPrivilegeId().equals(oldId)) {
				if (privilegeService
						.checkPrivilegeExists(bean.getPrivilegeId())) {
					valid = false;
					result.rejectValue("privilegeId", ERROR_PRIVILEGE_ID_EXISTS);
				}
			}
		}

		if (StringUtils.isEmpty(bean.getPrivilegeName())) {
			valid = false;
			result.rejectValue("privilegeName", ERROR_PRIVILEGE_NAME_MANDATORY);
		}

		return valid;
	}

	private MgrPrivilege buildPrivilegeEntity(PrivilegeBean bean,
	                                          MgrPrivilege entity, HttpServletRequest request) {
		if (entity == null) {
			entity = new MgrPrivilege();
			entity.setCreator(getCurretnUserName(request));
			entity.setCreateTime(DateUtil.getCurrentDateString());
		}
		entity.setPrivilegeId(bean.getPrivilegeId());
		entity.setPrivilegeName(bean.getPrivilegeName());
		entity.setParentId(bean.getParentId());
		entity.setDesc(bean.getDesc());
		entity.setUpdater(getCurretnUserName(request));
		entity.setUpdateTime(DateUtil.getCurrentDateString());
		entity.setIsEnterpriseShare(bean.getIsEnterpriseShare());
		return entity;
	}

	private PrivilegeBean buildPrivilegeBean(MgrPrivilege entity) {
		PrivilegeBean bean = new PrivilegeBean();
		bean.setPrivilegeId(entity.getPrivilegeId());
		bean.setPrivilegeName(entity.getPrivilegeName());
		bean.setParentId(entity.getParentId());
		bean.setDesc(entity.getDesc());
		bean.setIsEnterpriseShare(entity.getIsEnterpriseShare());
		return bean;
	}
	
	@RequestMapping(value = "/getPrivilegeGroup", method = RequestMethod.POST)
	@ResponseBody
	public String getSite() {
		JSONArray array = new JSONArray();
		List<MgrPrivilege> result = privilegeService.getPrivilegeGroup();
		if(null!=result && 
				!result.isEmpty()){
			array.addAll(result);
		}
		logger.info("privilege group message" + array.toString());
		return array.toString();
	}
}
