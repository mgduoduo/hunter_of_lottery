package com.payegis.tscsecurid.manage.action.customer;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import com.payegis.tscsecurid.common.action.BaseAction;
import com.payegis.tscsecurid.common.constant.PropertyFileKeys;
import com.payegis.tscsecurid.common.data.bo.BindInfoQueryBo;
import com.payegis.tscsecurid.common.data.bo.BindingInfoBo;
import com.payegis.tscsecurid.common.data.bo.BindingTerminalPwdProtectionBo;
import com.payegis.tscsecurid.common.data.bo.EnterpriseInfoBo;
import com.payegis.tscsecurid.common.data.bo.FeedbackInfoBo;
import com.payegis.tscsecurid.common.data.entity.BindingTerminalPwdProtection;
import com.payegis.tscsecurid.common.data.entity.BusinessSystem;
import com.payegis.tscsecurid.common.data.entity.FeedbackInfo;
import com.payegis.tscsecurid.common.data.entity.SysUser;
import com.payegis.tscsecurid.common.data.entity.TerminalPwdReset;
import com.payegis.tscsecurid.common.result.ResultBean;
import com.payegis.tscsecurid.manage.service.business.customer.CustomerInfoService;
import com.payegis.tscsecurid.manage.service.business.enterprise.EnterpriseService;
import com.payegis.tscsecurid.manage.service.business.msg.MsgService;
import com.payegis.tscsecurid.manage.util.SessionUtil;

@Controller
@RequestMapping("/customerService")
public class CustomerAction extends ManageBaseAction{

    private static final Logger logger = Logger.getLogger(CustomerServiceAction.class);


    @Autowired
    CustomerInfoService customerInfoService;
    
    @Autowired
	private MsgService msgService;
    
    @Autowired
	private EnterpriseService enterpriseService;

    @ModelAttribute("feedbackStates")
    public Map<String, String> getFeedBackStates() {
        Map<String, String> map = new HashMap<String, String>();
        map.put("Y", "已处理");
        map.put("N", "未处理");
        return map;
    }
    
    @ModelAttribute("businessTypes")
	public Map<String, String> getBusinessTypes(HttpSession session) {
		SysUser su = SessionUtil.getUser(session);
		Map<String, String> map = new HashMap<String, String>();
		if (null != su) {
			List<BusinessSystem> bs = msgService.findBusinessSystemsByUserId(su
					.getUserId());
			if (null != bs && !bs.isEmpty()) {
				for (BusinessSystem b : bs) {
					map.put(String.valueOf(b.getSystemId()), b.getSystemName());
				}
			}
		}
		return map;
	}

    @ModelAttribute("enterpriseTypes")
	public Map<Integer, String> enterpriseTypes(HttpSession session) {
		SysUser su = SessionUtil.getUser(session);
		Map<Integer, String> map = new HashMap<Integer, String>();
		if (null != su && su.getEnterpriseNo().equals(PropertyFileKeys.ENTERPRISE_NO_PAYEGIS)) {
			List<EnterpriseInfoBo> ebi = enterpriseService.findAllEnterprise();
			if (null != ebi && !ebi.isEmpty()) {
				for (EnterpriseInfoBo e : ebi) {
					map.put(e.getEnterpriseId(), e.getEnterpriseName());
				}
			}
		}
		return map;
	}
    
    @RequestMapping("/feedback")
    public String feedback(Model model) {
        return "page/customer/customer_feedback_query";
    }

    @RequestMapping("/feedback/search")
    public String search(FeedbackInfoBo queryBo,Model model,HttpSession session) {
        SysUser user = SessionUtil.getUser(session);
        if (!PropertyFileKeys.ENTERPRISE_NO_PAYEGIS.equals(user.getEnterpriseNo())) {
            queryBo.setEnterpriseId(user.getEnterpriseId());
        }
        queryBo.setFeedbackType(PropertyFileKeys.FEEDBACK_TYPE_APP);
        ResultBean<FeedbackInfoBo> feedbackInfoResultBean = customerInfoService.getPageList(queryBo);
        model.addAttribute("dataList", feedbackInfoResultBean.getRows());
        model.addAttribute("total", feedbackInfoResultBean.getTotal());
        return "page/customer/customer_feedback_query_list";
    }
    
    @RequestMapping("/feedbackForPayegis")
    public String feedbackForPayegis(Model model) {
        return "page/customer/customer_feedback_query_payegis";
    }
    
    @RequestMapping("/feedbackForPayegis/search")
    public String feedbackForPayegissearch(FeedbackInfoBo queryBo,Model model,HttpSession session) {
        SysUser user = SessionUtil.getUser(session);
        if (!PropertyFileKeys.ENTERPRISE_NO_PAYEGIS.equals(user.getEnterpriseNo())) {
            queryBo.setEnterpriseId(user.getEnterpriseId());
        }
        ResultBean<FeedbackInfoBo> feedbackInfoResultBean = customerInfoService.getPageList(queryBo);
        model.addAttribute("dataList", feedbackInfoResultBean.getRows());
        model.addAttribute("total", feedbackInfoResultBean.getTotal());
        return "page/customer/customer_feedback_query_list";
    }

    @RequestMapping("/feedback/operate")
    public ModelAndView operate(FeedbackInfo fbi,Model model,HttpSession session,HttpServletRequest request) {
        customerInfoService.updateFeedBackInfo(fbi);
        ModelAndView mav = new ModelAndView("redirect:/customerService/feedback", getMessage(MESSAGE_TYPE_SUCCESS, SUCCESS_OPERATION, request));
        return mav;
    }
    
    @RequestMapping("/pwdreset")
    public String pwdrest(Model model) {
        return "page/customer/customer_pwdreset_query";
    }

    @RequestMapping("/pwdreset/search")
    public String deviceSearch(BindInfoQueryBo queryBo,Model model,HttpSession session) {
        SysUser user = SessionUtil.getUser(session);
        if (!PropertyFileKeys.ENTERPRISE_NO_PAYEGIS.equals(user.getEnterpriseNo())) {
            queryBo.setEnterpriseId(user.getEnterpriseId());
        }
        ResultBean<BindingInfoBo> feedbackInfoResultBean = customerInfoService.getPageListForReset(queryBo);
        model.addAttribute("dataList", feedbackInfoResultBean.getRows());
        model.addAttribute("total", feedbackInfoResultBean.getTotal());
        return "page/customer/customer_pwdreset_query_list";
    }

    @RequestMapping("/pwdreset/operate")
    public ModelAndView pwdrestOperate(TerminalPwdReset tpr,Model model,HttpSession session,HttpServletRequest request) {
    	SysUser user = SessionUtil.getUser(session);
    	tpr.setEnterpriseId(user.getEnterpriseId());
    	tpr.setOperationUser(user.getUserId());
    	customerInfoService.updatePwdReset(tpr);
        ModelAndView mav = new ModelAndView("redirect:/customerService/pwdreset", getMessage(MESSAGE_TYPE_SUCCESS, SUCCESS_OPERATION, request));
        return mav;
    }
    
    @RequestMapping("/pwdquestion/view")
    @ResponseBody
    public Map<String, Object> view(BindingTerminalPwdProtectionBo queryBo) {
    	Map<String, Object> resMap = new HashMap<String, Object>();
    	List<BindingTerminalPwdProtection> questionList = customerInfoService.viewPwdQuestion(queryBo);
    	resMap.put("questionList", questionList);
		resMap.put("qm", PropertyFileKeys.QUESTION_MAP);
        return resMap;
    }
    
    @RequestMapping("/feedBackContent/view")
    @ResponseBody
    public Map<String, Object> feedBackContentView(Integer feedbackInfoId) {
    	Map<String, Object> resMap = new HashMap<String, Object>();
    	FeedbackInfo feedbackInfo = customerInfoService.selectByPrimaryKey(feedbackInfoId);
    	resMap.put("feedbackInfo", feedbackInfo);
        return resMap;
    }
}
