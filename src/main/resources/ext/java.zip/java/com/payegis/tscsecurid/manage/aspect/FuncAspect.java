package com.payegis.tscsecurid.manage.aspect;


import com.payegis.tscsecurid.common.data.entity.MgrPrivilege;
import com.payegis.tscsecurid.manage.annotation.FuncNum;
import com.payegis.tscsecurid.manage.common.LoginBean;
import com.payegis.tscsecurid.manage.util.SessionUtil;
import org.apache.log4j.Logger;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import java.lang.reflect.Method;
import java.util.List;

/**
 * 权限证切面
 * 
 * @author xuxm
 * 
 */
@Component("funcaspect")
public class FuncAspect extends CommonAspect {
   private static final Logger logger = Logger.getLogger(FuncAspect.class);
	@Override
	public void doAfter(JoinPoint jp) {

	}

	@Override
	public Object doAround(ProceedingJoinPoint pjp) throws Throwable {
		MethodSignature joinPointObject = (MethodSignature) pjp.getSignature();
		// 获取所有参数
		// 获取对象的参数类型
		Class<?>[] parameterTypes = joinPointObject.getMethod()
				.getParameterTypes();
		// 获取连接点目标对象的方法
		Method method = pjp.getTarget().getClass()
				.getMethod(pjp.getSignature().getName(), parameterTypes);
		if (method.isAnnotationPresent(FuncNum.class)) {
			HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder
					.getRequestAttributes()).getRequest();
			FuncNum funcnum = method.getAnnotation(FuncNum.class);
			List<MgrPrivilege> privileges = SessionUtil.getPriliegeList(request);
			if (privileges != null && !privileges.isEmpty()) {
				for (MgrPrivilege privilege : privileges) {
					if (privilege.getPrivilegeId().equals(funcnum.value())) {
						return pjp.proceed();
					}
				}
			}
			logger.warn("try to access url:"+request.getServletPath()+", but don't have privilege:"+funcnum.value());
		}
		ModelAndView view = new ModelAndView();
		view.addObject(new LoginBean());
		view.setViewName("redirect:/");
		return view;
	}

	@Override
	public void doBefore(JoinPoint jp) {
	}

	@Override
	public void doThrowing(JoinPoint jp, Throwable ex) {
	}

}
