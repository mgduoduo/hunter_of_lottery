package com.payegis.tscsecurid.manage.service.impl.mgr;


import com.payegis.tscsecurid.common.data.entity.MgrMenu;
import com.payegis.tscsecurid.common.data.entity.MgrPrivilege;
import com.payegis.tscsecurid.common.data.entity.MgrUserRole;
import com.payegis.tscsecurid.common.data.entity.SysUser;
import com.payegis.tscsecurid.common.mapper.*;
import com.payegis.tscsecurid.common.service.BaseServiceImpl;
import com.payegis.tscsecurid.manage.bean.UserBean;
import com.payegis.tscsecurid.manage.common.MessageConstant;
import com.payegis.tscsecurid.manage.service.business.mgr.UserService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class UserServiceImpl extends BaseServiceImpl implements UserService, MessageConstant {

	@Autowired
	private SysUserMapper sysUserMapper;

	@Autowired
	private MgrUserRoleMapper mgrUserRoleMapper;

	@Autowired
	private MgrPrivilegeMapper mgrPrivilegeMapper;

	@Autowired
	private MgrMenuMapper mgrMenuMapper;

	@Override
	public void saveUser(SysUser user, String roleIds) {
		Integer userId = sysUserMapper.insert(user);
		if (userId>0 && roleIds != null && roleIds.trim().length() > 0) {
			String[] roleids = roleIds.split("\\|");
			for (String roleid : roleids) {
				MgrUserRole userRole = new MgrUserRole();
				userRole.setRoleId(roleid);
				userRole.setUserId(user.getUserId().toString());
				mgrUserRoleMapper.insert(userRole);
			}
		}
	}

	private List<String> preparePrivilegeIds(List<MgrPrivilege> list) {
		List<String> ids = new ArrayList<String>();
		if (list != null) {
			for (MgrPrivilege p : list) {
				ids.add(p.getPrivilegeId());
			}
		}
		return ids;
	}

	private List<MgrMenu> prepareMenus(List<MgrMenu> list) {
		if (list == null)
			return null;
		List<MgrMenu> newMenuList = new ArrayList<MgrMenu>();
		for (MgrMenu m : list) {

			arrangeMenu(m, list, newMenuList);
		}
		return newMenuList;
	}

	private void arrangeMenu(MgrMenu m, List<MgrMenu> list, List<MgrMenu> newList) {
		if (m.getParent() < 0) {
			newList.add(m);
			return;
		} else {
			for (MgrMenu parentMenu : list) {
				if (parentMenu.getMenuId() == m.getParent()) {
					parentMenu.getSubMenus().add(m);
				}
			}
		}
	}

	@Override
	public Integer findUsersize(String loginName) {
		return sysUserMapper.selectByLoginName(loginName)==null?0:1;
	}

	@Override
	public void updateUserWithRole(SysUser user, String roleIdsStr) {
		sysUserMapper.updateByPrimaryKeySelective(user);
		List<MgrUserRole> list = mgrUserRoleMapper.findUserRole(user.getUserId().toString());
            //需新增角色
			Set<String> addroleidlist = new HashSet<String>();
            //需删除角色
			Set<String> deleroleidlist = new HashSet<String>();

            //目标角色
            List<String> targetRoleIds = Arrays.asList(StringUtils.split(roleIdsStr,"|"));
            //原有角色
            List<String> oldRoleIds = new ArrayList<String>();

            for (MgrUserRole userRole : list){
                oldRoleIds.add(userRole.getRoleId());
            }

            addroleidlist.addAll(targetRoleIds);
            addroleidlist.removeAll(oldRoleIds);


            deleroleidlist.addAll(oldRoleIds);
            deleroleidlist.removeAll(targetRoleIds);

			if (!addroleidlist.isEmpty()) {
				for (String roleid : addroleidlist) {
					MgrUserRole userRole = new MgrUserRole();
					userRole.setRoleId(roleid);
					userRole.setUserId(user.getUserId().toString());
					mgrUserRoleMapper.insert(userRole);
				}
			}

			if (!deleroleidlist.isEmpty()) {
				for (String roleid : deleroleidlist) {
					MgrUserRole userRole = new MgrUserRole();
					userRole.setRoleId(roleid);
					userRole.setUserId(user.getUserId().toString());
					mgrUserRoleMapper.deleteByPrimaryKey(userRole);
				}
			}

	}

	@Override
	public UserBean findUser(String userId) {
		SysUser user = sysUserMapper.selectByPrimaryKey(Integer.valueOf(userId));
		UserBean userBean = new UserBean();
		userBean.setUserId(user.getUserName());
		userBean.setName(user.getUserName());
		userBean.setEmail(user.getUserEmail());
		userBean.setStatus(user.getIsDelete());
		userBean.setSystemNo(user.getSystemNo());
		List<MgrUserRole> list = mgrUserRoleMapper.findUserRole(user.getUserId().toString());
		StringBuilder sb = new StringBuilder();
		if (list != null && !list.isEmpty()) {
			for (MgrUserRole userRole : list) {
				if (sb.length() > 0) {
					sb.append("|");
				}
				sb.append(userRole.getRoleId());
			}
		}
		userBean.setRoleids(sb.toString());
		return userBean;
	}

	@Override
	public SysUser findUserById(String userId) {
		return sysUserMapper.selectByPrimaryKey(Integer.valueOf(userId));
	}

   @Override
   protected BaseMapper getMapper() {
      return sysUserMapper;
   }

   @Override
   public SysUser findUserByLoginName(String loginName) {
      return sysUserMapper.selectByLoginName(loginName);
   }

    @Override
    public void updateUser(SysUser user) {
        sysUserMapper.updateByPrimaryKeySelective(user);
    }

    @Override
    public void deleteUser(String userId) {
        List<MgrUserRole> list = mgrUserRoleMapper.findUserRole(userId);
        for(MgrUserRole mur:list){
            mgrUserRoleMapper.deleteByPrimaryKey(mur);
        }
        sysUserMapper.deleteByPrimaryKey(Integer.parseInt(userId));
    }
}
