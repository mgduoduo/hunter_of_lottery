package com.payegis.tscsecurid.manage.common;

/**
 * Created by payegis on 2015/7/22.
 */
public enum ScanTypeEnum {

    BINDING("000", "/rest/account/bind"),
    UNBINDING("001", "/rest/account/unbind"),
    LOGIN("002", "/rest/account/login"),
    LOGOUT("003", "/rest/account/logout"),
    OPEN("004", "/rest/account/open"),
    VALID("005", ""),
    PAY("006", "");

    private String codeId;

    private String codeUrl;

    private ScanTypeEnum(String codeId, String codeUrl) {
        this.codeId = codeId;
        this.codeUrl = codeUrl;
    }

    public String getCodeId() {
        return codeId;
    }

    public void setCodeId(String codeId) {
        this.codeId = codeId;
    }

    public String getCodeUrl() {
        return codeUrl;
    }

    public void setCodeUrl(String codeUrl) {
        this.codeUrl = codeUrl;
    }
    /*public String getCodeUrl(String codeId) {
        for (ScanTypeEnum type : ScanTypeEnum.values()) {
            if (codeId.equals(type.getCodeId())) {
                return type.getCodeUrl();
            }
        }
        return null;
    }*/
}
