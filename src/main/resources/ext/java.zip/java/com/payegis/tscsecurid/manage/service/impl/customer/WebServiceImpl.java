package com.payegis.tscsecurid.manage.service.impl.customer;


import com.payegis.tscsecurid.common.constant.PropertyFileKeys;
import com.payegis.tscsecurid.common.data.entity.MgrMenu;
import com.payegis.tscsecurid.common.data.entity.MgrPrivilege;
import com.payegis.tscsecurid.common.data.entity.MgrUserRole;
import com.payegis.tscsecurid.common.data.entity.SysUser;
import com.payegis.tscsecurid.common.mapper.MgrMenuMapper;
import com.payegis.tscsecurid.common.mapper.MgrPrivilegeMapper;
import com.payegis.tscsecurid.common.mapper.MgrUserRoleMapper;
import com.payegis.tscsecurid.common.mapper.SysUserMapper;
import com.payegis.tscsecurid.manage.common.ManageException;
import com.payegis.tscsecurid.manage.common.MessageConstant;
import com.payegis.tscsecurid.manage.service.business.customer.WebService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class WebServiceImpl implements WebService, MessageConstant {

    @Autowired
    private SysUserMapper sysUserMapper;

    @Autowired
    private MgrPrivilegeMapper privilegeMapper;

    @Autowired
    private MgrMenuMapper menuMapper;



    @Autowired
    MgrUserRoleMapper mgrUserRoleMapper;

    public SysUser doUserLogin(String loginName, String password) {
        SysUser user = sysUserMapper.selectByLoginNameNew(loginName);

        if (user == null) {
            // usr not found error
            throw new ManageException(ERROR_USER_NOT_EXISTS);
        } else if (!user.getUserPassword().equals(password)) {
            // login name and password incorrect .
            throw new ManageException(ERROR_USER_PASSWORD_INCORRECT);
        } else if (PropertyFileKeys.STATUS_CODE_Y.equals(user.getIsDelete())) {
            throw new ManageException(ERROR_USER_NOT_ACTIVE);
        }

        // get user's privileges
        List<MgrPrivilege> privileges = privilegeMapper.getPrivilegesByUserId(user.getUserId());
        user.setPrivileges(privileges);

        // prepare menus for user
        List<MgrMenu> menus = menuMapper
                .getMenuByPrivileges(preparePrivilegeIds(privileges));
        user.setMenus(prepareMenus(menus));

        List<MgrUserRole> roles = mgrUserRoleMapper.findUserRole(user.getUserId().toString());
        Set<String> roleNames = new HashSet<String>();
        for (MgrUserRole mur : roles) {
            roleNames.add(mur.getRoleId());
        }
        user.setRoleNames(roleNames);

        return user;
    }

    private List<String> preparePrivilegeIds(List<MgrPrivilege> list) {
        List<String> ids = new ArrayList<String>();
        if (list != null) {
            for (MgrPrivilege p : list) {
                ids.add(p.getPrivilegeId());
            }
        }
        return ids;
    }

    private List<MgrMenu> prepareMenus(List<MgrMenu> list) {
        if (list == null)
            return null;

        Map<Integer, MgrMenu> topMenu = new HashMap<Integer, MgrMenu>();
        Map<Integer, ArrayList<MgrMenu>> subMenus = new HashMap<Integer, ArrayList<MgrMenu>>();

        for (MgrMenu menu : list) {
            Integer parentId = menu.getParent();
            if (parentId < 0) {
                if (!topMenu.containsKey(menu.getMenuId())) {
                    topMenu.put(menu.getMenuId(), menu);
                }
                if (!subMenus.containsKey(menu.getMenuId())) {
                    subMenus.put(menu.getMenuId(), new ArrayList<MgrMenu>());
                }
            } else {
                if (!subMenus.containsKey(menu.getParent())) {
                    subMenus.put(menu.getParent(), new ArrayList<MgrMenu>());
                }
                subMenus.get(menu.getParent()).add(menu);
            }
        }

        //如果存在子菜单，默认显示父菜单
        for (Integer parentId : subMenus.keySet()) {
            if (!topMenu.containsKey(parentId)) {
                MgrMenu m = menuMapper.selectByPrimaryKey(parentId);
                if (null != m) {
                    topMenu.put(parentId, m);
                }
            }
        }


        List<MgrMenu> newMenuList = new ArrayList<MgrMenu>();
        for (Map.Entry<Integer, MgrMenu> entry : topMenu.entrySet()) {
            ArrayList<MgrMenu> ms = subMenus.get(entry.getKey());
            entry.getValue().setSubMenus(ms);

        }
        newMenuList.addAll(topMenu.values());

        Comparator<MgrMenu> comparator = new Comparator<MgrMenu>() {
            @Override
            public int compare(MgrMenu o1, MgrMenu o2) {
                return o1.getOrder() - o2.getOrder();
            }
        };

        Collections.sort(newMenuList, comparator);
        return newMenuList;
    }

    private void arrangeMenu(MgrMenu m, List<MgrMenu> list, List<MgrMenu> newList) {
        if (m.getParent() < 0) {
            newList.add(m);
            return;
        } else {
            for (MgrMenu parentMenu : list) {
                if (parentMenu.getMenuId() == m.getParent()) {
                    parentMenu.getSubMenus().add(m);
                }
            }
        }
    }



    @Override
    public SysUser getSysUserByEmail(String email) {

        SysUser user = sysUserMapper.selectByLoginNameNew(email);

        if (null != user) {
            // get user's privileges
            List<MgrPrivilege> privileges = privilegeMapper.getPrivilegesByUserId(user.getUserId());
            user.setPrivileges(privileges);

            // prepare menus for user
            List<MgrMenu> menus = menuMapper
                    .getMenuByPrivileges(preparePrivilegeIds(privileges));
            user.setMenus(prepareMenus(menus));


            List<MgrUserRole> roles = mgrUserRoleMapper.findUserRole(user.getUserId().toString());
            Set<String> roleNames = new HashSet<String>();
            for (MgrUserRole mur : roles) {
                roleNames.add(mur.getRoleId());
            }
            user.setRoleNames(roleNames);

        }

        return user;
    }
}
