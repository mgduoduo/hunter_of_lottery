package com.payegis.tscsecurid.manage.service.impl.mgr;

import com.payegis.tscsecurid.common.data.entity.BusinessSystem;
import com.payegis.tscsecurid.common.data.entity.SysCode;
import com.payegis.tscsecurid.common.data.entity.SysLog;
import com.payegis.tscsecurid.common.mapper.BusinessSystemMapper;
import com.payegis.tscsecurid.common.mapper.SysCodeMapper;
import com.payegis.tscsecurid.common.mapper.SysLogMapper;
import com.payegis.tscsecurid.common.result.ResultBean;
import com.payegis.tscsecurid.common.util.StringUtil;
import com.payegis.tscsecurid.manage.common.MessageConstant;
import com.payegis.tscsecurid.manage.service.business.mgr.LogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class LogServiceImpl implements LogService, MessageConstant {

	@Autowired
	private SysLogMapper sysLogMapper;
	
	@Autowired
	private BusinessSystemMapper businessSystemMapper;
	
	@Autowired
	private SysCodeMapper sysCodeMapper;
	
	@Override
	public ResultBean listAll(SysLog param) {
		if (StringUtil.isNotEmpty(param.getStartTime()))
			param.setStartTime(param.getStartTime()
					+ " 00:00:00");
		if (StringUtil.isNotEmpty(param.getEndTime()))
			param.setEndTime(param.getEndTime() + " 23:59:59");
		ResultBean result = new ResultBean();
		List<Object> logs = sysLogMapper.listAll(param);
		result.setRows(logs);
        result.setTotal(sysLogMapper.count(param)+sysLogMapper.countHistory(param));
		return result;
	}


	@Override
	public List<Object> listAllRecords(String param) {
		return sysLogMapper.listAllRecords(param);
	}


	@Override
	public List<Object> listAllRecordsOfEnterprise(SysLog param) {
		param.setRows(null);
		return sysLogMapper.listAll(param);
	}


	@Override
	public List<BusinessSystem> getBusinessSystemByEnterpriseId(
			Map<String, Object> map) {
		return businessSystemMapper.getBusinessSystemByEnterpriseId(map);
	}


	@Override
	public List<SysCode> getAllCodeBySystemNo(String codeTypeCallBack) {
		return sysCodeMapper.getAllCodeBySystemNo(codeTypeCallBack);
	}

	public ResultBean<SysLog> statisticsSearch(SysLog sysLog) {
		if (StringUtil.isNotEmpty(sysLog.getStartTime()))
			sysLog.setStartTime(sysLog.getStartTime()
					+ " 00:00:00");
		if (StringUtil.isNotEmpty(sysLog.getEndTime()))
			sysLog.setEndTime(sysLog.getEndTime() + " 23:59:59");
		ResultBean<SysLog> result = new ResultBean<SysLog>();
		List<SysLog> logs = sysLogMapper.statisticsSearch(sysLog);
		result.setRows(logs);
		result.setTotal(sysLogMapper.statisticsSearchCount(sysLog));
		return result;
	}

    @Override
    public ResultBean listAllLogs(SysLog param) {
        /*if (StringUtil.isNotEmpty(param.getStartTime()))
            param.setStartTime(param.getStartTime()
                    + " 00:00:00");
        if (StringUtil.isNotEmpty(param.getEndTime()))
            param.setEndTime(param.getEndTime() + " 23:59:59");*/
        ResultBean result = new ResultBean();
        List<Object> logs = sysLogMapper.listAllLogs(param);
        result.setRows(logs);
        result.setTotal(sysLogMapper.count(param)+sysLogMapper.countHistory(param));
        return result;
    }
}
