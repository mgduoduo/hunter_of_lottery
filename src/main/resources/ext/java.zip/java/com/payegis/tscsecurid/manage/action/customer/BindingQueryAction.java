package com.payegis.tscsecurid.manage.action.customer;


import com.payegis.tscsecurid.common.constant.PropertyFileKeys;
import com.payegis.tscsecurid.common.data.bo.BindInfoQueryBo;
import com.payegis.tscsecurid.common.data.bo.BindingInfoBo;
import com.payegis.tscsecurid.common.data.bo.DIDDetailBo;
import com.payegis.tscsecurid.common.data.entity.BusinessSystem;
import com.payegis.tscsecurid.common.data.entity.SysUser;
import com.payegis.tscsecurid.common.result.ResultBean;
import com.payegis.tscsecurid.manage.service.business.customer.CustomerService;
import com.payegis.tscsecurid.manage.util.SessionUtil;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpSession;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by liucheng on 2014/11/17.
 */
@Controller
@RequestMapping("/customerService")
public class BindingQueryAction {
    private static final Logger logger = Logger.getLogger(BindingQueryAction.class);

    @ModelAttribute("search_url")
    public String getSearchUrl() {
        return "/customerService/bindingQuery/search";
    }

    @RequestMapping("/bindingQuery")
    public String showUnbindSupply(Model model) {
        return "page/customer/bindingQuery";
    }

    @ModelAttribute("feedbackStatus")
    public Map<String,String> getFeedbackStatus(Model model) {
        Map<String,String> map = new HashMap<String, String>();
        map.put("Y", "已处理");
        map.put("N", "未处理");
        return map;
    }

    @Autowired
    CustomerService customerService;

    @ModelAttribute("systems")
    public List<BusinessSystem> getCallBackTypes(HttpSession session) {
        Object object = session.getAttribute("systems");
        if (object == null) {
            SysUser user = SessionUtil.getUser(session);
            List<BusinessSystem> businessSystemList = customerService.getBusinessSystemByUser(user.getEnterpriseId());
            session.setAttribute("systems", businessSystemList);
            return businessSystemList;
        } else {
            return (List<BusinessSystem>) object;
        }
    }

    @RequestMapping("/bindingQuery/search")
    public String search(BindInfoQueryBo queryBo,Model model,HttpSession session) {
        SysUser user = SessionUtil.getUser(session);
        /*if (!PropertyFileKeys.ENTERPRISE_NO_PAYEGIS.equals(user.getEnterpriseNo())) {
            queryBo.setEnterpriseId(user.getEnterpriseId());
        }*/
        if (StringUtils.isNotEmpty(queryBo.getActiveStartDate())) {
            queryBo.setActiveStartDate(queryBo.getActiveStartDate()+" 00:00:00");
        }
        if (StringUtils.isNotEmpty(queryBo.getStartDate())) {
            queryBo.setStartDate(queryBo.getStartDate() + " 00:00:00");
        }

        if (StringUtils.isNotEmpty(queryBo.getActiveEndDate())) {
            queryBo.setActiveEndDate(queryBo.getActiveEndDate() + " 23:59:59");
        }
        if (StringUtils.isNotEmpty(queryBo.getEndDate())) {
            queryBo.setEndDate(queryBo.getEndDate() + " 23:59:59");
        }
        queryBo.setEnterpriseId(user.getEnterpriseId());
        ResultBean<BindingInfoBo> bindingInfoResultBean = customerService.getPageList(queryBo);
        model.addAttribute("result", bindingInfoResultBean);
        return "page/customer/bindingQuery_list";
    }
    
    @RequestMapping("/showDIDDetail/{did}")
    public String showDIDDetail(@PathVariable String did, Model model,HttpSession session) {
        SysUser user = SessionUtil.getUser(session);
        DIDDetailBo didDetailBo = customerService.getDIDDetail(did,user.getEnterpriseId());
        model.addAttribute("didDetail", didDetailBo);
        model.addAttribute("did", did);
        model.addAttribute("q_m", PropertyFileKeys.QUESTION_MAP);
        return "page/customer/did_detail";
    }

    @RequestMapping("/showDIDDetail/{enterpriseId}/{did}")
    public String showDIDDetailWithEnterpriseId(@PathVariable String did,@PathVariable Integer enterpriseId, Model model) {
//        SysUser user = SessionUtil.getUser(session);
        DIDDetailBo didDetailBo = customerService.getDIDDetail(did,enterpriseId);
        model.addAttribute("didDetail", didDetailBo);
        model.addAttribute("did", did);
        model.addAttribute("q_m", PropertyFileKeys.QUESTION_MAP);
        return "page/customer/did_detail";
    }
}
