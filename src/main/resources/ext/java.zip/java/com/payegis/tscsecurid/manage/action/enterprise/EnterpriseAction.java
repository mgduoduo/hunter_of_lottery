package com.payegis.tscsecurid.manage.action.enterprise;


import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.payegis.tscsecurid.common.action.BaseAction;
import com.payegis.tscsecurid.common.aop.AvoidDuplicateSubmission;
import com.payegis.tscsecurid.common.data.bo.EnterpriseInfoBo;
import com.payegis.tscsecurid.common.data.entity.SysUser;
import com.payegis.tscsecurid.common.result.ResultBean;
import com.payegis.tscsecurid.common.util.DateUtil;
import com.payegis.tscsecurid.common.util.StringUtil;
import com.payegis.tscsecurid.manage.service.business.enterprise.EnterpriseService;
import com.payegis.tscsecurid.manage.service.business.mgr.RoleService;
import com.payegis.tscsecurid.manage.service.business.mgr.UserService;
import com.payegis.tscsecurid.manage.util.SessionUtil;

@Controller
@RequestMapping("/enterprise")
public class EnterpriseAction extends BaseAction {

	@Autowired
	private EnterpriseService enterpriseService;
	
	@Autowired
	private UserService userService;

	@Autowired
	private RoleService roleService;
	@ModelAttribute("isEnableTypes")
	public Map<String, String> getproductTypes() {
		Map<String, String> map = new HashMap<String, String>();
		map.put("Y", "启用");
		map.put("N", "停用");
		return map;
	}
	  @RequestMapping(value = "/enterpriseQuery", method = RequestMethod.GET)
		public ModelAndView query(HttpServletRequest request) {
			return new ModelAndView("page/enterprise/enterprise_query");
		}
	  
		@RequestMapping(value = "/enterpriseSearch")
		public ModelAndView enterpriseSearch(EnterpriseInfoBo enterpriseInfoBo,
				HttpServletRequest request) {
			HashMap<String, Object> resMap = new HashMap<String, Object>();
			logger.info("[param] enterpriseInfoBo.getEnterpriseName="+enterpriseInfoBo.getEnterpriseName());
//			try {
//				if(StringUtil.isNotEmpty(enterpriseInfoBo.getEnterpriseName())){
//					String enterpriseName = new String(enterpriseInfoBo.getEnterpriseName().getBytes("ISO-8859-1") ,"UTF-8");
//					enterpriseInfoBo.setEnterpriseName(enterpriseName);
//				}
//			} catch (UnsupportedEncodingException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
			
			ResultBean resBean = enterpriseService.listAll(enterpriseInfoBo);
			
			resMap.put("dataList", resBean.getRows());
			resMap.put("total", resBean.getTotal());
			ModelAndView mav = new ModelAndView("page/enterprise/enterprise_query_list",resMap);
			return mav;
		}
		
		@RequestMapping(value = "/goAddEnterprise", method = RequestMethod.GET)
		@AvoidDuplicateSubmission(needSaveToken = true)
		public ModelAndView goAddEnterprise() {
			ModelAndView mav = new ModelAndView("page/enterprise/enterprise_add");
			EnterpriseInfoBo enterpriseInfoBo = new EnterpriseInfoBo();
			mav.addObject("enterpriseInfoBo", enterpriseInfoBo);
			return mav;
		}
		
		@RequestMapping(value = "/saveEnterprise", method = RequestMethod.POST)
		@AvoidDuplicateSubmission(needRemoveToken = true)
		public ModelAndView doSave(
				@ModelAttribute("enterpriseInfoBo") @Valid EnterpriseInfoBo enterpriseInfoBo,BindingResult result,
				HttpServletRequest request, RedirectAttributes redirectAttributes,HttpSession session) {
			ModelAndView mav = new ModelAndView("redirect:/enterprise/enterpriseQuery");
			if (result.hasErrors()) {
				mav.setViewName("page/enterprise/enterprise_add");
				return mav;
			}
			SysUser su = (SysUser) SessionUtil.getUser(session);
			String msg = "增加成功";
			int res = -1;
			try {
				if(null != su ){
					if (userService.findUsersize(enterpriseInfoBo.getManagerAccount()) > 0) {
						result.rejectValue("managerAccount", "???", "管理员账号已经存在");
					}else {
                        res = enterpriseService.save(enterpriseInfoBo, su);
                    }
				}
			} catch (Exception e) {
				logger.info("save enterprise:" + e.getMessage());
			}

			if (res == -1) {
				msg = "增加失败";
			}
			redirectAttributes.addFlashAttribute("success", msg);
			return mav;
		}
		
		@RequestMapping(value = "/enterpriseEdit/{id}", method = RequestMethod.GET)
		@AvoidDuplicateSubmission(needSaveToken = true)
		public ModelAndView enterpriseEdit(HttpServletRequest request,
				@PathVariable Integer id) {
			ModelAndView mav = new ModelAndView();
			EnterpriseInfoBo eb = enterpriseService.findById(id);
			mav.addObject("enterpriseInfoBo", eb);
			mav.setViewName("page/enterprise/enterprise_update");
			return mav;
		}
		
		
		@RequestMapping(value = "/enterpriseUpdateDisable/{id}", method = RequestMethod.GET)
		@AvoidDuplicateSubmission(needSaveToken = true)
		public ModelAndView enterpriseDelete(HttpServletRequest request,
				@PathVariable Integer id) {
			enterpriseService.updateDisable(id);
			ModelAndView mav = new ModelAndView(
					"redirect:/enterprise/enterpriseQuery");
			
			return mav;
		}
		
		@RequestMapping(value = "/enterpriseDetail/{id}", method = RequestMethod.GET)
		public ModelAndView enterpriseDetail(HttpServletRequest request,
				@PathVariable Integer id) {
			ModelAndView mav = new ModelAndView();
			EnterpriseInfoBo eb = enterpriseService.findByIdWithMembers(id);
			mav.addObject("enterpriseInfoBo", eb);
			mav.setViewName("page/enterprise/enterprise_detail");
			return mav;
		}
		
		@RequestMapping(value = "/updateEnterprise", method = RequestMethod.POST)
		@AvoidDuplicateSubmission(needRemoveToken = true)
		public ModelAndView updateEnterprise(
				@ModelAttribute("enterpriseInfoBo")@Valid EnterpriseInfoBo enterpriseInfoBo,BindingResult result,
				HttpServletRequest request, RedirectAttributes redirectAttributes,HttpSession session) {
			ModelAndView mav = new ModelAndView(
					"redirect:/enterprise/enterpriseQuery");
			String msg = "更新失败";
			if (result.hasErrors()) {
				mav.setViewName("page/enterprise/enterprise_add");
				return mav;
			}
			SysUser su = (SysUser) SessionUtil.getUser(session);
			if (null != su) {
				try {
                    int res = 0;
					enterpriseInfoBo.setEditTime(DateUtil.getCurrentDateString());
					enterpriseInfoBo.setEditUserId(su.getUserId());
					EnterpriseInfoBo old = enterpriseService.findById(enterpriseInfoBo.getEnterpriseId());
					if(!old.getManagerAccount().equals(enterpriseInfoBo.getManagerAccount()) && userService.findUsersize(enterpriseInfoBo.getManagerAccount()) > 0){
							result.rejectValue("managerAccount", "???", "管理员账号已经存在");
					}else {
                        res = enterpriseService.update(enterpriseInfoBo);
                    }
					msg = (res == 1 ? "更新成功" : "更新失败");
				} catch (Exception e) {
					logger.info("update enterprise fail:"+e.getMessage());
				}
			}
			redirectAttributes.addFlashAttribute("success", msg);
			return mav;
		}
		
		
}
