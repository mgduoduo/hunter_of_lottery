package com.payegis.tscsecurid.manage.service.impl.system;

import com.payegis.tscsecurid.common.constant.PropertyFileKeys;
import com.payegis.tscsecurid.common.data.bo.BindingLogEnterpriseBo;
import com.payegis.tscsecurid.common.data.entity.*;
import com.payegis.tscsecurid.common.mapper.*;
import com.payegis.tscsecurid.common.service.BaseServiceImpl;
import com.payegis.tscsecurid.common.util.DateUtil;
import com.payegis.tscsecurid.common.util.PropertyUtil;
import com.payegis.tscsecurid.manage.service.business.system.BindingInfoEnterpriseService;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.representation.Form;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by liucheng on 2014/12/9.
 */
@Service
public class BindingInfoEnterpriseServiceImpl extends BaseServiceImpl implements BindingInfoEnterpriseService {
    private static final Logger logger = Logger.getLogger(BindingInfoEnterpriseServiceImpl.class);

    @Autowired
    BindingInfoEnterpriseMapper mapper;

    @Autowired
    BindingInfoMapper bindingInfoMapper;

    @Autowired
    private BusinessSystemMapper businessSystemMapper;

    @Autowired
    BindingLogEnterpriseMapper logMapper;

    @Autowired
    private SysMsgMapper sysMsgMapper;

    @Override
    protected BaseMapper getMapper() {
        return mapper;
    }

    public BindingInfoEnterprise getBindingInfoByPrimaryKey(Integer bindId) {
        return mapper.selectByPrimaryKey(bindId);
    }

    public void saveUnBinding(BindingLogEnterprise log, Integer bindingInfoId) {
        try {
            final BindingInfoEnterprise info = mapper.selectByPrimaryKey(bindingInfoId);

            Client client = Client.create();
            final String push_url = PropertyUtil.getPropertyValue("config.properties", "push.url");
            logger.info("push url:" + push_url);
            WebResource rs = client.resource(push_url);
            final String messageContent = "{\"type\":\"" + PropertyFileKeys.BINDING_LOG_TYPE_UNBINDING + "\"," +
                    "\"ctx\":{\"systemNo\":\"" + info.getSystemNo() + "\",\"from\":\"cloud"  + "\",\"systemAccount\":\"" + info.getSystemAccount() + "\"}}";
            Form formParam = new Form();
            formParam.add("msgContent",messageContent);
            formParam.add("msgTitle","解绑成功");
            formParam.add("deviceId",info.getDeviceId());
            final String result = rs.post(String.class, formParam);
            logger.info("push result:"+result);

            mapper.deleteByPrimaryKey(bindingInfoId);
            logMapper.insertSelective(log);

            //同时解绑binding_info中的记录
            BusinessSystem businessSystem = businessSystemMapper.selectBySystemNo(info.getSystemNo());
            if(businessSystem == null){
                logger.info("解绑失败，业务系统不存在！");
                return;
            }
            BindingInfo bindInfo = bindingInfoMapper.selectByDeviceIdAndSystemIdAndAccount(info.getDeviceId(),businessSystem.getSystemId(),info.getSystemAccount());
            if (null == bindInfo) {
                logger.info("绑定关系已不存在！");
                return ;
            }
            bindingInfoMapper.deleteByPrimaryKey(bindInfo.getBingdingId());
            SysMsg msg = new SysMsg();
            msg.setEnterpriseId(bindInfo.getEnterpriseId());
            msg.setDeviceId(bindInfo.getDeviceId());
            msg.setMsgType("system");
            msg.setMsgContent("您的账号："+bindInfo.getSystemAccount()+"解绑成功");
            msg.setSendTime(DateUtil.getCurrentDateString());
            if (StringUtils.contains(result, "成功")) {
                msg.setIsSend("Y");
            }
            sysMsgMapper.insertSelective(msg);

        } catch (Exception e) {
            logger.error(e.getMessage(),e);
        }
    }

    public List<BindingLogEnterpriseBo> selectAccountHistory(BindingLogEnterprise bindingLog) {
        return logMapper.selectAccountHistory(bindingLog);
    }
}
