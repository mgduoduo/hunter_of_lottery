package com.payegis.tscsecurid.manage.util;

import com.payegis.tscsecurid.common.constant.PropertyFileKeys;
import com.payegis.tscsecurid.common.util.DateUtil;
import com.payegis.tscsecurid.common.util.FileUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.ServletContext;
import java.io.File;
import java.io.IOException;

/**
 * Created by liucheng on 2014/11/6.
 */
public class LocalFileUtils implements FileUtils {

    private static final Logger logger = Logger.getLogger(LocalFileUtils.class);

    public static final String DATA_FORMAT = "yyyyMMddHHmmssSSS";

    @Autowired
    private ServletContext servletContext;

    private String uploadPath;

    private String uploadVersionPath;

    public String saveMultipartFile(Integer enterpriseId, MultipartFile file) {
        final String upload =  uploadPath  + enterpriseId + File.separator;
        try {
            final String imageName = file.getOriginalFilename();
            String suffix = imageName.substring(imageName.lastIndexOf("."));
            final String newImageName = DateUtil.getCurrentDateString(DATA_FORMAT) + suffix;
            final String imagePath = upload + newImageName;
            File image = new File(imagePath);
            File parentDir = new File(upload);
            if (!parentDir.exists()) org.apache.commons.io.FileUtils.forceMkdir(parentDir);
            file.transferTo(image);
            return ("upload"+File.separator+enterpriseId + File.separator + newImageName).replaceAll("\\\\","/");
        } catch (IOException e) {
            logger.error(e);
        }
        return "";
    }

    public String saveVersionFile(String versionName,String type, MultipartFile file) {
        versionName =versionName+ file.getOriginalFilename().substring(file.getOriginalFilename().lastIndexOf("."));
        if ((type.equals(PropertyFileKeys.ANDRIOD) &&  file.getOriginalFilename().endsWith("."+PropertyFileKeys.ANDRIOD_SUFIX) )|| (type.equals(PropertyFileKeys.IOS) &&  file.getOriginalFilename().endsWith("."+PropertyFileKeys.IOS_SUFIX) ) ){
            final String path =  uploadVersionPath  +File.separator+ type +File.separator;
            try {
                File parentDir = new File(path);
                logger.info("file path:"+path+versionName+File.separator);
                File version = new File(path+versionName+File.separator);
                if (!parentDir.exists()) org.apache.commons.io.FileUtils.forceMkdir(parentDir);
                file.transferTo(version);
                return ("upload"+File.separator+"file" +File.separator+ type +File.separator+versionName).replaceAll("\\\\","/");
            } catch (IOException e) {
                logger.error(e);
                return "";
            }
        }
        return "";
    }
    public String getUploadPath() {
        return uploadPath;
    }

    public void setUploadPath(String uploadPath) {
        this.uploadPath = uploadPath;
    }

    public String getUploadVersionPath() {
        return uploadVersionPath;
    }

    public void setUploadVersionPath(String uploadVersionPath) {
        this.uploadVersionPath = uploadVersionPath;
    }
}
