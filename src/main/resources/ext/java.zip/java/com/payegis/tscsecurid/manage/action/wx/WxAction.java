package com.payegis.tscsecurid.manage.action.wx;

import com.payegis.tscsecurid.common.action.BaseAction;
import com.payegis.tscsecurid.common.data.bo.BindInfoDto;
import com.payegis.tscsecurid.common.data.entity.AppRelationBean;
import com.payegis.tscsecurid.common.exception.CommonException;
import com.payegis.tscsecurid.common.util.PropertyUtil;
import com.payegis.tscsecurid.common.util.StringUtil;
import com.payegis.tscsecurid.manage.common.Constant;
import com.payegis.tscsecurid.manage.common.ScanTypeEnum;
import com.payegis.tscsecurid.manage.service.business.customer.AppRelationService;
import com.payegis.tscsecurid.manage.util.Base64;
import com.payegis.tscsecurid.manage.util.JsonStringUtil;
import com.payegis.tscsecurid.manage.util.SigTool;
import com.payegis.tscsecurid.manage.util.WSUtil;
import me.chanjar.weixin.common.api.WxConsts;
import me.chanjar.weixin.common.bean.WxMenu;
import me.chanjar.weixin.common.exception.WxErrorException;
import me.chanjar.weixin.common.session.WxSessionManager;
import me.chanjar.weixin.mp.api.*;
import me.chanjar.weixin.mp.bean.WxMpXmlMessage;
import me.chanjar.weixin.mp.bean.WxMpXmlOutMessage;
import me.chanjar.weixin.mp.bean.WxMpXmlOutTextMessage;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.UnsupportedEncodingException;
import java.util.*;

@Controller
@RequestMapping("/wx")
public class WxAction extends BaseAction {

    protected static Config config = null;
    protected static WxMpInMemoryConfigStorage wxMpConfigStorage = null;
    protected static WxMpService wxMpService = null;
    protected static WxMpMessageRouter wxMpMessageRouter = null;

    @Autowired
    private AppRelationService appRelationService;

    static {
        config = Config.getInstance();
    }

    /**
     * 微信公众号开发者中心的服务地址
     * @param request
     * @param response
     * @return
     */
    @RequestMapping(value = "/devCenter")
    @ResponseBody
    public void getBusiness(HttpServletRequest request, HttpServletResponse response) {
        try {
            logger.info("enter devcenter");
            init(response);
            response.setContentType("text/html;charset=utf-8");
            response.setStatus(HttpServletResponse.SC_OK);
            String signature = request.getParameter("signature");
            String nonce = request.getParameter("nonce");
            String timestamp = request.getParameter("timestamp");
            if (!wxMpService.checkSignature(timestamp, nonce, signature)) {
                // 消息签名不正确，说明不是公众平台发过来的消息
                response.getWriter().println("非法请求");
                return;
            }

            if(!Config.isHasCreateButton()){
                List<WxMenu.WxMenuButton> x5Meuns = new ArrayList<WxMenu.WxMenuButton>();
                WxMenu.WxMenuButton my = new WxMenu.WxMenuButton();
                my.setName("账号");
                my.setType(WxConsts.BUTTON_VIEW);
                my.setUrl(PropertyUtil.getPropertyValue("config.properties", "wx.my"));
                x5Meuns.add(my);

                WxMenu.WxMenuButton scan = new WxMenu.WxMenuButton();
                scan.setName("扫码");
                scan.setType(WxConsts.BUTTON_VIEW);
                scan.setKey("w_scan");
                scan.setUrl(PropertyUtil.getPropertyValue("config.properties", "wx.scan"));
                x5Meuns.add(scan);

                WxMenu.WxMenuButton about = new WxMenu.WxMenuButton();
                about.setName("关于");
                about.setType(WxConsts.BUTTON_CLICK);
                about.setKey("w_about");

                List<WxMenu.WxMenuButton> subMenus = new ArrayList<WxMenu.WxMenuButton>();
                WxMenu.WxMenuButton gw = new WxMenu.WxMenuButton();
                gw.setName("官网");
                gw.setType(WxConsts.BUTTON_VIEW);
                gw.setUrl(Constant.OFFICIAL_WEBSITE);
                subMenus.add(gw);

                WxMenu.WxMenuButton userHelp = new WxMenu.WxMenuButton();
                userHelp.setName("用户帮助");
                userHelp.setType(WxConsts.BUTTON_VIEW);
                userHelp.setUrl(Constant.USER_HELP_URL);
                subMenus.add(userHelp);

                WxMenu.WxMenuButton seftyPrivacy = new WxMenu.WxMenuButton();
                seftyPrivacy.setName("安全隐私");
                seftyPrivacy.setType(WxConsts.BUTTON_VIEW);
                seftyPrivacy.setUrl(Constant.SAFETY_PRIVACY_URL);
                subMenus.add(seftyPrivacy);

                about.setSubButtons(subMenus);
                x5Meuns.add(about);

                WxMenu x5Menu = new WxMenu();
                x5Menu.setButtons(x5Meuns);
                wxMpService.menuDelete();
                wxMpService.menuCreate(x5Menu);
                Config.setHasCreateButton(true);
                logger.info("----------------------------------create menus------------------------------");
            }
            String echostr = request.getParameter("echostr");
            if (StringUtils.isNotBlank(echostr)) {
                // 说明是一个仅仅用来验证的请求，回显echostr
                response.getWriter().println(echostr);
                return;
            }

            String encryptType = StringUtils.isBlank(request.getParameter("encrypt_type")) ?
                    "raw" :
                    request.getParameter("encrypt_type");

            if ("raw".equals(encryptType)) {
                // 明文传输的消息
                WxMpXmlMessage inMessage = WxMpXmlMessage.fromXml(request.getInputStream());
                WxMpXmlOutMessage outMessage = wxMpMessageRouter.route(inMessage);
                response.getWriter().write(outMessage.toXml());
                return;
            }

            if ("aes".equals(encryptType)) {
                // 是aes加密的消息
                String msgSignature = request.getParameter("msg_signature");
                WxMpXmlMessage inMessage = WxMpXmlMessage.fromEncryptedXml(request.getInputStream(), wxMpConfigStorage, timestamp, nonce, msgSignature);
                WxMpXmlOutMessage outMessage = wxMpMessageRouter.route(inMessage);
                response.getWriter().write(outMessage.toEncryptedXml(wxMpConfigStorage));
                return;
            }

            response.getWriter().println("不可识别的加密类型");
            return;
        } catch (Exception e) {
            logger.info(e.getMessage());
        }
    }


    /**
     * 微信oauth2网页静默授权回调接口，用于获取微信用户在某公众号中对应的openid后，并重定向到要访问的地址去
     * @param request
     * @param response
     * @return
     */
    @RequestMapping(value = "/openid", method = {RequestMethod.POST, RequestMethod.GET})
    public ModelAndView getOpenid(HttpServletRequest request, HttpServletResponse response) {
        String requestUrl = (String) request.getSession().getAttribute("requestUrl");
        logger.info("requestUrl:" + requestUrl);
        String code = request.getParameter("code");
        Map<String, Object> param = new HashMap<String, Object>();
        param.put("appid", PropertyUtil.getPropertyValue("config.properties", "wx.appid"));
        param.put("secret", PropertyUtil.getPropertyValue("config.properties", "wx.secret"));
        param.put("code", code);
        param.put("grant_type", "authorization_code");
        String result = WSUtil.sendRequest(Constant.WX_OAUTH2_URL, param);
        String openid = null;
        if (StringUtils.isNotEmpty(result)) {
            net.sf.json.JSONObject jo = net.sf.json.JSONObject.fromObject(result);
            if (jo != null) {
                logger.info(jo.toString());
                openid = jo.getString("openid");
                logger.info("weixin auth and get open id:" + openid);
            }
        }
        ModelAndView mav = new ModelAndView();
        String[] urlArr = requestUrl.split("/");
        StringBuilder url = new StringBuilder("/");
        if (null != urlArr && urlArr.length > 0) {
            for (int i = 2; i < urlArr.length; i++) {
                if (StringUtil.isNotEmpty(urlArr[i])) {
                    url.append(urlArr[i]);
                    if (i != (urlArr.length - 1)) {
                        url.append("/");
                    }
                }
            }
        }
        request.getSession().setAttribute("openid", openid);
        mav.setViewName("redirect:" + url.toString());
        return mav;
    }

    /**
     * 微信公众号下面的“我的”对应接口
     * @param request
     * @param response
     * @return
     */
    @RequestMapping(value = "/bussiness/list", method = RequestMethod.GET)
    public ModelAndView list(HttpServletRequest request, HttpServletResponse response) {
        ModelAndView mav = new ModelAndView();
        String openid = (String) request.getSession().getAttribute("openid");
        logger.info("enter list method and openid is :" + openid);
        if (StringUtil.isNotEmpty(openid)) {
            mav.addObject("openid", openid);
            mav.addObject("appId", PropertyUtil.getPropertyValue("config.properties", "manage.app.id"));
            boolean alreadyAttention = checkAttention(openid, PropertyUtil.getPropertyValue("config.properties", "wx.appid"));
            if (!alreadyAttention) {
                mav.setViewName("page/wx/call_attention");
            } else {
                String timestamp = String.valueOf(System.currentTimeMillis() / 1000);
                String noncestr = UUID.randomUUID().toString().replace("-", "");
                //jsapiTicket放redis中全局缓存
                String jsapiTicket = "";
                try {
                    jsapiTicket = getJsapiTicket();
                } catch (Exception e) {
                    e.printStackTrace();
                }

                String share2FirendUrl = request.getScheme() + "://"
                        + request.getServerName() + request.getRequestURI();
                String signature = getSignature(timestamp, noncestr, jsapiTicket, share2FirendUrl);
                mav.addObject("timestamp", timestamp);
                mav.addObject("noncestr", noncestr);
                mav.addObject("signature", signature);
                mav.addObject("share2FirendUrl", share2FirendUrl);

                String hostName = PropertyUtil.getPropertyValue("config.properties", "tscsecurid.rest.cloud.list.url");
                String url = hostName + "?t=" + new Random().nextInt(1000);
                Map<String, Object> params = new HashMap<String, Object>();
                params.put("deviceId", openid);
                String result = WSUtil.sendRequest(url, params);
                JSONArray jsonArray = ((JSONObject)JSONObject.fromObject(result).get("data")).getJSONArray("bindInfos");

                List<BindInfoDto> list = new ArrayList<BindInfoDto>();
                if(jsonArray.isEmpty() || jsonArray.size()<1){
                    list = new ArrayList<BindInfoDto>();
                }else{
                    list = (List<BindInfoDto>)JSONArray.toCollection(jsonArray, BindInfoDto.class);
                }

                mav.addObject("rslist", list);
                mav.setViewName("page/wx/MyList");
            }
        } else {
            mav.setViewName("page/wx/notAuth");
        }
        return mav;
    }

    /**
     * 推广接口
     * @param request
     * @param response
     * @return
     */
    @RequestMapping(value = "/bussiness/promote", method = RequestMethod.GET)
    public ModelAndView promote(HttpServletRequest request, HttpServletResponse response) {
        ModelAndView mav = new ModelAndView();
        mav.setViewName("page/wx/promote_document");
        return mav;
    }

    @RequestMapping(value = "/temp", method = RequestMethod.GET)
    public ModelAndView temp(HttpServletRequest request) {
        ModelAndView mav = new ModelAndView();
        mav.setViewName("page/wx/temp");
        return mav;
    }

    /**
     * 扫一扫地址
     * @param request
     * @param response
     * @return
     */
    @RequestMapping(value = "/bussiness/doScan", method = RequestMethod.GET)
    public ModelAndView scan(HttpServletRequest request, HttpServletResponse response) {
        ModelAndView mav = new ModelAndView();
        try {
            String openid = (String) request.getSession().getAttribute("openid");
            logger.info("enter dosacn method and openid is :" + openid);
            String timestamp = String.valueOf(System.currentTimeMillis() / 1000);
            String noncestr = UUID.randomUUID().toString().replace("-", "");
            String requestUrl = request.getScheme() + "://"
                    + request.getServerName() + request.getRequestURI();
            //jsapiTicket放redis中全局缓存
            String jsapiTicket = null;
            try {
                jsapiTicket = getJsapiTicket();
            } catch (Exception e) {
                e.printStackTrace();
            }

            String signature = SigTool.getSignature(timestamp, noncestr, jsapiTicket, requestUrl);
            mav.addObject("timestamp", timestamp);
            mav.addObject("noncestr", noncestr);
            mav.addObject("signature", signature);
            mav.addObject("wxAppID", PropertyUtil.getPropertyValue("config.properties", "wx.appid"));
            if (StringUtil.isNotEmpty(openid)) {
                mav.addObject("openid", openid);
                mav.addObject("requestUrl", requestUrl);
                mav.addObject("appId", PropertyUtil.getPropertyValue("config.properties", "manage.app.id"));
                mav.setViewName("page/wx/scan");
            } else {
                logger.error("无法打开扫一扫操作");
                //关闭扫一扫？
                mav.setViewName("page/wx/error");
            }
        } catch (Exception e) {
            logger.error("无法打开扫一扫操作");
            //关闭扫一扫？
            mav.setViewName("page/wx/error");
        }

        return mav;
    }

    /**
     * 时空码验证
     * @param request
     * @param response
     * @return
     */
    @RequestMapping(value = "/bussiness/validate", method = RequestMethod.POST)
    @ResponseBody
    public String validateCode(HttpServletRequest request, HttpServletResponse response) {

        ModelAndView mav = new ModelAndView();
        StringBuffer jsonBuf = new StringBuffer();
        try {

            //Step 1: validate
            String paramCode = request.getParameter("cdCode");
            String tscCode = generateCode(paramCode);
            String feedbackCode = validateTscCode(tscCode);
            String[] tempArr = parseExternalId(feedbackCode);

            jsonBuf.append("{")
                    .append("'status':'0',")
                    .append("'message':'验证通过',")
                    .append("'systemNo':'" + tempArr[0] + "'")
                    .append("}");


        } catch (CommonException e) {
            logger.info(">>>>系统出错>>>>,异常信息：" + e.getMessage(), e);
            return JSONObject.fromObject(e.getMessage()).toString();
        } catch (Exception e2) {
            logger.info(">>>>系统出错>>>>,异常信息：" + e2.getMessage(), e2);
            return JSONObject.fromObject(e2.getMessage()).toString();
        }

        return JSONObject.fromObject(jsonBuf.toString()).toString();
    }

    /**
     * 处理扫一扫获得的数据：先验证合法性，再做后续操作，如绑定、登录等
     * @param request
     * @param response
     * @return
     */
    @RequestMapping(value = "/bussiness/bind", method = RequestMethod.POST)
    @ResponseBody
    public String bindAccount(HttpServletRequest request, HttpServletResponse response) {
        String openid = (String) request.getSession().getAttribute("openid");
        logger.info("enter bind method and openid is :" + openid);
        try {
            //Step 1: validate
            String tscType = request.getParameter("scanType");
            if (StringUtil.isEmpty(tscType) || !ScanTypeEnum.BINDING.getCodeId().equals(tscType)) {
                logger.info("请求类型不匹配");
                throw new CommonException(JsonStringUtil.jsonExceptionMsg(-1, "请求类型不匹配"));
            }
            String paramCode = request.getParameter("cdCode");
            String tscCode = generateCode(paramCode);
            String result = validateTscCode(tscCode);
            String[] tempArr = parseExternalId(result);
            //logger.info("~~~~~~1" + tempArr[0] + ", 2=" + tempArr[1] + ", 3=" + tempArr[2]);

            //Step 2: do business
            Map<String, Object> paramMap = new HashMap<String, Object>();
            paramMap.put("systemNo", tempArr[0]);
            paramMap.put("deviceId", openid);
            paramMap.put("systemAccount", tempArr[1]);
            paramMap.put("systemUrl", tempArr[2]);
            String bindingResult = WSUtil.sendRequest(tempArr[2] + ScanTypeEnum.BINDING.getCodeUrl(), paramMap);
            if (StringUtils.isEmpty(bindingResult) || !Constant.SUCCESS_STATUS.equals(JSONObject.fromObject(bindingResult).getString("status"))) {
                logger.info("~~~~~~~~Step 2 绑定失败，返回结果为：" + bindingResult);
                throw new CommonException(bindingResult);
            }
            logger.info("~~~~~~~~Step 2 绑定成功");
            return bindingResult;
        } catch (CommonException e) {
            logger.info(">>>>bind 出错>>>>,异常信息：" + e.getMessage(), e);
            return JSONObject.fromObject(e.getMessage()).toString();
        } catch (Exception e2) {
            logger.info(">>>>bind 出错>>>>,异常信息2：" + e2.getMessage(), e2);
            return JSONObject.fromObject(e2.getMessage()).toString();
        }

    }


    /**
     * 处理扫一扫获得的数据：先验证合法性，再做登录等
     * @param request
     * @param response
     * @return
     */

    @RequestMapping(value = "/bussiness/login", method = RequestMethod.POST)
    @ResponseBody
    public String login(HttpServletRequest request, HttpServletResponse response) {

        ModelAndView mav = new ModelAndView();
        String openid = (String) request.getSession().getAttribute("openid");
        logger.info("enter dosacn method and openid is :" + openid);
        try {
            //Step 1: validate
            String tscType = request.getParameter("scanType");
            if (StringUtil.isEmpty(tscType) || !ScanTypeEnum.LOGIN.getCodeId().equals(tscType)) {
                logger.info("请求类型不匹配");
                throw new CommonException(JsonStringUtil.jsonExceptionMsg(-1, "请求类型不匹配"));
            }
            String userAccount = request.getParameter("userAccount");
            String userSystemNo = request.getParameter("userSystemNo");
            if (StringUtils.isBlank(userAccount) || StringUtils.isBlank(userSystemNo)) {
                logger.info("参数不符，登录失败");
                throw new CommonException(JsonStringUtil.jsonExceptionMsg(-1, "参数不符，登录失败"));
            }

            String paramCode = request.getParameter("cdCode");
            String loginCode = request.getParameter("loginCode");
            String tscCode = generateCode(paramCode);
            String result = validateTscCode(tscCode);
            String[] tempArr = parseExternalId(result);
            //logger.info("~~~~~~1" + tempArr[0] + ", 2=" + tempArr[1] + ", 3=" + tempArr[2]);

            Map<String, Object> paramMap = new HashMap<String, Object>();

            //Step 2: do business
            //Step 2.1, 获取账号列表
            paramMap.put("deviceId", openid);
            String listResult = WSUtil.sendRequest(PropertyUtil.getPropertyValue("config.properties", "tscsecurid.rest.cloud.list.url"), paramMap);

            if (StringUtil.isEmpty(listResult)) {
                logger.info("账号列表为空");
                throw new CommonException(JsonStringUtil.jsonExceptionMsg(-1, "该用户没有可用账号"));
            }
            JSONArray accounts = JSONObject.fromObject(listResult).getJSONObject("data").getJSONArray("bindInfos");
            //logger.info(accounts.toString());

            if (accounts.isEmpty() || accounts.size() == 0) {
                logger.info("没有可用账号，无法登录");
                throw new CommonException(JsonStringUtil.jsonExceptionMsg(-1, "没有可用账号，无法登录"));
            }
            //Step 2.2, 如果是多个账号，跳转到选择页面；如果是唯一账号，直接登录
            boolean isValidAccount = false;
            if (accounts.size() > 1) {//multiple accounts, redirect to choose page
                for (int i = 0; i < accounts.size(); i++) {
                    JSONObject obj = (JSONObject) accounts.get(i);
                    String systemNo = obj.getString("systemNo");
                    String systemAccount = obj.getString("systemAccount");
                    if (userAccount.equals(systemAccount) && userSystemNo.equals(systemNo)) {
                        isValidAccount = true;
                        break;
                    }
                }

            } else if (accounts.size() == 1) {// if has only one account, can login directly.
                if (userAccount.equals(((JSONObject) accounts.get(0)).getString("systemAccount")) && userSystemNo.equals(tempArr[0])) {
                    isValidAccount = true;
                }
            }

            if (!isValidAccount) {
                logger.info("登录账号信息不匹配，登录失败，systemNo=" + userSystemNo + ",systemAccount=" + userAccount);
                throw new CommonException(JsonStringUtil.jsonExceptionMsg(-1, "参数不匹配，登录失败"));
            }

            paramMap.put("systemNo", userSystemNo);
            paramMap.put("systemAccount", userAccount);
            paramMap.put("deviceId", openid);
            paramMap.put("systemUrl", tempArr[2]);
            paramMap.put("loginCode", loginCode);
            paramMap.put("sessionId", tempArr[1]);
            String loginReult = WSUtil.sendRequest(tempArr[2] + ScanTypeEnum.LOGIN.getCodeUrl(), paramMap);
            if (StringUtils.isEmpty(loginReult) || !Constant.SUCCESS_STATUS.equals(JSONObject.fromObject(loginReult).getString("status"))) {
                logger.info("~~~~~~~~Step 2 登录失败，返回结果为：" + loginReult + ",loginCode=" + loginCode);
                throw new CommonException(loginReult);
            }
            logger.info("~~~~~~~~Step 2 登录成功");
            return loginReult;
        } catch (CommonException e) {
            logger.info(">>>>login出错>>>>,异常信息：" + e.getMessage(), e);
            return JSONObject.fromObject(e.getMessage()).toString();
        } catch (Exception e2) {
            logger.info(">>>>login出错>>>>,异常信息2：" + e2.getMessage(), e2);
            return JsonStringUtil.jsonExceptionMsg(-1, "系统出错");
        }

    }

    /**
     * 处理扫一扫获得的数据：先验证合法性，再做开门等
     * @param request
     * @param response
     * @return
     */
    @RequestMapping(value = "/bussiness/open", method = RequestMethod.POST)
    @ResponseBody
    public String open(HttpServletRequest request, HttpServletResponse response) {

        String openid = (String) request.getSession().getAttribute("openid");
        logger.info("enter open method and openid is :" + openid);
        try {
            //Step 1: validate
            String tscType = request.getParameter("scanType");
            if (StringUtil.isEmpty(tscType) || !ScanTypeEnum.OPEN.getCodeId().equals(tscType)) {
                logger.info("请求类型不匹配");
                throw new CommonException(JsonStringUtil.jsonExceptionMsg(-1, "请求类型不匹配"));
            }
            String userAccount = request.getParameter("userAccount");
            String userSystemNo = request.getParameter("userSystemNo");
            if(StringUtils.isBlank(userAccount) || StringUtils.isBlank(userSystemNo)){
                logger.info("参数不符，开门失败");
                throw new CommonException(JsonStringUtil.jsonExceptionMsg(-1, "参数不符，开门失败"));
            }
            String paramCode = request.getParameter("cdCode");
            String loginCode = request.getParameter("loginCode");
            String tscCode = generateCode(paramCode);
            String result = validateTscCode(tscCode);
            String[] tempArr = parseExternalId(result);
            //logger.info("~~~~~~1" + tempArr[0] + ", 2=" + tempArr[1] + ", 3=" + tempArr[2]);

            Map<String, Object> paramMap = new HashMap<String, Object>();

            //Step 2: do business
            //Step 2.1, 获取账号列表
            paramMap.put("deviceId", openid);
            String listResult = WSUtil.sendRequest(PropertyUtil.getPropertyValue("config.properties", "tscsecurid.rest.cloud.list.url"), paramMap);

            JSONArray accounts = JSONObject.fromObject(listResult).getJSONObject("data").getJSONArray("bindInfos");
            logger.info(accounts.toString());

            if (accounts.isEmpty() || accounts.size() == 0) {
                logger.info("没有可用账号，无法继续操作");
                throw new CommonException(JsonStringUtil.jsonExceptionMsg(-1, "没有可用账号，无法继续操作"));
            }
            /*String systemAccount = "";
            for (int i = 0; i < accounts.size(); i++) {
                JSONObject obj = (JSONObject) accounts.get(i);
                String sysNO = obj.getString("systemNo");
                if (tempArr[0].equals(sysNO)) {
                    systemAccount = obj.getString("systemAccount");
                    break;
                }
            }*/

            boolean isValidAccount = false;
            if (accounts.size()>1){//multiple accounts, redirect to choose page
                for (int i = 0; i <accounts.size() ; i++) {
                    JSONObject obj = (JSONObject)accounts.get(i);
                    String systemNo = obj.getString("systemNo");
                    String systemAccount = obj.getString("systemAccount");
                    if(userAccount.equals(systemAccount) && userSystemNo.equals(systemNo)){
                        isValidAccount = true;
                        break;
                    }
                }

            }else if(accounts.size() == 1){
                if(userAccount.equals(((JSONObject) accounts.get(0)).getString("systemAccount")) && userSystemNo.equals(tempArr[0])){
                    isValidAccount = true;
                }
            }

            if(!isValidAccount){
                logger.info("账号信息不匹配，开门失败，systemNo="+userSystemNo+",systemAccount="+userAccount);
                throw new CommonException(JsonStringUtil.jsonExceptionMsg(-1, "参数不匹配，开门失败"));
            }

            //Step 2.2 开门
            paramMap.put("systemAccount", userAccount);
            paramMap.put("loginCode", loginCode);
            paramMap.put("systemNo", userSystemNo);
            paramMap.put("sessionId", tempArr[1]);
            paramMap.put("systemUrl", tempArr[2]);
            paramMap.put("bssid", "");
            String result2 = WSUtil.sendRequest(tempArr[2] + ScanTypeEnum.OPEN.getCodeUrl(), paramMap);
            if (StringUtils.isEmpty(result2) || !Constant.SUCCESS_STATUS.equals(JSONObject.fromObject(result2).getString("status"))) {
                logger.info("~~~~~~~~Step 2 开门失败，返回结果为：" + result2 + ",loginCode=" + loginCode);
                throw new CommonException(result2);
            }
            logger.info("~~~~~~~~Step 2 开门成功~~~~~~~~~~~~~~~~~~~~~");
            return result2;
        } catch (CommonException e) {
            logger.info(">>>>open 出错>>>>,异常信息：" + e.getMessage(), e);
            return JSONObject.fromObject(e.getMessage()).toString();
        } catch (Exception e2) {
            logger.info(">>>>open 出错>>>>,异常信息2：" + e2.getMessage(), e2);
            return JsonStringUtil.jsonExceptionMsg(-1, "系统出错");
        }
    }

    /**
     * 获取微信公众号的绑定设备列表
     * @param request
     * @param session
     * @return
     */

    @RequestMapping(value = "/bussiness/listBindInfos", produces = {"application/json;charset=UTF-8"})
    public
    @ResponseBody
    String devicelog(HttpServletRequest request, HttpSession session) {
        String did = request.getParameter("deviceId");
        String url = request.getParameter("url");
        Map<String,Object> params = new HashMap<String,Object>();
        params.put("deviceId",did);
        String result = WSUtil.sendRequest(url,params);
        return result;
    }
    private String generateCode(String paramCdCode) {
        String code = paramCdCode.substring(3);
        String requestTimeString = String.valueOf(System.currentTimeMillis()).substring(0, 10);
        return code + requestTimeString;
    }

    public void init(final HttpServletResponse response) throws Exception {
        wxMpConfigStorage = new WxMpInMemoryConfigStorage();
        wxMpConfigStorage.setAppId(PropertyUtil.getPropertyValue("config.properties", "wx.appid")); // 设置微信公众号的appid
        wxMpConfigStorage.setSecret(PropertyUtil.getPropertyValue("config.properties", "wx.secret")); // 设置微信公众号的app corpSecret
        wxMpConfigStorage.setToken(PropertyUtil.getPropertyValue("config.properties", "wx.token")); // 设置微信公众号的token
        //config.setAesKey("..."); // 设置微信公众号的EncodingAESKey
        wxMpService = new WxMpServiceImpl();
        wxMpService.setWxMpConfigStorage(wxMpConfigStorage);
        WxMpMessageHandler handler = new WxMpMessageHandler() {
            @Override
            public WxMpXmlOutMessage handle(WxMpXmlMessage wxMessage, Map<String, Object> context, WxMpService wxMpService, WxSessionManager sessionManager) throws WxErrorException {
                String msg = "感谢使用通付盾微信身份认证服务公众号，您的身份由您做主！\n" +
                        "扫描时空码（动态二维码）添加更多账号。\n" +
                        "扫描时空码（动态二维码）使用您的账号登录系统。\n" +
                        "我们可以提升您的登录体验，快速登录。\n" +
                        "但，更重要的，我们可以提升您账号的安全性！\n"+
                        "甩开短信码，比肩硬件Key！\n";
                WxMpXmlOutTextMessage m
                        = WxMpXmlOutMessage.TEXT().content(msg).fromUser(wxMessage.getToUserName())
                        .toUser(wxMessage.getFromUserName()).build();
                logger.info("wxMessage.getFromUserName()-----" + wxMessage.getFromUserName() + ";---commonId:-----" + PropertyUtil.getPropertyValue("config.properties", "wx.appid"));
                attention(response, wxMessage.getEvent(), wxMessage.getFromUserName(), PropertyUtil.getPropertyValue("config.properties", "wx.appid"));
                return m;
            }
        };
        wxMpMessageRouter = new WxMpMessageRouter(wxMpService);
        wxMpMessageRouter
                .rule()
                .async(false)
                        //.content("哈哈") // 拦截内容为“哈哈”的消息wechat_attention
                .handler(handler)
                .end();

    }

    public String getJsapiTicket() throws Exception {
        String jsapiTicket = null;
        if (StringUtil.isEmpty(Config.getInstance().getJsapiTicket())) {
            jsapiTicket = initParam();
            if (StringUtil.isNotEmpty(jsapiTicket)) {
                Config.getInstance().setJsapiTicket(jsapiTicket);
                Config.getInstance().setTime(System.currentTimeMillis()/1000);
            }
        } else {
            long now = System.currentTimeMillis()/1000;
            if(now - config.getInstance().getTime()>7000){
                jsapiTicket = initParam();
                Config.getInstance().setJsapiTicket(jsapiTicket);
                Config.getInstance().setTime(System.currentTimeMillis()/1000);
            }else
                jsapiTicket = Config.getInstance().getJsapiTicket();
        }
        logger.info("jsapiTicket:"+jsapiTicket);
        return jsapiTicket;
    }
    public String initParam() throws Exception {
        wxMpConfigStorage = new WxMpInMemoryConfigStorage();
        wxMpConfigStorage.setAppId(PropertyUtil.getPropertyValue("config.properties", "wx.appid")); // 设置微信公众号的appid
        wxMpConfigStorage.setSecret(PropertyUtil.getPropertyValue("config.properties", "wx.secret")); // 设置微信公众号的app corpSecret
        wxMpConfigStorage.setToken(PropertyUtil.getPropertyValue("config.properties", "wx.token")); // 设置微信公众号的token
        //config.setAesKey("..."); // 设置微信公众号的EncodingAESKey
        wxMpService = new WxMpServiceImpl();
        wxMpService.setWxMpConfigStorage(wxMpConfigStorage);
        return wxMpService.getJsapiTicket();
    }

    public boolean checkAttention(String openId, String commonId) {
        boolean alreadyAttention = true;
        AppRelationBean appRelationBean = appRelationService.getAppRelationStatus(openId, commonId);
        //没查到，或者查到的状态为0，均表示未关注公众号
        if (appRelationBean == null || "0".equals(appRelationBean.getStatus())) {
            alreadyAttention = false;
        }
        return alreadyAttention;
    }

    public void attention(HttpServletResponse response, String event, String openId, String commonId) {
        if ("subscribe".equals(event)) {
            addAttention(response, openId, commonId);
        } else if ("unsubscribe".equals(event)) {
            cancelAttention(openId, commonId);
        }
    }

    private String getSignature(String timestamp, String noncestr, String jsapiTicket, String share2FirendUrl) {
        String[] array = {"timestamp=" + timestamp, "noncestr=" + noncestr,
                "jsapi_ticket=" + jsapiTicket, "url=" + share2FirendUrl};
        Arrays.sort(array);
        String signature = array[0].concat("&" + array[1]).concat("&" + array[2]).concat("&" + array[3]);
        signature = DigestUtils.sha1Hex(signature);
        return signature;
    }

    public String addAttention(HttpServletResponse response, String openId, String commonId) {
        try {
            logger.info("enter addAttention method");
            //根据微信号，公众号到t_wechat表里去查，看看能否查到记录
            logger.info(appRelationService == null);
            AppRelationBean appRelationBean = appRelationService.getAppRelationStatus(openId, commonId);
            logger.info("enter addAttention method--appRelationBean==null?-" + appRelationBean == null);
            //如果没有找到，则表明该openId没有关注过我们的公众号;
            if (appRelationBean == null) {
                //将openId,commonId,封装成WeChatManageBean对象插入到t_wechat表中
                appRelationBean = new AppRelationBean();
                appRelationBean.setOpenId(openId);
                appRelationBean.setCommonId(commonId);
                //type为1表示微信
                appRelationBean.setType("1");
                //1表示已关注
                appRelationBean.setStatus("1");
                logger.info("appRelationService.create begin");
                appRelationService.create(appRelationBean);
                logger.info("appRelationService.create  end");
            }
            //如果找到了但是状态为0，表示未关注，则表明该openId以前关注过我们的公众号，但是又取消关注了
            else if ("0".equals(appRelationBean.getStatus())) {
                //更新openId,commonId这条数据库记录，将它的status设置为已关注
                logger.info("已经关注");
                //1表示已关注
                appRelationBean.setStatus("1");
                appRelationService.updateAppRelation(appRelationBean);
            }
            return "success";
        } catch (Exception e) {
            logger.info(e.getMessage());
            return "error";
        }
    }

    public String cancelAttention(String openId, String commonId) {
        try {
            //更新openId,commonId这条数据库记录，将它的status设置为未关注
            AppRelationBean appRelationBean = appRelationService.getAppRelationStatus(openId, commonId);
            //0表示取消关注
            appRelationBean.setStatus("0");
            appRelationService.updateAppRelation(appRelationBean);
            return "success";
        } catch (Exception e) {
            logger.error(e);
            return "error";
        }
    }

    private String validateTscCode(String tscCode) {
        String validateUrl = "";
        if (StringUtil.isEmpty(config.getTscServerUrl())) {
            String tscRestCloudUrl = PropertyUtil.getPropertyValue("config.properties", "tscsecurid.rest.cloud.config.url");
            String configStr = WSUtil.sendRequest(tscRestCloudUrl, null);
            if (StringUtil.isNotEmpty(configStr)) {
                JSONObject jo = JSONObject.fromObject(configStr);
                if (null != jo && jo.getString("status") != null && jo.getString("status").equals("0")) {
                    validateUrl = jo.getJSONObject("data").getString("tscValidateInner");
                    if (StringUtil.isNotEmpty(validateUrl)) {
                        config.setTscServerUrl(validateUrl);
                    }
                }
            }
        } else
            validateUrl = config.getTscServerUrl();
        String result = WSUtil.sendAppRequest(tscCode, validateUrl, PropertyUtil.getPropertyValue("config.properties", "manage.app.id"), PropertyUtil.getPropertyValue("config.properties", "manage.app.key"));
        if (StringUtils.isEmpty(result) || !Constant.SUCCESS_STATUS.equals(JSONObject.fromObject(result).getString("status"))) {
            logger.info("验证失败，返回结果为：" + result);
            throw new CommonException(result);
        }
        logger.info("验证成功");
        return result;
    }

    private String[] parseExternalId(String jsonResult) throws UnsupportedEncodingException {
        JSONObject jsonObject = JSONObject.fromObject(jsonResult);
        String externalId = new String(Base64.decode(jsonObject.getJSONObject("data").getString("externalId"), Base64.NO_WRAP), "UTF-8");
        String[] tempArr = externalId.split("\\|");
        return tempArr;
    }
}
