package com.payegis.tscsecurid.manage.service.business.system;

import com.payegis.tscsecurid.common.data.bo.EnterpriseInfoBo;
import com.payegis.tscsecurid.common.data.entity.TxnLog;
import com.payegis.tscsecurid.common.data.entity.TxnStatus;
import com.payegis.tscsecurid.common.service.BaseService;

import java.util.List;


public interface SystemTxnService extends BaseService {

    List<TxnStatus> selectTxnStatusByLogId(String txnId);

    List<EnterpriseInfoBo> findAllEnterprise();

    TxnLog selectTxnLogByLogId(String logId);
}
