package com.payegis.tscsecurid.manage.bean;


import com.payegis.tscsecurid.common.data.BaseDto;

public class MenuBean extends BaseDto {
	private static final long serialVersionUID = -7315463110194704486L;
	private String menuId;
	private String menuName;
	private String url;
	private String privilege;

	public MenuBean() {
	}

	public MenuBean(String menuId, String menuName, String url, String privilege) {
		super();
		this.menuId = menuId;
		this.menuName = menuName;
		this.url = url;
		this.privilege = privilege;
	}

	public String getMenuId() {
		return menuId;
	}

	public void setMenuId(String menuId) {
		this.menuId = menuId;
	}

	public String getMenuName() {
		return menuName;
	}

	public void setMenuName(String menuName) {
		this.menuName = menuName;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getPrivilege() {
		return privilege;
	}

	public void setPrivilege(String privilege) {
		this.privilege = privilege;
	}

}
