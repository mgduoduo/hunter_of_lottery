package com.payegis.tscsecurid.manage.action.mgr;

import com.payegis.tscsecurid.common.constant.PropertyFileKeys;
import com.payegis.tscsecurid.common.data.bo.EnterpriseInfoBo;
import com.payegis.tscsecurid.common.data.entity.BusinessSystem;
import com.payegis.tscsecurid.common.data.entity.SysCode;
import com.payegis.tscsecurid.common.data.entity.SysLog;
import com.payegis.tscsecurid.common.data.entity.SysUser;
import com.payegis.tscsecurid.common.result.ResultBean;
import com.payegis.tscsecurid.common.util.EncryUtil;
import com.payegis.tscsecurid.common.util.StringUtil;
import com.payegis.tscsecurid.common.util.ToolUtil;
import com.payegis.tscsecurid.common.util.UserAgentUtil;
import com.payegis.tscsecurid.manage.action.customer.ManageBaseAction;
import com.payegis.tscsecurid.manage.common.Constant;
import com.payegis.tscsecurid.manage.service.business.enterprise.EnterpriseService;
import com.payegis.tscsecurid.manage.service.business.mgr.LogService;
import com.payegis.tscsecurid.manage.service.business.msg.MsgService;
import com.payegis.tscsecurid.manage.util.SessionUtil;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.OutputStream;
import java.util.*;

@Controller
@RequestMapping("/log")
public class LogAction extends ManageBaseAction {

    @Autowired
    private MsgService msgService;

    @Autowired
    private LogService logService;

    @Autowired
    private EnterpriseService enterpriseService;

    @ModelAttribute("businessTypes")
    public Map<Integer, String> getBusinessTypes(HttpSession session) {
        SysUser su = super.getSessionInfo(session).getLoginUser();
        Map<Integer, String> map = new HashMap<Integer, String>();
        if (null != su) {
            Map<String, Object> param = new HashMap<String, Object>();
            if (!su.getRoleNames().contains(Constant.SYSTEM_USER))
                param.put("enterpriseId", su.getEnterpriseId());
            List<BusinessSystem> bs = logService
                    .getBusinessSystemByEnterpriseId(param);
            if (null != bs && !bs.isEmpty()) {
                for (BusinessSystem b : bs) {
                    map.put(b.getSystemId(), b.getSystemName());
                }
            }
        }
        return map;
    }

    @ModelAttribute("enterpriseTypes")
    public Map<Integer, String> enterpriseTypes(HttpSession session) {
        SysUser su = super.getSessionInfo(session).getLoginUser();
        Map<Integer, String> map = new HashMap<Integer, String>();
        if (null != su && su.getRoleNames().contains(Constant.SYSTEM_USER)) {
            List<EnterpriseInfoBo> ebi = enterpriseService.findAllEnterprise();
            if (null != ebi && !ebi.isEmpty()) {
                for (EnterpriseInfoBo e : ebi) {
                    map.put(e.getEnterpriseId(), e.getEnterpriseName());
                }
            }
        }
        return map;
    }

    @ModelAttribute("logTypes")
    public Map<String, String> getLogTypes(HttpSession session) {
        Map<String, String> map = new HashMap<String, String>();
        List<SysCode> sysCodes = logService
                .getAllCodeBySystemNo(PropertyFileKeys.CODE_TYPE_CALL_BACK);
        if (null != sysCodes && !sysCodes.isEmpty()) {
            for (SysCode sc : sysCodes) {
                map.put(sc.getCodeNo(), sc.getCodeValue());
            }
        }
        return map;
    }

    @RequestMapping(value = "/logList", method = RequestMethod.GET)
    public ModelAndView logList(HttpServletRequest request, HttpSession session) {
        SysUser user = super.getSessionInfo(request.getSession()).getLoginUser();
        if(!user.getRoleNames().contains(Constant.SYSTEM_USER))
            return new ModelAndView("page/mgr/log_query");
        else
            return new ModelAndView("page/mgr/log_query_payegis");
    }

    @RequestMapping(value = "/logListPayEgis", method = RequestMethod.GET)
    public ModelAndView logListPayEgis(HttpServletRequest request,
                                       HttpSession session) {
        return new ModelAndView("page/mgr/log_query_payegis");
    }

    @RequestMapping(value = "/logSearch")
    public ModelAndView logSearch(SysLog sysLog, HttpServletRequest request,
                                  HttpSession session) {
        HashMap<String, Object> resMap = new HashMap<String, Object>();
        SysUser su = SessionUtil.getUser(session);
        String url = "page/mgr/log_query_list";
        if (null != su) {
            sysLog.setEnterpriseId(su.getEnterpriseId());
            sysLog.setOrder("DESC");
            ResultBean resBean = logService.listAll(sysLog);
            resMap.put("dataList", resBean.getRows());
            resMap.put("total", resBean.getTotal());
        }

        ModelAndView mav = new ModelAndView(url, resMap);
        return mav;
    }

    /*@RequestMapping(value = "/test", method = RequestMethod.GET)
    public ModelAndView test(HttpServletRequest request, HttpSession session) {
        HashMap<String, Object> resMap = new HashMap<String, Object>();
        String enterprise = request.getParameter("enterprise");
        String account = request.getParameter("account");
            resMap.put("enterprise",enterprise);
            resMap.put("account",account);
        return new ModelAndView("page/mgr/test",resMap);
    }*/

    @RequestMapping(value = "/logs", method = RequestMethod.GET)
    public ModelAndView logs(HttpServletRequest request, HttpSession session) {
        String requestTimeString = request.getParameter("x-hmac-auth-date");
        String oldSign = request.getParameter("x-hmac-auth-signature");
        if(null == requestTimeString)
            requestTimeString = request.getHeader("x-hmac-auth-date");
        if(null == oldSign)
            requestTimeString = request.getHeader("x-hmac-auth-signature");

        HashMap<String, String> parameter = new HashMap<String, String>();
        boolean isTrue = false;
        if(null != requestTimeString && null != oldSign)
            isTrue = EncryUtil.checkSign0(requestTimeString, parameter, oldSign, "de82967019906571ae879c460358e148");
        if (!isTrue) {
            request.setAttribute("errorMsg", "签名校验未通过！");
            return new ModelAndView("page/mgr/log_query_for_yunshan_error");
        }
        String enterprise = request.getParameter("enterprise");
        String account = request.getParameter("account");
        session.setAttribute("enterprise",enterprise);
        session.setAttribute("account",account);
        if(StringUtil.isEmpty(enterprise) && StringUtil.isEmpty(account)){
            request.setAttribute("errorMsg","参数不合法！");
            return new ModelAndView("page/mgr/log_query_for_yunshan_error");
        }
        return new ModelAndView("page/mgr/log_query_for_yunshan");
    }

    @RequestMapping(value = "/logsSearch")
    public ModelAndView logsSearch(SysLog sysLog, HttpServletRequest request,
                                   HttpSession session) {
        HashMap<String, Object> resMap = new HashMap<String, Object>();
        String enterprise = (String) session.getAttribute("enterprise");
        String account = (String) session.getAttribute("account");
        if(null != enterprise && StringUtil.isNotEmpty(enterprise.trim()))
            sysLog.setEnterpriseId(Integer.parseInt(enterprise));
        sysLog.setBindingAccount(account);
        String url = "page/mgr/log_query_list_for_yunshan";
        sysLog.setOrder("DESC");
        resMap.put("account", account);
        ResultBean resBean = logService.listAllLogs(sysLog);
        resMap.put("dataList", resBean.getRows());
        resMap.put("total", resBean.getTotal());
        ModelAndView mav = new ModelAndView(url, resMap);
        return mav;
    }

    @RequestMapping("/logSearch/export")
    public ModelAndView exportExcel(SysLog sysLog, HttpServletResponse response, Model model, HttpServletRequest request) {
        SysUser su = SessionUtil.getUser(request.getSession());
        sysLog.setEnterpriseId(su.getEnterpriseId());
        sysLog.setOrder("DESC");
        sysLog.setRows(0);
        ResultBean<SysLog> resBean = logService.listAll(sysLog);
        try {
            Workbook wb = new HSSFWorkbook();
            Sheet sheet = wb.createSheet();
            Row row = sheet.createRow(0);
            row.createCell(0).setCellValue("设备ID");
            row.createCell(1).setCellValue("业务系统");
            row.createCell(2).setCellValue("关联账号");
            row.createCell(3).setCellValue("日志类型");
            row.createCell(4).setCellValue("日志时间");

            Map<String, String> logTypes = (Map<String, String>) model.asMap().get("logTypes");
            Map<Integer, String> businessTypes = (Map<Integer, String>) model.asMap().get("businessTypes");
            long totalIndex = 1;
            int rowIndex = 0;
            for (SysLog log : resBean.getRows()) {
                if(totalIndex % 65535 == 0){
                    rowIndex = 1;
                    sheet = wb.createSheet();
                }else{
                    rowIndex = rowIndex + 1;
                }
                Row rowLoop = sheet.createRow(rowIndex);
                rowLoop.createCell(0).setCellValue(log.getDeviceId());
                rowLoop.createCell(1).setCellValue(businessTypes.get(log.getSystemId()));
                rowLoop.createCell(2).setCellValue(log.getBindingAccount());
                rowLoop.createCell(3).setCellValue(logTypes.get(log.getLogType()));
                rowLoop.createCell(4).setCellValue(log.getLogTime());
                totalIndex = totalIndex + 1;
            }

            String filename = "日志报表.xls";//设置下载时客户端Excel的名称
            filename = UserAgentUtil.encodeFileName(request, filename);//处理中文文件名
            response.setContentType("application/vnd.ms-excel");
            response.setHeader("Content-disposition", "attachment;" + filename);
            OutputStream ouputStream = response.getOutputStream();
            wb.write(ouputStream);
            ouputStream.flush();
            ouputStream.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    @RequestMapping(value = "/logSearchPayEgis")
    public ModelAndView logSearchPayEgis(SysLog sysLog,
                                         HttpServletRequest request, HttpSession session) {
        HashMap<String, Object> resMap = new HashMap<String, Object>();
        SysUser su = SessionUtil.getUser(session);
        String url = "page/mgr/log_query_list_payegis";
        if (null != su) {
            sysLog.setOrder("DESC");
            ResultBean resBean = logService.listAll(sysLog);
            resMap.put("dataList", resBean.getRows());
            resMap.put("total", resBean.getTotal());
        }

        ModelAndView mav = new ModelAndView(url, resMap);
        return mav;
    }

    @RequestMapping("/logSearchPayEgis/export")
    public ModelAndView exportPayEgisExcel(SysLog sysLog, HttpServletResponse response, Model model, HttpServletRequest request) {
        sysLog.setOrder("DESC");
        sysLog.setRows(0);
        ResultBean<SysLog> resBean = logService.listAll(sysLog);
        try {
            Workbook wb = new HSSFWorkbook();
            Sheet sheet = wb.createSheet();
            Row row = sheet.createRow(0);
            row.createCell(0).setCellValue("设备ID");
            row.createCell(1).setCellValue("业务系统");
            row.createCell(2).setCellValue("关联账号");
            row.createCell(3).setCellValue("日志类型");
            row.createCell(4).setCellValue("日志时间");
            row.createCell(5).setCellValue("所属企业");

            Map<String, String> logTypes = (Map<String, String>) model.asMap().get("logTypes");
            Map<Integer, String> businessTypes = (Map<Integer, String>) model.asMap().get("businessTypes");
            Map<Integer, String> enterpriseTypes = (Map<Integer, String>) model.asMap().get("enterpriseTypes");
            long totalIndex = 1;
            int rowIndex = 0;
            for (SysLog log : resBean.getRows()) {
                if(totalIndex % 65535 == 0){
                    rowIndex = 1;
                    sheet = wb.createSheet();
                }else{
                    rowIndex++;
                }
                Row rowLoop = sheet.createRow(rowIndex);
                rowLoop.createCell(0).setCellValue(log.getDeviceId());
                rowLoop.createCell(1).setCellValue(businessTypes.get(log.getSystemId()));
                rowLoop.createCell(2).setCellValue(log.getBindingAccount());
                rowLoop.createCell(3).setCellValue(logTypes.get(log.getLogType()));
                rowLoop.createCell(4).setCellValue(log.getLogTime());
                rowLoop.createCell(5).setCellValue(enterpriseTypes.get(log.getEnterpriseId()));
                totalIndex++;
            }

            String filename = "日志报表.xls";//设置下载时客户端Excel的名称
            filename = UserAgentUtil.encodeFileName(request, filename);//处理中文文件名
            response.setContentType("application/vnd.ms-excel");
            response.setHeader("Content-disposition", "attachment;" + filename);
            OutputStream ouputStream = response.getOutputStream();
            wb.write(ouputStream);
            ouputStream.flush();
            ouputStream.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    @RequestMapping(value = "/logReport/{deviceId}", method = RequestMethod.GET)
    public ModelAndView logReport(HttpServletRequest request,
                                  @PathVariable String deviceId) {
        HashMap<String, Object> resMap = new HashMap<String, Object>();
        resMap.put("deviceId", deviceId);
        ModelAndView mav = new ModelAndView("page/mgr/device_log_detail",
                resMap);
        return mav;
    }

    @RequestMapping(value = "/logAnalysis", method = RequestMethod.GET)
    public ModelAndView logAnalysis(HttpServletRequest request,
                                    HttpSession session) {
        return new ModelAndView("page/mgr/log_analysis");
    }

    @RequestMapping(value = "/logAnalysisPayEgis", method = RequestMethod.GET)
    public ModelAndView logAnalysisPayEgis(HttpServletRequest request,
                                           HttpSession session) {
        return new ModelAndView("page/mgr/log_analysis_payegis");
    }

    @RequestMapping(value = "/deviceLog", produces = {"application/json;charset=UTF-8"})
    public
    @ResponseBody
    net.sf.json.JSONObject devicelog(
            HttpServletRequest request, String deviceId, HttpSession session) {
        SysUser su = SessionUtil.getUser(session);
        if (!StringUtil.isEmptyStr(deviceId) && null != su) {
            SysLog log = new SysLog();
            log.setDeviceId(deviceId);
            if (!su.getEnterpriseNo().equals(PropertyFileKeys.ENTERPRISE_NO_PAYEGIS))
                log.setEnterpriseId(su.getEnterpriseId());
            List<Object> logs = logService.listAllRecordsOfEnterprise(log);
            return reportJson0(logs);
        }
        return null;
    }

    @RequestMapping(value = "/enterpriseDeviceLog", produces = {"application/json;charset=UTF-8"})
    public
    @ResponseBody
    net.sf.json.JSONObject enterpriseDeviceLog(
            HttpServletRequest request, HttpSession session,
            Integer enterpriseId) {
        SysUser su = SessionUtil.getUser(session);
        SysLog param = new SysLog();
        net.sf.json.JSONObject returnJsonObject = null;
        param.setEnterpriseId(su.getEnterpriseId());
        List<Object> logs = logService.listAllRecordsOfEnterprise(param);
        returnJsonObject = reportJson0(logs);
        return returnJsonObject;
    }

    @RequestMapping(value = "/enterpriseDeviceLogPayEgis", produces = {"application/json;charset=UTF-8"})
    public
    @ResponseBody
    net.sf.json.JSONObject enterpriseDeviceLogPayEgis(
            HttpServletRequest request, HttpSession session,
            Integer enterpriseId) {
        SysLog param = new SysLog();
        net.sf.json.JSONObject returnJsonObject = null;
        param.setEnterpriseId(enterpriseId);
        List<Object> logs = logService.listAllRecordsOfEnterprise(param);
        returnJsonObject = reportJson(logs);
        return returnJsonObject;
    }

    /**
     * 获取企业下的业务系统
     *
     * @param request
     * @return
     */
    @RequestMapping(value = "/getBusiness", method = RequestMethod.POST)
    @ResponseBody
    public String getBusiness(HttpServletRequest request, String enterpriseId) {
        JSONObject result = new JSONObject();
        try {
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("enterpriseId", enterpriseId);
            List<BusinessSystem> bsLst = logService
                    .getBusinessSystemByEnterpriseId(map);
            JSONArray data = new JSONArray();
            for (BusinessSystem bs : bsLst) {
                JSONObject o = new JSONObject();
                o.put("systemId", bs.getSystemId());
                o.put("systemName", bs.getSystemName());
                data.put(o);
            }
            result.put("data", data);
            result.put("status", "success");
        } catch (Exception e) {
        }
        return result.toString();
    }

    public net.sf.json.JSONObject reportJson(List<Object> logs) {
        net.sf.json.JSONObject returnJsonObject = null;
        if (ToolUtil.isNotEmpty(logs)) {
            returnJsonObject = new net.sf.json.JSONObject();
            Map<String, Map<String, Integer>> map = new HashMap<String, Map<String, Integer>>();
            Map<String, List<String>> lineData = null;
            Map<String, Integer> circleMap = new HashMap<String, Integer>();
            Map<String, Map<String, Integer>> barMap = new HashMap<String, Map<String, Integer>>();
            Map<String, List<Integer>> barData = null;
            List<String> lineAxis = new ArrayList<String>();
            String tempStr;
            List<SysCode> sysCodes = logService
                    .getAllCodeBySystemNo(PropertyFileKeys.CODE_TYPE_CALL_BACK);
            List<EnterpriseInfoBo> ebis = enterpriseService.findAllEnterprise();
            String enterpriseName;
            String lType;
            List<String> logTypesOrder = null;
            List<String> logTypeNamesOrder = null;
            List<String> keyValsLst = null;
            List<String> enterpriseKeysLst = null;
            for (Object obj : logs) {
                SysLog log = (SysLog) obj;
                enterpriseName = getEnterpriseName(ebis, log.getEnterpriseId());
                if (null == enterpriseName)
                    continue;
                if (null == barMap.get(enterpriseName)) {
                    barMap.put(enterpriseName, new HashMap<String, Integer>());
                }
                lType = getKeyType(sysCodes, log.getLogType());
                if (null == lType)
                    continue;
                Integer ct = barMap.get(enterpriseName).get(lType);
                ct = ct == null ? 1 : (ct + 1);
                barMap.get(enterpriseName).put(lType, ct);

                Integer total = barMap.get(enterpriseName).get("total");
                total = total == null ? 1 : (total + 1);
                barMap.get(enterpriseName).put("total", total);

                if (!StringUtil.isEmptyStr(log.getLogTime())) {
                    tempStr = log.getLogTime().substring(0, 10);
                    if (!lineAxis.contains(tempStr))
                        lineAxis.add(tempStr);
                    if (null == map.get(log.getLogType())) {
                        map.put(log.getLogType(),
                                new HashMap<String, Integer>());
                    }
                    Integer count = map.get(log.getLogType()).get(tempStr);
                    count = count == null ? 1 : (count + 1);
                    map.get(log.getLogType()).put(tempStr, count);
                }

                if (null != log.getLogType()
                        && null == circleMap.get(log.getLogType())) {
                    circleMap.put(log.getLogType(), 1);
                } else if (null != log.getLogType())
                    circleMap.put(log.getLogType(),
                            circleMap.get(log.getLogType()) + 1);
            }
            Set<String> logTypes = map.keySet();
            if (ToolUtil.isNotEmpty(lineAxis) && ToolUtil.isNotEmpty(logTypes)) {
                lineData = new HashMap<String, List<String>>();
                for (String time : lineAxis) {
                    for (String logType : logTypes) {
                        if (null == map.get(logType).get(time)) {
                            map.get(logType).put(time, 0);
                        }
                    }
                }

                List<String> ls = null;
                for (String logType : logTypes) {
                    ls = new ArrayList<String>();
                    for (String time : lineAxis) {
                        ls.add(String.valueOf(map.get(logType).get(time)));
                    }
                    lineData.put(logType, ls);
                }
            }
            Set<String> keys = circleMap.keySet();
            Set<String> keyVals = new HashSet<String>();
            JSONArray jarr = null;
            net.sf.json.JSONObject jo;
            if (ToolUtil.isNotEmpty(logTypes)) {
                logTypeNamesOrder = new ArrayList<String>();
                logTypesOrder = new ArrayList<String>(logTypes);
                for (String type : logTypesOrder) {
                    String lgtype = getKeyType(sysCodes, type);
                    if (null != lgtype)
                        logTypeNamesOrder.add(lgtype);
                }
            }
            if (ToolUtil.isNotEmpty(keys)) {
                jarr = new JSONArray();
                for (String key : keys) {
                    String keyVal = getKeyType(sysCodes, key);
                    if (null != keyVal)
                        keyVals.add(keyVal);
                    if (null != keyVal) {
                        jo = new net.sf.json.JSONObject();
                        jo.put("value", circleMap.get(key));
                        jo.put("name", keyVal);
                        jarr.put(jo);
                    }
                }
                if (ToolUtil.isNotEmpty(keyVals)) {
                    keyValsLst = new ArrayList<String>(keyVals);
                    Collections.sort(keyValsLst);
                    Set<String> enterpriseKeys = barMap.keySet();
                    if (ToolUtil.isNotEmpty(enterpriseKeys)) {
                        enterpriseKeysLst = new ArrayList<String>(
                                enterpriseKeys);
                        // 按照企业活跃度排序
                        for (int i = 0; i < enterpriseKeysLst.size(); i++) {
                            for (int j = i + 1; j < enterpriseKeysLst.size(); j++) {
                                if (barMap.get(enterpriseKeysLst.get(i)).get(
                                        "total") > barMap.get(
                                        enterpriseKeysLst.get(j)).get("total")) {
                                    String temp = enterpriseKeysLst.get(i);
                                    enterpriseKeysLst.set(i,
                                            enterpriseKeysLst.get(j));
                                    enterpriseKeysLst.set(j, temp);
                                }
                            }
                        }

                        List<Integer> tempList;
                        barData = new HashMap<String, List<Integer>>();
                        for (String logType : keyValsLst) {
                            tempList = new ArrayList<Integer>();
                            for (String enterpriseId : enterpriseKeysLst) {
                                if (null != barMap.get(enterpriseId)
                                        && null != barMap.get(enterpriseId)
                                        .get(logType))
                                    tempList.add(barMap.get(enterpriseId).get(
                                            logType));
                                else
                                    tempList.add(0);
                            }
                            barData.put(logType, tempList);
                        }
                    }
                }

            }
            returnJsonObject = new net.sf.json.JSONObject();

            returnJsonObject.put("lineData", lineData);
            returnJsonObject.put("lineAxis", lineAxis);
            returnJsonObject.element("circleData", jarr.toString());
            returnJsonObject.put("circleAxis", keyValsLst);
            returnJsonObject.put("enterprise", enterpriseKeysLst);
            returnJsonObject.put("barData", barData);
            returnJsonObject.put("logTypeNames", logTypeNamesOrder);
            returnJsonObject.put("logTypes", logTypesOrder);
        }

        return returnJsonObject;
    }

    public net.sf.json.JSONObject reportJson0(List<Object> logs) {
        net.sf.json.JSONObject returnJsonObject = null;
        if (ToolUtil.isNotEmpty(logs)) {
            returnJsonObject = new net.sf.json.JSONObject();
            Map<String, Map<String, Integer>> map = new HashMap<String, Map<String, Integer>>();
            Map<String, List<String>> returnVal = null;
            List<String> axis = new ArrayList<String>();
            List<String> logTypesOrder = null;
            List<String> logTypeNamesOrder = null;
            String tempStr;
            List<SysCode> sysCodes = logService
                    .getAllCodeBySystemNo(PropertyFileKeys.CODE_TYPE_CALL_BACK);
            String lType;
            for (Object obj : logs) {
                SysLog log = (SysLog) obj;
                lType = getKeyType(sysCodes, log.getLogType());
                if (null == lType)
                    continue;
                if (!StringUtil.isEmptyStr(log.getLogTime())) {
                    tempStr = log.getLogTime().substring(0, 10);
                    if (!axis.contains(tempStr))
                        axis.add(tempStr);
                    if (null == map.get(log.getLogType())) {
                        map.put(log.getLogType(),
                                new HashMap<String, Integer>());
                    }
                    Integer count = map.get(log.getLogType()).get(tempStr);
                    count = count == null ? 1 : (count + 1);
                    map.get(log.getLogType()).put(tempStr, count);

                }
            }
            Set<String> logTypes = map.keySet();
            if (ToolUtil.isNotEmpty(axis) && ToolUtil.isNotEmpty(logTypes)) {
                List<String> ls = null;
                returnVal = new HashMap<String, List<String>>();
                for (String time : axis) {
                    for (String logType : logTypes) {
                        if (null == map.get(logType).get(time)) {
                            map.get(logType).put(time, 0);
                        }
                    }
                }
                for (String logType : logTypes) {
                    ls = new ArrayList<String>();
                    for (String time : axis) {
                        ls.add(String.valueOf(map.get(logType).get(time)));
                    }
                    returnVal.put(logType, ls);
                }
            }
            if (ToolUtil.isNotEmpty(logTypes)) {
                logTypesOrder = new ArrayList<String>(logTypes);
                logTypeNamesOrder = new ArrayList<String>();
                for (String type : logTypesOrder) {
                    String lgtype = getKeyType(sysCodes, type);
                    if (null != lgtype)
                        logTypeNamesOrder.add(lgtype);
                }
            }
            returnJsonObject = new net.sf.json.JSONObject();
            returnJsonObject.put("lineData", returnVal);
            returnJsonObject.put("lineAxis", axis);
            returnJsonObject.put("logTypes", logTypesOrder);
            returnJsonObject.put("logTypeNames", logTypeNamesOrder);

        }

        return returnJsonObject;
    }

    private String getKeyType(List<SysCode> sysCodes, String key) {
        if (null != sysCodes && sysCodes.size() > 0 && null != key) {
            for (SysCode sc : sysCodes) {
                if (sc.getCodeNo().equals(key))
                    return sc.getCodeValue();
            }
        }
        return null;
    }

    private String getEnterpriseName(List<EnterpriseInfoBo> ebis,
                                     Integer enterpriseId) {
        if (null != ebis && ebis.size() > 0 && null != enterpriseId) {
            for (EnterpriseInfoBo eb : ebis) {
                if (eb.getEnterpriseId().equals(enterpriseId))
                    return eb.getEnterpriseName();
            }
        }
        return null;
    }

}
