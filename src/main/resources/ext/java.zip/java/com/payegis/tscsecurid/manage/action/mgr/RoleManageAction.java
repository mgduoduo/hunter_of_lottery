package com.payegis.tscsecurid.manage.action.mgr;


import com.payegis.tscsecurid.common.constant.PropertyFileKeys;
import com.payegis.tscsecurid.common.data.entity.MgrPrivilege;
import com.payegis.tscsecurid.common.data.entity.MgrRole;
import com.payegis.tscsecurid.common.data.entity.SysUser;
import com.payegis.tscsecurid.common.result.ResultBean;
import com.payegis.tscsecurid.common.util.DateUtil;
import com.payegis.tscsecurid.manage.action.customer.ManageBaseAction;
import com.payegis.tscsecurid.manage.bean.RoleBean;
import com.payegis.tscsecurid.manage.common.Constant;
import com.payegis.tscsecurid.manage.common.ManageException;
import com.payegis.tscsecurid.manage.service.business.mgr.PrivilegeService;
import com.payegis.tscsecurid.manage.service.business.mgr.RoleService;
import com.payegis.tscsecurid.manage.util.SessionUtil;

import net.sf.json.JSONObject;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * uaer manager controller
 * 
 * @author xuman.xu
 * 
 */
@Controller
@RequestMapping("/role")
public class RoleManageAction extends ManageBaseAction {

	private static Logger logger = Logger.getLogger(RoleManageAction.class);

	@Autowired
	private RoleService roleService;

	@Autowired
	private PrivilegeService privilegeService;

    @RequestMapping(value = "/list", method = RequestMethod.GET)
    public ModelAndView receivables(
            HttpServletRequest request) {
        ModelAndView mav = new ModelAndView("page/mgr/role_receivables");
        return mav;
    }

    @RequestMapping(value = "/roleSearch")
    public ModelAndView search(MgrRole oiqb,
                               HttpServletRequest request) {
        HashMap<String, Object> resMap = new HashMap<String, Object>();
        SysUser user = super.getSessionInfo(request.getSession()).getLoginUser();
        if(!user.getRoleNames().contains(Constant.SYSTEM_USER))
            oiqb.setEnterpriseId(user.getEnterpriseId());
        ResultBean resBean = roleService.getPageList(oiqb);
        resMap.put("dataList", resBean.getRows());
        resMap.put("total", resBean.getTotal());
        resMap.put("processType", "receivables");
        ModelAndView mav = new ModelAndView("page/mgr/role_query_list", resMap);
        return mav;
    }

	@RequestMapping(value = "/addrole")
	public ModelAndView toAddRole(HttpServletRequest request) {
		ModelAndView mav = new ModelAndView("page/mgr/addrole");
		mav.addObject(new RoleBean());
		MgrPrivilege privilege = new MgrPrivilege();
		SysUser sysUser = super.getSessionInfo(request.getSession()).getLoginUser();
        if (null != sysUser && !PropertyFileKeys.ENTERPRISE_NO_PAYEGIS.equals(sysUser.getEnterpriseNo())) {
        	privilege.setIsEnterpriseShare("Y");
        }
		mav.addObject("privilege", preparePrivilege(privilegeService.FindAllPrivilegeForEnterprise(privilege)));
		return mav;
	}

	@RequestMapping(value = "/updaterole/{roleId}")
	public ModelAndView toUpdateRole(@PathVariable String roleId,HttpServletRequest request) {
		ModelAndView mav = new ModelAndView("page/mgr/updaterole");
		mav.addObject(roleService.findRole(roleId));
		MgrPrivilege privilege = new MgrPrivilege();
		SysUser sysUser = super.getSessionInfo(request.getSession()).getLoginUser();
        if (null != sysUser && !PropertyFileKeys.ENTERPRISE_NO_PAYEGIS.equals(sysUser.getEnterpriseNo())) {
        	privilege.setIsEnterpriseShare("Y");
        }
		mav.addObject("privilege", preparePrivilege(privilegeService.FindAllPrivilegeForEnterprise(privilege)));
		return mav;
	}
	
	private List<MgrPrivilege> preparePrivilege(List<MgrPrivilege> privileges){
		List<MgrPrivilege> privilegeGroup = new ArrayList<MgrPrivilege>();
		Map<String,List<MgrPrivilege>> map = new HashMap<String,List<MgrPrivilege>>();
		for(MgrPrivilege p:privileges){
			if(null!=p.getParentId()&&
					p.getParentId().length()>0&&
					!p.getParentId().equals("-1")){
				List<MgrPrivilege> list = map.get(p.getParentId());
				if(null==list){
					list = new ArrayList<MgrPrivilege>();
					map.put(p.getParentId(), list);
				}
				list.add(p);
			}else{
				privilegeGroup.add(p);
			}
		}
		
		for(MgrPrivilege p:privilegeGroup){
			List<MgrPrivilege> subPrivileges = map.get(p.getPrivilegeId());
			if(null!=subPrivileges){
				p.getSubPrivilege().addAll(subPrivileges);
			}
		}
		
		return privilegeGroup;
	}

	@RequestMapping(value = "/dosaverole")
	public ModelAndView saveUser(@ModelAttribute RoleBean roleBean,
			BindingResult result, HttpServletRequest request,
			HttpServletResponse response) {
		ModelAndView mav = new ModelAndView();
		boolean pass = true;
//		if (roleBean.getRoleId() == null
//				|| roleBean.getRoleId().trim().equals("")
//				|| roleBean.getRoleId().length() < 1
//				|| roleBean.getRoleId().length() > 50) {
//			result.rejectValue("roleId", "???", "角色标识必须为1-50");
//			pass = false;
//		} else {
//			if (roleService.findRoleById(roleBean.getRoleId()) !=null) {
//				result.rejectValue("roleId", "???", "角色标识已经存在");
//				pass = false;
//			}
//		}
		if (roleBean.getRoleName() == null
				|| roleBean.getRoleName().trim().equals("")
				|| roleBean.getRoleName().length() > 50) {
			result.rejectValue("roleName", "???", "角色名称长度不能为空且长度不能超过50");
			pass = false;
		}
		if (roleBean.getPrivilegeIds() == null
				|| roleBean.getPrivilegeIds().trim().equals("")) {
			result.rejectValue("privilegeIds", "???", "角色至少拥有一个权限");
			pass = false;
		}
		if (pass) {
			try {
				MgrRole role = new MgrRole();
				role.setRoleId(UUID.randomUUID().toString().replaceAll("-", ""));
				role.setRoleName(roleBean.getRoleName());
                role.setCreateTime(DateUtil.getCurrentDateString());
                role.setCreator(getCurretnUserName(request));
                SysUser sysUser = super.getSessionInfo(request.getSession()).getLoginUser();
                if (null != sysUser) {
                	role.setEnterpriseId(sysUser.getEnterpriseId());
                }
				roleService.saveRole(role, roleBean.getPrivilegeIds());
				RedirectView rv = new RedirectView("list");
				mav = new ModelAndView(rv, getMessage(MESSAGE_TYPE_SUCCESS,
						SUCCESS_OPERATION, request));
			} catch (Exception e) {
				logger.warn("exception when save role.", e);
				setMessage(MESSAGE_TYPE_EXCEPTION, e.getMessage(), request);
				RedirectView rv = new RedirectView("list");
				mav = new ModelAndView(rv, getMessage(MESSAGE_TYPE_ERROR,
						FAILED_OPERATION, request));
			}

		} else {
			mav.addObject(roleBean);
			mav.setViewName("page/mgr/addrole");
		}
		return mav;
	}

	@RequestMapping(value = "/doupdaterole")
	public ModelAndView updateRole(@ModelAttribute RoleBean roleBean,
			BindingResult result, HttpServletRequest request,
			HttpServletResponse response) {
		ModelAndView mav = new ModelAndView();
		boolean pass = true;
		if (roleBean.getRoleId() == null
				|| roleBean.getRoleId().trim().equals("")
				|| roleBean.getRoleId().length() < 1
				|| roleBean.getRoleId().length() > 50) {
			result.rejectValue("roleId", "???", "角色标识必须为1-50");
			pass = false;
		}
		if (roleBean.getRoleName() == null
				|| roleBean.getRoleName().trim().equals("")
				|| roleBean.getRoleName().length() > 50) {
			result.rejectValue("roleName", "???", "角色名称长度不能为空且长度不能超过50");
			pass = false;
		}
		if (roleBean.getPrivilegeIds() == null
				|| roleBean.getPrivilegeIds().trim().equals("")) {
			result.rejectValue("privilegeIds", "???", "角色至少拥有一个权限");
			pass = false;
		}
		if (pass) {
			try {
				MgrRole role = roleService.findRoleById(roleBean.getRoleId());
				SysUser sysUser = super.getSessionInfo(request.getSession()).getLoginUser();
                if (null != sysUser) {
                	role.setEnterpriseId(sysUser.getEnterpriseId());
                }
				role.setRoleName(roleBean.getRoleName());
				role.setUpdater(SessionUtil.getLoginName(request));
                role.setUpdateTime(DateUtil.getCurrentDateString());
				roleService.updateRoler(role, roleBean.getPrivilegeIds());
				RedirectView rv = new RedirectView("list");
				mav = new ModelAndView(rv, getMessage(MESSAGE_TYPE_SUCCESS,
						SUCCESS_OPERATION, request));
			} catch (Exception e) {
				logger.warn("exception when update role.", e);
				RedirectView rv = new RedirectView("list");
				mav = new ModelAndView(rv, getMessage(MESSAGE_TYPE_ERROR,
						FAILED_OPERATION, request));
			}

		} else {
			mav.addObject(roleBean);
			mav.setViewName("page/mgr/updaterole");
		}
		return mav;
	}

	@RequestMapping(value = "checkroleid", method = RequestMethod.POST)
	@ResponseBody
	public String checkUserid(String roleid) {
		JSONObject json = new JSONObject();
		if (roleService.findRoleById(roleid)!=null) {
			json.put("status", "1");
			json.put("data", "");
		} else {
			json.put("status", "0");
			json.put("data", "");
		}
		return json.toString();
	}

	@RequestMapping(value = "deleteRole/{roleId}")
	public ModelAndView deleteRole(HttpServletRequest request,
                                   @PathVariable String roleId,
			HttpServletResponse response) {
		ModelAndView mav = new ModelAndView();
		try {
			roleService.deleteRole(roleId);
			mav = new ModelAndView("redirect:/role/list", getMessage(MESSAGE_TYPE_SUCCESS,
					SUCCESS_OPERATION, request));
		} catch(ManageException he){
            mav = new ModelAndView("redirect:/role/list", getMessage(MESSAGE_TYPE_ERROR,
                    he.getErrorCode(), request));
        }catch (Exception e) {
			mav = new ModelAndView("redirect:/role/list", getMessage(MESSAGE_TYPE_ERROR,
					FAILED_OPERATION, request));
		}
		return mav;
	}
}