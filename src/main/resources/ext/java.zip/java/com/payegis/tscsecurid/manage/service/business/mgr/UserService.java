package com.payegis.tscsecurid.manage.service.business.mgr;


import com.payegis.tscsecurid.common.data.entity.SysUser;
import com.payegis.tscsecurid.common.service.BaseService;
import com.payegis.tscsecurid.manage.bean.UserBean;


public interface UserService extends BaseService {
	public void saveUser(SysUser user, String roleIds);

	public void updateUserWithRole(SysUser user, String roleIds);

	public Integer findUsersize(String userId);

	public UserBean findUser(String userId);

	public SysUser findUserById(String userId);
	
	public SysUser findUserByLoginName(String loginName);

    public void updateUser(SysUser user);

    public void deleteUser(String suerId);
}
