package com.payegis.tscsecurid.manage.service.impl.version;

import com.payegis.tscsecurid.common.data.entity.SysUser;
import com.payegis.tscsecurid.common.data.entity.VersionManage;
import com.payegis.tscsecurid.common.mapper.VersionManageMapper;
import com.payegis.tscsecurid.common.result.ResultBean;
import com.payegis.tscsecurid.common.util.DateUtil;
import com.payegis.tscsecurid.common.util.FileUtils;
import com.payegis.tscsecurid.common.util.StringUtil;
import com.payegis.tscsecurid.manage.common.Constant;
import com.payegis.tscsecurid.manage.common.MessageConstant;
import com.payegis.tscsecurid.manage.service.business.version.VersionService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;

/**
 * Created by zzg on 2014/12/9.
 */
@Service
public class VersionServiceImpl implements VersionService, MessageConstant {

    @Autowired
    private VersionManageMapper versionManageMapper;

    @Autowired
    FileUtils fileUtils;

    @Override
    public ResultBean listAll(VersionManage param) {
        ResultBean result = new ResultBean();
        result.setRows(versionManageMapper.listAll(param));
        result.setTotal(versionManageMapper.count(param));
        return result;
    }

    @Override
    public int save(VersionManage param, SysUser su) {
        String filePath = fileUtils.saveVersionFile(param.getVersionNo(),param.getVersionType(),param.getVersionFile());
        if(StringUtil.isEmptyStr(filePath))
            return -1;
        param.setFilePath(filePath);
        param.setCreateTime(DateUtil.getCurrentDateString());
        param.setAddUserId(su.getUserId());
        long size = Long.parseLong(param.getVersionFile().getSize() + "");
        BigDecimal filesize = new BigDecimal(size);
        BigDecimal megabyte = new BigDecimal(1024 * 1024);
        float returnValue = filesize.divide(megabyte, 2, BigDecimal.ROUND_UP)
                .floatValue();
        if (returnValue >= 0)
            param.setFileSize(returnValue + "MB");
        if (param.getPublishState().equals(Constant.PUBLISH_STATE_ON))
            param.setPublishTime(DateUtil.getCurrentDateString());
        int res = versionManageMapper.insertSelective(param);
        if(res >= 0 && param.getPublishState().equals(Constant.PUBLISH_STATE_ON)){
            versionManageMapper.updatePublishStateOff(param);
        }
        return res;
    }

    @Override
    public int update(VersionManage param, SysUser su) {
        if(null != param.getVersionFile() && !param.getVersionFile().isEmpty() ){
            String filePath = fileUtils.saveVersionFile(param.getVersionNo(),param.getVersionType(),param.getVersionFile());
            if(StringUtil.isEmptyStr(filePath))
                return -1;
            param.setFilePath(filePath);
            long size = Long.parseLong(param.getVersionFile().getSize() + "");
            BigDecimal filesize = new BigDecimal(size);
            BigDecimal megabyte = new BigDecimal(1024 * 1024);
            float returnValue = filesize.divide(megabyte, 2, BigDecimal.ROUND_UP)
                    .floatValue();
            if (returnValue >= 0)
                param.setFileSize(returnValue + "MB");
        }

        param.setEditTime(DateUtil.getCurrentDateString());
        param.setEditUserId(su.getUserId());
        VersionManage old = versionManageMapper.selectByPrimaryKey(param.getVersionId());
        if (!param.getPublishState().equals(Constant.PUBLISH_STATE_ON)) {
            param.setPublishTime("");
        }else if(StringUtils.isEmpty(old.getPublishTime())){
            param.setPublishTime(DateUtil.getCurrentDateString());
        }
        int res = versionManageMapper.updateByPrimaryKeySelective(param);
        if(res >= 0 && param.getPublishState().equals(Constant.PUBLISH_STATE_ON)){
            versionManageMapper.updatePublishStateOff(param);
        }
        return res;
    }

    @Override
    public VersionManage findById(Integer versionId) {
        return versionManageMapper.selectByPrimaryKey(versionId);
    }

    @Override
    public int findByVersionNoAndType(VersionManage param) {
        return versionManageMapper.findByVersionNoAndType(param);
    }
}
