package com.payegis.tscsecurid.manage.action.system;

import com.payegis.tscsecurid.common.constant.PropertyFileKeys;
import com.payegis.tscsecurid.common.data.bo.*;
import com.payegis.tscsecurid.common.data.entity.*;
import com.payegis.tscsecurid.common.result.ResultBean;
import com.payegis.tscsecurid.common.util.DateUtil;
import com.payegis.tscsecurid.common.util.PropertyUtil;
import com.payegis.tscsecurid.manage.common.Constant;
import com.payegis.tscsecurid.manage.service.business.strategy.StrategyService;
import com.payegis.tscsecurid.manage.service.business.system.SystemConfigService;
import com.payegis.tscsecurid.manage.service.business.system.SystemTxnService;
import com.payegis.tscsecurid.manage.util.SessionUtil;
import com.payegis.tscsecurid.manage.util.WSUtil;
import net.sf.json.JSONObject;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by liucheng on 2014/11/6.
 */
@Controller
@RequestMapping("/system")
public class SystemConfigAction {

    private static final Logger logger = Logger.getLogger(SystemConfigAction.class);

    private static final String[] SUFFIX_ARRAY = {"jpg", "jpeg", "gif", "png"};

    @Autowired
    SystemConfigService configService;

    @Autowired
    private StrategyService strategyService;

    @Autowired
    private SystemTxnService systemTxnService;

    @ModelAttribute("useEnvs")
    public List<SysCode> getUserEnvs(HttpSession session) {
        Object object = session.getAttribute("useEnvs");
        if (object == null) {
            List<SysCode> sysCodes = configService.getSysCodeByCodeNo(PropertyFileKeys.CODE_TYPE_USE_ENV);
            session.setAttribute("useEnvs",sysCodes);
            return sysCodes;
        } else {
            return (List<SysCode>) object;
        }

    }

    @ModelAttribute("callbackTypes")
    public List<SysCode> getCallbackType(HttpSession session) {
        Object object = session.getAttribute("callbackTypes");
        if (object == null) {
            List<SysCode> sysCodes = configService.getSysCodeByCodeNo(PropertyFileKeys.CODE_TYPE_CALL_BACK);
            session.setAttribute("callbackTypes",sysCodes);
            return sysCodes;
        } else {
            return (List<SysCode>) object;
        }
    }

    @ModelAttribute("statusList")
    public Map<String, String> getStatusList(HttpSession session) {
        Map<String, String> map = new HashMap<String, String>();
        map.put("W", "等待用户确认");
        map.put("R", "交易被用户拒绝");
        map.put("F", "校验失败");
        map.put("S", "交易成功");
        return map;
    }

    @ModelAttribute("EnterpriseInfoList")
    public Map<String, String> getEnterpriseInfo(HttpSession session) {
        SysUser su = SessionUtil.getUser(session);
        Map<String, String> map = new HashMap<String, String>();
        if (null != su) {
            List<EnterpriseInfoBo> bos = systemTxnService.findAllEnterprise();
            if (null != bos && !bos.isEmpty()) {
                for (EnterpriseInfoBo b : bos) {
                    map.put(String.valueOf(b.getEnterpriseId()), b.getEnterpriseName());
                }
            }
        }
        return map;
    }

    @ModelAttribute("deviceTerminal")
    public List<SysCode> getDeviceTerminal(HttpSession session) {
        Object object = session.getAttribute("deviceTerminal");
        if (object == null) {
            List<SysCode> sysCodes = configService.getSysCodeByCodeNo(PropertyFileKeys.CODE_TYPE_DEVICE_TERMINAL);
            session.setAttribute("deviceTerminal",sysCodes);
            return sysCodes;
        } else {
            return (List<SysCode>) object;
        }

    }


    @RequestMapping(value = "/config", method = RequestMethod.GET)
    public String showConfig(Model model, HttpSession session) {
        SysUser user = SessionUtil.getUser(session);
        final SysEnterpriseConfig config = configService.getSystemEnterpriseConfig(user.getEnterpriseId());
        model.addAttribute("config", config);
        return "page/system/systemConfig";
    }

    @RequestMapping(value = "/config", method = RequestMethod.POST)
    public String saveConfig(@Valid SysEnterpriseConfigBo configBo, Model model, HttpSession session,

                             RedirectAttributes redirectAttributes) {
        boolean valid = true;
        /*if (!isValidSuffix(configBo.getBackground().getOriginalFilename())) {
            valid = false;
            model.addAttribute("backgroundError", "文件类型不正确");
        }
        if (!isValidSuffix(configBo.getLogo().getOriginalFilename())) {
            valid = false;
            model.addAttribute("logoError", "文件类型不正确");
        }
        if (!valid) {
            return "page/system/systemConfig";
        }*/
        SysUser user = SessionUtil.getUser(session);
        if (configBo.getEnterpriseConfigId() != null) {
            configBo.setEditUserId(user.getUserId() + "");
            configBo.setEditTime(DateUtil.getCurrentDateString());
        } else {
            configBo.setEnterpriseId(user.getEnterpriseId());
            configBo.setAddUserId(user.getUserId() + "");
            configBo.setCreateTime(DateUtil.getCurrentDateString());
            configBo.setEditUserId(user.getUserId() + "");
            configBo.setEditTime(DateUtil.getCurrentDateString());
        }
        configService.saveConfig(configBo);
        redirectAttributes.addFlashAttribute("info", "保存成功");
        return "redirect:/system/config";
    }


    @RequestMapping(value = "/aboutUs", method = RequestMethod.GET)
    public String aboutUs(Model model,HttpSession session) {
        model.addAttribute("user", SessionUtil.getUser(session));
        return "page/system/aboutUs";
    }

    @RequestMapping(value = "/aboutUs", method = RequestMethod.POST)
    public String suggestion(FeedbackInfo feedbackInfo,Model model,RedirectAttributes redirectAttributes) {
        feedbackInfo.setFeedbackTime(DateUtil.getCurrentDateString());
        configService.saveFeedBackInfo(feedbackInfo);
        redirectAttributes.addFlashAttribute("info", "提交成功");
        return "redirect:/system/aboutUs";
    }

    private boolean isValidSuffix(String originalFilename) {
//        boolean result = true;
        for (String s : SUFFIX_ARRAY) {
            if (originalFilename.toLowerCase().endsWith(s)) {
                return true;
            }
        }
        return false;
    }

    @ModelAttribute("callBackTypes")
    public List<SysCode> getCallBackTypes(HttpSession session) {
        Object object = session.getAttribute("callBackTypes");
        if (object == null) {
            List<SysCode> sysCodes = configService.getCallBackTypes();
            session.setAttribute("callBackTypes",sysCodes);
            return sysCodes;
        } else {
            return (List<SysCode>) object;
        }
    }



    @RequestMapping(value = "/business", method = RequestMethod.GET)
    public String showBusinessSystem(@RequestParam(required = false) String businessName,Model model,HttpSession session) {
//        Integer enterpriseId = SessionUtil.getUser(session).getEnterpriseId();
//        final String enterpriseNo = "";
//        List<BusinessSystemBo> businessSystems =  configService.searchBusinessSystem(businessName,enterpriseNo,enterpriseId);
//        model.addAttribute("businessSystems", businessSystems);
//        model.addAttribute("businessName", businessName);
//        model.addAttribute("total", businessSystems!=null?businessSystems.size():0);
        return "page/system/business";
    }

    @RequestMapping(value = "/search/searchBusiness")
    public String searchBusinessSystem(BindInfoQueryBo queryBo, Model model, HttpSession session) {

        SysUser loginUser = SessionUtil.getUser(session);
        if (!PropertyFileKeys.ENTERPRISE_NO_PAYEGIS.equals(loginUser.getEnterpriseNo())) {
            queryBo.setEnterpriseId(loginUser.getEnterpriseId());
        }
        logger.info("[param] systemName="+queryBo.getSystemName());
        ResultBean resBean = configService.getPageList(queryBo);
        model.addAttribute("result", resBean);
        return "page/system/business_list";
    }

    @RequestMapping(value = "/business/create", method = RequestMethod.GET)
    public String showCreateBusinessSystem(Model model,HttpSession session) {
        Integer enterpriseId = SessionUtil.getUser(session).getEnterpriseId();
        model.addAttribute("enterpriseId", enterpriseId);
        return "page/system/business_add";
    }

    @RequestMapping(value = "/business/create", method = RequestMethod.POST)
    public String createBusinessSystem(BusinessSystemBo businessSystemBo, StrategyConfig strategyConfig, Model model,HttpSession session,
                                       RedirectAttributes redirectAttributes) {
        SysUser user = SessionUtil.getUser(session);
        configService.createBusinessSystem(businessSystemBo,strategyConfig, user);
        redirectAttributes.addFlashAttribute("info", "新增成功");
        return "redirect:/system/business";
    }


    @RequestMapping(value = "/business/update/{id}", method = RequestMethod.GET)
    public String showUpdateBusinessSystem(@PathVariable Integer id, Model model) {
        BusinessSystemBo businessSystemBo = configService.selectBusinessSystemBoById(id);
        model.addAttribute("businessSystemBo", businessSystemBo);
        if(businessSystemBo!=null && StringUtils.isNotBlank(businessSystemBo.getSystemNo())){
            StrategyConfig strategyConfig = strategyService.findObjBySystemNo(businessSystemBo.getSystemNo());
            model.addAttribute("strategyConfig", strategyConfig);
        }
        return "page/system/business_update";
    }

    @RequestMapping(value = "/business/update/{id}", method = RequestMethod.POST)
    public String updateBusinessSystem(BusinessSystemBo businessSystemBo, StrategyConfig strategyConfig, Model model,HttpSession session,
                                       RedirectAttributes redirectAttributes) {
        strategyService.update(strategyConfig);
        configService.updateBusinessSystem(businessSystemBo, SessionUtil.getUser(session));
        redirectAttributes.addFlashAttribute("info", "操作成功");
        return "redirect:/system/business";
    }

    @RequestMapping(value = "/business/delete/{id}", method = RequestMethod.GET)
    public String deleteBusinessSystem(@PathVariable Integer id,HttpSession session,
                                       RedirectAttributes redirectAttributes) {

//        model.addAttribute("businessSystemBo", businessSystemBo);
        Integer count = configService.deleteBusinessSystem(id);
        if (count == 1) {
            redirectAttributes.addFlashAttribute("info", "操作成功");
        } else {
            redirectAttributes.addFlashAttribute("error", "当前业务系统已存在关联数据，无法删除!");
        }
        return "redirect:/system/business";
    }

    @RequestMapping(value = "/business/updateSecIdenConfig/{id}_{type}", method = RequestMethod.GET)
    public String updateSecIdenConfig(@PathVariable Integer id, @PathVariable Integer type, RedirectAttributes redirectAttributes) {
        if(id==null || type==null || (type!=null && type!=1 && type!=0)){
            redirectAttributes.addFlashAttribute("error", "参数异常");
            return "redirect:/system/business";
        }
        BusinessSystemBo bo = configService.selectBusinessSystemBoById(id);
        if(bo == null){
            redirectAttributes.addFlashAttribute("error", "业务系统不存在");
            return "redirect:/system/business";
        }
        StrategyConfig config = new StrategyConfig();
        config.setSystemNo(bo.getSystemNo());
        config.setIsOpenSecIden(""+type);
        int count = strategyService.updateSecIden(config);
        if (count >= 1) {
            redirectAttributes.addFlashAttribute("info", "修改成功");
        } else {
            redirectAttributes.addFlashAttribute("error", "修改失败");
        }
        return "redirect:/system/business";
    }

    @RequestMapping(value = "/business/showServiceSpecInfo/{serviceId}_{appId}_{id}", method = RequestMethod.GET)
    public String showServiceSpecInfo(@PathVariable Integer appId,
                                      @PathVariable Integer serviceId,
                                      @PathVariable Integer id,
                                      RedirectAttributes redirectAttributes,
                                      Model model,
                                      HttpSession session) {

        //获取服务规格信息
        Map<String, Object> paramMap = new HashMap<String, Object>();
        paramMap.put("appId",appId);
        paramMap.put("serviceId",serviceId);
        String result = WSUtil.sendRequest(PropertyUtil.getPropertyValue("config.properties", "egiscloud.web.api.url") + "/rest/core/appServiceSepDetail", paramMap);

        if (StringUtils.isEmpty(result) || !Constant.SUCCESS_STATUS.equals(JSONObject.fromObject(result).getString("status"))) {
//            redirectAttributes.addFlashAttribute("error", "没有相关数据!");
//            return "redirect:/system/business";
            return "page/system/serviceSpecDetail";
        }
        BusinessSystemBo businessSystemBo = configService.selectBusinessSystemBoById(id);
        model.addAttribute("businessSystemBo", businessSystemBo);

        JSONObject jsonObject = JSONObject.fromObject(JSONObject.fromObject(result).get("data"));

        logger.info("~~~~~app service specification detail~~~~~~~~:"+jsonObject.toString());
        //app detail
        model.addAttribute("appName", jsonObject.get("appName"));
        model.addAttribute("appVersion", jsonObject.get("appVersion"));
        model.addAttribute("appPackageName", jsonObject.get("appPackageName"));
        model.addAttribute("appCreateTime", jsonObject.get("appCreateTime"));
        model.addAttribute("appUpdateTime", jsonObject.get("appUpdateTime"));
        //service specification detail
        model.addAttribute("serviceName", jsonObject.get("serviceName"));
        model.addAttribute("serviceSpecificationName", jsonObject.get("serviceSpecificationName"));
        model.addAttribute("purchaseTime", jsonObject.get("purchaseTime"));
        model.addAttribute("openTime", jsonObject.get("openTime"));
        model.addAttribute("closeTime", jsonObject.get("closeTime"));
        model.addAttribute("purchaseAmount", jsonObject.get("purchaseAmount"));
        model.addAttribute("usedAmount", jsonObject.get("usedAmount"));
        model.addAttribute("remaingAmount", jsonObject.get("remaingAmount"));

        return "page/system/serviceSpecDetail";
    }

    @RequestMapping(value = "/searchTxn", method = RequestMethod.GET)
    public String showSystemTxn(Model model, HttpSession session) {
        TxnLogBo bo = new TxnLogBo();
        bo.setStartTime(DateUtil.getYesterday());
        bo.setEndTime(DateUtil.getCurrentDateString("yyyy-MM-dd"));
        model.addAttribute("txnLogBo",bo);
        SysUser loginUser = SessionUtil.getUser(session);
        if (PropertyFileKeys.ENTERPRISE_NO_PAYEGIS.equals(loginUser.getEnterpriseNo())) {
            model.addAttribute("system", PropertyFileKeys.ENTERPRISE_NO_PAYEGIS);
        }
        return "page/system/txn_search";
    }

    @RequestMapping(value = "/search/getTxnList")
    public String searchSystemTxnHistory(TxnLogBo queryBo, Model model, HttpSession session) {

        SysUser loginUser = SessionUtil.getUser(session);
        if (!PropertyFileKeys.ENTERPRISE_NO_PAYEGIS.equals(loginUser.getEnterpriseNo())) {
            queryBo.setEnterpriseId(loginUser.getEnterpriseId());
        }
        logger.info("[param] systemName="+queryBo.getSystemName());
        queryBo.setStartTime(queryBo.getStartTime()+" 00:00:00");
        queryBo.setEndTime(queryBo.getEndTime() + " 23:59:59");
        ResultBean resBean = systemTxnService.getPageList(queryBo);
        model.addAttribute("result", resBean);
        return "page/system/txn_list";
    }

    @RequestMapping(value = "/search/showTxnDetail/{logId}", method = RequestMethod.GET)
    public String searchSystemTxnDetail(@PathVariable String logId, Model model, HttpSession session) {
        TxnLog txnLog = systemTxnService.selectTxnLogByLogId(logId);
        SysUser loginUser = SessionUtil.getUser(session);
        List<TxnStatus> txnStatusDetails = null;
        if (!PropertyFileKeys.ENTERPRISE_NO_PAYEGIS.equals(loginUser.getEnterpriseNo())) {
            if(loginUser.getEnterpriseId() != txnLog.getEnterpriseId()){
                model.addAttribute("txnStatusDetails", txnStatusDetails);
                return "page/system/txn_detail";
            }
        }

        txnStatusDetails = systemTxnService.selectTxnStatusByLogId(logId);
        model.addAttribute("txnLog", txnLog);
        model.addAttribute("txnStatusDetails", txnStatusDetails);
        return "page/system/txn_detail";
    }
}
