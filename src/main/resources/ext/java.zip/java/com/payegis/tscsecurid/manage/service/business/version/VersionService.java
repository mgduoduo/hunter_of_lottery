package com.payegis.tscsecurid.manage.service.business.version;


import com.payegis.tscsecurid.common.data.entity.SysUser;
import com.payegis.tscsecurid.common.data.entity.VersionManage;
import com.payegis.tscsecurid.common.result.ResultBean;
/**
 * Created by zzg on 2014/12/9.
 */
public interface VersionService {

    /**
     * 根据查询条件过滤所有版本列表
     * @return
     */
    public ResultBean listAll(VersionManage param);

    /**
     * 保存一个版本
     * @return
     */
    public int save(VersionManage param, SysUser su);

    /**
     * 更新一个版本
     * @return
     */
    public int update(VersionManage param, SysUser su);

    /**
     * 查找一个版本
     * @return
     */
    public VersionManage findById(Integer versionId);

    /**
     * 查找一个版本是否存在
     * @return
     */
    public int findByVersionNoAndType(VersionManage param);
}
