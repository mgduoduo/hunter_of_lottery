package com.payegis.tscsecurid.manage.service.impl.mgr;

import com.payegis.tscsecurid.common.data.entity.MgrPrivilege;
import com.payegis.tscsecurid.common.mapper.BaseMapper;
import com.payegis.tscsecurid.common.mapper.MgrPrivilegeMapper;
import com.payegis.tscsecurid.common.service.BaseServiceImpl;
import com.payegis.tscsecurid.manage.bean.PrivilegeBean;
import com.payegis.tscsecurid.manage.common.ManageException;
import com.payegis.tscsecurid.manage.common.MessageConstant;
import com.payegis.tscsecurid.manage.common.PageBean;
import com.payegis.tscsecurid.manage.service.business.mgr.PrivilegeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;



@Service
public class PrivilegeServiceImpl extends BaseServiceImpl implements PrivilegeService {

	@Autowired
	private MgrPrivilegeMapper privilegeMapper;

	@Override
	public PageBean searchPrivileges(PrivilegeBean searchDto) {
		/*PageBean result = privilegeMapper.getPrivileges(searchDto);
		return result;*/
	   return new PageBean();
	}

	@Override
	public List<MgrPrivilege> findPrivilegeList() {
		return privilegeMapper.getAllPrivilege();
	}

	@Override
	public void createPrivilege(MgrPrivilege privilege) {
		privilegeMapper.insertSelective(privilege);
	}

	@Override
	public void updatePrivilege(MgrPrivilege privilege) {
		privilegeMapper.updateByPrimaryKeySelective(privilege);
	}

	@Override
	public boolean checkPrivilegeExists(String privilegeId) {
		MgrPrivilege p = privilegeMapper.selectByPrimaryKey(privilegeId);
		if (p == null)
			return false;
		return true;
	}

	@Override
	public void deletePrivilege(String[] privilegeIds) {
		for (String id : privilegeIds) {
			if (privilegeMapper.checkPrivilegeInUse(id)>0) {
				throw new ManageException(
						MessageConstant.ERROR_PRIVILEGE_IN_USE);
			}
			privilegeMapper.deleteByPrimaryKey(id);
		}

	}

	@Override
	public MgrPrivilege retrievePrivilegeById(String privilegeId) {
		return privilegeMapper.selectByPrimaryKey(privilegeId);
	}

	@Override
	public List<MgrPrivilege> retrievePrivileges() {
		return privilegeMapper.getAllPrivilege();
	}

	@Override
	public List<MgrPrivilege> getPrivilegeGroup() {
		return privilegeMapper.getPrivilegeGroup();
	}

   @Override
   protected BaseMapper getMapper() {
      return privilegeMapper;
   }
   
   @Override
	public List<MgrPrivilege> FindAllPrivilegeForEnterprise(MgrPrivilege privilege) {
		return privilegeMapper.getAllPrivilegeForEnterprise(privilege);
	}

}
