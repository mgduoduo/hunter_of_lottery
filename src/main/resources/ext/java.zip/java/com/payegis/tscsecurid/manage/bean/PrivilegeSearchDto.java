package com.payegis.tscsecurid.manage.bean;


import com.payegis.tscsecurid.common.data.BaseDto;

public class PrivilegeSearchDto extends BaseDto {
	private static final long serialVersionUID = 8263062959112620562L;
	private String privilegeId = "";
	private String privilegeName = "";

	public String getPrivilegeId() {
		return privilegeId;
	}

	public void setPrivilegeId(String privilegeId) {
		this.privilegeId = privilegeId;
	}

	public String getPrivilegeName() {
		return privilegeName;
	}

	public void setPrivilegeName(String privilegeName) {
		this.privilegeName = privilegeName;
	}

}
