package com.payegis.tscsecurid.manage.service.business.enterprise;



import java.util.List;

import com.payegis.tscsecurid.common.data.bo.EnterpriseInfoBo;
import com.payegis.tscsecurid.common.data.entity.SysUser;
import com.payegis.tscsecurid.common.result.ResultBean;

public interface EnterpriseService {

    /**
     * 根据查询条件过滤所有企业列表
     * @return
     */
    public ResultBean listAll(EnterpriseInfoBo param);

    /**
     * 保存一个企业
     * @return
     */
    public int save(EnterpriseInfoBo param,SysUser su);
    
    /**
     * 更新一个企业
     * @return
     */
    public int update(EnterpriseInfoBo param);
    
    /**
     * 查找一个企业
     * @return
     */
    public EnterpriseInfoBo findById(Integer enterpriseId);
    
    /**
     * 查找一个企业(包含企业成员用户和业务系统集合)
     * @return
     */
    public EnterpriseInfoBo findByIdWithMembers(Integer enterpriseId);
    
    /**
     * 查出所有企业(ID、name)
     * @return
     */
    public List<EnterpriseInfoBo> findAllEnterprise();
    
    public int updateDisable(Integer enterpriseId);
}
